package az.kinera.edit;
/** Centered luma, local shift and edge statistics, 48x48 input. */
final class Vision80Features {
 static final int[][] SHIFTS={{2,0},{-2,0},{0,2},{0,-2},{4,0},{-4,0},{0,4},{0,-4},{2,2},{-2,-2},{2,-2},{-2,2}};
 static double[] features(int[] a,int[] b){if(a==null||b==null||a.length!=2304||b.length!=2304)return null;double ma=0,mb=0,aa=0,bb=0,raw=0,edge=0;for(int y=4;y<44;y+=2)for(int x=4;x<44;x+=2){int i=y*48+x;double v=a[i],w=b[i];ma+=v;mb+=w;aa+=v*v;bb+=w*w;raw+=Math.abs(v-w);if(x<42)edge+=Math.abs((a[i+2]-v)-(b[i+2]-w));}ma/=400;mb/=400;double center=0;for(int y=4;y<44;y+=2)for(int x=4;x<44;x+=2){int i=y*48+x;center+=Math.abs(a[i]-ma-b[i]+mb);}center/=400*255;double best=center;for(int[] s:SHIFTS){double mq=0,e=0;int off=s[1]*48+s[0];for(int y=4;y<44;y+=2)for(int x=4;x<44;x+=2)mq+=b[y*48+x+off];mq/=400;for(int y=4;y<44;y+=2)for(int x=4;x<44;x+=2){int i=y*48+x;e+=Math.abs(a[i]-ma-b[i+off]+mq);}best=Math.min(best,e/(400*255));}return new double[]{raw/(400*255),center,best,Math.max(0,center-best),Math.abs(ma-mb)/255,edge/(380*510),Math.sqrt(Math.max(0,aa/400-ma*ma))/128,Math.sqrt(Math.max(0,bb/400-mb*mb))/128};}
 static boolean aligned(int[] a,int[] b){double[] f=features(a,b);return f!=null&&f[2]<.025&&f[1]-f[2]>.035&&Vision80Confidence.ENABLED&&Vision80Confidence.score(f)<=.08;}
}
