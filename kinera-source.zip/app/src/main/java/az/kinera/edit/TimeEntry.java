package az.kinera.edit;
/** Parse seconds, mm:ss, or hh:mm:ss; reject ambiguous and overflowing input. */
final class TimeEntry {
 static long parse(String value,long durationMs){if(value==null||durationMs<0)return -1;String s=value.trim();if(!s.matches("[0-9]{1,9}(:[0-9]{1,2}){0,2}"))return -1;String[] a=s.split(":");long seconds=0;for(int i=0;i<a.length;i++){long n=Long.parseLong(a[i]);if(i>0&&n>=60)return -1;seconds=seconds*60+n;}return seconds<=durationMs/1000?seconds*1000:-1;}
}
