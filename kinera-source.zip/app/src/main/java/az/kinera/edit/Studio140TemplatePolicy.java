package az.kinera.edit;
final class Studio140TemplatePolicy {
 static final int FIRST=3934,TOTAL=3984;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0013f;float[][] a={{.015f,.028f,.985f,.972f},{.023f,.095f,.977f,.905f},{.031f,.157f,.969f,.843f},{.042f,.217f,.958f,.783f},{.052f,.283f,.948f,.717f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,71)!=38)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Studio140TemplatePolicy(){}
}
