package az.kinera.edit;
/** Free source-space crop; fixed-ratio gestures remain optional. */
final class Crop139 {
 static final String[] LABELS={"Sərbəst","9:16","16:9","1:1","4:5","4:3","3:4"};
 static final float[] RATIOS={0,9f/16,16f/9,1,4f/5,4f/3,3f/4};
 static float ratio(float[] r,float source){return (r[2]-r[0])*source/(r[3]-r[1]);}
 static float[] fit(float[] r,float source,float lock){if(!RegionMath.active(r))r=RegionMath.full();return lock<=0?r.clone():EditMath.coverCrop(r,RegionMath.full(),source,lock);}
 static float[] drag(float[] r,int handle,float dx,float dy,float source,float lock){if(!RegionMath.active(r))return RegionMath.full();if(!Float.isFinite(dx)||!Float.isFinite(dy))return r.clone();if(handle==5)return RegionMath.move(r,dx,dy);if(lock<=0){float x=(handle==1||handle==3||handle==8?r[0]:r[2])+dx,y=(handle==1||handle==2||handle==6?r[1]:r[3])+dy;return RegionMath.resize(r,handle,x,y,.035f);}return Crop109.drag(r,handle,dx,dy,source*Crop109.RATIO/lock);}
 static float[] pinch(float[] r,float scale,float dx,float dy){if(!RegionMath.active(r))return RegionMath.full();if(!Float.isFinite(scale)||scale<=0||!Float.isFinite(dx)||!Float.isFinite(dy))return r.clone();float w=r[2]-r[0],h=r[3]-r[1];float max=Math.min(1/w,1/h),min=Math.min(max,Math.max(Math.min(.035f,w)/w,Math.min(.035f,h)/h));float f=EditMath.clamp(scale,min,max);w*=f;h*=f;float l=EditMath.clamp((r[0]+r[2]-w)/2+dx,0,1-w),t=EditMath.clamp((r[1]+r[3]-h)/2+dy,0,1-h);return new float[]{l,t,Math.min(1,l+w),Math.min(1,t+h)};}
 static int progress(float[] r){return RegionMath.active(r)?Math.round(100*EditMath.clamp((1-Math.max(r[2]-r[0],r[3]-r[1]))/.965f,0,1)):0;}
 static float[] zoom(float[] r,int p){if(!RegionMath.active(r))r=RegionMath.full();return pinch(r,(1-.965f*EditMath.clamp(p/100f,0,1))/Math.max(r[2]-r[0],r[3]-r[1]),0,0);}
 static boolean manual(float[] r){return Crop109.keepTemplate(r);}
 static float[] sample(float[] r,float[] window,float source,float canvas){return manual(r)?r.clone():EditMath.coverCrop(r,window,source,canvas);}
 static float[] frame(float[] r,float[] window,float source,float canvas){if(!manual(r))return window.clone();float a=ratio(r,source),w=window[2]-window[0],h=window[3]-window[1];float fw=Math.min(w,h*a/canvas),fh=Math.min(h,w*canvas/a),cx=(window[0]+window[2])/2,cy=(window[1]+window[3])/2;return new float[]{cx-fw/2,cy-fh/2,cx+fw/2,cy+fh/2};}
 private Crop139(){}
}
