package az.kinera.edit;
/** New layouts; old IDs and palettes remain unchanged. */
final class Director124TemplatePolicy {
 static final int FIRST=3384,TOTAL=3434;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=k%10*.0013f;float[][] w={{.012f,.026f,.988f,.974f},{.018f,.096f,.982f,.904f},{.030f,.174f,.970f,.826f},{.018f,.244f,.982f,.756f},{.034f,.305f,.966f,.695f}};float[] a=w[k/10];return new float[]{a[0]+v,a[1]+v,a[2]-v,a[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,23)!=11)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Director124TemplatePolicy(){}
}
