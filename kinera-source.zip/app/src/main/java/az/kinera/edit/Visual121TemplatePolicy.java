package az.kinera.edit;
final class Visual121TemplatePolicy {
 static final int FIRST=3234,TOTAL=3284;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0016f;float[][] w={{.012f,.018f,.988f,.982f},{.028f,.112f,.972f,.888f},{.04f,.196f,.96f,.804f},{.025f,.274f,.975f,.726f},{.045f,.322f,.955f,.678f}};float[] a=w[k/10];return new float[]{a[0]+v,a[1]+v,a[2]-v,a[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,19)!=9)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Visual121TemplatePolicy(){}
}
