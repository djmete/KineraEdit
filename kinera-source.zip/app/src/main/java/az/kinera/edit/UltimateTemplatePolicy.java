package az.kinera.edit;
final class UltimateTemplatePolicy {
 static final int FIRST=192,COUNT=198;
 static int choose(int previous,float aspect,int semantic,int seed){if(previous<0||previous>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==0||semantic==3||Math.floorMod(seed,5)!=2)return previous;return FIRST+2*(aspect<=.82f?0:aspect>=1.30f?1:2)+Math.floorMod(seed/5,2);}
 static float[] window(int style){int family=(style-FIRST)/2;return family==0?new float[]{.018f,.145f,.982f,.89f}:family==1?new float[]{.015f,.26f,.985f,.70f}:new float[]{.025f,.20f,.975f,.78f};}
}
