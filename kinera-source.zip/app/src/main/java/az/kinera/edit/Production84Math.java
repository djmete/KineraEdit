package az.kinera.edit;
final class Production84Math {
 static boolean validCut(long[] cuts,int i,long duration){return cuts!=null&&i>=0&&i<cuts.length&&duration>0&&cuts[i]>0&&cuts[i]<duration&&(i==0||cuts[i-1]>=0&&cuts[i-1]<cuts[i])&&(i+1==cuts.length||cuts[i+1]>cuts[i]&&cuts[i+1]<=duration);}
 static float scale(long[] cuts,int i,long duration){if(!validCut(cuts,i,duration))return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];float gap=Math.min(left,right)/1800000f;return Math.max(0,Math.min(1,gap));}
 static boolean balanced(long older,long previous,long now,int fps){if(older<0||previous<=older||now<=previous)return false;long a=previous-older,b=now-previous;long max=Math.max(a,b),min=Math.min(a,b);return max-min<=Math.max(12000L,Math.min(40000L,1000000L/Math.max(12,fps)))&&max<=3*min;}
}
