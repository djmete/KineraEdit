package az.kinera.edit;
/** Weak cut candidate guard for coherent chroma shifts; no additional decoding. */
final class Contextual91 {
 static float sceneScore(int[] a,int[] b,float score){
  if(a==null||b==null||a.length!=2304||b.length!=2304||!Float.isFinite(score)||score<.22f||score>=.40f)return score;
  int nr=0,ng=0,nb=0,n=0,edges=0,stable=0;
  for(int y=0;y<48;y+=3)for(int x=0;x<48;x+=3){int i=y*48+x;nr+=((b[i]>>>16)&255)-((a[i]>>>16)&255);ng+=((b[i]>>>8)&255)-((a[i]>>>8)&255);nb+=(b[i]&255)-(a[i]&255);n++;if(x<45){int da=SceneMath.luma(a[i+3])-SceneMath.luma(a[i]),db=SceneMath.luma(b[i+3])-SceneMath.luma(b[i]);if(Math.abs(da)>=16){edges++;if(Math.abs(da-db)<=6)stable++;}}}
  if(edges<32||stable<edges*.94||Math.max(Math.max(Math.abs(nr-ng),Math.abs(ng-nb)),Math.abs(nr-nb))<n*12)return score;
  float dr=nr/(float)n,dg=ng/(float)n,db=nb/(float)n;int similar=0;
  for(int y=0;y<48;y+=3)for(int x=0;x<48;x+=3){int i=y*48+x;if(Math.abs(((b[i]>>>16)&255)-((a[i]>>>16)&255)-dr)<=6&&Math.abs(((b[i]>>>8)&255)-((a[i]>>>8)&255)-dg)<=6&&Math.abs((b[i]&255)-(a[i]&255)-db)<=6)similar++;}
  return similar>=n*.94?score*.86f:score;
 }
}
