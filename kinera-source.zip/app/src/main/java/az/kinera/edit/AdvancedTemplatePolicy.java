package az.kinera.edit;
final class AdvancedTemplatePolicy {
 static final int FIRST=180,COUNT=192;
 static int choose(int previous,float aspect,int semantic,int seed){if(previous<0||previous>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==0||semantic==3||Math.floorMod(seed,4)!=1)return previous;return FIRST+4*(aspect<=.82f?0:aspect>=1.30f?1:2)+Math.floorMod(seed/4,4);}
 static float[] window(int style){int family=Math.max(0,Math.min(2,(style-FIRST)/4));return family==0?new float[]{.018f,.142f,.982f,.90f}:family==1?new float[]{.015f,.255f,.985f,.69f}:new float[]{.028f,.19f,.972f,.79f};}
}
