package az.kinera.edit;
import java.util.List;
/** Conservative extension of a detected subtitle to adjacent centered short lines. */
final class Unified106 {
 static float[] caption(float[] base,List<float[]> shorts){if(!RegionMath.active(base)||shorts==null)return base;float[] best=base;float center=(base[0]+base[2])*.5f;if(Math.abs(center-.5f)>.13f)return base;for(int i=0;i<Math.min(16,shorts.size());i++){float[] q=shorts.get(i);if(!RegionMath.active(q))continue;float c=(q[0]+q[2])*.5f,h=q[3]-q[1],bh=base[3]-base[1];float gap=Math.max(q[1]-base[3],base[1]-q[3]);if(Math.abs(c-center)>.065f||gap<0||gap>Math.min(.024f,h*.65f)||h<bh*.4f||h>bh*1.5f)continue;float[] joined={Math.min(best[0],q[0]),Math.min(best[1],q[1]),Math.max(best[2],q[2]),Math.max(best[3],q[3])};if(joined[3]-joined[1]<=.15f&&joined[2]-joined[0]<=Math.max(base[2]-base[0],q[2]-q[0])+.04f)best=joined;}return best;}
 static boolean validDeferred(long start,long now,long generation,long current,boolean editor,boolean active){return now>=start&&now-start<=5000&&generation==current&&editor&&active;}
 private Unified106(){}
}
