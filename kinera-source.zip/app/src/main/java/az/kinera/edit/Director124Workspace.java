package az.kinera.edit;
/** Keep slider value readable, avoid surplus rows on compact displays. */
final class Director124Workspace {
 static boolean compact(int h,int w,float f){return Reconstruction123Workspace.compact(h,w,f)||h<880&&(w<420||f>1.15f);}
 static int valueWidth(int w,float f){return w<300?40:w<360?44:w<420?50:f>1.35f?64:52;}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return last<0||now<last||now-last>=(pressure?500:playing?125:70);}
 static boolean metadata(int h,int mode,boolean focus,float font){return Reconstruction123Workspace.metadata(h,mode,focus,font)&&font<=1.35f;}
 private Director124Workspace(){}
}
