package az.kinera.edit;
/** Bounded time-domain accent with less leading effect at abrupt pacing changes. */
final class Advanced132Rhythm {
 static long width(long[] cuts,int i,long duration,long desired){return Supreme131Rhythm.width(cuts,i,duration,desired);}
 static float scale(long[] cuts,int i,long duration){return Supreme131Rhythm.scale(cuts,i,duration);}
 static float envelope(long[] cuts,int i,long duration,long time,long desired){long w=width(cuts,i,duration,desired);if(w<=0)return 0;long l=cuts[i]-(i==0?0:cuts[i-1]),rr=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(time<cuts[i]&&l<rr/2)w=Math.max(1,w*3/4);else if(time>=cuts[i]&&rr<l/2)w=Math.max(1,w*3/4);return DirectorMath.envelope(Math.abs(time-cuts[i]),w);}
 private Advanced132Rhythm(){}
}
