package az.kinera.edit;
/** Deterministic, shot-pace-driven decorative animation. Never modifies source chronology. */
final class ReactiveMotionMath {
 static float[] window(int style){int family=Math.max(0,Math.min(2,(style-162)/4));return family==0?new float[]{.025f,.125f,.975f,.91f}:family==1?new float[]{.018f,.285f,.982f,.65f}:new float[]{.035f,.205f,.965f,.755f};}
 static int choose(int previous,float aspect,int semantic){if(previous<0||previous>=162||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT)return previous;int family=aspect<=.82f?0:aspect>=1.30f?1:2;return 162+4*family+Math.floorMod(previous,4);}
 static float phase(long time,int style,long[] cuts,long duration){float base=BrandMotionMath.motionPhase(time,style);if(style<162||(style>=198&&style<216)||style>=684||time<0||time>=duration||cuts==null||cuts.length==0)return base;int i=DirectorMath.nearest(cuts,time);if(i<0)return base;long width=DirectorMath.effectWidth(cuts,i,duration,550000L);float pulse=DirectorMath.envelope(Math.abs(time-cuts[i]),width);float adjusted=base+.075f*pulse;return adjusted>=1?adjusted-1:adjusted;}
}
