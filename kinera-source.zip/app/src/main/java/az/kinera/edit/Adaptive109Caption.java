package az.kinera.edit;
import java.util.*;
final class Adaptive109Caption {
 static long at(long duration,int n,int i){long a=FullCaptionPlan.boundary(duration,i/2,n),b=FullCaptionPlan.boundary(duration,i/2+1,n);return i%2==0?DenseCaptionPlan.first(a,b):DenseCaptionPlan.second(a,b);}
 static float[] get(List<float[]> a,List<float[]> b,int i){return i%2==0?a.get(i/2):b.get(i/2);}
 @SuppressWarnings("unchecked") static List<float[]>[] bridge(long duration,int n,List<float[]> left,List<float[]> right,long[] cuts){List<float[]> a=new ArrayList<>(left),b=new ArrayList<>(right);for(int i=1;i<2*n-1;i++){if(RegionMath.active(get(left,right,i)))continue;long p=at(duration,n,i-1),q=at(duration,n,i+1);if(q-p>300000L)continue;boolean cross=false;for(long cut:cuts){if(cut>p&&cut<=q){cross=true;break;}}if(cross)continue;float[] prev=get(left,right,i-1),next=get(left,right,i+1);if(!Studio94CaptionPlan.bridge(prev,next))continue;float[] u=DenseCaptionPlan.union(prev,next);(i%2==0?a:b).set(i/2,u);}return new List[]{a,b};}
 private Adaptive109Caption(){}
}
