package az.kinera.edit;
/** Keep the timeline accessible and reclaim disabled header controls during edits. */
final class Precision133Workspace {
 static boolean showHistory(boolean editor,boolean focus,boolean draft){return editor&&!focus&&!draft;}
 static int valueWidth(int w,float f){int old=Advanced132Workspace.valueWidth(w,f);return w<360?Math.min(old,48):old;}
 static boolean compact(int h,int w,float f){return Advanced132Workspace.compact(h,w,f)||w<400&&h<900;}
 static boolean scrollTools(int w,float f){return Advanced132Workspace.scrollTools(w,f)||w<400&&f>1.25f;}
 static boolean shouldRefresh(PreviewKey old,PreviewKey next){return old!=null&&next!=null&&!old.equals(next);}
 private Precision133Workspace(){}
}
