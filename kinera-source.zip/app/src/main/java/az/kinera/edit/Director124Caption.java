package az.kinera.edit;
/** Reject stale neighbor masks with little overlap; keep current OCR geometry. */
final class Director124Caption {
 static float[] stabilize(float[] anchor,float[] candidate){
  if(!RegionMath.active(anchor))return RegionMath.empty();if(!RegionMath.active(candidate))return anchor.clone();
  float w=Math.max(0,Math.min(anchor[2],candidate[2])-Math.max(anchor[0],candidate[0]));float h=Math.max(0,Math.min(anchor[3],candidate[3])-Math.max(anchor[1],candidate[1]));
  double area=(double)(anchor[2]-anchor[0])*(anchor[3]-anchor[1]);
  if(w*h<area*.55)return anchor.clone();return Reconstruction123Caption.stabilize(anchor,candidate);
 }
 private Director124Caption(){}
}
