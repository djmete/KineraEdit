package az.kinera.edit;
final class Adaptive122Workspace {
 static boolean compact(int h,int w,float font){return Visual121Workspace.compact(h,w,font)||h<780&&font>1.1f;}
 static boolean metadata(int h,int mode,boolean focus,float font){return Visual121Workspace.metadata(h,mode,focus,font);}
 static int sliderPadding(int w){return w<360?3:6;}
 static int valueWidth(int w,float font){return Visual121Workspace.valueWidth(w,font);}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return Visual121Workspace.liveTick(last,now,playing,pressure);}
 static boolean cancelBeforeFocus(boolean editing,boolean draft){return Visual121Workspace.cancelBeforeFocus(editing,draft);}
 private Adaptive122Workspace(){}
}
