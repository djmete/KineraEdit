package az.kinera.edit;
/** Side-dependent accent with a continuous blend through the cut. */
final class Cognitive135Rhythm {
 static float scale(long span){float x=Math.max(0f,Math.min(1f,span/900000f));return .65f+.35f*x*x*(3-2*x);}
 static float side(long[] cuts,int i,long duration,long time){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long l=cuts[i]-(i==0?0:cuts[i-1]),r=(i==cuts.length-1?duration:cuts[i+1])-cuts[i];if(l<=0||r<=0)return 0;long width=Math.min(40000L,Math.min(l,r)/4);if(width<=0)return Math.min(scale(l),scale(r));double x=Math.max(0.,Math.min(1.,((double)time-cuts[i]+width)/(2.*width)));float t=(float)(x*x*(3.-2.*x));return scale(l)*(1-t)+scale(r)*t;}
 private Cognitive135Rhythm(){}
}
