package az.kinera.edit;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
/** Density-aware vector icons for the editing toolbar. */
final class StudioIcon extends Drawable {
 private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final int type,size;
 StudioIcon(Context c,int type){this.type=type;size=Math.round(20*c.getResources().getDisplayMetrics().density);p.setColor(StudioPalette.FG);p.setStrokeWidth(1.8f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStyle(Paint.Style.STROKE);}
 @Override public void draw(Canvas canvas){Rect b=getBounds();canvas.save();canvas.translate(b.left,b.top);canvas.scale(b.width()/24f,b.height()/24f);if(type==6){canvas.drawRoundRect(2,4,22,20,2,2,p);canvas.drawLine(8,4,8,20,p);canvas.drawLine(16,4,16,20,p);canvas.drawLine(3,9,7,9,p);canvas.drawLine(17,15,21,15,p);}else if(type==7){canvas.drawRoundRect(3,3,21,21,3,3,p);canvas.drawLine(3,9,21,9,p);canvas.drawLine(3,17,21,17,p);}else if(type==5){canvas.drawCircle(10,10,6,p);canvas.drawLine(14.5f,14.5f,21,21,p);}else if(type==0){canvas.drawLine(6,2,6,18,p);canvas.drawLine(6,18,22,18,p);canvas.drawLine(2,6,18,6,p);canvas.drawLine(18,6,18,22,p);}else if(type==1){canvas.drawRoundRect(3,3,21,21,4,4,p);for(int y=7;y<=17;y+=5)for(int x=7;x<=17;x+=5)canvas.drawPoint(x,y,p);}else if(type==4){canvas.drawRoundRect(3,5,21,19,3,3,p);canvas.drawLine(7,10,17,10,p);canvas.drawLine(9,14,15,14,p);canvas.drawLine(20,1,20,5,p);canvas.drawLine(18,3,22,3,p);}else if(type==3){Path speaker=new Path();speaker.moveTo(3,9);speaker.lineTo(8,9);speaker.lineTo(13,5);speaker.lineTo(13,19);speaker.lineTo(8,15);speaker.lineTo(3,15);speaker.close();canvas.drawPath(speaker,p);canvas.drawArc(10,7,20,17,-55,110,false,p);canvas.drawArc(10,3,25,21,-55,110,false,p);}else{canvas.drawRoundRect(2,4,22,20,3,3,p);Path triangle=new Path();triangle.moveTo(10,8);triangle.lineTo(16,12);triangle.lineTo(10,16);triangle.close();canvas.drawPath(triangle,p);}canvas.restore();}
 @Override public int getIntrinsicWidth(){return size;}@Override public int getIntrinsicHeight(){return size;}
 @Override public void setAlpha(int alpha){p.setAlpha(alpha);invalidateSelf();}@Override public void setColorFilter(ColorFilter f){p.setColorFilter(f);invalidateSelf();}@Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
