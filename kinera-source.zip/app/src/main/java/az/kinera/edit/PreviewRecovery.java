package az.kinera.edit;
/** Bounded retries; no infinite codec restart loop. */
final class PreviewRecovery {
 static final int RETRY=1,RAW=2,STOP=3;
 static int next(int previous,boolean raw){if(previous<=0)return RETRY;if(previous==1&&!raw)return RAW;if(previous==1)return RETRY;return STOP;}
 static int previewHeight(int normal,int attempts){return attempts>0?Math.min(480,normal):normal;}
 static long startPosition(long position,long duration,int attempts){long end=Math.max(0,duration);long max=attempts>0?Math.max(0,end-100):end;if(attempts>0&&end<=250&&position>=max)return 0;return Math.max(0,Math.min(max,position));}
 static long relativePosition(long actual,long saved,long delta,long duration){long end=Math.max(0,duration);long base=Math.max(0,Math.min(end,actual>=0?actual:saved));if(delta>0)return base+Math.min(delta,end-base);if(delta<0)return base+Math.max(delta,-base);return base;}
 static long delayMs(int action){return action==RAW?1250:850;}
}
