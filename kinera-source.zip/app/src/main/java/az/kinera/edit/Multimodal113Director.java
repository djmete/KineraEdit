package az.kinera.edit;
/** Protect fast-paced cuts from accumulated accents; unchanged source chronology. */
final class Multimodal113Director {
 static float accent(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];long gap=Math.min(left,right);if(gap<=0)return 0;return Math.min(1f,.55f+.45f*gap/1500000f);}
 private Multimodal113Director(){}
}
