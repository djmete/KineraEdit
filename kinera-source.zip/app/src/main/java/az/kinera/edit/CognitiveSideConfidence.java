package az.kinera.edit;
/** Shared side-boundary weighting network for last-resort restoration. */
final class CognitiveSideConfidence {
 static final boolean ENABLED=true;
 private static final double SCALE=0.00016926748266174254;
 private static final short[] Q={346,-6736,-32760,-8180,3353,2378,-26224,-10676,-2346,4490,-1459,1037,3759,-4545,25930,-10677,208};
 static double score(double d,double g){double z=Q[16]*SCALE;for(int j=0;j<4;j++)z+=Q[12+j]*SCALE*Math.tanh((d*Q[j]+g*Q[4+j]+Q[8+j])*SCALE);return z;}
 static final String GLSL="float cognitiveSideScore(vec2 x){float z=0.0352076364;z+=(0.6362764673)*rtanh(dot(x,vec2(0.0585665490,0.5675538694))+(-0.3971015143));z+=(-0.7693207087)*rtanh(dot(x,vec2(-1.1401857632,0.4025180738))+(0.7600109972));z+=(4.3891058254)*rtanh(dot(x,vec2(-5.5452027320,-4.4388704653))+(-0.2469612572));z+=(-1.8072689124)*rtanh(dot(x,vec2(-1.3846080082,-1.8070996449))+(0.1755303795));return clamp(z,-8.,8.);}";
}
