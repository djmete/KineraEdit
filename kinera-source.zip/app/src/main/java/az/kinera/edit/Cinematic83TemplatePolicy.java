package az.kinera.edit;
/** Permanent cinematic template IDs; source framing remains user-editable. */
final class Cinematic83TemplatePolicy {
 static final int FIRST=934,TOTAL=984;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.025f,.988f,.975f};case 1:return new float[]{.026f,.09f,.974f,.91f};case 2:return new float[]{.04f,.22f,.96f,.80f};case 3:return new float[]{.024f,.26f,.976f,.74f};default:return new float[]{.016f,.29f,.984f,.71f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,23)!=9)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
}
