package az.kinera.edit;
final class Creative145Template {
 static final int FIRST=4184,TOTAL=4234;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0015f;float[][] a={{.021f,.061f,.979f,.939f},{.031f,.145f,.969f,.855f},{.043f,.202f,.957f,.798f},{.051f,.260f,.949f,.740f},{.065f,.320f,.935f,.680f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,97)!=53)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Creative145Template(){}
}
