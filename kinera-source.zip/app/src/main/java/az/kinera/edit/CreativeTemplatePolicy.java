package az.kinera.edit;
final class CreativeTemplatePolicy {
 static final int FIRST=222,COUNT=228;
 static int choose(int prior,float aspect,int semantic,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==0||semantic==3||Math.floorMod(seed,7)!=5)return prior;return FIRST+2*(aspect<=.82f?0:aspect>=1.30f?1:2)+Math.floorMod(seed/7,2);}
 static float[] window(int id){int family=(id-FIRST)/2;return family==0?new float[]{.016f,.11f,.984f,.922f}:family==1?new float[]{.012f,.285f,.988f,.728f}:new float[]{.024f,.178f,.976f,.826f};}
 static int cognitiveChoose(int prior,float aspect,int semantic,int seed){if(prior<0||prior>=228||!Float.isFinite(aspect)||aspect<=0||semantic==0||semantic==3||Math.floorMod(seed,11)!=8)return prior;return 228+2*(aspect<=.82f?0:aspect>=1.30f?1:2)+Math.floorMod(seed/11,2);}
 static float[] cognitiveWindow(int id){int family=(id-228)/2;return family==0?new float[]{.018f,.105f,.982f,.925f}:family==1?new float[]{.012f,.26f,.988f,.745f}:new float[]{.022f,.17f,.978f,.835f};}
}
