package az.kinera.edit;
/** Compact modes retain one persistent touch target; avoid competing navigation strips. */
final class Adaptive117Workspace {
 static boolean filmstrip(int h,int mode,boolean focus,float font){return Precision116Workspace.filmstrip(h,mode,focus,font)&&h>=820&&font<=1.3f;}
 static boolean seek(int h,int mode,boolean focus,float font){return !focus&&h>=480&&mode<=0&&!filmstrip(h,mode,focus,font);}
 static int valueWidth(int w,float font){return w<320?44:w<380?48:font>1.4f?64:56;}
 static int blurPadding(int w){return w<340?6:12;}
 static int liveInterval(boolean playing,boolean pressure){return pressure?250:playing?90:65;}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return last<0||now<last||now-last>=liveInterval(playing,pressure);}
 static int previewHeight(int h,boolean pressure){return Precision116Workspace.previewHeight(h,pressure);}
 private Adaptive117Workspace(){}
}
