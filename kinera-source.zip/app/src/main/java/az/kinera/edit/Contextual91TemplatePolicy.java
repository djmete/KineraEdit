package az.kinera.edit;
final class Contextual91TemplatePolicy {
 static final int FIRST=1334,TOTAL=1384;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.015f,.032f,.985f,.968f};case 1:return new float[]{.038f,.09f,.962f,.91f};case 2:return new float[]{.035f,.23f,.965f,.77f};case 3:return new float[]{.025f,.27f,.975f,.73f};default:return new float[]{.018f,.305f,.982f,.695f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,13)!=9)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/13,10),10);}
}
