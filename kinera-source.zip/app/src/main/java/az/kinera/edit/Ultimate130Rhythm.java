package az.kinera.edit;
final class Ultimate130Rhythm {
 static float scale(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long before=cuts[i]-(i==0?0:cuts[i-1]),after=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(before<=0||after<=0)return 0;float ratio=Math.min(before,after)/(float)Math.max(before,after);return .75f+.25f*(float)Math.sqrt(ratio);}
 private Ultimate130Rhythm(){}
}