package az.kinera.edit;
/** Allocate compact controls by actual space and keep live preview cadence bounded. */
final class Supreme131Workspace {
 static boolean compact(int h,int w,float f){return Ultimate130Workspace.compact(h,w,f)||h<820&&f>1.2f;}
 static int valueWidth(int w,float f){return Ultimate130Workspace.valueWidth(w,f);}
 static boolean metadata(int h,int mode,boolean focus,float f){return Ultimate130Workspace.metadata(h,mode,focus,f)&&h>=1000;}
 static boolean filmstrip(int h,int mode,boolean focus,float f){return Ultimate130Workspace.filmstrip(h,mode,focus,f)&&h>=940;}
 static boolean seek(int h,int mode,boolean focus,float f){return !focus&&mode<=0&&h>=440&&!filmstrip(h,mode,focus,f);}
 static int toolLines(boolean compact,float font){return compact&&font<=1.3f?1:2;}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return last<0||now<last||now-last>=(pressure?550:playing?140:75);}
 private Supreme131Workspace(){}
}
