package az.kinera.edit;
/** HD-only user resolution and conservative temporal history eligibility. */
final class Temporal97 {
 private Temporal97(){}
 static int index(int old){return old>=0&&old<4?old:old>=4&&old<=6?0:1;}
 static int height(int old){switch(index(old)){case 0:return 1280;case 2:return 2560;case 3:return 3840;default:return 1920;}}
 static boolean historySafe(int activeMasks,boolean pressure,long pixels){return activeMasks>=0&&activeMasks<=TimedRegions.ACTIVE_MAX&&Adaptive88.captureHistory(pixels,pressure);}
 // Keep editorial accents restrained for rapidly alternating shots, without moving any mask or time marker.
 static float accentScale(long[] cuts,int i,long duration){if(!Production84Math.validCut(cuts,i,duration))return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];return Math.max(.45f,Math.min(1f,Math.min(left,right)/3000000f));}
 static boolean safeUnion(float[] a,float[] b){if(!Reconstruction96.safeUnion(a,b))return false;float aw=a[2]-a[0],bw=b[2]-b[0];float intersection=Math.max(0f,Math.min(a[2],b[2])-Math.max(a[0],b[0]));return intersection>=.72f*Math.min(aw,bw);}
}
