package az.kinera.edit;
import android.content.Context;import android.os.PowerManager;import android.app.ActivityManager;
/** Android 12+ platform pressure signals; no invented temperature values. */
final class DeviceLoad87 {
 static int thermal(Context context){try{PowerManager manager=context.getSystemService(PowerManager.class);return manager==null?0:manager.getCurrentThermalStatus();}catch(RuntimeException e){return 0;}}
 static boolean lowMemory(Context context){try{ActivityManager manager=context.getSystemService(ActivityManager.class);if(manager==null)return false;ActivityManager.MemoryInfo info=new ActivityManager.MemoryInfo();manager.getMemoryInfo(info);return info.lowMemory;}catch(RuntimeException e){return false;}}
 static boolean pressure(Context context){try{ActivityManager manager=context.getSystemService(ActivityManager.class);if(manager==null)return Adaptive88.pressure(thermal(context),0,0);ActivityManager.MemoryInfo info=new ActivityManager.MemoryInfo();manager.getMemoryInfo(info);return Adaptive88.pressure(thermal(context),info.availMem,info.threshold);}catch(RuntimeException e){return Adaptive88.pressure(thermal(context),0,0);}}
 static boolean hot(Context context){return Performance87.refuseStart(thermal(context),lowMemory(context));}
}