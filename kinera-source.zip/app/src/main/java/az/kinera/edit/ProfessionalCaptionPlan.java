package az.kinera.edit;
import java.util.*;
/** 0.5 second windows up to 62; two observations per window. No fake every-frame OCR claim. */
final class ProfessionalCaptionPlan {
 static int windows(long duration){return duration<=0?0:(int)Math.min(62,1+(duration-1)/500000L);}
 static List<TimedRegions.Mask> build(long duration,List<float[]> left,List<float[]> right){return PrecisionCaptionPlan.build(duration,windows(duration),left,right);}
}
