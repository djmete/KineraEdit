package az.kinera.edit;
/** Small, deterministic runtime policies. No new decoder or inference on the UI thread. */
final class Architecture105 {
 static long liveInterval(boolean playing){return playing?50:180;}
 static boolean liveTick(long last,long now,boolean playing){return last<0||now<last||now-last>=liveInterval(playing);}
 static int filmHeight(int dp){return dp<550?48:dp<720?52:60;}
 static int actionHeight(int dp){return dp<600?48:52;}
 static float rhythm(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i==cuts.length-1?duration:cuts[i+1])-cuts[i];if(left<=0||right<=0)return 0;double small=Math.min(left,right)/1000000d;return (float)(.55+.45*Math.min(1,small/2.5));}
 private Architecture105(){}
}
