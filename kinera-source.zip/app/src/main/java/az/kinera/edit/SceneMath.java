package az.kinera.edit;
import java.util.ArrayList;
import java.util.Arrays;
/** Conservative, deterministic shot-change heuristics. Not a neural model. */
final class SceneMath {
 static final int BINS=16;
 private static final ThreadLocal<int[]> HIST=ThreadLocal.withInitial(()->new int[BINS*2]);
 static float distance(int[] a,int[] b){
  if(a.length!=b.length||a.length==0)throw new IllegalArgumentException("frame sizes");
  int[] histograms=HIST.get();Arrays.fill(histograms,0); double local=0,chroma=0;
  for(int i=0;i<a.length;i++){int x=luma(a[i]),y=luma(b[i]);histograms[x/16]++;histograms[BINS+y/16]++;local+=Math.abs(x-y);int ar=(a[i]>>>16)&255,ag=(a[i]>>>8)&255,ab=a[i]&255,br=(b[i]>>>16)&255,bg=(b[i]>>>8)&255,bb=b[i]&255;chroma+=Math.abs((ar-ag)-(br-bg))+Math.abs((ab-ag)-(bb-bg));}
  double hist=0;for(int i=0;i<BINS;i++)hist+=Math.abs(histograms[i]-histograms[BINS+i]);
  double luminance=.65*local/(a.length*255.)+.35*hist/(2.*a.length);double color=chroma/(a.length*1020.);return (float)Math.min(1,Math.max(luminance,.78*luminance+.60*color));
 }
 // A brief lighting flash or A-B-A sample should not trigger two ornamental cuts.
 static boolean transientSpike(float incoming,float outgoing,float returnDistance){return Float.isFinite(incoming)&&Float.isFinite(outgoing)&&Float.isFinite(returnDistance)&&incoming>=.34f&&outgoing>=.34f&&returnDistance<=.13f;}
 static int luma(int rgb){return (77*((rgb>>>16)&255)+150*((rgb>>>8)&255)+29*(rgb&255))>>>8;}
 static long[] candidates(long[] times,float[] scores,long duration){
  if(times.length!=scores.length)throw new IllegalArgumentException("scores");
  ArrayList<Long> out=new ArrayList<>();long last=-3000000;
  for(int i=0;i<times.length;i++){long t=times[i];float s=scores[i];if(!Float.isFinite(s)||s>1||t<900000||t>duration-900000||t-last<2200000||s<.34f)continue;
   if(i>0&&scores[i-1]>s||i+1<scores.length&&scores[i+1]>s)continue;
   out.add(t);last=t; if(out.size()>=120)break;
  }
  long[] result=new long[out.size()];for(int i=0;i<result.length;i++)result[i]=out.get(i);return result;
 }
 // Robust adaptive threshold for editorial cuts, with a conservative absolute floor.
 static long[] adaptiveCandidates(long[] times,float[] scores,long duration){
  if(times.length!=scores.length)throw new IllegalArgumentException("scores");
  if(scores.length==0)return new long[0];
  float[] sorted=new float[scores.length];int count=0;for(float value:scores)if(Float.isFinite(value))sorted[count++]=value;if(count==0)return new long[0];sorted=Arrays.copyOf(sorted,count);Arrays.sort(sorted);float median=sorted[count/2];
  for(int i=0;i<count;i++)sorted[i]=Math.abs(sorted[i]-median);
  Arrays.sort(sorted);float mad=sorted[count/2];float threshold=Math.max(.30f,median+Math.max(.10f,3.5f*mad));
  ArrayList<Integer> peaks=new ArrayList<>();
  for(int i=0;i<scores.length;i++){long t=times[i];float v=scores[i];if(!Float.isFinite(v)||t<900000||t>duration-900000||v<threshold)continue;
   if((i>0&&scores[i-1]>v)||(i+1<scores.length&&scores[i+1]>v))continue;peaks.add(i);}
  // Prioritize the clearest cut rather than whichever candidate occurred first.
  peaks.sort((i,k)->{int c=Float.compare(scores[k],scores[i]);return c!=0?c:Long.compare(times[i],times[k]);});
  java.util.TreeSet<Long> accepted=new java.util.TreeSet<>();
  for(int i:peaks){long t=times[i];Long low=accepted.floor(t),high=accepted.ceiling(t);if(low!=null&&t-low<2200000||high!=null&&high-t<2200000)continue;accepted.add(t);if(accepted.size()>=120)break;}
  long[] result=new long[accepted.size()];int i=0;for(long t:accepted)result[i++]=t;return result;
 }
 // Reject broad motion peaks: compare an already eligible cut to the local background.
 static long[] studioCandidates(long[] times,float[] scores,long duration){long[] base=adaptiveCandidates(times,scores,duration);ArrayList<Long> out=new ArrayList<>();for(long time:base){int i=Arrays.binarySearch(times,time);if(i<0)continue;float sum=0;int n=0;for(int k=Math.max(0,i-2);k<=Math.min(scores.length-1,i+2);k++)if(k!=i&&Float.isFinite(scores[k])&&TemporalPolicy.contiguous(times,i,k)){sum+=scores[k];n++;}if(n==0||scores[i]>=sum/n+.07f)out.add(time);}long[] result=new long[out.size()];for(int i=0;i<out.size();i++)result[i]=out.get(i);return result;}
 // A gentle grade pulse near a candidate, without removing frames or changing audio timing.
 static float dip(long t,long[] cuts,float amount){if(cuts.length==0||amount<=0)return 1f;int i=Arrays.binarySearch(cuts,t);if(i>=0)return 1-amount;i=-i-1;long d=Long.MAX_VALUE;if(i<cuts.length)d=Math.min(d,Math.abs(cuts[i]-t));if(i>0)d=Math.min(d,Math.abs(cuts[i-1]-t));float x=Math.max(0,1-d/180000f);return 1-amount*x*x*(3-2*x);}
 // A restrained, non-darkening punch after a detected editorial cut.
 static float zoom(long t,long[] cuts){if(t<900000||cuts.length==0)return 1f;int i=Arrays.binarySearch(cuts,t);if(i<0)i=-i-2;if(i<0)return 1f;long d=t-cuts[i];if(d<0||d>=360000)return 1f;float x=d/360000f;float envelope=(float)Math.sin(Math.PI*x);return 1+.035f*envelope*envelope;}
}
