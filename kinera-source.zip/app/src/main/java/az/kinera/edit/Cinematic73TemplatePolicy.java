package az.kinera.edit;
final class Cinematic73TemplatePolicy {
 static final int FIRST=434,TOTAL=484;
 static int family(float a){return Director72TemplatePolicy.family(a);}
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.068f,.988f,.96f};case 1:return new float[]{.025f,.13f,.975f,.90f};case 2:return new float[]{.035f,.21f,.965f,.77f};case 3:return new float[]{.025f,.29f,.975f,.638f};default:return new float[]{.025f,.345f,.975f,.612f};}}
 static int choose(int prior,float a,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(a)||a<=0||semantic<=0||semantic==3||Math.floorMod(seed,11)!=3)return prior;return FIRST+10*family(a)+Math.floorMod(palette+Math.floorMod(seed/11,10),10);}
}
