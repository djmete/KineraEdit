package az.kinera.edit;
/** Detects stalled local preview even when the decoder emits no error. Main-thread only. */
final class PlaybackWatchdog {
 static final long STALL_MS=12000, STABLE_MS=3000;
 private long lastAt=-1,lastPosition=-1,stableSince=-1;
 void reset(){lastAt=-1;lastPosition=-1;stableSince=-1;}
 boolean stalled(long now,long position,boolean expected,boolean progressing){
  if(!expected){reset();return false;}
  if(position<0)progressing=false;
  if(lastAt<0||now<lastAt){lastAt=now;lastPosition=position;stableSince=-1;return false;}
  if(progressing&&position!=lastPosition){if(stableSince<0||now-lastAt>1000||position<lastPosition)stableSince=now;lastAt=now;lastPosition=position;return false;}
  if(!progressing||now-lastAt>1000||position==lastPosition&&now-lastAt>=1000)stableSince=-1;
  return now-lastAt>=STALL_MS;
 }
 boolean stable(long now){return stableSince>=0&&now-stableSince>=STABLE_MS&&now-lastAt<=1000;}
}
