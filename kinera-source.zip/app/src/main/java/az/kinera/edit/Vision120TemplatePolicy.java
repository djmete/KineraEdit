package az.kinera.edit;
final class Vision120TemplatePolicy {
 static final int FIRST=3184,TOTAL=3234;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0014f;float[][] w={{.014f,.022f,.986f,.978f},{.024f,.098f,.976f,.902f},{.04f,.186f,.96f,.814f},{.035f,.26f,.965f,.74f},{.04f,.31f,.96f,.69f}};float[] a=w[k/10];return new float[]{a[0]+v,a[1]+v,a[2]-v,a[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,17)!=8)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Vision120TemplatePolicy(){}
}
