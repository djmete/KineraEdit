package az.kinera.edit;
/** A current OCR anchor is never shrunk. Reject vertical drift on narrow text lines. */
final class Supreme131Caption {
 static float[] stabilize(float[] anchor,float[] candidate){float[] old=Ultimate130Caption.stabilize(anchor,candidate);if(!RegionMath.active(anchor)||!RegionMath.active(candidate))return old;float h=anchor[3]-anchor[1];float c=(anchor[1]+anchor[3]-candidate[1]-candidate[3])*.5f;float overlap=Math.max(0,Math.min(anchor[3],candidate[3])-Math.max(anchor[1],candidate[1]));if(Math.abs(c)>h*.32f||overlap<h*.68f)return anchor.clone();return old;}
 private Supreme131Caption(){}
}
