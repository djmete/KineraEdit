package az.kinera.edit;
final class Vision139TemplatePolicy {
 static final int FIRST=3884,TOTAL=3934;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0012f;float[][] a={{.018f,.035f,.982f,.965f},{.026f,.108f,.974f,.892f},{.038f,.182f,.962f,.818f},{.047f,.235f,.953f,.765f},{.058f,.296f,.942f,.704f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,67)!=35)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Vision139TemplatePolicy(){}
}
