package az.kinera.edit;
final class Scene81TemplatePolicy {
 static final int FIRST=834,TOTAL=884;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.045f,.988f,.985f};case 1:return new float[]{.025f,.125f,.975f,.925f};case 2:return new float[]{.035f,.215f,.965f,.805f};case 3:return new float[]{.022f,.265f,.978f,.745f};default:return new float[]{.015f,.315f,.985f,.685f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,17)!=7)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
}
