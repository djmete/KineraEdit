package az.kinera.edit;
final class Adaptive88TemplatePolicy {
 static final int FIRST=1184,TOTAL=1234;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.015f,.035f,.985f,.965f};case 1:return new float[]{.03f,.095f,.97f,.925f};case 2:return new float[]{.04f,.23f,.96f,.77f};case 3:return new float[]{.025f,.29f,.975f,.71f};default:return new float[]{.02f,.32f,.98f,.68f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,11)!=7)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/11,10),10);}
}
