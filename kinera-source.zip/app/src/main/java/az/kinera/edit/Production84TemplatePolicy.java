package az.kinera.edit;
/** New permanent editorial style IDs, preserving all earlier IDs. */
final class Production84TemplatePolicy {
 static final int FIRST=984,TOTAL=1034;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.025f,.035f,.975f,.965f};case 1:return new float[]{.035f,.115f,.965f,.895f};case 2:return new float[]{.05f,.235f,.95f,.765f};case 3:return new float[]{.035f,.285f,.965f,.715f};default:return new float[]{.025f,.31f,.975f,.69f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,29)!=11)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
}
