package az.kinera.edit;
/** Scene rhythm context; never modifies cuts, masks, or user framing. */
final class Deep148Director {
 static float rest(long[] cuts,int i,long duration){if(cuts==null||i<2||i>=cuts.length||duration<=0)return 1f;long a=cuts[i-1]-cuts[i-2],b=cuts[i]-cuts[i-1],c=(i+1<cuts.length?cuts[i+1]:duration)-cuts[i];if(a<=0||b<=0||c<=0||a>2400000L||b>2400000L)return 1f;float density=Math.max(0f,Math.min(1f,1f-(a+b)/4800000f));return 1f-.20f*density;}
 private Deep148Director(){}
}
