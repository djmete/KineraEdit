package az.kinera.edit;
/** Per-render-thread nearest cut cache. Equal distances choose the earlier cut. */
final class Director147Cursor {
 private final long[] cuts;private int index=-1;
 Director147Cursor(long[] sorted){cuts=sorted.clone();}
 int nearest(long time){if(time<0||cuts.length==0)return -1;int i=index;if(i>=0&&(i==0||time-cuts[i-1]>cuts[i]-time)&&(i==cuts.length-1||time-cuts[i]<=cuts[i+1]-time))return i;
 if(i>=0&&i+1<cuts.length&&time>=cuts[i]&&time-cuts[i]>cuts[i+1]-time&&(i+2==cuts.length||time-cuts[i+1]<=cuts[i+2]-time))return index=i+1;
 return index=DirectorMath.nearest(cuts,time);}
}
