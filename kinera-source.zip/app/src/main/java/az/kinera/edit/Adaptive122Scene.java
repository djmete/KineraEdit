package az.kinera.edit;
/** Limit the influence of a changing lower-third or a small moving object on cut confidence. */
final class Adaptive122Scene {
 static final int MAX_PAIRS=6144;
 static boolean eligible(long duration,long remaining,boolean pressure){return duration>0&&(duration<=90000000L?Studio119FramePlan.eligible(duration,remaining,pressure):!pressure&&duration<=195000000L&&remaining>=26000);}
 static long budget(long duration){return duration<=90000000L?Studio119FramePlan.budget(duration):40000L;}
 static long totalBudget(long duration,boolean pressure){return !pressure&&duration>90000000L&&duration<=195000000L?65000L:Performance86.budget(true);}
 static long refineDeadline(long now,long end,long duration,boolean pressure){return duration<=90000000L?Studio119FramePlan.refineDeadline(now,end,duration,pressure):eligible(duration,end-now,pressure)?Math.max(now,end-40000):end;}
 static boolean format(int w,int h,int fps,long duration){return w>0&&h>0&&fps>0&&fps<=30&&(long)w*h<=1920L*1080L&&duration>0&&duration<=195000000L&&duration/1000000d*fps<MAX_PAIRS;}
 static double upperDelta(int[] a,int[] b){if(a==null||b==null||a.length!=2304||b.length!=2304)return 0;long sum=0;for(int y=0;y<32;y++)for(int x=0;x<48;x++)sum+=Math.abs(a[y*48+x]-b[y*48+x]);return sum/(32d*48*255);}
 static boolean localized(int[] a,int[] b,double d){return d>=.16&&upperDelta(a,b)<Math.min(.12,d*.52);}
 static boolean blocked(int[] a,int[] b,double d){return Visual121Scene.blocked(a,b,d)||localized(a,b,d);}
 static int probeLimit(long d,long remaining,boolean pressure){return Visual121Scene.probeLimit(d,remaining,pressure);}
 private Adaptive122Scene(){}
}
