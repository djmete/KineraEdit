package az.kinera.edit;
import java.util.ArrayList;
final class Ultra95 {
 private Ultra95(){}
 static int height(int w,int h,boolean pressure,boolean lowRam,int memoryClass,boolean restore){int bound=Studio94.height(w,h,pressure,lowRam,memoryClass,restore);if(pressure||lowRam||memoryClass<=128)bound=Math.min(bound,960);int source=Math.max(w,h);if(source<=0)return bound;int chosen=source<=480?480:source<=640?640:source<=960?960:source<=1280?1280:source<1600?1280:1920;return Math.min(bound,chosen);}
 static int fps(float source){if(!Float.isFinite(source)||source<=0)return 30;return Math.max(1,Math.min(30,Math.round(source)));}
 static int[][] fallbacks(int h,int fps){ArrayList<int[]> out=new ArrayList<>();int f=Math.max(1,Math.min(fps,30));if(f>24)out.add(new int[]{h,24});for(int v:new int[]{1280,960,640,480})if(v<h)out.add(new int[]{v,Math.min(f,24)});return out.toArray(new int[0][]);}
 static long sequentialBudget(long duration,long remaining,boolean pressure){return pressure||duration<=0||duration>90000000L||remaining<1800L?0L:Math.min(3600L,remaining);}
 static int afterPrep(int h,boolean pressure){return pressure?Math.min(h,960):h;}
 static boolean safeUnion(float[] a,float[] b){if(!RegionMath.active(a)||!RegionMath.active(b))return false;float[] u=DenseCaptionPlan.union(a,b);double area=(u[2]-u[0])*(u[3]-u[1]);double aa=(a[2]-a[0])*(a[3]-a[1]),bb=(b[2]-b[0])*(b[3]-b[1]);return area<=1.28*Math.max(aa,bb);}
 static float[] caption(float[] longRegion,java.util.List<float[]> shortLines){float[] best=RegionMath.empty();float score=Float.POSITIVE_INFINITY;for(float[] c:shortLines){if(!RegionMath.active(c))continue;float d=Math.abs((c[0]+c[2])/2-.5f);if(d<score){best=c;score=d;}}if(!RegionMath.active(longRegion))return best;if(RegionMath.active(best)&&score<=.075f&&Math.abs((longRegion[0]+longRegion[2])/2-.5f)>.24f)return best;return longRegion;}
}
