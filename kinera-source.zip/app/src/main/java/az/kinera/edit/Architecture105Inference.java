package az.kinera.edit;
import java.io.*;
/** Portable FP32 reference inference for the compact research CNN. Not enabled in the video render path. */
final class Architecture105Inference {
 static final int SIDE=32, PIX=SIDE*SIDE, INPUT=12*PIX, OUTPUT=3*PIX;
 private final float[] w1,b1,w2,b2;
 Architecture105Inference(InputStream stream)throws IOException{DataInputStream d=new DataInputStream(stream);if(d.readInt()!=105)throw new IOException("model version");w1=read(d,16*12*9);b1=read(d,16);w2=read(d,3*16);b2=read(d,3);if(d.read()!=-1)throw new IOException("trailing weights");}
 private static float[] read(DataInputStream d,int n)throws IOException{if(d.readInt()!=n)throw new IOException("model shape");float[] a=new float[n];for(int i=0;i<n;i++){a[i]=d.readFloat();if(!Float.isFinite(a[i]))throw new IOException("nonfinite weight");}return a;}
 float[] infer(float[] x){if(x==null||x.length!=INPUT)throw new IllegalArgumentException("input shape");for(float v:x)if(!Float.isFinite(v)||v<0||v>1)throw new IllegalArgumentException("input range");float[] hidden=new float[16],out=new float[OUTPUT];
 for(int i=0;i<PIX;i++){float m=x[9*PIX+i];if(m==0){for(int c=0;c<3;c++)out[c*PIX+i]=x[c*PIX+i];continue;}int y=i/SIDE,u=i%SIDE;for(int o=0;o<16;o++){float v=b1[o];for(int c=0;c<12;c++)for(int ky=0;ky<3;ky++){int yy=y+ky-1;if(yy<0||yy>=SIDE)continue;for(int kx=0;kx<3;kx++){int xx=u+kx-1;if(xx>=0&&xx<SIDE)v+=x[c*PIX+yy*SIDE+xx]*w1[((o*12+c)*3+ky)*3+kx];}}hidden[o]=Math.max(0,v);}
 float a=b2[0],b=b2[1],c=b2[2];for(int h=0;h<16;h++){float v=hidden[h];a+=v*w2[h];b+=v*w2[16+h];c+=v*w2[32+h];}float max=Math.max(a,Math.max(b,c));double ea=Math.exp(a-max),eb=Math.exp(b-max),ec=Math.exp(c-max),sum=ea+eb+ec;for(int k=0;k<3;k++){int j=k*PIX+i;out[j]=(float)((1-m)*x[j]+m*(ea*x[j]+eb*x[j+3*PIX]+ec*x[j+6*PIX])/sum);}}
 return out;}
}
