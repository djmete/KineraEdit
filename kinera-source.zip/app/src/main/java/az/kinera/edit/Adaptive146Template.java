package az.kinera.edit;
final class Adaptive146Template {
 static final int FIRST=4234,TOTAL=4284;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0012f;float[][] a={{.026f,.083f,.974f,.917f},{.034f,.166f,.966f,.834f},{.047f,.214f,.953f,.786f},{.056f,.278f,.944f,.722f},{.070f,.334f,.930f,.666f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,101)!=79)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Adaptive146Template(){}
}
