package az.kinera.edit;
final class Adaptive76TemplatePolicy {
 static final int FIRST=584,TOTAL=634;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.015f,.048f,.985f,.962f};case 1:return new float[]{.025f,.115f,.975f,.906f};case 2:return new float[]{.029f,.190f,.971f,.783f};case 3:return new float[]{.020f,.276f,.98f,.654f};default:return new float[]{.022f,.331f,.978f,.626f};}}
 static int choose(int prior,float a,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(a)||a<=0||semantic<=0||semantic==3||Math.floorMod(seed,19)!=9)return prior;return FIRST+10*Director72TemplatePolicy.family(a)+Math.floorMod(palette+Math.floorMod(seed/19,10),10);}
}
