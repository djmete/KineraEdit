package az.kinera.edit;
final class Vision93TemplatePolicy {
 static final int FIRST=1434,TOTAL=1484;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.025f,.988f,.975f};case 1:return new float[]{.026f,.09f,.974f,.91f};case 2:return new float[]{.032f,.23675f,.968f,.76325f};case 3:return new float[]{.018f,.292f,.982f,.708f};default:return new float[]{.014f,.32f,.986f,.68f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,19)!=13)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/19,10),10);}
}
