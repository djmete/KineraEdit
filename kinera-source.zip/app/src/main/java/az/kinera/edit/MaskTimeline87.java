package az.kinera.edit;
import java.util.*;
/** Immutable interval index. Build once per changed mask snapshot; exact original slot order. */
final class MaskTimeline87 {
 private final long[] times; private final float[][] rects,modes;
 MaskTimeline87(List<TimedRegions.Mask> masks){TreeSet<Long> keys=new TreeSet<>();for(TimedRegions.Mask m:masks){keys.add(m.from);keys.add(m.until);}times=new long[keys.size()];rects=new float[times.length][TimedRegions.ACTIVE_MAX*4];modes=new float[times.length][TimedRegions.ACTIVE_MAX];int i=0;for(long t:keys){times[i]=t;TimedRegions.fillBoth(masks,t,rects[i],modes[i]);i++;}}
 void fill(long time,float[] r,float[] m){int i=Arrays.binarySearch(times,time);if(i<0)i=-i-2;if(i<0){Arrays.fill(r,0);Arrays.fill(m,0);}else{System.arraycopy(rects[i],0,r,0,rects[i].length);System.arraycopy(modes[i],0,m,0,modes[i].length);}}
}
