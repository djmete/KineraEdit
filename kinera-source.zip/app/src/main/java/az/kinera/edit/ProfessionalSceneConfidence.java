package az.kinera.edit;
/** Trained lighting pulse guard; not a platform originality classifier. */
final class ProfessionalSceneConfidence {
 static final boolean ENABLED=false;
 static final double THRESHOLD=0.8,SCALE=0.0003620815696194768;
 private static final short[] W={-1508,3275,2689,-16032,-2328,-1970,-2478,4478,-3637,-1588,-4195,-6302,982,-1260,339,-12164,-2386,-537,-2364,2017,-2986,-2418,-2642,-5483,-384,-555,-10497,-32767,4222,14856,9187,-6764,7111,3872,9058,-390,20952,-19412,735,2098,-23091,317,959,691,1087,-20615,259,694,-20025,19025,2847,1568,22120,-2396,-860,36,-674,19626,-1589,441,2718,-2729,1915,5493,3899,-2913,-1204,-147,-47,3530,-685,890,-16677,12717,6097,-21342,-13773,-6641,-5318,4127,-4430,-10688,-5458,-5513,570};
 static double score(double a,double b,double c,double d,double e){double[] x={a,b,c,d,e};double sum=W[84]*SCALE;for(int j=0;j<12;j++){double h=W[60+j]*SCALE;for(int i=0;i<5;i++)h+=x[i]*W[i*12+j]*SCALE;sum+=Math.tanh(h)*W[72+j]*SCALE;}return 1/(1+Math.exp(-Math.max(-40,Math.min(40,sum))));}
 static boolean lightingPulse(float a,float b,float c,float d,float e){return ENABLED&&a>=.22f&&b>=.22f&&c<=.13f&&d*e<0&&score(a,b,c,d,e)>=THRESHOLD;}
 static float meanLuma(int[] rgb){if(rgb==null||rgb.length==0)return 0;long sum=0;for(int p:rgb)sum+=SceneMath.luma(p);return (float)(sum/(255.0*rgb.length));}
}
