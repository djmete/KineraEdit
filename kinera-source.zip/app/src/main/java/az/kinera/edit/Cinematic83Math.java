package az.kinera.edit;
final class Cinematic83Math {
 static float effectScale(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];long gap=Math.min(left,right);if(gap<=0)return 0;return Math.max(.25f,Math.min(1f,gap/2500000f));}
 static boolean ordered(long[] pts,double[] scores,int n){if(pts==null||scores==null||n<1||n>pts.length||n>scores.length)return false;for(int i=0;i<n;i++)if(pts[i]<0||!Double.isFinite(scores[i])||scores[i]<0||scores[i]>1.2||(i>0&&pts[i]<=pts[i-1]))return false;return true;}
}
