package az.kinera.edit;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import java.util.Arrays;
/** Bounded low-resolution keyframe sampling; timestamps are approximate. */
final class SceneScanner {
 static long[] scan(Context context, Uri uri,long durationUs) throws Exception {
  if(durationUs<2000000)return new long[0];
  long step=ImportMath.sampleStep(durationUs);int count=ImportMath.sampleCount(durationUs);
  float[] scores=new float[count];long[] times=new long[count];int[] previous=null,pixels=new int[48*48];int n=0;long prevTime=-1;long deadline=android.os.SystemClock.elapsedRealtime()+18000;
  MediaMetadataRetriever r=new MediaMetadataRetriever();try{r.setDataSource(context,uri);
   for(int i=0;i<count;i++){if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(android.os.SystemClock.elapsedRealtime()>=deadline)break;long t=i*step;Bitmap b=null,small=null;try{
    b=AnalysisFrameReader.read(r,t,48,48);
    if(b==null){previous=null;continue;}small=Bitmap.createScaledBitmap(b,48,48,true);small.getPixels(pixels,0,48,0,0,48,48);
    if(previous!=null&&prevTime>=0&&t-prevTime<=step*1.5){times[n]=prevTime+(t-prevTime)/2;scores[n]=SceneMath.distance(previous,pixels);n++;}int[] swap=previous;previous=pixels;prevTime=t;pixels=swap==null?new int[48*48]:swap;
   }finally{if(small!=null&&small!=b)small.recycle();if(b!=null)b.recycle();}}
  }finally{r.release();}return KineraAI.editorialCuts(Arrays.copyOf(times,n),Arrays.copyOf(scores,n),durationUs);
 }
}
