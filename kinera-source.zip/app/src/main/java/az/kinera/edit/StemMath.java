package az.kinera.edit;
/** Pure PCM helpers for the experimental offline stem separator. */
final class StemMath {
 static final int RATE=44100, MODEL_FRAMES=343980;
 private StemMath(){}
 static int blockFrames(int rate){if(rate<8000||rate>96000)throw new IllegalArgumentException("Unsupported sample rate");return Math.round(MODEL_FRAMES*(rate/(float)RATE));}
 static int overlapFrames(int rate){return rate/2;}
 static float sample(float[] a,int frames,int channels,int channel,double at){if(frames<=0||at<0||at>=frames)return 0;int i=(int)at,j=Math.min(frames-1,i+1);float k=(float)(at-i);int c=Math.min(channel,channels-1);return a[i*channels+c]*(1-k)+a[j*channels+c]*k;}
 static float[] toModel(float[] pcm,int frames,int rate,int channels){float[] out=new float[2*MODEL_FRAMES];fillModel(pcm,frames,rate,channels,java.nio.FloatBuffer.wrap(out));return out;}
 static void fillModel(float[] pcm,int frames,int rate,int channels,java.nio.FloatBuffer out){if(out.capacity()<2*MODEL_FRAMES)throw new IllegalArgumentException("Model input capacity");out.clear();for(int c=0;c<2;c++)for(int i=0;i<MODEL_FRAMES;i++)out.put(sample(pcm,frames,channels,c,i*(rate/(double)RATE)));out.flip();}
 static float[] toNative(float[] stems,int frames,int rate,int channels){float[] out=new float[frames*channels];fillNative(stems,frames,rate,channels,out);return out;}
 static void fillNative(float[] stems,int frames,int rate,int channels,float[] out){if(stems.length!=2*MODEL_FRAMES||out.length<frames*channels)throw new IllegalArgumentException("Invalid stem shape");for(int i=0;i<frames;i++){double at=i*(RATE/(double)rate);int a=Math.min(MODEL_FRAMES-1,(int)at),b=Math.min(MODEL_FRAMES-1,a+1);float k=(float)Math.max(0,Math.min(1,at-a));for(int c=0;c<channels;c++){float left=stems[a]*(1-k)+stems[b]*k;float right=stems[MODEL_FRAMES+a]*(1-k)+stems[MODEL_FRAMES+b]*k;out[i*channels+c]=channels==1?(left+right)*.5f:c==0?left:right;}}}
 static int inferenceThreads(int processors){return Math.max(1,Math.min(3,processors/2));}
 static void sumMusic(java.nio.FloatBuffer buffer,float[] music){int n=2*MODEL_FRAMES;if(buffer==null||buffer.remaining()!=4*n||music.length!=n)throw new IllegalArgumentException("Invalid stem length");int base=buffer.position();for(int i=0;i<n;i++){float a=buffer.get(base+i),b=buffer.get(base+n+i),c=buffer.get(base+2*n+i);float v=a+b+c;if(!Float.isFinite(v))throw new IllegalStateException("Non-finite model output");music[i]=v;}}
 static float crossfade(float old,float next,int frame,int overlap){float t=overlap<=1?1f:Math.max(0,Math.min(1,frame/(float)(overlap-1)));return old*(1-t)+next*t;}
 static float safe(float x){return Float.isFinite(x)?Math.max(-1,Math.min(1,x)):0;}
 // Conservative soundtrack gain, not a guarantee of perceptual loudness or dialogue absence.
 static float recommendedGain(float[] samples,int count){double sum=0;float peak=0;count=samples==null?0:Math.max(0,Math.min(count,samples.length));for(int i=0;i<count;i++){float x=safe(samples[i]);sum+=x*x;peak=Math.max(peak,Math.abs(x));}double rms=Math.sqrt(sum/Math.max(1,count));if(rms<1e-5)return .10f;return (float)Math.max(.05,Math.min(.15,Math.min(.025/rms,.25/Math.max(.001,peak))));}
}
