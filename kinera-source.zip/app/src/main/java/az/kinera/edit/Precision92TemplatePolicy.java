package az.kinera.edit;
final class Precision92TemplatePolicy {
 static final int FIRST=1384,TOTAL=1434;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.014f,.035f,.986f,.965f};case 1:return new float[]{.036f,.105f,.964f,.895f};case 2:return new float[]{.04f,.24125f,.96f,.75875f};case 3:return new float[]{.022f,.30f,.978f,.70f};default:return new float[]{.018f,.325f,.982f,.675f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,17)!=12)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/17,10),10);}
}
