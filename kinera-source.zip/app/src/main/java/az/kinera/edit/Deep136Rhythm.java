package az.kinera.edit;
/** Budget optional accent tails by available shot time. */
final class Deep136Rhythm {
 static float scale(long[] cuts,int i,long duration,long time){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long l=cuts[i]-(i==0?0:cuts[i-1]),r=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(l<=0||r<=0)return 0;double min=Math.min(l,r),max=Math.max(l,r),balance=min/max;double scarcity=Math.max(0,Math.min(1,1-min/1400000.0));double u=Math.max(0,Math.min(1,Math.abs((double)time-cuts[i])/Math.max(1,Math.min(180000,min/3))));return (float)(1-.28*scarcity*(1-balance)*u*u*(3-2*u));}
 private Deep136Rhythm(){}
}
