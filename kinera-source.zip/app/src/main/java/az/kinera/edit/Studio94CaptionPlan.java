package az.kinera.edit;
import java.util.*;
final class Studio94CaptionPlan {
 static final long MAX_BRIDGE_US=150000L;
 static boolean bridge(float[] a,float[] b){if(!RestorePolicy.usable(a)||!RestorePolicy.usable(b)||!PrecisionCaptionPlan.compatible(a,b))return false;double[] f=PrecisionCaptionPlan.features(a,b);return f!=null&&f[0]>=.80&&f[1]>=.80&&f[2]<=.012&&f[6]<=.035&&f[7]>=.55&&RestorePolicy.usable(DenseCaptionPlan.union(a,b));}
 static List<TimedRegions.Mask> build(long duration,List<float[]> left,List<float[]> right,boolean restore){int n=StableCaptionPlan.windows(duration);if(n<=0||left==null||right==null||left.size()!=n||right.size()!=n)throw new IllegalArgumentException("incomplete scan");ArrayList<float[]> a=new ArrayList<>(left),b=new ArrayList<>(right);for(int i=1;i<2*n-1;i++){float[] cur=i%2==0?left.get(i/2):right.get(i/2);if(RegionMath.active(cur))continue;long from=FullCaptionPlan.boundary(duration,i/2,n),until=FullCaptionPlan.boundary(duration,i/2+1,n);if(until-from>2*MAX_BRIDGE_US)continue;int before=i-1,after=i+1;float[] prev=before%2==0?left.get(before/2):right.get(before/2),next=after%2==0?left.get(after/2):right.get(after/2);if(bridge(prev,next)){float[] union=DenseCaptionPlan.union(prev,next);if(i%2==0)a.set(i/2,union);else b.set(i/2,union);}}
 return PrecisionCaptionPlan.build(duration,n,a,b,restore);}
}
