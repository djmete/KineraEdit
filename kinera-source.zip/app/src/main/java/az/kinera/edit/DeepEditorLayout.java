package az.kinera.edit;
final class DeepEditorLayout {
 static boolean showTools(int regionMode,boolean focus){return !focus&&regionMode<=0;}
 static boolean showFilmstrip(int availableDp,int regionMode,boolean focus){return !focus&&regionMode<=0&&availableDp>=640;}
 static boolean showSeek(int availableDp,int regionMode,boolean focus){return !focus&&(regionMode<=0||availableDp>=(regionMode==2?640:560));}
 static int playbackHeight(int availableDp){return availableDp<540?44:48;}
 static int adjustmentHeight(int screenDp,int availableDp){return Math.max(56,Math.min(adjustmentHeight(screenDp),Math.max(56,availableDp/5)));}
 static int adjustmentHeight(int screenDp){return Math.max(72,Math.min(210,Math.round(screenDp*(screenDp<640?.18f:.24f))));}
}
