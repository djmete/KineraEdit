package az.kinera.edit;
final class CaptionBudget99 {
 static final long SCAN_MS=90000L, UI_MS=105000L;
 static int windows(long duration,boolean pressure){return duration<=0?0:(int)Math.min(pressure?36:72,1+(duration-1)/250000L);}
 static int progress(int done,int total){return total<=0?0:Math.max(0,Math.min(100,(int)(100L*done/total)));}
 static boolean active(boolean busy,boolean decoding){return busy||decoding;}
 static boolean valid(long job,long current,long generation,long currentGeneration){return job==current&&generation==currentGeneration;}
}
