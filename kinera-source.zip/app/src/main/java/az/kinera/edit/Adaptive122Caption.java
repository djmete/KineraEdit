package az.kinera.edit;
/** Conservative geometry for user-confirmed caption editing. Never expand away from a valid anchor. */
final class Adaptive122Caption {
 static float[] stabilize(float[] anchor,float[] candidate){
  float[] r=Visual121Caption.stabilize(anchor,candidate);
  if(!RegionMath.active(anchor))return RegionMath.empty();
  if(!RegionMath.active(r))return anchor.clone();
  float w=anchor[2]-anchor[0],h=anchor[3]-anchor[1];
  // A neighbor cannot expand a compact text mask by more than a fraction of its own height.
  float dx=Math.min(.018f,w*.045f),dy=Math.min(.012f,h*.12f);
  float[] bounded={Math.max(anchor[0]-dx,r[0]),Math.max(anchor[1]-dy,r[1]),Math.min(anchor[2]+dx,r[2]),Math.min(anchor[3]+dy,r[3])};
  return RegionMath.active(bounded)?bounded:anchor.clone();
 }
 private Adaptive122Caption(){}
}
