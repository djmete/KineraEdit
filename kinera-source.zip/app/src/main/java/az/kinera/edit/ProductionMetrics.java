package az.kinera.edit;
import java.util.Locale;
/** Measurements describe the completed successful render attempt; not a benchmark promise. */
final class ProductionMetrics {
 static double factor(long renderMs,long durationUs){return renderMs<=0||durationUs<=0?0:durationUs/1000.0/renderMs;}
 static String renderSummary(long renderMs,long durationUs,int gain,boolean mute,int retries){return UiLanguage.tr("Render vaxtı")+": "+TimelineMath.time(renderMs)+" • "+String.format(Locale.ROOT,"%.2f×",factor(renderMs,durationUs))+" • "+UiLanguage.tr("Səs")+": "+(mute?0:KAiEdit.gainPercent(gain))+"% • "+UiLanguage.tr("Təkrar cəhd")+": "+Math.max(0,retries);}
}
