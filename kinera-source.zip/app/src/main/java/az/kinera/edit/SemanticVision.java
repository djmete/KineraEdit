package az.kinera.edit;
import android.graphics.Bitmap;
import com.google.android.gms.tasks.Tasks;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import java.util.List;
import java.util.concurrent.TimeUnit;
/** Bundled on-device image labeler. Background import only; bounded wait, deterministic fallback. */
final class SemanticVision {
 private SemanticVision(){}
 static int classify(Bitmap frame){if(frame==null||Thread.currentThread().isInterrupted())return CreativePolicy.UNKNOWN;
  VisualInferenceGate.Lease lease=VisualInferenceGate.tryEnter();if(lease==null)return CreativePolicy.UNKNOWN;
  ImageLabeler labeler=null;Bitmap owned=null;Task<List<ImageLabel>> task=null;try{
   // Independent copy: a timed-out asynchronous task may still reference it.
   owned=frame.copy(Bitmap.Config.ARGB_8888,false);if(owned==null)return CreativePolicy.UNKNOWN;
   labeler=ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
   task=labeler.process(InputImage.fromBitmap(owned,0));List<ImageLabel> labels=Tasks.await(task,1200,TimeUnit.MILLISECONDS);
   float best=0;int result=CreativePolicy.UNKNOWN;for(ImageLabel l:labels){int kind=CreativePolicy.category(l.getText(),l.getConfidence());if(kind!=CreativePolicy.UNKNOWN&&l.getConfidence()>best){best=l.getConfidence();result=kind;}}
   return result;
  }catch(InterruptedException e){Thread.currentThread().interrupt();return CreativePolicy.UNKNOWN;}
  catch(Exception|LinkageError e){return CreativePolicy.UNKNOWN;}
  finally{final Bitmap input=owned;final ImageLabeler client=labeler;Runnable cleanup=()->{try{if(input!=null)input.recycle();if(client!=null)try{client.close();}catch(RuntimeException ignored){}}finally{lease.close();}};if(task!=null&&!task.isComplete())task.addOnCompleteListener(Runnable::run,t->cleanup.run());else cleanup.run();}
 }
}
