package az.kinera.edit;
import java.util.*;
/** Bounded timed source-coordinate masks; up to three active at any instant, immutable export snapshots. */
final class TimedRegions {
 static final int MAX=31,ACTIVE_MAX=3;
 static final class Mask {
  private final float[] rect; final long from,until; final boolean restore;
  Mask(float[] r,long f,long u){this(r,f,u,false);}
  Mask(float[] r,long f,long u,boolean restore){if(!RegionMath.active(r))throw new IllegalArgumentException("region");for(float v:r)if(!Float.isFinite(v)||v<0||v>1)throw new IllegalArgumentException("coordinate");if(f<0||u<=f)throw new IllegalArgumentException("time");rect=r.clone();from=f;until=u;this.restore=restore;}
  float[] rect(){return rect.clone();}
  @Override public boolean equals(Object o){if(!(o instanceof Mask))return false;Mask m=(Mask)o;return from==m.from&&until==m.until&&restore==m.restore&&Arrays.equals(rect,m.rect);}
  @Override public int hashCode(){return Objects.hash(from,until,restore,Arrays.hashCode(rect));}
 }
 static List<Mask> snapshot(List<Mask> input){if(input.size()>MAX)throw new IllegalArgumentException("region limit");for(Mask start:input){int count=0;for(Mask m:input)if(m.from<=start.from&&m.until>start.from)count++;if(count>ACTIVE_MAX)throw new IllegalArgumentException("concurrent region limit");}return Collections.unmodifiableList(new ArrayList<>(input));}
 static void fillModes(List<Mask> masks,long time,float[] out){if(out.length<ACTIVE_MAX)throw new IllegalArgumentException("buffer");Arrays.fill(out,0);int slot=0;for(Mask m:masks)if(time>=m.from&&time<m.until){if(slot>=ACTIVE_MAX)break;out[slot++]=m.restore?1f:0f;}}
 static void fill(List<Mask> masks,long time,float[] out){if(out.length<ACTIVE_MAX*4)throw new IllegalArgumentException("buffer");Arrays.fill(out,0);int slot=0;for(Mask m:masks){if(time>=m.from&&time<m.until){if(slot>=ACTIVE_MAX)break;System.arraycopy(m.rect,0,out,slot++*4,4);}}}
}
