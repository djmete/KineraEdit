package az.kinera.edit;
/** Conservative triple-frame flash guard. Inputs are 48x48 decoder luminance samples. */
final class PrecisionPulseMath {
 static double[] features(int[] a,int[] b,int[] c){if(a==null||b==null||c==null||a.length!=2304||b.length!=2304||c.length!=2304)return null;double ab=0,bc=0,ac=0,ma=0,mb=0,mc=0;for(int y=0;y<48;y+=2)for(int x=0;x<48;x+=2){int i=y*48+x;double p=a[i]/255.,q=b[i]/255.,r=c[i]/255.;ab+=Math.abs(p-q);bc+=Math.abs(q-r);ac+=Math.abs(p-r);ma+=p;mb+=q;mc+=r;}return new double[]{ab/576,bc/576,ac/576,(mb-ma)/576,(mc-mb)/576,Math.abs(ma-mc)/576};}
 static boolean pulse(int[] a,int[] b,int[] c){return PrecisionPulseConfidence.reject(features(a,b,c));}
}
