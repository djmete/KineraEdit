package az.kinera.edit;
/** Append-only layout families, preserve existing draft IDs. */
final class Vision80TemplatePolicy {
 static final int FIRST=784,TOTAL=834;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.015f,.065f,.985f,.975f};case 1:return new float[]{.026f,.145f,.974f,.905f};case 2:return new float[]{.034f,.23f,.966f,.79f};case 3:return new float[]{.020f,.29f,.98f,.72f};default:return new float[]{.014f,.33f,.986f,.67f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,13)!=5)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorDiv(seed,13),10);}
}
