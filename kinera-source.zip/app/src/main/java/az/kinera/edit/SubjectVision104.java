package az.kinera.edit;
import android.graphics.Bitmap;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;
import java.util.concurrent.TimeUnit;
/** Bundled ML Kit human segmentation. Single sampled import frame, not identity recognition. */
final class SubjectVision104 {
 static boolean present(Bitmap frame){if(frame==null||Thread.currentThread().isInterrupted())return false;VisualInferenceGate.Lease lease=VisualInferenceGate.tryEnter();if(lease==null)return false;
 Bitmap owned=null;Segmenter client=null;Task<SegmentationMask> task=null;try{owned=frame.copy(Bitmap.Config.ARGB_8888,false);if(owned==null)return false;
 client=Segmentation.getClient(new SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).enableRawSizeMask().build());
 task=client.process(InputImage.fromBitmap(owned,0));SegmentationMask mask=Tasks.await(task,1800,TimeUnit.MILLISECONDS);
 return Fusion104.subject(mask.getBuffer().duplicate().order(java.nio.ByteOrder.nativeOrder()).asFloatBuffer(),mask.getWidth(),mask.getHeight());
 }catch(InterruptedException e){Thread.currentThread().interrupt();return false;}catch(Exception|LinkageError e){return false;}
 finally{final Bitmap bitmap=owned;final Segmenter segmenter=client;Runnable cleanup=()->{try{if(bitmap!=null)bitmap.recycle();if(segmenter!=null)try{segmenter.close();}catch(RuntimeException ignored){}}finally{lease.close();}};if(task!=null&&!task.isComplete())task.addOnCompleteListener(Runnable::run,t->cleanup.run());else cleanup.run();}}
 private SubjectVision104(){}
}
