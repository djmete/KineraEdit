package az.kinera.edit;
final class DeepTemplatePolicy {
 static final int FIRST=210,COUNT=216;
 static int choose(int previous,float aspect,int semantic,int seed){if(previous<0||previous>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==0||semantic==3||Math.floorMod(seed,7)!=3)return previous;return FIRST+2*(aspect<=.82f?0:aspect>=1.30f?1:2)+Math.floorMod(seed/7,2);}
 static float[] window(int id){int family=(id-FIRST)/2;return family==0?new float[]{.018f,.11f,.982f,.92f}:family==1?new float[]{.012f,.28f,.988f,.72f}:new float[]{.022f,.18f,.978f,.81f};}
}
