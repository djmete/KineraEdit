package az.kinera.edit;
/** Reject a neighbor with substantially different text-band size, keeping current anchor intact. */
final class Precision133Caption {
 static float[] stabilize(float[] a,float[] b){if(!RegionMath.active(a)||!RegionMath.active(b))return Advanced132Caption.stabilize(a,b);double ar=Ultimate130Caption.area(a),br=Ultimate130Caption.area(b);float h=a[3]-a[1],bh=b[3]-b[1];if(br>ar*1.65||br<ar*.55||bh>h*1.35||bh<h*.65)return a.clone();return Advanced132Caption.stabilize(a,b);}
 private Precision133Caption(){}
}
