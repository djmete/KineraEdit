package az.kinera.edit;
final class Reconstruction123Workspace {
 static boolean compact(int h,int w,float f){return Adaptive122Workspace.compact(h,w,f)||h<820&&w<400;}
 static boolean metadata(int h,int mode,boolean focus,float f){return Adaptive122Workspace.metadata(h,mode,focus,f)&&h>=900;}
 static int sliderPadding(int w){return w<360?2:5;}
 static int valueWidth(int w,float f){return w<300?40:w<380?46:f>1.4f?60:50;}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return last<0||now<last||now-last>=(pressure?420:playing?110:65);}
 static boolean cancelBeforeFocus(boolean editing,boolean draft){return Adaptive122Workspace.cancelBeforeFocus(editing,draft);}
 private Reconstruction123Workspace(){}
}
