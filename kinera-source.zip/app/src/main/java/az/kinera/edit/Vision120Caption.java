package az.kinera.edit;
final class Vision120Caption {
 static float[] stabilize(float[] anchor,float[] proposed){float[] p=Studio119Caption.stabilize(anchor,proposed);if(!RegionMath.active(anchor)||!RegionMath.active(p))return p;float area=(anchor[2]-anchor[0])*(anchor[3]-anchor[1]);float next=(p[2]-p[0])*(p[3]-p[1]);return next>area*1.30f?anchor.clone():p;}
 private Vision120Caption(){}
}
