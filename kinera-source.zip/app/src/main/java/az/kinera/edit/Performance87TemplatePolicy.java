package az.kinera.edit;
final class Performance87TemplatePolicy {
 static final int FIRST=1134,TOTAL=1184;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.018f,.05f,.982f,.96f};case 1:return new float[]{.035f,.13f,.965f,.91f};case 2:return new float[]{.04f,.235f,.96f,.775f};case 3:return new float[]{.025f,.295f,.975f,.705f};default:return new float[]{.018f,.335f,.982f,.665f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,13)!=5)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/13,10),10);}
}
