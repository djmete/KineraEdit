package az.kinera.edit;
/** Bounded, offline amplitude heuristic; not a speech separator or LUFS meter. */
final class AudioLevelMath {
 static final int AUTO_MIN=5, AUTO_MAX=20, AUTO_FALLBACK=10;
 static int recommend(double rms,double peak,long samples){
  if(samples<=0||!Double.isFinite(rms)||!Double.isFinite(peak)||rms<0||peak<0)return AUTO_FALLBACK;
  // User-facing percentage is linear gain, not dB/LUFS. Keep loud material audible.
  double level=Math.min(1,rms), crest=Math.min(1,peak);
  double energy=level<=.14?20-5*level/.14:level<=.28?15-5*(level-.14)/.14:10-5*Math.min(1,(level-.28)/.27);
  // A single isolated peak cannot reduce an otherwise normal clip below 15%.
  double peakPenalty=5+5*Math.max(0,Math.min(1,(level-.14)/.14));
  double peakGain=crest<=.70?20:20-peakPenalty*(crest-.70)/.30;
  return Math.max(AUTO_MIN,Math.min(AUTO_MAX,(int)Math.round(Math.min(energy,peakGain))));
 }
 static boolean currentGain(int gain,boolean measured,int policy){return measured&&policy>=109&&(gain==0||(gain>=AUTO_MIN&&gain<=AUTO_MAX));}
 static int restoredGain(int gain,boolean automatic,boolean measured,int policy){return !automatic?Math.max(0,Math.min(100,gain)):currentGain(gain,measured,policy)?gain:AUTO_FALLBACK;}
 static int combined(Meter[] windows){if(windows==null||windows.length==0)return AUTO_FALLBACK;int gain=AUTO_MAX;boolean usable=false;for(Meter m:windows){if(m!=null&&m.n>=1024){usable=true;gain=Math.min(gain,m.gain());}}return usable?gain:AUTO_FALLBACK;}
 static int sampleCount(long duration){return duration<=3000000?1:duration<=12000000?3:duration<=45000000?5:7;}
 static int measuredGain(Meter[] windows,int expected){if(windows==null||expected<=0)return AUTO_FALLBACK;int gain=combined(windows),valid=0;for(Meter m:windows)if(m!=null&&m.n>=1024)valid++;return valid<expected?Math.min(gain,AUTO_FALLBACK):gain;}
 static int completedGain(Meter[] windows,int expected){if(windows==null)return AUTO_FALLBACK;Meter[] verified=windows.clone();for(int i=0;i<verified.length;i++)if(verified[i]!=null&&!verified[i].complete)verified[i]=null;int gain=measuredGain(verified,expected);for(Meter m:windows)if(m!=null&&!m.complete&&m.n>0)gain=Math.min(gain,m.gain());return gain;}
 static long sampleStart(long duration,int index,int count){if(duration<=1500000||count<=1)return 0;long span=duration-1500000;return (long)(span*(Math.max(0,Math.min(index,count-1))/(double)(count-1)));}
 static final class Meter {
  // Fixed-size energy blocks protect short loud passages from averaging into silence.
  static final int BLOCK=4096;
  boolean complete;double sum,peak,blockSum,maxBlockRms,shortSum,maxShortRms;long n;int blockN,shortN;
  void add(float x){if(!Float.isFinite(x))return;double a=Math.min(1,Math.abs(x));sum+=a*a;peak=Math.max(peak,a);n++;shortSum+=a*a;if(++shortN==512){maxShortRms=Math.max(maxShortRms,Math.sqrt(shortSum/shortN));shortN=0;shortSum=0;}blockSum+=a*a;if(++blockN==BLOCK){maxBlockRms=Math.max(maxBlockRms,Math.sqrt(blockSum/blockN));blockSum=0;blockN=0;}}
  int gain(){double rms=n==0?0:Math.sqrt(sum/n);double last=blockN>=256?Math.sqrt(blockSum/blockN):0;return recommend(Math.max(rms,Math.max(Math.max(last,maxBlockRms),Math.max(maxShortRms,shortN>=64?Math.sqrt(shortSum/shortN):0))),peak,n);}
 }
}
