package az.kinera.edit;
/** Bounded recent-shot context, reduces over-editing. */
final class Creative145Director {
 static float budget(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 1f;int nearby=0;for(int k=i-1;k>=0&&i-k<=3&&cuts[i]-cuts[k]<10000000L;k--)nearby++;return nearby>=3?.72f:nearby==2?.86f:1f;}
 private Creative145Director(){}
}
