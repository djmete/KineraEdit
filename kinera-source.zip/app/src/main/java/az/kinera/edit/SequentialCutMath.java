package az.kinera.edit;
/** Bounded, conservative refinement based on presentation timestamps, never adds or removes shots. */
final class SequentialCutMath {
 static double distance(int[] a,int[] b){if(a==null||b==null||a.length!=2304||b.length!=2304)return 0;double sum=0,sq=0,ma=0,mb=0;int q=0,h=0;for(int i=0;i<a.length;i++){double d=Math.abs(a[i]-b[i])/255.;sum+=d;sq+=d*d;ma+=a[i];mb+=b[i];if(d>.25)q++;if(d>.5)h++;}double x=sum/a.length;return CinematicFrameConfidence.ENABLED?CinematicFrameConfidence.score(x,Math.abs(ma-mb)/(255*a.length),Math.sqrt(Math.max(0,sq/a.length-x*x)),q/(double)a.length,h/(double)a.length):x;}
 static long refine(long original,long[] pts,double[] score,int n,long radius){if(n<5||n>pts.length||n>score.length)return original;int best=-1;double peak=0,second=0;for(int i=0;i<n;i++){if(i>0&&pts[i]<=pts[i-1]||!Double.isFinite(score[i]))return original;if(score[i]>peak){second=peak;peak=score[i];best=i;}else second=Math.max(second,score[i]);}if(best<=0||best>=n-1||peak<.22||peak<second+.075||Math.abs(pts[best]-original)>radius)return original;return pts[best];}
}
