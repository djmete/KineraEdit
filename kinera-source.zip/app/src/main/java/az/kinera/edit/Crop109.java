package az.kinera.edit;
/** Locked 9:16 crop geometry in oriented source coordinates. No pixel decoding required. */
final class Crop109 {
 static final float RATIO=9f/16f,MIN_SCALE=.20f;
 static float ratio(float source){return RATIO/(Float.isFinite(source)&&source>0?source:1f);}
 static float maxW(float source){return Math.min(1f,ratio(source));}
 static float maxH(float source){return Math.min(1f,1f/ratio(source));}
 private static float[] box(float cx,float cy,float w,float h){float l=EditMath.clamp(cx-w/2,0,1-w),t=EditMath.clamp(cy-h/2,0,1-h);return new float[]{l,t,Math.min(1,l+w),Math.min(1,t+h)};}
 static float[] reset(float source){return box(.5f,.5f,maxW(source),maxH(source));}
 static float[] fit(float[] old,float source){if(!RegionMath.active(old))return reset(source);float w=maxW(source),h=maxH(source);float scale=EditMath.clamp(Math.min((old[2]-old[0])/w,(old[3]-old[1])/h),MIN_SCALE,1);return box((old[0]+old[2])/2,(old[1]+old[3])/2,w*scale,h*scale);}
 static int progress(float[] r,float source){if(!RegionMath.active(r))return 0;return Math.round(100*EditMath.clamp((1-(r[2]-r[0])/maxW(source))/(1-MIN_SCALE),0,1));}
 static float[] zoom(float[] r,float source,int p){r=fit(r,source);float f=1-(1-MIN_SCALE)*EditMath.clamp(p/100f,0,1);return box((r[0]+r[2])/2,(r[1]+r[3])/2,maxW(source)*f,maxH(source)*f);}
 static float[] pinch(float[] r,float source,float scale,float dx,float dy){if(!RegionMath.active(r)||!Float.isFinite(scale)||scale<=0||!Float.isFinite(dx)||!Float.isFinite(dy))return fit(r,source);float f=EditMath.clamp((r[2]-r[0])/maxW(source)*scale,MIN_SCALE,1);return box((r[0]+r[2])/2+dx,(r[1]+r[3])/2+dy,maxW(source)*f,maxH(source)*f);}
 static float[] drag(float[] r,int handle,float dx,float dy,float source){if(!RegionMath.active(r))return reset(source);if(!Float.isFinite(dx)||!Float.isFinite(dy))return r.clone();if(handle==5)return RegionMath.move(r,dx,dy);if(handle<1||handle>4)return r.clone();boolean left=handle==1||handle==3,top=handle==1||handle==2;float ax=left?r[2]:r[0],ay=top?r[3]:r[1],sx=left?-1:1,sy=top?-1:1;float mw=maxW(source),mh=maxH(source);float available=Math.min((left?ax:1-ax)/mw,(top?ay:1-ay)/mh);float old=(r[2]-r[0])/mw; // project drag onto the diagonal in physical pixels
 float dw=sx*dx*source,dh=sy*dy,pw=mw*source,ph=mh;float f=EditMath.clamp(old+(dw*pw+dh*ph)/(pw*pw+ph*ph),Math.min(MIN_SCALE,available),available);float x=ax+sx*mw*f,y=ay+sy*mh*f;return new float[]{Math.max(0,Math.min(ax,x)),Math.max(0,Math.min(ay,y)),Math.min(1,Math.max(ax,x)),Math.min(1,Math.max(ay,y))};}
 static boolean keepTemplate(float[] r){return RegionMath.active(r)&&(r[0]>.0001f||r[1]>.0001f||r[2]<.9999f||r[3]<.9999f);}
 private Crop109(){}
}
