package az.kinera.edit;
final class Professional100TemplatePolicy {
 static final int FIRST=1784,TOTAL=1834;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.010f,.020f,.990f,.980f};case 1:return new float[]{.020f,.060f,.980f,.940f};case 2:return new float[]{.020f,.230f,.980f,.770f};case 3:return new float[]{.020f,.290f,.980f,.710f};default:return new float[]{.020f,.323f,.980f,.677f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,47)!=33)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/47,10),10);}
}
