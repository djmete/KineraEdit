package az.kinera.edit;
final class Spatial137Rhythm {
 static float scale(long[] cuts,int i,long duration,long time){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long c=cuts[i],left=c-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-c;if(left<=0||right<=0)return 0;long side=time<c?left:right;if(side>=450000)return 1;double t=Math.min(1,Math.abs((double)time-c)/Math.max(1,side*.5));double shortness=1-side/450000.0;return (float)(1-.18*shortness*t*t*(3-2*t));}
 private Spatial137Rhythm(){}
}
