package az.kinera.edit;
final class Adaptive109TemplatePolicy {
 static final int FIRST=2634,TOTAL=2684;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.018f,.018f,.982f,.982f};case 1:return new float[]{.023f,.075f,.977f,.925f};case 2:return new float[]{.027f,.234f,.973f,.766f};case 3:return new float[]{.026f,.278f,.974f,.722f};default:return new float[]{.024f,.33f,.976f,.67f};}}
 static int choose(int prior,float aspect,int semantic,int palette){if(prior<2584||prior>=2634||!Float.isFinite(aspect)||aspect<=0||semantic!=CreativePolicy.PERSON)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Adaptive109TemplatePolicy(){}
}
