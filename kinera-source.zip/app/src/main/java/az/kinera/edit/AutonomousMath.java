package az.kinera.edit;
/** Conservative per-video color correction from sampled source RGB pixels. */
final class AutonomousMath {
 private AutonomousMath(){}
 static int[] grade(int[] pixels){if(pixels==null||pixels.length<16)return new int[]{50,50,50};int[] hist=new int[256];double chroma=0;for(int c:pixels){int r=(c>>16)&255,g=(c>>8)&255,b=c&255;hist[SceneMath.luma(c)]++;chroma+=Math.max(r,Math.max(g,b))-Math.min(r,Math.min(g,b));}int p10=quantile(hist,pixels.length,.10),p50=quantile(hist,pixels.length,.50),p90=quantile(hist,pixels.length,.90);if(p90-p10<20)return new int[]{50,50,50};int brightness=clamp(50+(int)Math.round((118-p50)*.17),37,63);int contrast=clamp(50+(int)Math.round((150-(p90-p10))*.06),43,57);if(p90>240&&brightness>50)brightness=50;if(p10<12&&brightness<50)brightness=50;int saturation=clamp(50+(int)Math.round((65-chroma/pixels.length)*.05),46,54);return new int[]{brightness,contrast,saturation};}
 static int quantile(int[] hist,int n,double q){int target=Math.max(1,(int)Math.ceil(n*q)),sum=0;for(int i=0;i<hist.length;i++){sum+=hist[i];if(sum>=target)return i;}return 255;}
 static int clamp(int n,int lo,int hi){return Math.max(lo,Math.min(hi,n));}
}
