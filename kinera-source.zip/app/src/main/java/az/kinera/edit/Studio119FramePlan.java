package az.kinera.edit;
/** Optional 90s full pass; strict wall-clock and thermal gates, old plan stays on partial decode. */
final class Studio119FramePlan {
 static final int MAX_FRAMES=3072;
 static boolean eligible(long d,long remaining,boolean pressure){return d<=60000000L?Cinematic118FramePlan.eligible(d,remaining,pressure):!pressure&&d<=90000000L&&remaining>=19000;}
 static long budget(long d){return d<=60000000L?Cinematic118FramePlan.budget(d):25000;}
 static long refineDeadline(long now,long deadline,long duration,boolean pressure){return duration<=60000000L?Cinematic118FramePlan.refineDeadline(now,deadline,duration,pressure):eligible(duration,deadline-now,pressure)?Math.max(now,deadline-19000):deadline;}
 static int probeLimit(long duration,long remaining,boolean pressure){return pressure||remaining<2000?0:duration>90000000L&&remaining>=8000?4:2;}
 static boolean blocked(int[] a,int[] b,double d){return Cinematic118FramePlan.blocked(a,b,d);}
 private Studio119FramePlan(){}
}
