package az.kinera.edit;
import java.util.ArrayList;
import java.util.List;
/** A single-frame review is anchored to the requested frame, never an unrelated neighbouring shot. */
final class Professional115Caption {
 static float[] review(float[] center,List<float[]> neighbors,int requested){
  if(requested<=0||!RegionMath.active(center))return RegionMath.empty();
  if(requested==1)return center.clone();
  ArrayList<float[]> valid=new ArrayList<>();valid.add(center);
  if(neighbors!=null)for(float[] r:neighbors){if(!RegionMath.active(r)||PrecisionMath.overlap(center,r)<.30f||!Context111Caption.safeArea(center,r,DenseCaptionPlan.union(center,r)))continue;valid.add(r);}
  if(valid.size()<2)return RegionMath.empty();
  // Union is tied to the requested frame, not to the largest pair of unrelated neighbours.
  float[] out=center.clone();for(int i=1;i<valid.size();i++){float[] u=DenseCaptionPlan.union(out,valid.get(i));if(Context111Caption.safeArea(center,valid.get(i),u))out=u;}
  return out;
 }
 private Professional115Caption(){}
}
