package az.kinera.edit;
/** Append only: five composition families with ten color treatments each. */
final class Advanced132TemplatePolicy {
 static final int FIRST=3534,TOTAL=3584;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=k%10*.0011f;float[][] a={{.015f,.045f,.985f,.955f},{.025f,.115f,.975f,.885f},{.035f,.175f,.965f,.825f},{.045f,.240f,.955f,.760f},{.055f,.300f,.945f,.700f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,37)!=23)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Advanced132TemplatePolicy(){}
}
