package az.kinera.edit;
final class Performance86 {
 static int samples(long d,boolean e){return e?Math.min(96,Math.max(1,1+(int)Math.min(95,Math.max(0,d-1)/650000L))):KAiEdit.analysisSamples(d);}
 static long budget(boolean e){return e?28000L:KAiEdit.SCENE_BUDGET_MS;}
 static int fps(int f,boolean e){return e?Math.min(30,f):f;}
 static int previewHeight(int h,int c,boolean e){return e&&c==0?Math.min(h,640):h;}
 static boolean restoration(EditSpec s){for(TimedRegions.Mask m:s.extraMasks)if(m.restore)return true;return false;}
}
