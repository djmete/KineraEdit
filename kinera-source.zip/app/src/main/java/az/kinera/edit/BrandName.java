package az.kinera.edit;
import java.util.Locale;
final class BrandName {
 static String clean(String input){if(input==null)return "Kinera Edit";String s=input.replaceAll("[\\p{Cntrl}]", " ").trim().replaceAll("\\s+"," ");return s.isEmpty()?"Kinera Edit":s;}
 static String initials(String input){String s=clean(input);String[] words=s.split(" ");String letters=words.length>1?first(words[0],1)+first(words[1],1):first(s,2);return letters.toUpperCase(Locale.ROOT);}
 static String first(String s,int n){return s.substring(0,s.offsetByCodePoints(0,Math.min(n,s.codePointCount(0,s.length()))));}
}
