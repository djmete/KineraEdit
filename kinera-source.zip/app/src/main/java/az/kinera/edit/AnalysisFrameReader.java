package az.kinera.edit;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
/** All supported versions (API 31+) provide scaled retrieval. */
final class AnalysisFrameReader {
 private AnalysisFrameReader(){}
 static Bitmap read(MediaMetadataRetriever r,long time,int width,int height){
  Bitmap b=null;try{b=r.getScaledFrameAtTime(Math.max(0,time),MediaMetadataRetriever.OPTION_CLOSEST,Math.max(2,width),Math.max(2,height));}catch(RuntimeException ignored){}if(b!=null)return b;try{int w=Integer.parseInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)),h=Integer.parseInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));if(w<=0||h<=0||(long)w*h>640L*480)return null;Bitmap raw=r.getFrameAtTime(Math.max(0,time),MediaMetadataRetriever.OPTION_CLOSEST);if(raw==null)return null;try{b=Bitmap.createScaledBitmap(raw,Math.max(2,width),Math.max(2,height),true);return b;}finally{if(b!=raw)raw.recycle();}}catch(RuntimeException ignored){return null;}
 }
}
