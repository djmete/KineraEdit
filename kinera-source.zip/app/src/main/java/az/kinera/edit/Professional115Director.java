package az.kinera.edit;
/** Continuous, bounded accents; no hard cuts, no time remapping, no mask geometry changes. */
final class Professional115Director {
 static float continuity(long[] cuts,int index,long duration){
  if(cuts==null||index<0||index>=cuts.length||duration<=0)return 0;
  long at=cuts[index],left=index==0?0:cuts[index-1],right=index==cuts.length-1?duration:cuts[index+1];
  if(at<=left||right<=at||left<0||right>duration)return 0;
  double a=at-left,b=right-at,shorter=Math.min(a,b),balance=shorter/Math.max(a,b);
  double x=Math.min(1,shorter/3000000d);return (float)((.60+.40*x*x*(3-2*x))*(.82+.18*Math.sqrt(balance)));
 }
 /** Use existing frame timestamps; no new decoder or frame rate conversion. */
 static long[] validateCuts(long[] cuts,long duration){return DirectorMath.clean(cuts,duration);}
 private Professional115Director(){}
}
