package az.kinera.edit;
final class Fusion104TemplatePolicy {
 static final int FIRST=2384,TOTAL=2434;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.018f,.025f,.982f,.975f};case 1:return new float[]{.02f,.085f,.98f,.915f};case 2:return new float[]{.02f,.23f,.98f,.77f};case 3:return new float[]{.018f,.27f,.982f,.73f};default:return new float[]{.018f,.325f,.982f,.675f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,19)!=11)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
}
