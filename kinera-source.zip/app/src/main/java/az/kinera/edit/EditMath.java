package az.kinera.edit;

final class EditMath {
    static float clamp(float x,float a,float b){return Math.max(a,Math.min(b,x));}
    // Normalized top-left coordinates; preserve aspect ratio in a window.
    static float[] fit(float[] box, float sourceAspect, float canvasAspect){
        if(sourceAspect<=0 || canvasAspect<=0) throw new IllegalArgumentException("aspect");
        float w=box[2]-box[0], h=box[3]-box[1];
        float wantedWidth=h*sourceAspect/canvasAspect;
        float wantedHeight=w*canvasAspect/sourceAspect;
        float fw=Math.min(w,wantedWidth),fh=Math.min(h,wantedHeight);
        float cx=(box[0]+box[2])/2,cy=(box[1]+box[3])/2;
        return new float[]{cx-fw/2,cy-fh/2,cx+fw/2,cy+fh/2};
    }
    // Center-cover in normalized source coordinates; no stretching or exposed matte.
    static float[] coverCrop(float[] crop,float[] window,float sourceAspect,float canvasAspect){
        if(!Float.isFinite(sourceAspect)||sourceAspect<=0||!Float.isFinite(canvasAspect)||canvasAspect<=0)throw new IllegalArgumentException("aspect");
        float w=crop[2]-crop[0],h=crop[3]-crop[1];
        float target=(window[2]-window[0])*canvasAspect/(window[3]-window[1]);
        if(w<=0||h<=0||target<=0)throw new IllegalArgumentException("region");
        float cw=Math.min(w,h*target/sourceAspect),ch=Math.min(h,w*sourceAspect/target);
        float x=(crop[0]+crop[2])/2,y=(crop[1]+crop[3])/2;
        return new float[]{x-cw/2,y-ch/2,x+cw/2,y+ch/2};
    }
    static float fade(long t,long duration,boolean enabled){
        if(!enabled || duration<=0)return 1;
        long edge=Math.min(300000,duration/4);
        if(edge==0)return 1;
        float x=clamp(Math.min(t,duration-t)/(float)edge,0,1);
        return x*x*(3-2*x);
    }
    static int bitrate(int h,int fps,int quality){double scale=h*h/(1280.0*1280.0);double q=quality==0?.65:quality==2?1.55:1.0;return (int)Math.max(1500000,Math.min(h<=1920?24000000:h<=2560?48000000:100000000,5000000*scale*q*Math.sqrt(fps/30.0)));}
    // Reserve space for requested encoded data, audio, mux overhead and safety margin.
    static long requiredCache(long durationUs,int videoBitrate,boolean mute){
        if(durationUs<=0||videoBitrate<=0)throw new IllegalArgumentException("export settings");
        double payload=durationUs/1000000.0*(videoBitrate+(mute?0:256000))/8.0;
        return (long)Math.min(Long.MAX_VALUE,Math.max(128L*1024*1024,payload*1.30+64L*1024*1024));
    }
    static boolean validExport(int w,int h,long actualUs,long expectedUs){
        if(w<=0||h<=0||actualUs<=0||expectedUs<=0)return false;
        return Math.abs(w/(double)h-9.0/16)<.012 && Math.abs((double)actualUs-expectedUs)<=Math.max(750000,expectedUs*.005);
    }
    static boolean matchesDimensions(int w,int h,int requestedHeight){return h==requestedHeight&&w==widthForHeight(requestedHeight);}
    static float progress(long t,long duration){return duration<=0?0:clamp(t/(float)duration,0,1);}
    static int widthForHeight(int height){return ((int)Math.round(height*9.0/16/2))*2;}
}
