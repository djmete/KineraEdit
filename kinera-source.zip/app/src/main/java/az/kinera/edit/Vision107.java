package az.kinera.edit;
/** Bound additional source sampling and preserve the last committed edit on cancelled gestures. */
final class Vision107 {
 static int rescueSourceEdge(int w,int h,int current,int attempts,long now,long deadline){int edge=Math.min(1280,Math.max(w,h));return attempts<4&&current>=960&&deadline>now&&deadline-now>=20000&&edge>current?edge:0;}
 static int rescueSide(int side,int longest,int edge){return Math.max(2,(int)Math.round((double)side*edge/Math.max(1,longest)));}
 static int sliderCommit(int committed,int pending,boolean cancelled){return cancelled||pending<0?committed:pending;}
 static int dockPadding(int height){return height<600?2:6;}
 static float zoomGuard(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length)return 0;long a=cuts[i]-(i==0?0:cuts[i-1]),b=(i==cuts.length-1?duration:cuts[i+1])-cuts[i];if(a<=0||b<=0)return 0;return (float)Math.sqrt(Math.min(a,b)/(double)Math.max(a,b));}
 private Vision107(){}
}
