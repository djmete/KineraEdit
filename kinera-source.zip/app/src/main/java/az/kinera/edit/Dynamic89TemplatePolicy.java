package az.kinera.edit;
final class Dynamic89TemplatePolicy {
 static final int FIRST=1234,TOTAL=1284;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.022f,.045f,.978f,.955f};case 1:return new float[]{.042f,.11f,.958f,.91f};case 2:return new float[]{.045f,.235f,.955f,.765f};case 3:return new float[]{.035f,.275f,.965f,.725f};default:return new float[]{.025f,.315f,.975f,.685f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,13)!=4)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/13,10),10);}
}
