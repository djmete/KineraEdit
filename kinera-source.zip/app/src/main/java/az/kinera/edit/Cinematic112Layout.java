package az.kinera.edit;
final class Cinematic112Layout {
 static int rulerStride(float width,float maxLabel,int count,float gap){if(count<=2)return 1;if(!Float.isFinite(width)||!Float.isFinite(maxLabel)||width<=0)return count-1;int slots=Math.max(1,(int)(width/Math.max(1,maxLabel+Math.max(0,gap)))-1);return Math.max(1,(int)Math.ceil((count-1)/(double)slots));}
 static boolean releaseThumbnails(int level,boolean visible,boolean decoding){return !decoding&&(level>=15||level>=10&&!visible);}
 private Cinematic112Layout(){}
}
