package az.kinera.edit;
final class Multimodal113Layout {
 static long position(long requested,long duration){return Math.max(0,Math.min(Math.max(0,duration),requested));}
 static boolean begin(boolean active,boolean valid){return !active&&valid;}
 static boolean showEndLabel(float width,float first,float last,float gap){return Float.isFinite(width)&&Float.isFinite(first)&&Float.isFinite(last)&&width>=first+last+Math.max(0,gap);}
 static boolean stackTime(int width,float font){return width<360||!Float.isFinite(font)||font>1.20f;}
 private Multimodal113Layout(){}
}
