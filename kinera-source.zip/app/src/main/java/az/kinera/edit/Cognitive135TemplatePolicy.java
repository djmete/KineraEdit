package az.kinera.edit;
final class Cognitive135TemplatePolicy {
 static final int FIRST=3684,TOTAL=3734;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=k%10*.0011f;float[][] a={{.012f,.017f,.988f,.983f},{.023f,.084f,.977f,.916f},{.033f,.157f,.967f,.843f},{.045f,.239f,.955f,.761f},{.054f,.308f,.946f,.692f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,47)!=17)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Cognitive135TemplatePolicy(){}
}
