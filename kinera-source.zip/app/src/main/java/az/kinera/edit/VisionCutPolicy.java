package az.kinera.edit;
final class VisionCutPolicy {
 static final int MAX_PROBES=12;static final long BUDGET_MS=14000L;
 static int[] indices(int count){if(count<=0)return new int[0];int n=Math.min(MAX_PROBES,count);int[] a=new int[n];if(n==1)return a;for(int i=0;i<n;i++)a[i]=(int)((long)i*(count-1)/(n-1));return a;}
 static double[] features(int[] a,int[] b){if(a==null||b==null||a.length!=2304||b.length!=2304)return null;double ma=0,mb=0,ad=0;int n=a.length;for(int i=0;i<n;i++){if(a[i]<0||a[i]>255||b[i]<0||b[i]>255)return null;ma+=a[i]/255.;mb+=b[i]/255.;ad+=Math.abs(a[i]-b[i])/255.;}ma/=n;mb/=n;double ca=0,cb=0,cov=0,res=0;for(int i=0;i<n;i++){double x=a[i]/255.-ma,y=b[i]/255.-mb;ca+=x*x;cb+=y*y;cov+=x*y;res+=Math.abs(y-x);}double sa=Math.sqrt(ca/n),sb=Math.sqrt(cb/n);return new double[]{ad/n,Math.abs(mb-ma),res/n,cov/n/Math.max(.0001,sa*sb),sa,sb};}
 static long refine(long original,long[] pts,double[] scores,boolean[] blocked,int n,long radius){long selected=SequentialCutMath.refine(original,pts,scores,n,radius);if(selected==original)return original;for(int i=0;i<n;i++)if(pts[i]==selected)return blocked[i]?original:selected;return original;}
}
