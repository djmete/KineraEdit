package az.kinera.edit;
/** New layouts; old IDs and palettes remain unchanged. */
final class Ultimate130TemplatePolicy {
 static final int FIRST=3434,TOTAL=3484;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=k%10*.0011f;float[][] w={{.009f,.020f,.991f,.980f},{.022f,.080f,.978f,.920f},{.027f,.156f,.973f,.844f},{.016f,.216f,.984f,.784f},{.030f,.282f,.970f,.718f}};float[] a=w[k/10];return new float[]{a[0]+v,a[1]+v,a[2]-v,a[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,29)!=17)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Ultimate130TemplatePolicy(){}
}
