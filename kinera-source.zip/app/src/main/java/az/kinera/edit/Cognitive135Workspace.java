package az.kinera.edit;
final class Cognitive135Workspace {
 static int valueWidth(int width,float font){int base=Motion134Workspace.valueWidth(width,font);int wanted=(int)Math.ceil(34*Math.max(1f,Math.min(2.5f,font))+12);return Math.min(Math.max(48,width-48-100-2*Motion134Workspace.sliderPadding(width)),Math.max(base,wanted));}
 static boolean scrollTools(int width,float font){return Motion134Workspace.scrollTools(width,font)||width<360&&font>=1.25f;}
 private Cognitive135Workspace(){}
}
