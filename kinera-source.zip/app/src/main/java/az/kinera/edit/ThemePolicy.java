package az.kinera.edit;
/** App-local appearance, independent of video/template colors. */
final class ThemePolicy {
 static final int STUDIO=0,AMOLED=1,DEVICE=2;
 static int sanitize(int mode){return mode>=0&&mode<=2?mode:STUDIO;}
 static boolean black(int mode,boolean night){return sanitize(mode)==AMOLED||sanitize(mode)==DEVICE&&night;}
 static int surface(int c,boolean black){if(!black||(c>>>24)!=255)return c;int r=c>>>16&255,g=c>>>8&255,b=c&255;int max=Math.max(r,Math.max(g,b));if(max>110||r>g+15&&r>b+15)return c;int y=(r*54+g*183+b*19)/256;int level=Math.max(0,Math.min(82,(int)(y*.78f)-6));return 0xff000000|level<<16|level<<8|level;}
}
