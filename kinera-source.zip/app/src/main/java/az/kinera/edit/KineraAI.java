package az.kinera.edit;
import java.util.*;
/** kAI 5.0 policy and scene confidence model: offline creative decisions with a trained shot-confidence MLP and deterministic policies. */
final class KineraAI {
 static final String VERSION="6.1";
 private KineraAI(){}
 static int exportIndex(int old){return Math.max(0,Math.min(3,old-1));}
 static int clampIndex(int value){return Math.max(0,Math.min(3,value));}
 // Preserve continuity: decor only on clear, well-separated shot boundaries.
 static long[] editorialCuts(long[] times,float[] scores,long duration){
  if(times==null||scores==null||times.length!=scores.length||duration<=0)return new long[0];
  for(int i=0;i<times.length;i++)if(times[i]<0||times[i]>=duration||(i>0&&times[i]<=times[i-1]))return new long[0];
  long[] base=SceneMath.studioCandidates(times,scores,duration); ArrayList<Long> accepted=new ArrayList<>(); ArrayList<Integer> eligible=new ArrayList<>(); double[] rank=new double[scores.length];
  // Do not add decorative effects to tightly spaced cuts. No frames are removed.
  for(long t:base){int i=Arrays.binarySearch(times,t);if(i<0)continue;float neighbor=0,peak=0;int n=0;
   for(int k=Math.max(0,i-2);k<=Math.min(scores.length-1,i+2);k++)if(k!=i&&Float.isFinite(scores[k])&&TemporalPolicy.contiguous(times,i,k)){neighbor+=scores[k];peak=Math.max(peak,scores[k]);n++;}
   if(n<2||scores[i]<Math.max(.30f,neighbor/n*1.35f)||!CutConfidence.accept(scores[i],neighbor/n,peak)||!TemporalConfidence.accept(times,scores,i))continue;
   rank[i]=scores[i]*(.65+.35*CutConfidence.probability(scores[i],neighbor/n,peak));eligible.add(i);
  }
  eligible.sort((a,b)->{int c=Double.compare(rank[b],rank[a]);return c!=0?c:Long.compare(times[a],times[b]);});
  for(int i:eligible){long t=times[i];boolean separated=true;for(long chosen:accepted)if(Math.abs(t-chosen)<3000000L){separated=false;break;}if(separated)accepted.add(t);}
  Collections.sort(accepted);long[] out=new long[accepted.size()];for(int i=0;i<out.length;i++)out[i]=accepted.get(i);return out;
 }
 static long refinedCut(long original,long[] times,float[] scores){if(times==null||scores==null||times.length!=scores.length||times.length<3)return original;for(int j=0;j<times.length;j++)if(times[j]<0||(j>0&&times[j]<=times[j-1]))return original;int best=-1;float top=0,second=0;for(int i=0;i<scores.length;i++){float v=scores[i];if(!Float.isFinite(v)||v<0||v>1)continue;if(v>top){second=top;top=v;best=i;}else second=Math.max(second,v);}return best>=0&&top>=.34f&&top-second>=.10f?times[best]:original;}
 // Balance scene votes so a single vivid scene cannot dominate the entire palette.
 static int paletteFor(int[] pixels){if(pixels==null||pixels.length==0)return 33;int global=BrandMotionMath.styleFor(pixels),blocks=pixels.length/64;if(blocks<3)return global;int[] usable=new int[blocks*64];int[] votes=new int[6];int valid=0;int[] block=new int[64];int[] family={28,29,30,32,33,35};for(int i=0;i<blocks;i++){System.arraycopy(pixels,i*64,block,0,64);if(!usablePaletteBlock(block))continue;System.arraycopy(block,0,usable,valid*64,64);valid++;int style=BrandMotionMath.styleFor(block);for(int k=0;k<family.length;k++)if(style==family[k]){votes[k]++;break;}}int best=0;for(int k=1;k<votes.length;k++)if(votes[k]>votes[best])best=k;return valid==0?33:votes[best]*2>valid?family[best]:BrandMotionMath.styleFor(Arrays.copyOf(usable,valid*64));}
 static boolean usablePaletteBlock(int[] p){int useful=0;for(int c:p){int l=SceneMath.luma(c);if(l>=18&&l<=240)useful++;}return useful>=p.length/3;}
 static int layoutFor(int color,float aspect){int family=BrandMotionMath.layoutFor(color,.75f);if(family>=42&&family<=47&&Float.isFinite(aspect)&&aspect>=1.6f)return family+30;if(family>=42&&family<=47&&Float.isFinite(aspect)&&aspect>0&&aspect<=.60f)return family+24;return BrandMotionMath.studioLayoutFor(color,aspect);}
 static int safeCount(int previous){return Math.min(100000,Math.max(0,previous)+1);}
}
