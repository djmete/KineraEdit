package az.kinera.edit;
import java.util.TreeSet;
/** Bounded, defensive marker storage. No dependence on Android runtime. */
final class ProjectMath {
 private ProjectMath(){}
 static String encode(long[] cuts){StringBuilder b=new StringBuilder();int count=0;for(long c:cuts){if(count++>=120)break;if(b.length()>0)b.append(',');b.append(c);}return b.toString();}
 static long[] decode(String text,long duration){if(text==null||text.isEmpty()||duration<=0||text.length()>4096)return new long[0];TreeSet<Long> s=new TreeSet<>();for(String part:text.split(",")){try{long n=Long.parseLong(part);if(n>=300000&&n<=duration-300000)s.add(n);}catch(NumberFormatException ignored){}if(s.size()>=120)break;}long[] out=new long[s.size()];int i=0;for(long n:s)out[i++]=n;return out;}
}
