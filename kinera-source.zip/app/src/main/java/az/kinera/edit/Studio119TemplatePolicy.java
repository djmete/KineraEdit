package az.kinera.edit;
final class Studio119TemplatePolicy {
 static final int FIRST=3134,TOTAL=3184;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));int f=k/10;float v=(k%10)*.0018f;float[][] windows={{.018f,.025f,.982f,.975f},{.027f,.11f,.973f,.89f},{.048f,.194f,.952f,.806f},{.033f,.267f,.967f,.733f},{.038f,.319f,.962f,.681f}};float[] a=windows[f];return new float[]{a[0]+v,a[1]+v,a[2]-v,a[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,13)!=6)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Studio119TemplatePolicy(){}
}
