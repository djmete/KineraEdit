package az.kinera.edit;
/** Fast monotonic scan of sorted cut timestamps; only skips work when all accent envelopes are zero. */
final class AudioAccentCursor {
 private static final long RADIUS=140000L;private final long[] cuts;private int index;private long last=-1;
 AudioAccentCursor(long[] sorted){cuts=sorted==null?new long[0]:sorted.clone();}
 void reset(){index=0;last=-1;}
 boolean active(long time){if(time<0)return false;if(time<last)reset();last=time;while(index<cuts.length&&time>cuts[index]&&time-cuts[index]>=RADIUS)index++;if(index==cuts.length)return false;long cut=cuts[index];return cut>=time?cut-time<RADIUS:time-cut<RADIUS;}
}
