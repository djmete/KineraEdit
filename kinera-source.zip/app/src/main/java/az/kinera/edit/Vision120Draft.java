package az.kinera.edit;
import java.util.*;
/** Immutable baseline for explicit Crop/Blur transactions. */
final class Vision120Draft {
 private final float[] crop,blur; final long from,until; final List<TimedRegions.Mask> masks; final int legacyBlur,legacyCrop,legacyTop;
 Vision120Draft(float[] c,float[] b,long f,long u,List<TimedRegions.Mask> m,int lb,int lc,int lt){crop=c.clone();blur=b.clone();from=f;until=u;masks=TimedRegions.snapshot(m);legacyBlur=lb;legacyCrop=lc;legacyTop=lt;}
 float[] crop(){return crop.clone();} float[] blur(){return blur.clone();}
}
