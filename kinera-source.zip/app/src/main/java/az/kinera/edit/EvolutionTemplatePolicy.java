package az.kinera.edit;
/** Five editorial compositions x ten palettes. New IDs append; no saved draft remapping. */
final class EvolutionTemplatePolicy {
 static final int FIRST=234, TOTAL=284;
 static int family(float a){if(!Float.isFinite(a)||a<=0)return 0;return a<=.68f?0:a<=.91f?1:a<=1.20f?2:a<=1.95f?3:4;}
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.016f,.132f,.984f,.925f};case 1:return new float[]{.028f,.145f,.972f,.865f};case 2:return new float[]{.025f,.215f,.975f,.749f};case 3:return new float[]{.016f,.294f,.984f,.601f};default:return new float[]{.012f,.340f,.988f,.570f};}}
 // Known semantic scenes use layouts matched to source aspect; keep document/unknown and older choices available.
 static int choose(int prior,float a,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(a)||a<=0||semantic<=0||semantic==3||Math.floorMod(seed,4)!=0)return prior;return FIRST+10*family(a)+Math.floorMod(palette+Math.floorMod(seed/4,10),10);}
}
