package az.kinera.edit;
final class Visual121Scene {
 static boolean structurePreserved(int[] a,int[] b){if(a==null||b==null||a.length!=2304||b.length!=2304)return false;double aa=0,bb=0,ab=0;int n=0;for(int y=2;y<46;y+=2)for(int x=2;x<46;x+=2){int i=y*48+x;int gx=a[i+1]-a[i-1],gy=a[i+48]-a[i-48],hx=b[i+1]-b[i-1],hy=b[i+48]-b[i-48];aa+=gx*gx+gy*gy;bb+=hx*hx+hy*hy;ab+=gx*hx+gy*hy;n+=2;}if(aa<n*36||bb<n*36)return false;return ab/Math.sqrt(aa*bb)>.985;}
 static boolean blocked(int[] a,int[] b,double d){return Studio119FramePlan.blocked(a,b,d)||(d>=.23&&structurePreserved(a,b));}
 static int probeLimit(long duration,long remaining,boolean pressure){if(pressure||remaining<2000)return 0;if(duration>90000000L&&remaining>=15000)return 8;return Vision120FramePlan.probeLimit(duration,remaining,false);}
 static long probeBudget(int count,long remaining){return count>=6?Math.min(remaining,count>=8?12000L:9000L):0;}
 private Visual121Scene(){}
}
