package az.kinera.edit;
final class Vision153Template {
 static final int FIRST=4534,TOTAL=4584;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0014f;float[][] a={{.027f,.114f,.973f,.886f},{.041f,.174f,.959f,.826f},{.057f,.228f,.943f,.772f},{.074f,.283f,.926f,.717f},{.089f,.333f,.911f,.667f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,127)!=107)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Vision153Template(){}
}
