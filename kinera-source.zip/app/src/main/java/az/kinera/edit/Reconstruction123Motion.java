package az.kinera.edit;
/** Context-only translational matching; reject ambiguous/flat/partially inconsistent results. */
final class Reconstruction123Motion {
 static boolean coherent(int[] a,int[] b){
  if(a==null||b==null||a.length!=2304||b.length!=2304)return false;
  long sum=0,sq=0;int n=0;for(int y=6;y<30;y+=2)for(int x=6;x<42;x+=2){int v=a[y*48+x];sum+=v;sq+=v*v;n++;}
  if(sq/(double)n-Math.pow(sum/(double)n,2)<200)return false;
  double raw=error(a,b,0,0,0,0),best=raw;int bx=0,by=0;
  for(int y=-4;y<=4;y++)for(int x=-4;x<=4;x++){double v=error(a,b,x,y,0,0)+.10*(Math.abs(x)+Math.abs(y));if(v<best){best=v;bx=x;by=y;}}
  if(raw<12||best>raw*.53||best>14||bx==0&&by==0)return false;
  double runner=Double.POSITIVE_INFINITY;for(int y=-4;y<=4;y++)for(int x=-4;x<=4;x++)if(Math.abs(x-bx)+Math.abs(y-by)>2)runner=Math.min(runner,error(a,b,x,y,0,0));
  if(runner-best<2)return false;
  for(int q=1;q<=4;q++)if(error(a,b,bx,by,q,0)>error(a,b,0,0,q,0)+1)return false;
  return true;
 }
 private static double error(int[] a,int[] b,int dx,int dy,int q,int ignored){long sum=0;int n=0;for(int y=6;y<30;y+=2)for(int x=6;x<42;x+=2){if(q!=0&&q!=1+(x>=24?1:0)+(y>=18?2:0))continue;sum+=Math.abs(a[y*48+x]-b[(y+dy)*48+x+dx]);n++;}return sum/(double)Math.max(n,1);}
 private Reconstruction123Motion(){}
}
