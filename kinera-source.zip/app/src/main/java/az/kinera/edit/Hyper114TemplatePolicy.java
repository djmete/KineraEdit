package az.kinera.edit;
final class Hyper114TemplatePolicy {
 static final int FIRST=2884,TOTAL=2934;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.016f,.029f,.984f,.971f};case 1:return new float[]{.024f,.052f,.976f,.948f};case 2:return new float[]{.018f,.229f,.982f,.771f};case 3:return new float[]{.026f,.273f,.974f,.727f};default:return new float[]{.014f,.336f,.986f,.664f};}}
 static int choose(int prior,float aspect,int semantic,int palette){if(prior<0||prior>=2884||!Float.isFinite(aspect)||aspect<=0||semantic!=CreativePolicy.LANDSCAPE||aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Hyper114TemplatePolicy(){}
}
