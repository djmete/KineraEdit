package az.kinera.edit;
/** Shared outer-perimeter weighting network for last-resort restoration. */
final class PerimeterRestoreConfidence {
 static final boolean ENABLED=true;
 private static final double SCALE=2.0652060169653227e-05;
 private static final short[] Q={-3860,-4532,1782,-5411,21985,-20857,-14209,-7241,-2272,9607,-19340,-6050,-15709,17572,12404,16571,-9448,1018,-12731,-7265,10242,-924,-6430,1716,4305,-6670,-1056,-2955,26906,-32760,-9363,-31583,-2742};
 static double score(double d,double g){double z=Q[32]*SCALE;for(int j=0;j<8;j++)z+=Q[24+j]*SCALE*Math.tanh((d*Q[j]+g*Q[8+j]+Q[16+j])*SCALE);return z;}
 static final String GLSL="float perimeterRestoreScore(vec2 x){float z=-0.0566279490;z+=(0.0889071190)*rtanh(dot(x,vec2(-0.0797169523,-0.0469214807))+(-0.1951206645));z+=(-0.1377492413)*rtanh(dot(x,vec2(-0.0935951367,0.1984043420))+(0.0210237973));z+=(-0.0218085755)*rtanh(dot(x,vec2(0.0368019712,-0.3994108437))+(-0.2629213780));z+=(-0.0610268378)*rtanh(dot(x,vec2(-0.1117482976,-0.1249449640))+(-0.1500372171));z+=(0.5556643309)*rtanh(dot(x,vec2(0.4540355428,-0.3244232132))+(0.2115184003));z+=(-0.6765614912)*rtanh(dot(x,vec2(-0.4307400190,0.3628980013))+(-0.0190825036));z+=(-0.1933652394)*rtanh(dot(x,vec2(-0.2934451230,0.2561681543))+(-0.1327927469));z+=(-0.6522540163)*rtanh(dot(x,vec2(-0.1495415677,0.3422252891))+(0.0354389353));return clamp(z,-8.,8.);}";
}
