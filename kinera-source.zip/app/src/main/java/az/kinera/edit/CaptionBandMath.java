package az.kinera.edit;
/** Convert source-normalized text geometry to a visible lower-band proposal. */
final class CaptionBandMath {
 static int blurPercent(float start,float top,float crop){
  if(!Float.isFinite(start)||!Float.isFinite(top)||!Float.isFinite(crop)||start<.55f||start>1f||top<0f||crop<0f)return 0;
  float visible=1f-top-crop;
  if(visible<=.1f||start>=1f-crop)return 0;
  float fraction=(1f-crop-start+.02f)/visible;
  if(fraction<=0f||fraction>.45f)return 0;
  return Math.max(1,Math.min(45,(int)Math.ceil(fraction*100f)));
 }
}
