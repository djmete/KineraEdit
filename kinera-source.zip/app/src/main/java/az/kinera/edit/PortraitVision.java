package az.kinera.edit;
import android.graphics.Bitmap;
import android.graphics.Rect;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import java.util.List;
import java.util.concurrent.TimeUnit;
/** Bundled face presence model, not identity recognition. Used only for import template hints. */
final class PortraitVision {
 static boolean present(Bitmap frame){if(frame==null||Thread.currentThread().isInterrupted())return false;
  VisualInferenceGate.Lease lease=VisualInferenceGate.tryEnter();if(lease==null)return false;
  Bitmap owned=null;FaceDetector client=null;Task<List<Face>> task=null;
  try{owned=frame.copy(Bitmap.Config.ARGB_8888,false);if(owned==null)return false;
   client=FaceDetection.getClient(new FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).setMinFaceSize(.12f).build());
   task=client.process(InputImage.fromBitmap(owned,0));List<Face> faces=Tasks.await(task,1500,TimeUnit.MILLISECONDS);
   for(Face face:faces){Rect b=face.getBoundingBox();if(CreativePolicy.significantFace(b.left,b.top,b.right,b.bottom,owned.getWidth(),owned.getHeight()))return true;}return false;
  }catch(InterruptedException e){Thread.currentThread().interrupt();return false;}catch(Exception|LinkageError e){return false;}
  finally{final Bitmap input=owned;final FaceDetector detector=client;Runnable cleanup=()->{try{if(input!=null)input.recycle();if(detector!=null)try{detector.close();}catch(RuntimeException ignored){}}finally{lease.close();}};if(task!=null&&!task.isComplete())task.addOnCompleteListener(Runnable::run,t->cleanup.run());else cleanup.run();}
 }
}
