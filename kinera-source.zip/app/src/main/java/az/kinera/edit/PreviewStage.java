package az.kinera.edit;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
/** A single layout owner: the surface and region overlay share the same exact canvas. */
final class PreviewStage extends FrameLayout {
 final FrameLayout canvas;
 private float aspect=9f/16f;
 PreviewStage(Context context){super(context);setClipChildren(true);canvas=new FrameLayout(context);canvas.setClipChildren(true);addView(canvas,new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT,Gravity.CENTER));}
 void setAspect(float ratio){if(!Float.isFinite(ratio)||ratio<=0)return;if(Math.abs(aspect-ratio)>.0001f){aspect=ratio;requestLayout();}}
 @Override protected void onMeasure(int widthSpec,int heightSpec){
  int w=View.MeasureSpec.getSize(widthSpec),h=View.MeasureSpec.getSize(heightSpec);setMeasuredDimension(w,h);
  int[] d=w<=0||h<=0?new int[]{0,0}:VisionMath.fit(w,h,aspect);canvas.measure(View.MeasureSpec.makeMeasureSpec(d[0],View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(d[1],View.MeasureSpec.EXACTLY));
  for(int i=0;i<getChildCount();i++){View child=getChildAt(i);if(child!=canvas&&child.getVisibility()!=GONE)measureChildWithMargins(child,widthSpec,0,heightSpec,0);}
 }
 @Override protected void onLayout(boolean changed,int left,int top,int right,int bottom){
  int x=(getWidth()-canvas.getMeasuredWidth())/2,y=(getHeight()-canvas.getMeasuredHeight())/2;canvas.layout(x,y,x+canvas.getMeasuredWidth(),y+canvas.getMeasuredHeight());
  for(int i=0;i<getChildCount();i++){View child=getChildAt(i);if(child==canvas||child.getVisibility()==GONE)continue;LayoutParams lp=(LayoutParams)child.getLayoutParams();int cx=Math.max(0,getWidth()-child.getMeasuredWidth()-lp.rightMargin),cy=Math.max(0,Math.min(lp.topMargin,getHeight()-child.getMeasuredHeight()));child.layout(cx,cy,cx+child.getMeasuredWidth(),cy+child.getMeasuredHeight());}
 }
}
