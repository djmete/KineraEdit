package az.kinera.edit;
/** Stable one-row blur controls. Layout depends on actual available height, not video aspect. */
final class Studio119Workspace {
 static int sliderPadding(int w){return w<340?5:12;}
 static int valueWidth(int w,float font){return w<300?42:w<380?48:font>1.4f?64:54;}
 static boolean compact(int h,int w,float font){return h<640||w<340||font>1.3f;}
 static boolean metadata(int h,int mode,boolean focus,float font){return !focus&&mode<=0&&h>=800&&font<=1.3f;}
 static int liveInterval(boolean playing,boolean pressure){return pressure?360:playing?115:80;}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return last<0||now<last||now-last>=liveInterval(playing,pressure);}
 private Studio119Workspace(){}
}
