package az.kinera.edit;
final class Evolution150Workspace {
 static boolean film(int h,int w,int mode,boolean focus,float f){return !focus&&mode<=0&&w>=360&&h>=760&&Float.isFinite(f)&&f<=1.2f;}
 static boolean audio(int h,int w,int mode,boolean focus,float f){return film(h,w,mode,focus,f)&&h>=940;}
 static boolean seek(int h,int w,int mode,boolean focus,float f){return !focus&&h>=(mode>0?620:400)&&(!film(h,w,mode,focus,f)||mode>0);}
 static int filmHeight(int h){return h<900?56:72;}
 private Evolution150Workspace(){}
}
