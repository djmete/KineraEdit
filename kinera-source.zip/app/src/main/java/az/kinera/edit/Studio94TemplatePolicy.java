package az.kinera.edit;
final class Studio94TemplatePolicy {
 static final int FIRST=1484,TOTAL=1534;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.016f,.028f,.984f,.972f};case 1:return new float[]{.030f,.084f,.970f,.916f};case 2:return new float[]{.028f,.2345f,.972f,.7655f};case 3:return new float[]{.024f,.294f,.976f,.706f};default:return new float[]{.02f,.324f,.98f,.676f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,23)!=15)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/23,10),10);}
}
