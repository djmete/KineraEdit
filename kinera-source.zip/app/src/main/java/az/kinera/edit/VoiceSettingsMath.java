package az.kinera.edit;
final class VoiceSettingsMath {
 static boolean useForClip(boolean enabled,boolean installed,long durationUs){return enabled&&installed&&durationUs>0&&durationUs<=600000000L;}
}
