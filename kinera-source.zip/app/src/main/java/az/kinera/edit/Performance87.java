package az.kinera.edit;
/** Pure, testable resource policy. Thermal statuses follow Android PowerManager (0..6). */
final class Performance87 {
 static final long POLL_MS=1000, UI_INTERVAL_MS=1200, SEVERE_GRACE_MS=15000;
 static boolean refuseStart(int thermal,boolean lowMemory){return thermal>=3||lowMemory;}
 static boolean stop(int thermal,long severeFor,boolean lowMemory){return thermal>=4||(thermal>=3&&severeFor>=SEVERE_GRACE_MS)||lowMemory;}
 static boolean publish(long now,long last,boolean changed){return changed||last<0||now-last>=UI_INTERVAL_MS;}
 static int refineLimit(boolean efficient){return efficient?6:40;}
 static int[] probes(int count,int limit){int n=Math.min(Math.max(0,count),Math.max(0,limit));int[] x=new int[n];if(n>1)for(int i=0;i<n;i++)x[i]=(int)((long)i*(count-1)/(n-1));return x;}
 static long overlayPixels(int w,int h){return Math.max(0L,(long)w*h);}
}
