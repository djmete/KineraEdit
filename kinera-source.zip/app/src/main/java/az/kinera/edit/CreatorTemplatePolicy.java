package az.kinera.edit;
final class CreatorTemplatePolicy {
 static final int FIRST=216,COUNT=222;
 static int choose(int prior,float aspect,int semantic,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==0||semantic==3||Math.floorMod(seed,7)!=4)return prior;return FIRST+2*(aspect<=.82f?0:aspect>=1.30f?1:2)+Math.floorMod(seed/7,2);}
 static float[] window(int id){int family=(id-FIRST)/2;return family==0?new float[]{.018f,.115f,.982f,.925f}:family==1?new float[]{.015f,.29f,.985f,.72f}:new float[]{.022f,.185f,.978f,.82f};}
}
