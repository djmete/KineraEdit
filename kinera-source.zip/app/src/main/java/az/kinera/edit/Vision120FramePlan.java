package az.kinera.edit;
final class Vision120FramePlan {
 static int probeLimit(long duration,long remaining,boolean pressure){if(pressure||remaining<2000)return 0;if(duration>90000000L&&remaining>=12000)return 6;return Studio119FramePlan.probeLimit(duration,remaining,false);}
 private Vision120FramePlan(){}
}
