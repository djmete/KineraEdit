package az.kinera.edit;
final class Motion102TemplatePolicy {
 static final int FIRST=1984,MOTION_FIRST=2034,TOTAL=2334;
 static int family(int id){return id>=MOTION_FIRST?Math.max(0,Math.min(4,(id-MOTION_FIRST)/60)):Math.max(0,Math.min(4,(id-FIRST)/10));}
 static float[] window(int id){switch(family(id)){case 0:return new float[]{.035f,.065f,.965f,.935f};case 1:return new float[]{.03f,.11f,.97f,.89f};case 2:return new float[]{.03f,.225f,.97f,.775f};case 3:return new float[]{.025f,.285f,.975f,.715f};default:return new float[]{.025f,.325f,.975f,.675f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3)return prior;int f=Director72TemplatePolicy.family(aspect),slot=Math.floorMod(seed,17);if(slot==10)return FIRST+10*f+Math.floorMod(palette,10);if(slot==11||slot==12)return MOTION_FIRST+60*f+3*Math.floorMod(seed/17,20)+Math.floorMod(palette,3);return prior;}
}
