package az.kinera.edit;
final class Expert151Director {
 static float continuity(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 1f;long a=cuts[i]-(i==0?0:cuts[i-1]),b=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(a<=0||b<=0||Math.max(a,b)>1800000L)return 1f;long before=i>0?cuts[i-1]-(i>1?cuts[i-2]:0):Long.MAX_VALUE;long after=i+1<cuts.length?(i+2<cuts.length?cuts[i+2]:duration)-cuts[i+1]:Long.MAX_VALUE;if(Math.min(before,after)>1800000L||Math.min(before,after)<=0)return 1f;return .8f+.2f*Math.min(1f,Math.min(a,b)/1800000f);}
 private Expert151Director(){}
}
