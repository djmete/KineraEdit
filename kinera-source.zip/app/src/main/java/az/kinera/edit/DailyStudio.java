package az.kinera.edit;
import android.content.*;import java.time.LocalDate;
/** Visible, optional device-local counter. Counts verified exports, not employee activity. */
final class DailyStudio {
 static String day(){return LocalDate.now().toString();}
 static int count(SharedPreferences p){return day().equals(p.getString("studio_day_v38",""))?p.getInt("studio_count_v38",0):0;}
 static void record(SharedPreferences p){p.edit().putString("studio_day_v38",day()).putInt("studio_count_v38",KineraAI.safeCount(count(p))).apply();}
 private static String key(String channel){return "studio_channel_v44:"+BrandName.clean(channel);}
 static int channelCount(SharedPreferences p,String channel){return day().equals(p.getString("studio_day_v44",""))?Math.max(0,p.getInt(key(channel),0)):0;}
 static void recordChannel(SharedPreferences p,String channel){String date=day();SharedPreferences.Editor e=p.edit();int n=channelCount(p,channel);if(!date.equals(p.getString("studio_day_v44","")))for(String k:p.getAll().keySet())if(k.startsWith("studio_channel_v44:"))e.remove(k);e.putString("studio_day_v44",date).putInt(key(channel),KineraAI.safeCount(n)).apply();}
 static void rename(SharedPreferences p,String old,String next){if(key(old).equals(key(next)))return;int n=channelCount(p,old);p.edit().remove(key(old)).putInt(key(next),n).apply();}
 static void remove(SharedPreferences p,String channel){p.edit().remove(key(channel)).apply();}
 static String summary(SharedPreferences p){int n=count(p);return String.format(java.util.Locale.ROOT,UiLanguage.tr("Bu gün %d video hazırdır. Şəxsi hədəfə qalan: %d."),n,Math.max(0,5-n));}
}
