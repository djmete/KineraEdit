package az.kinera.edit;
final class StudioMath {
 private StudioMath() {}
 static long estimatedBytes(long durationUs,int bitrate,boolean mute){
  if(durationUs<=0||bitrate<=0)return 0;
  return (long)Math.min(Long.MAX_VALUE,Math.ceil(durationUs/1e6*(bitrate+(mute?0:256000))/8.0));
 }
 static int artHeight(int height,int maxTexture){
  if(height<=0||maxTexture<2)throw new IllegalArgumentException("texture size");
  return Math.min(Math.min(height,1920),maxTexture);
 }
 static float safeCropBottom(float top,float bottom){return EditMath.clamp(bottom,0,Math.min(.45f,.65f-EditMath.clamp(top,0,.35f)));}
 static boolean sourceUpscaled(int sourceW,int sourceH,int outputH){
  if(sourceW<=0||sourceH<=0)return false;
  return outputH>Math.max(sourceW,sourceH);
 }
 static boolean keepPrevious(boolean complete,boolean valid,boolean nonEmpty){return !(complete&&valid&&nonEmpty);}
 static long[] toggleCut(long[] cuts,long time,long duration){
  if(time<300000||time>duration-300000)return cuts.clone();
  java.util.TreeSet<Long> out=new java.util.TreeSet<>();Long nearest=null;long delta=250001;
  for(long c:cuts){if(c>=300000&&c<=duration-300000){out.add(c);if(Math.abs(c-time)<delta){delta=Math.abs(c-time);nearest=c;}}}
  if(nearest!=null)out.remove(nearest);else if(out.size()<120)out.add(time);
  long[] result=new long[out.size()];int i=0;for(long c:out)result[i++]=c;return result;
 }
}
