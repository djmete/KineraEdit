package az.kinera.edit;
final class ImportMath {
 static final int MAX_SAMPLES=64;
 static long sampleStep(long durationUs){return Math.max(750000,Math.max(0,durationUs)/MAX_SAMPLES+(Math.max(0,durationUs)%MAX_SAMPLES==0?0:1));}
 static int sampleCount(long durationUs){return (int)Math.min(MAX_SAMPLES,Math.max(0,durationUs)/sampleStep(durationUs));}
}
