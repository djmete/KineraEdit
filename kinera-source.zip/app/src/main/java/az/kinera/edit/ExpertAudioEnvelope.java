package az.kinera.edit;
/** Bounded PCM timeline. Unobserved windows are unknown, never silence. */
final class ExpertAudioEnvelope {
 static final int BINS=300;static final long BIN_US=100000L;
 private final double[] sum=new double[BINS];private final int[] count=new int[BINS];
 void add(long time,float value){if(time<0||time/BIN_US>=BINS||!Float.isFinite(value))return;int i=(int)(time/BIN_US);double v=Math.max(-1,Math.min(1,value));sum[i]+=v*v;count[i]++;}
 double rms(int i){return i<0||i>=BINS||count[i]<64?Double.NaN:Math.sqrt(sum[i]/count[i]);}
 double[] features(long time){if(time<0||time/BIN_US>=BINS)return null;int i=(int)(time/BIN_US);double a=(rms(i-2)+rms(i-1))/2,b=(rms(i+1)+rms(i+2))/2;if(!Double.isFinite(a)||!Double.isFinite(b))return null;return new double[]{Math.abs(a-b),Math.max(a,b)};}
 static double rawDistance(int[] a,int[] b){if(a==null||b==null||a.length!=2304||b.length!=2304)return 0;double d=0;for(int i=0;i<a.length;i++)d+=Math.abs(a[i]-b[i])/255.;return d/a.length;}
 static double bonus(double distance,double returning,double[] audio){if(audio==null||audio.length!=2||!Double.isFinite(distance)||!Double.isFinite(returning)||!Double.isFinite(audio[0])||!Double.isFinite(audio[1])||distance<.24||returning<.20||audio[0]<.10||audio[1]<.15)return 0;double[] x={distance,returning,audio[0],audio[1]};if(ExpertAVConfidence.ENABLED&&ExpertAVConfidence.score(x)<ExpertAVConfidence.THRESHOLD)return 0;return Math.min(.025,.05*audio[0]);}
}
