package az.kinera.edit;
/** Shared corner weighting network for last-resort restoration. */
final class CornerRestoreConfidence {
 static final boolean ENABLED=true;
 private static final double SCALE=1.3497641250939025e-05;
 private static final short[] Q={-1318,-2842,-16354,-1385,-11043,7749,4359,-19829,-14393,29853,8251,20068,4343,22644,24408,-18476,-17841,19350,6593,-1416,-2892,-7499,-5946,-8366,5653,-32760,-588,-20340,-683,-15416,-24968,16092,17171};
 static double score(double d,double g){double z=Q[32]*SCALE;for(int j=0;j<8;j++)z+=Q[24+j]*SCALE*Math.tanh((d*Q[j]+g*Q[8+j]+Q[16+j])*SCALE);return z;}
 static final String GLSL="float cornerRestoreScore(vec2 x){float z=0.2317679979;z+=(0.0763021660)*rtanh(dot(x,vec2(-0.0177898912,-0.1942715505))+(-0.2408114176));z+=(-0.4421827274)*rtanh(dot(x,vec2(-0.0383602964,0.4029450843))+(0.2611793582));z+=(-0.0079366131)*rtanh(dot(x,vec2(-0.2207404250,0.1113690380))+(0.0889899488));z+=(-0.2745420230)*rtanh(dot(x,vec2(-0.0186942331,0.2708706646))+(-0.0191126600));z+=(-0.0092188890)*rtanh(dot(x,vec2(-0.1490544523,0.0586202560))+(-0.0390351785));z+=(-0.2080796375)*rtanh(dot(x,vec2(0.1045932221,0.3056405885))+(-0.1012188117));z+=(-0.3370091068)*rtanh(dot(x,vec2(0.0588362182,0.3294504277))+(-0.0802569749));z+=(0.2172040430)*rtanh(dot(x,vec2(-0.2676447284,-0.2493824198))+(-0.1129212667));return clamp(z,-8.,8.);}";
}
