package az.kinera.edit;
/** Prevent a compatible ordinary-blur union from expanding far beyond either observation. */
final class Context111Caption {
 static float area(float[] r){return RegionMath.active(r)?(r[2]-r[0])*(r[3]-r[1]):0;}
 static boolean safeArea(float[] a,float[] b,float[] u){float max=Math.max(area(a),area(b));return max>0&&area(u)<=1.28f*max;}
 private Context111Caption(){}
}
