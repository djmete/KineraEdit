package az.kinera.edit;
final class Ultimate130Caption {
 static double area(float[] a){return (double)(a[2]-a[0])*(a[3]-a[1]);}
 static float[] stabilize(float[] a,float[] b){float[] u=Director124Caption.stabilize(a,b);if(!RegionMath.active(a)||!RegionMath.active(b)||!RegionMath.active(u))return u;
 double intersection=Math.max(0,Math.min(a[2],b[2])-Math.max(a[0],b[0]))*Math.max(0,Math.min(a[3],b[3])-Math.max(a[1],b[1]));double iou=intersection/Math.max(1e-9,area(a)+area(b)-intersection);double cap=area(a)*(iou>=.85?1.12:iou>=.70?1.09:1.06);
 if(area(u)<=cap)return u;double lo=0,hi=1;float[] result=a.clone();for(int i=0;i<20;i++){double f=(lo+hi)/2;float[] p=new float[4];for(int k=0;k<4;k++)p[k]=(float)(a[k]+f*(u[k]-a[k]));if(area(p)<=cap){lo=f;result=p;}else hi=f;}return result;}
 private Ultimate130Caption(){}
}