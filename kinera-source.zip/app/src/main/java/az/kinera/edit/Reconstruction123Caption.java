package az.kinera.edit;
/** Preserve the current OCR anchor; bound neighbor-driven excess area. This is not OCR itself. */
final class Reconstruction123Caption {
 static float[] stabilize(float[] anchor,float[] candidate){
  if(!RegionMath.active(anchor))return RegionMath.empty();
  float[] r=Adaptive122Caption.stabilize(anchor,candidate);
  if(!RegionMath.active(r))return anchor.clone();
  float[] u={Math.min(anchor[0],r[0]),Math.min(anchor[1],r[1]),Math.max(anchor[2],r[2]),Math.max(anchor[3],r[3])};
  double a=area(anchor);if(area(u)<=a*1.12)return u;
  double low=0,high=1;for(int i=0;i<16;i++){double f=(low+high)*.5;if(area(interpolate(anchor,u,f))<=a*1.12)low=f;else high=f;}
  return interpolate(anchor,u,low);
 }
 private static double area(float[] b){return (double)(b[2]-b[0])*(b[3]-b[1]);}
 private static float[] interpolate(float[] a,float[] b,double f){float[] out=new float[4];for(int i=0;i<4;i++)out[i]=(float)(a[i]+(b[i]-a[i])*f);return out;}
 private Reconstruction123Caption(){}
}
