package az.kinera.edit;
/** Append-only, source-aspect driven collection. */
final class ProfessionalTemplatePolicy {
 static final int FIRST=204,COUNT=210;
 static int choose(int previous,float aspect,int semantic,int seed){if(previous<0||previous>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==0||semantic==3||Math.floorMod(seed,5)!=2)return previous;return FIRST+2*(aspect<=.82f?0:aspect>=1.30f?1:2)+Math.floorMod(seed/5,2);}
 static float[] window(int id){int family=(id-FIRST)/2;return family==0?new float[]{.015f,.115f,.985f,.915f}:family==1?new float[]{.015f,.265f,.985f,.735f}:new float[]{.025f,.19f,.975f,.805f};}
}
