package az.kinera.edit;
final class Context111Layout {
 static boolean filmstrip(int height,int mode,boolean focus,float font){return DeepEditorLayout.showFilmstrip(height,mode,focus)&&height>=680&&Float.isFinite(font)&&font<=1.25f;}
 static boolean seek(int height,int mode,boolean focus,float font){return !focus&&height>=470&&(mode==1||mode==2||DeepEditorLayout.showSeek(height,mode,false))&&!filmstrip(height,mode,focus,font);}
 static int playbackHeight(int height){return 48;}
 private Context111Layout(){}
}
