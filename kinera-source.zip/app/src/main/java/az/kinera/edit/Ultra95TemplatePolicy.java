package az.kinera.edit;
final class Ultra95TemplatePolicy {
 static final int FIRST=1534,TOTAL=1584;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.022f,.988f,.978f};case 1:return new float[]{.024f,.076f,.976f,.924f};case 2:return new float[]{.022f,.231125f,.978f,.768875f};case 3:return new float[]{.018f,.291f,.982f,.709f};default:return new float[]{.016f,.3225f,.984f,.6775f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,29)!=17)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/29,10),10);}
}
