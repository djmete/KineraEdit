package az.kinera.edit;
/** Shared, deterministic preview geometry and automatic editorial choice. */
final class VisionMath {
 private VisionMath(){}
 static int[] fit(int w,int h,float aspect){if(w<=0||h<=0)return new int[]{0,0};if(!Float.isFinite(aspect)||aspect<=0)aspect=9f/16f;int cw=Math.max(1,Math.min(w,Math.round(h*aspect)));int ch=Math.max(1,Math.min(h,Math.round(cw/aspect)));return new int[]{cw,ch};}
 static int chooseTemplate(int[] pixels,int palette,float aspect,int fallback){int hash=0x811c9dc5,n=0;if(pixels!=null)for(int rgb:pixels){int q=((rgb>>19)&31)<<10|((rgb>>11)&31)<<5|((rgb>>3)&31);hash=(hash^q)*0x01000193;n++;}int family=BrandMotionMath.layoutFor(palette,.75f)-42;if(family<0||family>5)family=4;int[] bases=aspect>=1.25f?new int[]{72,102,120,132}:aspect<=.65f?new int[]{66,108,114,126}:new int[]{60,78,90,96,114,126};int seed=n==0?fallback:hash;return bases[Math.floorMod(seed,bases.length)]+family;}
 static float[] sweptMask(float[] a,float[] b){return new float[]{Math.max(0,Math.min(a[0],b[0])-.008f),Math.max(0,Math.min(a[1],b[1])-.008f),Math.min(1,Math.max(a[2],b[2])+.008f),Math.min(1,Math.max(a[3],b[3])+.008f)};}
 static float[] sweptThree(float[] a,float[] b,float[] c){return new float[]{Math.max(0,Math.min(a[0],Math.min(b[0],c[0]))-.008f),Math.max(0,Math.min(a[1],Math.min(b[1],c[1]))-.008f),Math.min(1,Math.max(a[2],Math.max(b[2],c[2]))+.008f),Math.min(1,Math.max(a[3],Math.max(b[3],c[3]))+.008f)};}
 static boolean hasMasks(EditSpec spec){return RegionMath.active(spec.blurRect)||!spec.extraMasks.isEmpty();}
 static float zoom(EditSpec spec,long time){return hasMasks(spec)?1f:SceneMath.zoom(time,spec.cuts);}
}
