package az.kinera.edit;
import java.util.*;
/** Full duration sampling, not frame-by-frame detection. Half-open intervals. */
final class FullCaptionPlan {
 static int windows(long duration){return duration<=0?0:(int)Math.min(TimedRegions.MAX,1+(duration-1)/1000000L);}
 static long boundary(long duration,int i,int n){if(duration<=0||n<1||i<0||i>n)throw new IllegalArgumentException("window");return (duration/n)*i+(duration%n)*i/n;}
 static long sample(long duration,int i,int n){long a=boundary(duration,i,n),b=boundary(duration,i+1,n);return a+(b-a)/2;}
 static boolean merge(float[] a,float[] b){if(!RegionMath.active(a)||!RegionMath.active(b))return false;double wa=a[2]-a[0],wb=b[2]-b[0],ha=a[3]-a[1],hb=b[3]-b[1];double ox=Math.max(0,Math.min(a[2],b[2])-Math.max(a[0],b[0]))/Math.min(wa,wb),oy=Math.max(0,Math.min(a[3],b[3])-Math.max(a[1],b[1]))/Math.min(ha,hb);double dy=Math.abs(((double)a[1]+a[3]-b[1]-b[3])/2),uh=Math.max(a[3],b[3])-Math.min(a[1],b[1]),uw=Math.max(a[2],b[2])-Math.min(a[0],b[0]);return ox>=.25&&oy>=.5&&dy<=.045&&uh<=.20&&uw<=.98&&(!CaptionLaneConfidence.ENABLED||CaptionLaneConfidence.score(new double[]{ox,oy,dy,uh,uw,Math.abs(ha-hb)})>=.85);}
 static List<TimedRegions.Mask> build(long duration,List<float[]> regions){int n=windows(duration);if(n==0||regions==null||regions.size()!=n)throw new IllegalArgumentException("incomplete scan");List<TimedRegions.Mask> out=new ArrayList<>();for(int i=0;i<n;i++){float[] r=regions.get(i);if(!RegionMath.active(r))continue;long from=boundary(duration,i,n),until=boundary(duration,i+1,n);if(until<=from)continue;if(!out.isEmpty()){TimedRegions.Mask last=out.get(out.size()-1);float[] a=last.rect();if(last.until==from&&merge(a,r)){out.set(out.size()-1,new TimedRegions.Mask(new float[]{Math.min(a[0],r[0]),Math.min(a[1],r[1]),Math.max(a[2],r[2]),Math.max(a[3],r[3])},last.from,until,true));continue;}}out.add(new TimedRegions.Mask(r,from,until,true));}return TimedRegions.snapshot(out);}
 static List<TimedRegions.Mask> fixed(long duration,float[] r){if(duration<=0||!RegionMath.active(r))throw new IllegalArgumentException("region");return TimedRegions.snapshot(Collections.singletonList(new TimedRegions.Mask(r,0,duration,true)));}
 static long covered(List<TimedRegions.Mask> masks){long n=0;for(TimedRegions.Mask m:masks)n+=m.until-m.from;return n;}
}
