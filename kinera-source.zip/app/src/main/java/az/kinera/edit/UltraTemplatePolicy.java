package az.kinera.edit;
/** Stable new layout IDs; old IDs remain valid. */
final class UltraTemplatePolicy {
 static int choose(int previous,float aspect,int semantic,int seed){if(previous<0||previous>=174||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,3)!=0)return previous;return 174+2*(aspect<=.82f?0:aspect>=1.30f?1:2)+Math.floorMod(seed/3,2);}
 static float[] window(int style){int family=Math.max(0,Math.min(2,(style-174)/2));return family==0?new float[]{.025f,.135f,.975f,.895f}:family==1?new float[]{.02f,.275f,.98f,.66f}:new float[]{.035f,.205f,.965f,.775f};}
}
