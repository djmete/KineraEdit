package az.kinera.edit;
final class ReliabilityCutMath {
 private ReliabilityCutMath(){}
 static long refine(long original,long[] pts,double[] scores,boolean[] blocked,int n,long radius){
  if(pts==null||scores==null||blocked==null||n<5||n>pts.length||n>scores.length||n>blocked.length||radius<=0||!Cinematic83Math.ordered(pts,scores,n))return original;
  long candidate=VisionCutPolicy.refine(original,pts,scores,blocked,n,radius);if(candidate==original)return original;
  int i=java.util.Arrays.binarySearch(pts,0,n,candidate);if(i<2||i>=n-2)return original;
  long before=pts[i]-pts[i-1],after=pts[i+1]-pts[i];if(before<=0||after<=0||before>150000||after>150000||Math.max(before,after)>3L*Math.min(before,after))return original;
  if(blocked[i-1]||blocked[i+1])return original;
  double baseline=Math.max(scores[i-1],scores[i+1]);return baseline<=.16&&scores[i]>=baseline+.12?candidate:original;
 }
}
