package az.kinera.edit;
import java.io.*;
/** Runs the bundled compact model against known reference outputs. No video decode. */
final class Vision107Diagnostics {
 static double check(InputStream weights,InputStream fixture)throws IOException{
  Architecture105Inference model=new Architecture105Inference(weights);DataInputStream d=new DataInputStream(fixture);int n=d.readInt();if(n!=2)throw new IOException("fixture count");float[][] x=new float[n][Architecture105Inference.INPUT];for(float[] a:x)for(int i=0;i<a.length;i++)a[i]=d.readFloat();double max=0;
  for(float[] a:x){float[] v=model.infer(a);for(int i=0;i<v.length;i++){float ref=d.readFloat();if(!Float.isFinite(ref)||!Float.isFinite(v[i]))throw new IOException("nonfinite output");max=Math.max(max,Math.abs(v[i]-ref));if(a[9*1024+i%1024]==0&&v[i]!=a[i])throw new IOException("visible pixel modified");}}
  if(d.read()!=-1||max>2e-5)throw new IOException("model parity "+max);return max;
 }
 private Vision107Diagnostics(){}
}
