package az.kinera.edit;
import java.util.*;
/** Spatial restoration needs a pair of uncontaminated opposite boundaries. Never invent untracked time. */
final class RestorePolicy {
 static boolean usable(float[] r){return RegionMath.active(r)&&((r[0]>.002f&&r[2]<.998f)||(r[1]>.002f&&r[3]<.998f))&&(r[2]-r[0])*(r[3]-r[1])<=.45f;}
 static List<TimedRegions.Mask> convert(List<TimedRegions.Mask> masks){ArrayList<TimedRegions.Mask> out=new ArrayList<>();for(TimedRegions.Mask m:masks){if(!usable(m.rect()))break;out.add(new TimedRegions.Mask(m.rect(),m.from,m.until,true));}return TimedRegions.snapshot(out);}
 static boolean legacy(String mime,int w,int h,float fps){return "video/3gpp".equals(mime)||"video/mp4v-es".equals(mime)||w>0&&h>0&&Math.min(w,h)<=240||Float.isFinite(fps)&&fps>0&&fps<=15;}
 static int previewHeight(int requested,boolean legacy){return legacy?Math.min(480,requested):requested;}
}
