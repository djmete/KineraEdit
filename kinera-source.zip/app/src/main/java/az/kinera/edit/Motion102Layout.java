package az.kinera.edit;
/** Four equal targets on normal phones; scroll only when accessibility text needs it. */
final class Motion102Layout {
 static boolean scrollTools(int width,float font){return width<320||!Float.isFinite(font)||font>1.20f;}
 static int toolWidth(float font){return Math.max(84,Math.min(160,Math.round(84*Math.max(1,Float.isFinite(font)?font:1))));}
 static int toolExtra(int height,boolean compact){return compact||height<680?6:10;}
}
