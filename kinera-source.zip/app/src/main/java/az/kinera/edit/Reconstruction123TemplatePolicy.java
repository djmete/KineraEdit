package az.kinera.edit;
final class Reconstruction123TemplatePolicy {
 static final int FIRST=3334,TOTAL=3384;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0011f;float[][] w={{.018f,.018f,.982f,.982f},{.024f,.084f,.976f,.916f},{.038f,.162f,.962f,.838f},{.024f,.232f,.976f,.768f},{.044f,.298f,.956f,.702f}};float[] a=w[k/10];return new float[]{a[0]+v,a[1]+v,a[2]-v,a[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,19)!=7)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Reconstruction123TemplatePolicy(){}
}
