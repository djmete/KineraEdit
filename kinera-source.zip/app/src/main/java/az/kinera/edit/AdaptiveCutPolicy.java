package az.kinera.edit;
final class AdaptiveCutPolicy {
 static final int MAX_PROBES=16;static final long BUDGET_MS=18000L;
 static int[] indices(int count){if(count<=0)return new int[0];int n=Math.min(count,MAX_PROBES);int[] a=new int[n];if(n>1)for(int i=0;i<n;i++)a[i]=(int)((long)i*(count-1)/(n-1));return a;}
 static double[] features(int[] a,int[] b,int[] c){if(a==null||b==null||c==null||a.length!=2304||b.length!=2304||c.length!=2304)return null;double ab=0,bc=0,ac=0,ma=0,mb=0;int n=a.length;for(int i=0;i<n;i++){if(a[i]<0||a[i]>255||b[i]<0||b[i]>255||c[i]<0||c[i]>255)return null;double x=(b[i]-a[i])/255.,y=(c[i]-b[i])/255.;ab+=Math.abs(x);bc+=Math.abs(y);ac+=Math.abs(x+y);ma+=x;mb+=y;}ma/=n;mb/=n;double ra=0,rb=0;for(int i=0;i<n;i++){ra+=Math.abs((b[i]-a[i])/255.-ma);rb+=Math.abs((c[i]-b[i])/255.-mb);}return new double[]{ab/n,bc/n,ac/n,ma,mb,ra/n,rb/n};}
 static boolean pulse(int[] a,int[] b,int[] c,double incoming,double outgoing){return incoming>=.16&&outgoing>=.16&&AdaptivePulseConfidence.reject(features(a,b,c));}
}
