package az.kinera.edit;
final class Expert151Export {
 static int percent(int v){return Math.max(0,Math.min(100,v));}
 static boolean animate(int previous,int next,boolean enabled){return enabled&&next>previous&&next-previous<=20;}
 static long elapsed(long now,long start){return start<=0||now<start?0:now-start;}
 static int sidePadding(int width){return width<360?16:24;}
 static int gap(int height){return height<520?8:height<720?16:24;}
 private Expert151Export(){}
}
