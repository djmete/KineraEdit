package az.kinera.edit;
/** Five source-aspect compositions with ten coordinated palettes. No draft ID remapping. */
final class MasterTemplatePolicy {
 static final int FIRST=284,TOTAL=334;
 static int family(float a){if(!Float.isFinite(a)||a<=0)return 0;return a<=.68f?0:a<=.92f?1:a<=1.20f?2:a<=2f?3:4;}
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.112f,.988f,.938f};case 1:return new float[]{.018f,.134f,.982f,.854f};case 2:return new float[]{.018f,.208f,.982f,.749f};case 3:return new float[]{.012f,.276f,.988f,.585f};default:return new float[]{.012f,.344f,.988f,.572f};}}
 static int choose(int prior,float a,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(a)||a<=0||semantic<=0||semantic==3||Math.floorMod(seed,5)!=0)return prior;return FIRST+10*family(a)+Math.floorMod(palette+Math.floorMod(seed/5,10),10);}
}
