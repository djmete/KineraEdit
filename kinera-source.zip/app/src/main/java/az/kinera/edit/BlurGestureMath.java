package az.kinera.edit;
final class BlurGestureMath {
 static int axis(int selection){switch(selection){case 0:return 2;case 1:return 3;case 2:return 4;case 3:return 0;case 4:return 1;default:return 2;}}
 static float[] drag(float[] start,int handle,float ax,float ay,float x,float y,float min){if(!Float.isFinite(ax)||!Float.isFinite(ay)||!Float.isFinite(x)||!Float.isFinite(y))return start==null?RegionMath.empty():start.clone();if(handle==0)return RegionMath.rect(ax,ay,x,y,min);if(!RegionMath.active(start))return RegionMath.empty();float dx=x-ax,dy=y-ay;if(handle==5)return RegionMath.move(start,dx,dy);float ex=(handle==1||handle==3||handle==8)?start[0]:start[2],ey=(handle==1||handle==2||handle==6)?start[1]:start[3];return RegionMath.resize(start,handle,ex+dx,ey+dy,min);}
 static boolean compact(int availableDp){return availableDp<300;}
 static boolean compact(int height,int width,float fontScale){return height<760||width<440||fontScale>1.10f;}
 static int panelHeight(int availableDp){return compact(availableDp)?64:104;}
}
