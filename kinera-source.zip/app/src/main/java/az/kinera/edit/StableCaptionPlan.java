package az.kinera.edit;
import java.util.List;
/** Bounded two-sample interval OCR; not glyph segmentation. */
final class StableCaptionPlan {
 static final int MAX_WINDOWS=192;static final long SCAN_TIMEOUT_MS=720000L,UI_TIMEOUT_MS=734000L;
 static int windows(long duration){return duration<=0?0:(int)Math.min(MAX_WINDOWS,1+(duration-1)/150000L);}
 static List<TimedRegions.Mask> build(long duration,List<float[]> left,List<float[]> right){return PrecisionCaptionPlan.build(duration,windows(duration),left,right);}
}
