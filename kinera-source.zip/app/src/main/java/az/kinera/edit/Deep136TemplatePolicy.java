package az.kinera.edit;
final class Deep136TemplatePolicy {
 static final int FIRST=3734,TOTAL=3784;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=k%10*.0013f;float[][] a={{.016f,.021f,.984f,.979f},{.026f,.091f,.974f,.909f},{.036f,.163f,.964f,.837f},{.046f,.247f,.954f,.753f},{.057f,.315f,.943f,.685f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,53)!=23)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Deep136TemplatePolicy(){}
}
