package az.kinera.edit;
final class ExportSafety {
 private ExportSafety(){}
 static long reserveForTwoCopies(long bytes){if(bytes<0)throw new IllegalArgumentException("bytes");return bytes>Long.MAX_VALUE/2?Long.MAX_VALUE:bytes*2;}
 static long stallMs(long durationUs){return Math.max(180000L,Math.min(900000L,Math.max(0,durationUs)/1000));}
 static boolean stalled(long now,long last,long durationUs){return now>=last&&now-last>=stallMs(durationUs);}
 static long ceilMiB(long bytes){if(bytes<0)throw new IllegalArgumentException("bytes");long unit=1048576;return bytes/unit+(bytes%unit==0?0:1);}
 static boolean lower(int h,int f,boolean hevc,int nh,int nf){return nh<=h&&nf<=f&&(nh<h||nf<f||hevc);}
 static int[][] fallbacks(int height,int fps){return new int[][]{{height,Math.min(fps,30)},{Math.min(height,2560),Math.min(fps,30)},{Math.min(height,1920),Math.min(fps,30)},{Math.min(height,1280),Math.min(fps,30)},{Math.min(height,1280),Math.min(fps,24)}};}
}
