package az.kinera.edit;
import android.app.job.*;
import android.content.*;
public final class ReminderJob extends JobService {
 static final int ID=3838;
 static final String ENABLE="reminders_v37",OPEN="last_open_v37",LAST="last_reminder_v37";
 static boolean schedule(Context c,boolean enabled){JobScheduler s=c.getSystemService(JobScheduler.class);s.cancel(3737);if(!enabled){s.cancel(ID);StudioNotifications.manager(c).cancel(StudioNotifications.REMINDER_ID);return true;}if(s.getPendingJob(ID)!=null)return true;try{return s.schedule(new JobInfo.Builder(ID,new ComponentName(c,ReminderJob.class)).setPeriodic(NotificationPolicy.DAY).setPersisted(true).build())==JobScheduler.RESULT_SUCCESS;}catch(RuntimeException e){return false;}}
 @Override public boolean onStartJob(JobParameters p){SharedPreferences prefs=getSharedPreferences("kinera",0);long now=System.currentTimeMillis();if(NotificationPolicy.dailyDue(prefs.getBoolean(ENABLE,true),now,prefs.getLong(LAST,0),prefs.getBoolean("export_in_progress_v24",false))&&StudioNotifications.remind(this))prefs.edit().putLong(LAST,now).apply();return false;}
 @Override public boolean onStopJob(JobParameters p){return false;}
}
