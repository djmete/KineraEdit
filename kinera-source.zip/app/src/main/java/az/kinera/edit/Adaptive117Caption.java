package az.kinera.edit;
import java.util.List;
/** Anchor to current-frame OCR; constrain only expanded restore suggestions. */
final class Adaptive117Caption {
 static float[] review(float[] center,List<float[]> neighbors,int requested){float[] r=Precision116Caption.review(center,neighbors,requested);if(!RegionMath.active(r)||requested<=1||!RegionMath.active(center))return r;float dx=(center[2]-center[0])*.10f,dy=(center[3]-center[1])*.16f;return new float[]{Math.max(r[0],center[0]-dx),Math.max(r[1],center[1]-dy),Math.min(r[2],center[2]+dx),Math.min(r[3],center[3]+dy)};}
 private Adaptive117Caption(){}
}
