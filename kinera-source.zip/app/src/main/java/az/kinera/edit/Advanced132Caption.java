package az.kinera.edit;
/** Keep the detected text anchor; reject horizontally displaced neighbors and cap added area. */
final class Advanced132Caption {
 static float[] stabilize(float[] a,float[] b){float[] q=Supreme131Caption.stabilize(a,b);if(!RegionMath.active(a)||!RegionMath.active(b)||!RegionMath.active(q))return q;float w=a[2]-a[0];float overlap=Math.max(0,Math.min(a[2],b[2])-Math.max(a[0],b[0]));if(overlap<w*.72f||Math.abs(a[0]+a[2]-b[0]-b[2])>w*.55f)return a.clone();double cap=Ultimate130Caption.area(a)*1.08;if(Ultimate130Caption.area(q)<=cap)return q;double lo=0,hi=1;float[] result=a.clone();for(int i=0;i<20;i++){double f=(lo+hi)/2;float[] p=new float[4];for(int k=0;k<4;k++)p[k]=(float)(a[k]+f*(q[k]-a[k]));if(Ultimate130Caption.area(p)<=cap){lo=f;result=p;}else hi=f;}return result;}
 private Advanced132Caption(){}
}
