package az.kinera.edit;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import java.util.Arrays;
/** Bounded palette and approximate shot analysis for creative editing. */
final class AutoPlan {
 final int style; final long[] cuts; AutoPlan(int s,long[] c){style=s;cuts=c;}
 interface Progress { void onFrame(int done,int total); }
 static AutoPlan analyze(Context context,Uri uri,long duration,Progress progress)throws Exception{
  if(duration<=0)return new AutoPlan(-1,new long[0]);long[] markers=new long[0];int count=KAiEdit.analysisSamples(duration);int[] palette=new int[count*64];int n=0,k=0,processed=0;long prevTime=0;float[] scores=new float[count];long[] times=new long[count];int[] older=null,prev=null;int[] pixels=new int[48*48];long deadline=android.os.SystemClock.elapsedRealtime()+KAiEdit.SCENE_BUDGET_MS;MediaMetadataRetriever r=new MediaMetadataRetriever();
  try{r.setDataSource(context,uri);for(int i=0;i<count;i++){if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(android.os.SystemClock.elapsedRealtime()>deadline)break;long time=(long)((i+.5)*duration/count);Bitmap raw=null,small=null;try{raw=AnalysisFrameReader.read(r,time,48,48);if(raw==null){older=null;prev=null;continue;}small=Bitmap.createScaledBitmap(raw,48,48,true);small.getPixels(pixels,0,48,0,0,48,48);if(prev!=null&&time-prevTime<=Math.max(1L,(long)(duration/(double)count*1.8))){scores[k]=SceneMath.distance(prev,pixels);if(scores[k]>=.30f&&(MasterMotionConfidence.translation(prev,pixels)||StableMotionConfidence.translation(prev,pixels)))scores[k]*=.6f;times[k]=prevTime+(time-prevTime)/2;if(older!=null&&k>0&&TemporalPolicy.contiguous(times,k-1,k)&&transientPulse(scores[k-1],scores[k],older,prev,pixels)){scores[k-1]=0;scores[k]=0;}k++;}for(int y=0;y<8;y++)for(int x=0;x<8;x++)palette[n++]=pixels[(y*6+3)*48+x*6+3];int[] swap=older;older=prev!=null&&time-prevTime<=Math.max(1L,(long)(duration/(double)count*1.8))?prev:null;prev=pixels;prevTime=time;pixels=swap==null?new int[48*48]:swap;}catch(RuntimeException ignored){older=null;prev=null;}finally{if(small!=null&&small!=raw)small.recycle();if(raw!=null)raw.recycle();processed=i+1;if(progress!=null)progress.onFrame(i+1,count);}}if(processed<count||n/64<Math.max(1,(count*3+3)/4))throw new InterruptedException("Analysis budget exceeded; previous edit retained");markers=KineraAI.editorialCuts(Arrays.copyOf(times,k),Arrays.copyOf(scores,k),duration);if(markers.length>0){markers=refine(r,markers,duration,Math.max(1,duration/count),Math.max(android.os.SystemClock.elapsedRealtime(),deadline-SemanticMotionMath.BUDGET_MS));markers=SequentialCutReader.refine(context,uri,markers,duration,deadline);}}finally{try{r.release();}catch(Exception ignored){}}return new AutoPlan(n==0?-1:KineraAI.paletteFor(Arrays.copyOf(palette,n)),markers);}
 private static boolean transientPulse(float incoming,float outgoing,int[] older,int[] prev,int[] current){
  if(incoming<.22f||outgoing<.22f)return false;float returning=SceneMath.distance(older,current);if(SceneMath.transientSpike(incoming,outgoing,returning))return true;if(returning>.13f)return false;float a=EvolutionSceneConfidence.meanLuma(older),b=EvolutionSceneConfidence.meanLuma(prev),c=EvolutionSceneConfidence.meanLuma(current);return EvolutionSceneConfidence.lightingPulse(incoming,outgoing,returning,b-a,c-b)||(ProfessionalSceneConfidence.ENABLED&&ProfessionalSceneConfidence.lightingPulse(incoming,outgoing,returning,b-a,c-b));
 }
 // Use a few additional nearby frames only within the original time budget. Keep a coarse
 // marker if decoding fails or the strongest adjacent change is not sufficiently distinct.
 private static long[] refine(MediaMetadataRetriever r,long[] markers,long duration,long interval,long deadline)throws InterruptedException{
  long[] result=markers.clone();int[] prev=new int[48*48],next=new int[48*48];
  for(int i:SemanticMotionMath.indices(markers.length)){
   if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(android.os.SystemClock.elapsedRealtime()+300>=deadline)break;
   long radius=Math.min(750000,interval/2),start=Math.max(0,markers[i]-radius),end=Math.min(duration-1,markers[i]+radius);if(end<=start)continue;
   long[] times=new long[4];float[] scores=new float[4];int n=0;boolean have=false;long previous=0;
   for(int j=0;j<5;j++){if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(android.os.SystemClock.elapsedRealtime()>=deadline)break;long t=start+(end-start)*j/4;Bitmap raw=null,scaled=null;try{raw=AnalysisFrameReader.read(r,t,48,48);if(raw==null){have=false;continue;}scaled=Bitmap.createScaledBitmap(raw,48,48,true);scaled.getPixels(next,0,48,0,0,48,48);if(have&&t>previous&&t-previous<=Math.max(1L,(end-start)/4+1)){times[n]=previous+(t-previous)/2;scores[n++]=SceneMath.distance(prev,next);}int[] swap=prev;prev=next;next=swap;previous=t;have=true;}catch(RuntimeException ignored){have=false;}finally{if(scaled!=null&&scaled!=raw)scaled.recycle();if(raw!=null)raw.recycle();}}
   long refined=n==4?KineraAI.refinedCut(markers[i],Arrays.copyOf(times,n),Arrays.copyOf(scores,n)):markers[i];if((i==0||refined-result[i-1]>=2200000)&&(i+1==markers.length||markers[i+1]-refined>=2200000))result[i]=refined;
  }return result;
 }
}
