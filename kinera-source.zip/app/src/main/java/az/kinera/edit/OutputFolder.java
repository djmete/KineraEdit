package az.kinera.edit;
/** Shared folder policy; no broad Movies fallback. */
final class OutputFolder {
 static final String NAME="Kinera Edit", RELATIVE="Movies/"+NAME+"/";
 static boolean contains(String relative){return RELATIVE.equals(relative);}
 private OutputFolder(){}
}
