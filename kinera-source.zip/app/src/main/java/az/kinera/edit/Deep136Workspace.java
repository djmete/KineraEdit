package az.kinera.edit;
final class Deep136Workspace {
 static int playheadPixel(long position,long duration,int width){if(duration<=0||width<=0)return -1;return (int)Math.round(Math.max(0,Math.min(1,(double)position/duration))*width);}
 static boolean redraw(long previous,long position,long previousDuration,long duration,int width){return previousDuration!=duration||previous<0||playheadPixel(previous,previousDuration,width)!=playheadPixel(position,duration,width);}
 private Deep136Workspace(){}
}
