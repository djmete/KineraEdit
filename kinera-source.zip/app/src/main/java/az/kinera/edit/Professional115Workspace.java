package az.kinera.edit;
/** Preview-first workspace, compact adjustment dock with a dedicated persistent slider. */
final class Professional115Workspace {
 static boolean seek(int height,int mode,boolean focus,float font){if(focus)return false;if(mode>0&&height<620)return false;return Context111Layout.seek(height,mode,focus,font);}
 static boolean filmstrip(int height,int mode,boolean focus,float font){return Context111Layout.filmstrip(height,mode,focus,font)&&height>=720;}
 static int valueWidth(int width,float font){return width<340&&font<=1.25f?48:64;}
 static boolean cancelTouch(int action){return action==3||action==5;}
 static int liveInterval(boolean playing,boolean pressure){return pressure?200:playing?65:120;}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return last<0||now<last||now-last>=liveInterval(playing,pressure);}
 private Professional115Workspace(){}
}
