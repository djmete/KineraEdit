package az.kinera.edit;
final class Autonomous74TemplatePolicy {
 static final int FIRST=484,TOTAL=534;
 static int family(float a){return Director72TemplatePolicy.family(a);}
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.014f,.060f,.986f,.964f};case 1:return new float[]{.026f,.125f,.974f,.905f};case 2:return new float[]{.030f,.205f,.970f,.775f};case 3:return new float[]{.022f,.285f,.978f,.645f};default:return new float[]{.022f,.340f,.978f,.618f};}}
 static int choose(int prior,float a,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(a)||a<=0||semantic<=0||semantic==3||Math.floorMod(seed,13)!=5)return prior;return FIRST+10*family(a)+Math.floorMod(palette+Math.floorMod(seed/13,10),10);}
}
