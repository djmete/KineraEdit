package az.kinera.edit;
/** Learned NCC confidence gate; photo-derived synthetic motion. Baseline checks remain mandatory. */
final class TrackConfidence {
 static final boolean ENABLED=false;
 static final double THRESHOLD=0.75;
 static final double[][][] W={{{7.88361776805},{8.1564274026}}};
 static final double[][] B={{-6.64578202938}};
 static double probability(double peak,double margin){if(!Double.isFinite(peak)||!Double.isFinite(margin))return 0;double[] a={peak,margin};for(int l=0;l<W.length;l++){double[] b=B[l].clone();for(int j=0;j<b.length;j++){for(int i=0;i<a.length;i++)b[j]+=a[i]*W[l][i][j];if(l<W.length-1)b[j]=Math.tanh(b[j]);}a=b;}return 1/(1+Math.exp(-a[0]));}
 static boolean accept(double peak,double margin){return Double.isFinite(peak)&&Double.isFinite(margin)&&(!ENABLED||probability(peak,margin)>=THRESHOLD);}
}
