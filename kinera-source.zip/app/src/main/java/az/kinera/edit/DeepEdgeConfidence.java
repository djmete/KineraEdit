package az.kinera.edit;
/** Shared edge weighting network for blocked-axis restoration. */
final class DeepEdgeConfidence {
 static final boolean ENABLED=true;
 private static final double SCALE=2.8352878317805512e-05;
 private static final short[] Q={-15175,1604,-13580,-22170,-32568,23505,3714,-32760,17249,-1784,12610,10809,21477,-11519,572,25443,3198,1156,8417,-2388,1177,-2420,-10003,2977,-9839,-13062,-24331,-13436,-3510,14603,-9853,-14057,-847};
 static double score(double d,double g){double z=Q[32]*SCALE;for(int j=0;j<8;j++)z+=Q[24+j]*SCALE*Math.tanh((d*Q[j]+g*Q[8+j]+Q[16+j])*SCALE);return z;}
 static final String GLSL="float deepEdgeScore(vec2 x){float z=-0.0240148879;z+=(-0.2789639698)*rtanh(dot(x,vec2(-0.4302549285,0.4890587981))+(0.0906725049));z+=(-0.3703452966)*rtanh(dot(x,vec2(0.0454780168,-0.0505815349))+(0.0327759273));z+=(-0.6898538824)*rtanh(dot(x,vec2(-0.3850320876,0.3575297956))+(0.2386461768));z+=(-0.3809492731)*rtanh(dot(x,vec2(-0.6285833123,0.3064662617))+(-0.0677066734));z+=(-0.0995186029)*rtanh(dot(x,vec2(-0.9233965411,0.6089347676))+(0.0333713378));z+=(0.4140370821)*rtanh(dot(x,vec2(0.6664344049,-0.3265968053))+(-0.0686139655));z+=(-0.2793609101)*rtanh(dot(x,vec2(0.1053025901,0.0162178464))+(-0.2836138418));z+=(-0.3985564105)*rtanh(dot(x,vec2(-0.9288402937,0.7213822830))+(0.0844065188));return clamp(z,-8.,8.);}";
}
