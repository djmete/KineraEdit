package az.kinera.edit;
final class Fusion138TemplatePolicy {
 static final int FIRST=3834,TOTAL=3884;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0012f;float[][] a={{.018f,.041f,.982f,.959f},{.026f,.125f,.974f,.875f},{.038f,.196f,.962f,.804f},{.047f,.251f,.953f,.749f},{.058f,.310f,.942f,.690f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,61)!=31)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Fusion138TemplatePolicy(){}
}
