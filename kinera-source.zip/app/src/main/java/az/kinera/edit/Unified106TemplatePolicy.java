package az.kinera.edit;
final class Unified106TemplatePolicy {
 static final int FIRST=2484,TOTAL=2534;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.016f,.028f,.984f,.972f};case 1:return new float[]{.028f,.103f,.972f,.897f};case 2:return new float[]{.025f,.235f,.975f,.765f};case 3:return new float[]{.024f,.275f,.976f,.725f};default:return new float[]{.024f,.327f,.976f,.673f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,29)!=11)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
}
