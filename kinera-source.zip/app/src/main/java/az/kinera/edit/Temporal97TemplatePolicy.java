package az.kinera.edit;
final class Temporal97TemplatePolicy {
 static final int FIRST=1634,TOTAL=1684;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.016f,.029f,.984f,.971f};case 1:return new float[]{.030f,.090f,.970f,.910f};case 2:return new float[]{.028f,.2345f,.972f,.7655f};case 3:return new float[]{.032f,.297f,.968f,.703f};default:return new float[]{.032f,.3285f,.968f,.6715f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,37)!=23)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/37,10),10);}
}
