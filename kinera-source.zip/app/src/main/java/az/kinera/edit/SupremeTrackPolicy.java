package az.kinera.edit;
/** Neural confidence may increase sampling frequency; it cannot approve or discard a mask. */
final class SupremeTrackPolicy {
 private SupremeTrackPolicy(){}
 static double[] features(int[] a,int[] b,int w,int h,float[] r,float[] s){
  if(a==null||b==null||w<=0||h<=0||a.length!=(long)w*h||b.length!=(long)w*h||!RegionMath.active(r)||!RegionMath.active(s))return null;
  double sx=0,sy=0,xx=0,yy=0,xy=0,dl=0,dc1=0,dc2=0;
  for(int y=0;y<8;y++)for(int x=0;x<8;x++){
   int u=sample(a,w,h,r,x,y),v=sample(b,w,h,s,x,y);double l=SceneMath.luma(u),m=SceneMath.luma(v);sx+=l;sy+=m;xx+=l*l;yy+=m*m;xy+=l*m;dl+=Math.abs(l-m);
   int ug=(u>>>8)&255,vg=(v>>>8)&255;dc1+=Math.abs(((u>>>16)&255)-ug-(((v>>>16)&255)-vg));dc2+=Math.abs((u&255)-ug-((v&255)-vg));
  }
  double su=Math.sqrt(Math.max(0,xx/64-sx*sx/4096)),sv=Math.sqrt(Math.max(0,yy/64-sy*sy/4096));double corr=(xy/64-sx*sy/4096)/Math.max(1,su*sv);
  return new double[]{Math.max(-1,Math.min(1,corr)),dl/(64*255),dc1/(64*510),dc2/(64*510),Math.min(su,sv)/128,Math.abs(su-sv)/128};
 }
 static boolean cautious(double[] f){if(f==null||f.length!=6||f[4]<.0625)return false;for(double x:f)if(!Double.isFinite(x))return false;return (SupremeConfidence.SCHEDULING_ENABLED&&SupremeConfidence.probability(f)<.1)||(CinematicConfidence.SCHEDULING_ENABLED&&CinematicConfidence.probability(f)<.03);}
 static long partialTime(long previous,long next){return previous>=0&&next>previous&&next-previous>=400000L?previous+(next-previous)/2:-1;}
 private static int sample(int[] a,int w,int h,float[] r,int x,int y){int px=Math.max(0,Math.min(w-1,(int)((r[0]+(r[2]-r[0])*(x+.5f)/8)*w))),py=Math.max(0,Math.min(h-1,(int)((r[1]+(r[3]-r[1])*(y+.5f)/8)*h)));return a[py*w+px];}
}
