package az.kinera.edit;
/** New permanent IDs, preserving every existing project. */
final class Reliability82TemplatePolicy {
 static final int FIRST=884,TOTAL=934;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.008f,.035f,.992f,.975f};case 1:return new float[]{.020f,.10f,.980f,.90f};case 2:return new float[]{.028f,.20f,.972f,.82f};case 3:return new float[]{.018f,.25f,.982f,.75f};default:return new float[]{.012f,.30f,.988f,.70f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,19)!=8)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
}
