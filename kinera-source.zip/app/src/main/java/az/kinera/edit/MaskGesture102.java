package az.kinera.edit;
/** A non-hit must never replace an existing Blur selection. Crop behavior is unchanged. */
final class MaskGesture102 {
 static boolean accepts(int mode,float[] region,int hit){return mode!=2||!RegionMath.active(region)||hit!=0;}
 static boolean moved(float x,float y,float downX,float downY,float slop){return Math.hypot(x-downX,y-downY)>=Math.max(1,slop);}
 static boolean pinchAllowed(int mode,boolean accepted,int count){return accepted&&(mode==1||mode==2)&&count==2;}
 private MaskGesture102(){}
}
