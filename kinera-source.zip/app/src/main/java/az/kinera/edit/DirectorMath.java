package az.kinera.edit;
import java.util.Arrays;
/** Deterministic, conservative editorial policy driven by detected shot markers.
 * Source chronology and duration are preserved; never move a privacy mask. */
final class DirectorMath {
 static final long WINDOW=220000L;
 private DirectorMath(){}
 static long[] clean(long[] input,long duration){return input==null||duration<=1800000L?new long[0]:Arrays.stream(input).filter(t->t>=900000L&&t<=duration-900000L).distinct().sorted().limit(120).toArray();}
 static int nearest(long[] cuts,long time){if(cuts==null||cuts.length==0||time<0)return -1;int i=Arrays.binarySearch(cuts,time);if(i>=0)return i;i=-i-1;if(i==0)return cuts.length==0?-1:0;if(i==cuts.length)return i-1;return time-cuts[i-1]<=cuts[i]-time?i-1:i;}
 static long effectWidth(long[] cuts,int i,long duration,long desired){if(cuts==null||i<0||i>=cuts.length||duration<=0||desired<=0)return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i==cuts.length-1?duration:cuts[i+1])-cuts[i];return Math.max(0,Math.min(desired,Math.min(left,right)/3));}
 static float envelope(long distance,long width){if(width<=0||distance>=width||distance<0)return 0;float x=1-distance/(float)width;return x*x*(3-2*x);}
 // Quick sequences get restrained color accents; long sequences get light/zoom accents.
 static int kind(long[] cuts,int index,long duration){if(cuts==null||index<0||index>=cuts.length||duration<=0)return -1;long left=cuts[index]-(index==0?0:cuts[index-1]);long right=(index+1==cuts.length?duration:cuts[index+1])-cuts[index];long gap=Math.min(left,right);if(gap<3500000L)return 0;if(gap>9000000L)return 2;return 1;}
 static float visual(long[] cuts,long time,long duration,float amount){int i=nearest(cuts,time);if(time<0||time>=duration||i<0||!Float.isFinite(amount)||amount<=0)return 0;int k=kind(cuts,i,duration);float e=envelope(Math.abs(time-cuts[i]),effectWidth(cuts,i,duration,k==0?140000L:k==1?280000L:380000L));return e*Adaptive117Director.scale(cuts,i,duration)*Cinematic118Director.continuity(cuts,i,duration)*Precision116Director.shortShotScale(cuts,i,duration)*Cinematic83Math.effectScale(cuts,i,duration)*Production84Math.scale(cuts,i,duration)*Professional85Math.safeAmount(amount)*Temporal97.accentScale(cuts,i,duration)*Professional100.accentScale(cuts,i,duration)*Deep103.transitionScale(cuts,i,duration)*Architecture105.rhythm(cuts,i,duration)*Multimodal113Director.accent(cuts,i,duration)*Professional115Director.continuity(cuts,i,duration)*(k==0?.38f:k==1?-.80f:.92f)*(time<cuts[i]?(.82f+.18f*e):1f);}
 static float styleAmount(int template,float amount){if(!Float.isFinite(amount)||amount<=0)return 0;return template>=156&&template<734?amount*.64f:amount;}
 static float zoom(long[] cuts,long time,long duration,float amount,boolean masks){int i=nearest(cuts,time);if(time<0||time>=duration||i<0||!Float.isFinite(amount)||amount<=0||masks||kind(cuts,i,duration)!=2)return 1;return 1+Math.min(.055f,amount*.32f)*Production84Math.scale(cuts,i,duration)*Cinematic98.zoomScale(cuts,i,duration)*Vision107.zoomGuard(cuts,i,duration)*Professional115Director.continuity(cuts,i,duration)*envelope(Math.abs(time-cuts[i]),effectWidth(cuts,i,duration,340000L));}
 // A soft synthesized transition accent, not a copyrighted clip or speech separator.
 static float sound(long[] cuts,long time,long duration){int i=nearest(cuts,time);if(time<0||time>=duration||i<0||kind(cuts,i,duration)==0)return 0;int k=kind(cuts,i,duration);long width=effectWidth(cuts,i,duration,k==2?140000L:90000L),d=time-cuts[i];if(width<=0||Math.abs(d)>=width)return 0;double x=(d+width)/(2.0*width),e=Math.sin(Math.PI*x);double phase=2*Math.PI*(k==2?140*x+180*x*x:80*x-35*x*x);return (float)((k==2?.018:.009)*Adaptive117Director.scale(cuts,i,duration)*Cinematic118Director.continuity(cuts,i,duration)*Production84Math.scale(cuts,i,duration)*Professional115Director.continuity(cuts,i,duration)*e*e*(Math.sin(phase)*.7+Math.sin(phase*1.713)*.3));}
 static float sourceAccent(float effect,float peak){if(!Float.isFinite(effect)||!Float.isFinite(peak))return 0;float x=Math.max(0,Math.min(1,(Math.abs(peak)-.35f)/.45f));return effect*(1-.85f*x*x*(3-2*x));}
 static float compress(float sample){if(!Float.isFinite(sample))return 0;float a=Math.abs(sample);if(a<=.65f)return sample;return Math.copySign(Math.min(.96f,.65f+(a-.65f)*.45f),sample);}
 static float linkedGain(float[] samples,float accent,int gain){
  if(samples==null||!Float.isFinite(accent))return 0;float peak=0;for(float s:samples){if(!Float.isFinite(s))continue;peak=Math.max(peak,Math.abs(Math.max(-1f,Math.min(1f,s))+Math.max(-1f,Math.min(1f,accent))));}
  float g=KAiEdit.gainPercent(gain)/100f;return peak<=.65f?g:g*compress(peak)/peak;
 }
 static float linkedSample(float sample,float accent,float gain){if(!Float.isFinite(sample)||!Float.isFinite(accent)||!Float.isFinite(gain))return 0;return Math.max(-.96f,Math.min(.96f,(Math.max(-1f,Math.min(1f,sample))+Math.max(-1f,Math.min(1f,accent)))*gain));}
 static float mix(float sample,float accent,int gain){float g=KAiEdit.gainPercent(gain)/100f;return compress(sample+accent)*g;}
}
