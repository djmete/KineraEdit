package az.kinera.edit;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.*;
/** Publish only complete videos; never remove the private verified output on failure. */
final class GallerySaver {
 interface Progress {void update(int percent);}
 static boolean permission(Context c){return Build.VERSION.SDK_INT>=29||c.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;}
 static Uri publish(Context c,File f,Progress p) throws IOException {
  if(!f.isFile()||f.length()==0)throw new IOException("Hazır video tapılmadı");if(!permission(c))throw new IOException("Qalereya yazma icazəsi verilməyib");
  String name="Kinera_"+System.currentTimeMillis()+".mp4";
  if(Build.VERSION.SDK_INT>=29){
   IOException first=null;for(String path:new String[]{OutputFolder.RELATIVE}){
    try{return publishModern(c,f,p,name,path);}catch(IOException|RuntimeException e){if(e instanceof InterruptedIOException)throw (InterruptedIOException)e;IOException wrapped=new IOException(path+": "+e.getMessage(),e);if(first==null)first=wrapped;else first.addSuppressed(wrapped);}
   }throw new IOException("MediaStore: "+(first==null?"unknown":first.getMessage())+(first!=null&&first.getSuppressed().length>0?"; "+first.getSuppressed()[0].getMessage():""),first);
  }
  File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),OutputFolder.NAME);if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Movies qovluğu yaradıla bilmədi");File target=new File(dir,name),tmp=new File(dir,name+".part");boolean done=false;try{try(OutputStream out=new FileOutputStream(tmp)){copy(f,out,p);}if(!tmp.renameTo(target))throw new IOException("Video köçürülmədi");done=true;MediaScannerConnection.scanFile(c,new String[]{target.getAbsolutePath()},new String[]{"video/mp4"},null);return Uri.fromFile(target);}finally{if(!done)tmp.delete();}
 }
 @android.annotation.TargetApi(29)
 private static Uri publishModern(Context c,File f,Progress p,String name,String path)throws IOException{
  ContentResolver cr=c.getContentResolver();ContentValues v=new ContentValues();v.put(MediaStore.Video.Media.DISPLAY_NAME,name);v.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");v.put(MediaStore.Video.Media.RELATIVE_PATH,path);v.put(MediaStore.Video.Media.IS_PENDING,1);
  Uri uri=cr.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY),v);if(uri==null)throw new IOException("MediaStore insert returned null");boolean done=false;
  try{try(OutputStream out=cr.openOutputStream(uri,"w")){copy(f,out,p);}
   try(android.os.ParcelFileDescriptor fd=cr.openFileDescriptor(uri,"r")){if(fd==null)throw new IOException("MediaStore readback failed");long size=fd.getStatSize();if(size>=0&&size!=f.length())throw new IOException("MediaStore length mismatch: "+size+" / "+f.length());}
   v.clear();v.put(MediaStore.Video.Media.IS_PENDING,0);if(cr.update(uri,v,null,null)!=1)throw new IOException("MediaStore publish failed");done=true;return uri;
  }finally{if(!done)try{cr.delete(uri,null,null);}catch(Exception ignored){}}
 }
 private static void copy(File f,OutputStream out,Progress p)throws IOException{if(out==null)throw new IOException("Yazma axını açılmadı");long bytes=0;int last=-1;try(InputStream in=new FileInputStream(f)){byte[] b=new byte[256*1024];for(int n;(n=in.read(b))!=-1;){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Dayandırıldı");out.write(b,0,n);bytes+=n;int now=(int)Math.min(100,bytes*100.0/f.length());if(now!=last){p.update(now);last=now;}}out.flush();}if(bytes!=f.length())throw new IOException("Video tam köçürülmədi");}
}
