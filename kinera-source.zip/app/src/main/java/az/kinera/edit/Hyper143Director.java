package az.kinera.edit;
/** Rhythm policy: clean cuts for rapid sequences, restrained accents for longer beats. */
final class Hyper143Director {
 static float emphasis(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long l=cuts[i]-(i==0?0:cuts[i-1]),r=(i==cuts.length-1?duration:cuts[i+1])-cuts[i];if(l<=0||r<=0)return 0;long gap=Math.min(l,r);if(gap<450000)return 0;float pace=gap<2000000?.38f+.62f*(gap-450000)/1550000f:1f;boolean rapid=i>0&&i+1<cuts.length&&l<2500000&&r<2500000;if(rapid)pace*=.65f;return Math.max(0,Math.min(1,pace));}
 static float side(long[] cuts,int i,long duration,long t){float base=emphasis(cuts,i,duration);if(base==0)return 0;long l=cuts[i]-(i==0?0:cuts[i-1]),r=(i==cuts.length-1?duration:cuts[i+1])-cuts[i];long side=t<cuts[i]?l:r;return base*Math.min(1f,side/1500000f);}
 static final int CLEAN=0,SOFT=1,DIP=2,LIFT=3,PUSH=4;
 static int profile(long[] cuts,int i,long duration){if(emphasis(cuts,i,duration)==0)return CLEAN;long l=cuts[i]-(i==0?0:cuts[i-1]),r=(i==cuts.length-1?duration:cuts[i+1])-cuts[i];long shortSide=Math.min(l,r),longSide=Math.max(l,r);if(shortSide<3500000)return SOFT;if(shortSide<=9000000)return DIP;return shortSide/(double)longSide>=.60?PUSH:LIFT;}
 static float grade(long[] cuts,int i,long duration){switch(profile(cuts,i,duration)){case SOFT:return .38f;case DIP:return -.80f;case LIFT:return .70f;case PUSH:return .92f;default:return 0;}}
 private Hyper143Director(){}
}
