package az.kinera.edit;
final class Reconstruction96 {
 private Reconstruction96(){}
 static int height(int index){return new int[]{1280,1920,2560,3840,480,640,960}[index>=0&&index<7?index:1];}
 static int index(int i){return i>=0&&i<7?i:1;}
 static int fps(float source,int h,boolean pressure,boolean restore){int rate=Ultra95.fps(source);return Math.min(rate,(pressure||h>=2560||restore&&h>=1920)?24:30);}
 static int[][] fallbacks(int h,int fps){return fps>24?new int[][]{{h,24}}:fps>15?new int[][]{{h,15}}:new int[0][];}
 static boolean safeUnion(float[] a,float[] b){if(!Ultra95.safeUnion(a,b))return false;double ah=a[3]-a[1],bh=b[3]-b[1];double shift=Math.abs((a[1]+a[3]-b[1]-b[3])*.5);return shift<=.35*Math.min(ah,bh);}
}
