package az.kinera.edit;
import java.util.List;
/** Bounded full-video OCR sampling, not frame-exact OCR. */
final class MasterCaptionPlan {
 static final int MAX_WINDOWS=160;static final long SCAN_TIMEOUT_MS=620000L,UI_TIMEOUT_MS=634000L;
 static int windows(long duration){return duration<=0?0:(int)Math.min(MAX_WINDOWS,1+(duration-1)/200000L);}
 static List<TimedRegions.Mask> build(long duration,List<float[]> left,List<float[]> right){return PrecisionCaptionPlan.build(duration,windows(duration),left,right);}
}
