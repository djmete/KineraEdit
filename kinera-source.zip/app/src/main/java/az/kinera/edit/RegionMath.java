package az.kinera.edit;
/** Normalized source coordinates, independent of display size and mirror. */
final class RegionMath {
 static float[] full(){return new float[]{0,0,1,1};}
 static float[] empty(){return new float[]{0,0,0,0};}
 static float[] rect(float x,float y,float X,float Y,float min){if(!Float.isFinite(x)||!Float.isFinite(y)||!Float.isFinite(X)||!Float.isFinite(Y)||!Float.isFinite(min)||min<0||min>1)return empty();float l=EditMath.clamp(Math.min(x,X),0,1),t=EditMath.clamp(Math.min(y,Y),0,1),r=EditMath.clamp(Math.max(x,X),0,1),b=EditMath.clamp(Math.max(y,Y),0,1);if(r-l<min){r=Math.min(1,l+min);l=Math.max(0,r-min);}if(b-t<min){b=Math.min(1,t+min);t=Math.max(0,b-min);}return new float[]{l,t,r,b};}
 static boolean active(float[] r){return r!=null&&r.length==4&&Float.isFinite(r[0])&&Float.isFinite(r[1])&&Float.isFinite(r[2])&&Float.isFinite(r[3])&&r[0]>=0f&&r[1]>=0f&&r[2]<=1f&&r[3]<=1f&&r[2]-r[0]>.001f&&r[3]-r[1]>.001f;}
 static float[] point(float[] c,float x,float y,boolean mirror){return new float[]{c[0]+(c[2]-c[0])*(mirror?1-x:x),c[1]+(c[3]-c[1])*y};}
 static float[] move(float[] r,float dx,float dy){if(!active(r))return empty();if(!Float.isFinite(dx)||!Float.isFinite(dy))return r.clone();dx=EditMath.clamp(dx,-r[0],1-r[2]);dy=EditMath.clamp(dy,-r[1],1-r[3]);return new float[]{r[0]+dx,r[1]+dy,r[2]+dx,r[3]+dy};}
 /** Centered mask resized around its own center, clamped to the image. */
 static float[] centered(float cx,float cy,float w,float h){if(!Float.isFinite(cx)||!Float.isFinite(cy)||!Float.isFinite(w)||!Float.isFinite(h))return empty();w=EditMath.clamp(w,.035f,1);h=EditMath.clamp(h,.035f,1);float l=EditMath.clamp(cx-w/2,0,1-w),t=EditMath.clamp(cy-h/2,0,1-h);return new float[]{l,t,Math.min(1,l+w),Math.min(1,t+h)};}
 static float[] pinch(float[] r,float scale,float dx,float dy){if(!active(r))return empty();if(!Float.isFinite(scale)||scale<=0||!Float.isFinite(dx)||!Float.isFinite(dy))return r.clone();return centered((r[0]+r[2])/2+dx,(r[1]+r[3])/2+dy,(r[2]-r[0])*scale,(r[3]-r[1])*scale);}
 /** Axis controls map 0..1000 to full usable travel, independent of screen size. */
 static int sliderValue(float[] r,int axis){if(!active(r))return axis==0||axis==1?500:axis==2?420:150;float w=r[2]-r[0],h=r[3]-r[1];float v=axis==0?(w>=.999f?.5f:r[0]/(1-w)):axis==1?(h>=.999f?.5f:r[1]/(1-h)):axis==2?w:h;return Math.round(EditMath.clamp(v,0,1)*1000);}
 static float[] sliderRegion(float[] r,int axis,int progress){if(!active(r))r=centered(.5f,.5f,.42f,.15f);float v=EditMath.clamp(progress/1000f,0,1),w=r[2]-r[0],h=r[3]-r[1];if(axis==0)return move(r,v*(1-w)-r[0],0);if(axis==1)return move(r,0,v*(1-h)-r[1]);if(axis==2)return centered((r[0]+r[2])/2,(r[1]+r[3])/2,Math.max(.035f,v),h);if(axis==3)return centered((r[0]+r[2])/2,(r[1]+r[3])/2,w,Math.max(.035f,v));return r.clone();}
 // Handles: 1=top-left, 2=top-right, 3=bottom-left, 4=bottom-right.
 static float[] resize(float[] r,int handle,float x,float y,float min){float[] a=r.clone();if(handle>=6&&handle<=9){if(handle==6)a[1]=EditMath.clamp(y,0,r[3]-min);else if(handle==7)a[3]=EditMath.clamp(y,r[1]+min,1);else if(handle==8)a[0]=EditMath.clamp(x,0,r[2]-min);else a[2]=EditMath.clamp(x,r[0]+min,1);return a;}if(handle==1||handle==3)a[0]=EditMath.clamp(x,0,r[2]-min);else a[2]=EditMath.clamp(x,r[0]+min,1);if(handle==1||handle==2)a[1]=EditMath.clamp(y,0,r[3]-min);else a[3]=EditMath.clamp(y,r[1]+min,1);return a;}
 static float[] display(float width,float height,float aspect){if(!Float.isFinite(width)||!Float.isFinite(height)||!Float.isFinite(aspect)||width<=0||height<=0||aspect<=0)return empty();float w=Math.min(width,height*aspect),h=Math.min(height,width/aspect);return new float[]{(width-w)/2,(height-h)/2,(width+w)/2,(height+h)/2};}
}
