package az.kinera.edit;
final class Vision120Workspace {
 static int sliderPadding(int w){return w<360?4:10;}
 static int valueWidth(int w,float font){return w<300?38:w<380?44:font>1.4f?60:50;}
 static boolean compact(int h,int w,float font){return h<700||w<360||font>1.25f;}
 static boolean metadata(int h,int mode,boolean focus,float font){return Studio119Workspace.metadata(h,mode,focus,font)&&h>=850;}
 static int liveInterval(boolean playing,boolean pressure){return pressure?380:playing?105:70;}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return last<0||now<last||now-last>=liveInterval(playing,pressure);}
 private Vision120Workspace(){}
}
