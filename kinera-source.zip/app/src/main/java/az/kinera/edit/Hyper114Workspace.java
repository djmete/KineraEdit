package az.kinera.edit;
final class Hyper114Workspace {
 static boolean publish(boolean current,boolean visible,boolean editing,boolean aborted,boolean pressure){return current&&visible&&!editing&&!aborted&&!pressure;}
 static boolean cancelTouch(int action){return action==3||action==5;}
 static boolean terminal(int action){return action==1||action==3;}
 static int transportWidth(int screenWidth,float font,boolean play){return screenWidth<360||font>1.2f?48:play?56:48;}
 private Hyper114Workspace(){}
}
