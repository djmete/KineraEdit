package az.kinera.edit;
/** Appended director collection; previous IDs are never migrated. */
final class Director72TemplatePolicy {
 static final int FIRST=384,TOTAL=434;
 static int family(float a){if(!Float.isFinite(a)||a<=0)return 0;return a<=.68f?0:a<=.92f?1:a<=1.2f?2:a<=2f?3:4;}
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.015f,.085f,.985f,.95f};case 1:return new float[]{.025f,.14f,.975f,.89f};case 2:return new float[]{.03f,.215f,.97f,.765f};case 3:return new float[]{.02f,.30f,.98f,.642f};default:return new float[]{.02f,.355f,.98f,.61f};}}
 static int choose(int prior,float a,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(a)||a<=0||semantic<=0||semantic==3||Math.floorMod(seed,7)!=2)return prior;return FIRST+10*family(a)+Math.floorMod(palette+Math.floorMod(seed/7,10),10);}
}
