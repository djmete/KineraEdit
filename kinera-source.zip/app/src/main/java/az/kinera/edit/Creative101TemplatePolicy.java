package az.kinera.edit;
final class Creative101TemplatePolicy {
 static final int FIRST=1834,MOTION_FIRST=1884,TOTAL=1984;
 static int family(int id){return id>=MOTION_FIRST?Math.max(0,Math.min(4,(id-MOTION_FIRST)/20)):Math.max(0,Math.min(4,(id-FIRST)/10));}
 static float[] window(int id){switch(family(id)){case 0:return new float[]{.04f,.07f,.96f,.93f};case 1:return new float[]{.035f,.12f,.965f,.88f};case 2:return new float[]{.035f,.23f,.965f,.77f};case 3:return new float[]{.025f,.29f,.975f,.71f};default:return new float[]{.025f,.325f,.975f,.675f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3)return prior;int f=Director72TemplatePolicy.family(aspect);int slot=Math.floorMod(seed,53);if(slot==37)return FIRST+10*f+Math.floorMod(palette,10);if(slot==38||slot==39)return MOTION_FIRST+20*f+2*Math.floorMod(palette,10)+slot-38;return prior;}
}
