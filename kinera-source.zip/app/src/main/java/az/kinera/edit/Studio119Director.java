package az.kinera.edit;
/** Keep clustered transitions understated; maintain chronology, timing and user masks. */
final class Studio119Director {
 static float rhythm(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length)return 0;long a=cuts[i]-(i==0?0:cuts[i-1]),b=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(a<=0||b<=0)return 0;long gap=Math.min(a,b);return gap<2200000L?.55f:gap<4000000L?.55f+.45f*(gap-2200000L)/1800000f:1f;}
 private Studio119Director(){}
}
