package az.kinera.edit;
final class Vision75TemplatePolicy {
 static final int FIRST=534,TOTAL=584;
 static int family(float a){return Director72TemplatePolicy.family(a);}
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.052f,.988f,.966f};case 1:return new float[]{.024f,.122f,.976f,.91f};case 2:return new float[]{.028f,.198f,.972f,.78f};case 3:return new float[]{.020f,.279f,.98f,.651f};default:return new float[]{.020f,.334f,.98f,.623f};}}
 static int choose(int prior,float a,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(a)||a<=0||semantic<=0||semantic==3||Math.floorMod(seed,17)!=7)return prior;return FIRST+10*family(a)+Math.floorMod(palette+Math.floorMod(seed/17,10),10);}
}
