package az.kinera.edit;
final class Cinematic144RenderPlan {
 private final long[] cuts;private final long duration;private final float amount;private final boolean manual,gradeEnabled;private final Director147Cursor cursor;
 private int index;private long last=-1;private long lastTime=Long.MIN_VALUE;private boolean lastMasks;private float grade,zoom=1;
 Cinematic144RenderPlan(EditSpec s){this(s,true);}
 Cinematic144RenderPlan(EditSpec s,boolean gradeEnabled){this.gradeEnabled=gradeEnabled;cuts=s.cuts.clone();cursor=new Director147Cursor(cuts);duration=s.durationUs;amount=DirectorMath.styleAmount(s.template,s.dip);manual=Crop139.manual(s.cropRect);}
 void reset(){index=0;last=-1;lastTime=Long.MIN_VALUE;grade=0;zoom=1;}
 boolean active(long time){if(time<0||time>=duration||amount<=0)return false;if(time<last)index=0;last=time;while(index<cuts.length&&time>cuts[index]&&time-cuts[index]>=380000L)index++;return index<cuts.length&&Math.abs(cuts[index]-time)<380000L;}
 void at(long time,boolean masks){if(lastTime==time&&lastMasks==masks)return;lastTime=time;lastMasks=masks;if(time<0||time>=duration||amount<=0||!gradeEnabled&&(manual||masks)){grade=0;zoom=1;return;}int nearest=cursor.nearest(time);if(nearest<0||Math.abs(cuts[nearest]-time)>=380000L){grade=0;zoom=1;return;}grade=gradeEnabled?DirectorMath.visualAt(cuts,time,duration,amount,nearest):0f;zoom=manual||masks?1:DirectorMath.zoomAt(cuts,time,duration,amount,masks,nearest);}
 float grade(){return grade;}float zoom(){return zoom;}
}
