package az.kinera.edit;
final class Cinematic144RenderPlan {
 private final long[] cuts;private final long duration;private final float amount;private final boolean manual;
 private int index;private long last=-1;private long lastTime=Long.MIN_VALUE;private boolean lastMasks;private float grade,zoom=1;
 Cinematic144RenderPlan(EditSpec s){cuts=s.cuts.clone();duration=s.durationUs;amount=DirectorMath.styleAmount(s.template,s.dip);manual=Crop139.manual(s.cropRect);}
 void reset(){index=0;last=-1;lastTime=Long.MIN_VALUE;grade=0;zoom=1;}
 boolean active(long time){if(time<0||time>=duration||amount<=0)return false;if(time<last)index=0;last=time;while(index<cuts.length&&time>cuts[index]&&time-cuts[index]>=380000L)index++;return index<cuts.length&&Math.abs(cuts[index]-time)<380000L;}
 void at(long time,boolean masks){if(lastTime==time&&lastMasks==masks)return;lastTime=time;lastMasks=masks;if(!active(time)){grade=0;zoom=1;return;}int nearest=DirectorMath.nearest(cuts,time);grade=DirectorMath.visualAt(cuts,time,duration,amount,nearest);zoom=manual?1:DirectorMath.zoomAt(cuts,time,duration,amount,masks,nearest);}
 float grade(){return grade;}float zoom(){return zoom;}
}
