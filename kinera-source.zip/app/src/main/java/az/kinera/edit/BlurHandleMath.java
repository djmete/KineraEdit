package az.kinera.edit;
/** Nearest-handle selection in view pixels; small selections retain a usable central move target. */
final class BlurHandleMath {
 static int hit(float l,float t,float r,float b,float x,float y,float density,boolean blur,boolean full){if(!(r>l&&b>t&&density>0))return 0;float cx=(l+r)/2,cy=(t+b)/2;float radius=Math.max(5*density,Math.min(22*density,Math.min(r-l,b-t)*.32f));if(!full&&x>=l&&x<=r&&y>=t&&y<=b&&Math.abs(x-cx)<=Math.max(1,(r-l)*.15f)&&Math.abs(y-cy)<=Math.max(1,(b-t)*.15f))return 5;float[] xs={l,r,l,r,cx,cx,l,r},ys={t,t,b,b,t,b,cy,cy};int[] ids={1,2,3,4,6,7,8,9};int best=0;float dist=radius*radius;for(int i=0;i<(blur?8:4);i++){float dx=x-xs[i],dy=y-ys[i],d=dx*dx+dy*dy;if(d<dist){best=ids[i];dist=d;}}if(best!=0)return best;return !full&&x>=l&&x<=r&&y>=t&&y<=b?5:0;}
}
