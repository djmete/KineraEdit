package az.kinera.edit;
import android.content.Context;
import android.graphics.Rect;
import android.media.*;
import android.net.Uri;
import android.os.SystemClock;
import java.nio.ByteBuffer;
/** Optional consecutive-frame probe around existing scene markers. A decoder failure leaves the old plan intact. */
final class SequentialCutReader {
 static long[] refine(Context context,Uri uri,long[] markers,long duration,long deadline)throws InterruptedException{
  if(markers.length==0||SystemClock.elapsedRealtime()+750>=deadline)return markers;
  long[] out=markers.clone();ExpertAudioEnvelope audio=deadline-SystemClock.elapsedRealtime()>8000?ExpertAudioProbe.read(context,uri,deadline):new ExpertAudioEnvelope();long stop=Math.min(deadline,SystemClock.elapsedRealtime()+SemanticMotionMath.BUDGET_MS);
  for(int i:SemanticMotionMath.indices(out.length)){if(SystemClock.elapsedRealtime()+500>=stop)break;
   if(Thread.currentThread().isInterrupted())throw new InterruptedException();long original=out[i];long next=probe(context,uri,original,duration,Math.min(stop,SystemClock.elapsedRealtime()+1800),audio);
   if(next>=900000&&next<=duration-900000&&(i==0||next-out[i-1]>=2200000)&&(i+1==out.length||out[i+1]-next>=2200000))out[i]=next;
  }return out;
 }
 static long[] refineBounded(Context c,Uri uri,long[] markers,long duration,long deadline,int limit)throws InterruptedException{
  if(markers.length==0||limit<=0)return markers;long[] out=markers.clone();ExpertAudioEnvelope audio=new ExpertAudioEnvelope();
  for(int i:Performance87.probes(out.length,Math.min(2,limit))){if(SystemClock.elapsedRealtime()+500>=deadline||DeviceLoad87.pressure(c))break;if(Thread.currentThread().isInterrupted())throw new InterruptedException();long next=probe(c,uri,out[i],duration,Math.min(deadline,SystemClock.elapsedRealtime()+1800),audio);if(next>=900000&&next<=duration-900000&&(i==0||next-out[i-1]>=2200000)&&(i+1==out.length||out[i+1]-next>=2200000))out[i]=next;}
  return out;
 }
 private static long probe(Context c,Uri uri,long original,long duration,long deadline,ExpertAudioEnvelope audio)throws InterruptedException{
  MediaExtractor ex=new MediaExtractor();MediaCodec codec=null;boolean started=false;
  long radius=350000,start=Math.max(0,original-radius),end=Math.min(duration-1,original+radius);long[] pts=new long[96];double[] scores=new double[96];boolean[] blocked=new boolean[96];int n=0;boolean complete=false;
  try{ex.setDataSource(c,uri,null);MediaFormat f=null;for(int i=0;i<ex.getTrackCount();i++){MediaFormat candidate=ex.getTrackFormat(i);String mime=candidate.getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("video/")){f=candidate;ex.selectTrack(i);break;}}if(f==null)return original;
   // Avoid large raw decoder allocations on mobile; old scaled-retriever fallback handles other formats.
   if((long)f.getInteger(MediaFormat.KEY_WIDTH)*f.getInteger(MediaFormat.KEY_HEIGHT)>1920L*1080)return original;
   f.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);codec=MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME));codec.configure(f,null,null,0);codec.start();started=true;ex.seekTo(start,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
   MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();boolean eos=false;long last=-1;int[] previous=null,older=null;double priorDistance=0;int decoded=0;
   while(SystemClock.elapsedRealtime()<deadline&&n<pts.length&&decoded<240){if(decoded%16==0&&DeviceLoad87.hot(c))return original;if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(!eos){int in=codec.dequeueInputBuffer(2000);if(in>=0){ByteBuffer buf=codec.getInputBuffer(in);if(buf==null)return original;buf.clear();int size=ex.readSampleData(buf,0);if(size<0){codec.queueInputBuffer(in,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);eos=true;}else{codec.queueInputBuffer(in,0,size,ex.getSampleTime(),0);ex.advance();}}}
    int ix=codec.dequeueOutputBuffer(info,2000);if(ix<0)continue;try{long time=info.presentationTimeUs;boolean finished=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;if(time>end){complete=true;break;}if(time>=start&&info.size>0){try(Image im=codec.getOutputImage(ix)){if(im==null)return original;int[] luma=sample(im);if(luma==null)return original;if(previous!=null&&time>last&&time-last<=150000){double distance=SequentialCutMath.distance(previous,luma);if(n>0&&AutonomousCutPolicy.pulse(older,previous,luma,priorDistance,distance)){scores[n-1]=0;scores[n]=0;}else scores[n]=distance;blocked[n]=(distance>=.16&&VisionLightConfidence.reject(VisionCutPolicy.features(previous,luma)))||SemanticMotionMath.veto(previous,luma,distance)||(distance>=.16&&Vision80Features.aligned(previous,luma));if(n>0&&(AdaptiveCutPolicy.pulse(older,previous,luma,priorDistance,distance)||PrecisionPulseMath.pulse(older,previous,luma))){blocked[n-1]=true;blocked[n]=true;}if(n>0&&!blocked[n-1]&&scores[n-1]>=.24){double raw=ExpertAudioEnvelope.rawDistance(older,previous),returning=ExpertAudioEnvelope.rawDistance(older,luma);scores[n-1]+=ExpertAudioEnvelope.bonus(raw,returning,audio.features(pts[n-1]));}pts[n++]=time;priorDistance=distance;}else if(previous!=null){return original;}older=previous;previous=luma;last=time;}}decoded++;if(finished){complete=last>=end-150000;break;}}finally{codec.releaseOutputBuffer(ix,false);}
   }
  }catch(RuntimeException|java.io.IOException ignored){return original;}finally{if(codec!=null){if(started)try{codec.stop();}catch(RuntimeException ignored){}try{codec.release();}catch(RuntimeException ignored){}}try{ex.release();}catch(RuntimeException ignored){}}
  return complete?ReliabilityCutMath.refine(original,pts,scores,blocked,n,radius):original;
 }
 private static int[] sample(Image im){if(im.getPlanes().length==0)return null;Image.Plane plane=im.getPlanes()[0];Rect crop=im.getCropRect();if(crop.width()<2||crop.height()<2)return null;ByteBuffer b=plane.getBuffer();int base=b.position();int row=plane.getRowStride(),pixel=plane.getPixelStride();if(row<=0||pixel<=0)return null;int[] values=new int[2304];for(int y=0;y<48;y++)for(int x=0;x<48;x++){int py=crop.top+(2*y+1)*crop.height()/96,px=crop.left+(2*x+1)*crop.width()/96;long offset=(long)base+(long)py*row+(long)px*pixel;if(offset<base||offset>=b.limit())return null;values[y*48+x]=b.get((int)offset)&255;}return values;}
}
