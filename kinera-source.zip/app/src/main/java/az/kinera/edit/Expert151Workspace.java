package az.kinera.edit;
/** Preserve preview space when fonts or active editing controls need more height. */
final class Expert151Workspace {
 static boolean film(int h,int w,int m,boolean focus,float f){return Evolution150Workspace.film(h,w,m,focus,f)&&h>=820;}
 static boolean audio(int h,int w,int m,boolean focus,float f){return Evolution150Workspace.audio(h,w,m,focus,f)&&h>=980;}
 static boolean seek(int h,int w,int m,boolean focus,float f){if(focus)return false;if(m<=0)return h>=400&&!film(h,w,m,focus,f);return h>=(f>1.3f?800:720);}
 static int filmHeight(int h){return h<900?52:64;}
 static int sliderPadding(int w){return w<360?16:20;}
 private Expert151Workspace(){}
}
