package az.kinera.edit;
final class Cinematic98TemplatePolicy {
 static final int FIRST=1684,TOTAL=1734;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.018f,.030f,.982f,.970f};case 1:return new float[]{.027f,.088f,.973f,.912f};case 2:return new float[]{.030f,.235625f,.970f,.764375f};case 3:return new float[]{.030f,.2959375f,.970f,.7040625f};default:return new float[]{.030f,.3278f,.970f,.6722f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,41)!=29)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/41,10),10);}
}
