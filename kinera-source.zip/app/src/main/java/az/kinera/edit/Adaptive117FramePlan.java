package az.kinera.edit;
/** Bounded, ordered decode plan. An incomplete pass never publishes additional cuts. */
final class Adaptive117FramePlan {
 static final int MAX_FRAMES=1024;
 static boolean eligible(long duration,long remaining,boolean pressure){return !pressure&&duration>=1800000L&&duration<=30000000L&&remaining>= (duration<=12000000L?4000L:9000L);}
 static long budget(long duration){return duration<=12000000L?6000L:12000L;}
 // Centered edge difference suppresses global exposure pulses; motion veto stays independent.
 static boolean exposureOnly(int[] a,int[] b){if(a==null||b==null||a.length!=2304||b.length!=2304)return false;double sum=0,err=0;int n=0;for(int y=2;y<46;y+=2)for(int x=2;x<46;x+=2){int i=y*48+x;sum+=b[i]-a[i];n++;}double mean=sum/n;if(Math.abs(mean)<28)return false;for(int y=2;y<46;y+=2)for(int x=2;x<46;x+=2){int i=y*48+x;err+=Math.abs(b[i]-a[i]-mean);}return err/n<12;}
 static boolean blocked(int[] a,int[] b,double d){return d>=.20&&(exposureOnly(a,b)||Vision80Features.aligned(a,b)||SemanticMotionMath.veto(a,b,d));}
 private Adaptive117FramePlan(){}
}
