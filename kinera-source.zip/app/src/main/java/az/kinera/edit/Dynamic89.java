package az.kinera.edit;
/** Bounded local-motion and thermal policy; no extra decoder pass. */
final class Dynamic89 {
 static boolean poll(long now,long last){return last<0||now<last||now-last>=1500;}
 static boolean latch(boolean prior,boolean pressure){return prior||pressure;}
 static float sceneScore(int[] a,int[] b,float score){
  if(a==null||b==null||a.length!=2304||b.length!=2304||!Float.isFinite(score)||score<.22f||score>=.46f)return score;
  int changed=0;for(int by=0;by<6;by++)for(int bx=0;bx<6;bx++){int sum=0;for(int y=by*8;y<by*8+8;y++)for(int x=bx*8;x<bx*8+8;x++){int i=y*48+x;sum+=Math.abs(SceneMath.luma(a[i])-SceneMath.luma(b[i]));}if(sum>=64*30)changed++;}
  return changed<=9?score*.72f:score;
 }
 static boolean useSecondHistory(boolean constrained,boolean supported){return !constrained&&supported;}
 static int blurValueWidth(int width,float font){return width<360?38:font>1.2f?54:44;}
}
