package az.kinera.edit;
/** Trained lighting pulse guard; not a platform originality classifier. */
final class EvolutionSceneConfidence {
 static final boolean ENABLED=true;
 static final double THRESHOLD=0.8,SCALE=0.00041267261258326471;
 private static final short[] W={893,3431,-299,2348,2865,-3815,-6179,1822,814,7343,5606,1927,-1103,-1202,1640,1129,-1066,-299,-2969,423,-3604,10647,2711,4827,-12136,10634,1709,-32767,-29998,-10724,-5702,1514,-4553,-23147,5024,-8907,3263,-12601,3404,-426,346,-12708,333,-4515,2514,-3870,566,-767,2814,16898,-5387,-562,169,14691,-1118,5951,-3351,164,201,-493,200,914,-3513,-1956,-1139,-114,-1405,1968,3525,413,1400,-370,-4600,-8942,6332,-18707,-11529,9970,4182,-3789,-7619,11158,-3875,3876,-2835};
 static double score(double a,double b,double c,double d,double e){double[] x={a,b,c,d,e};double sum=W[84]*SCALE;for(int j=0;j<12;j++){double h=W[60+j]*SCALE;for(int i=0;i<5;i++)h+=x[i]*W[i*12+j]*SCALE;sum+=Math.tanh(h)*W[72+j]*SCALE;}return 1/(1+Math.exp(-Math.max(-40,Math.min(40,sum))));}
 static boolean lightingPulse(float a,float b,float c,float d,float e){return ENABLED&&a>=.22f&&b>=.22f&&c<=.13f&&d*e<0&&score(a,b,c,d,e)>=THRESHOLD;}
 static float meanLuma(int[] rgb){if(rgb==null||rgb.length==0)return 0;long sum=0;for(int p:rgb)sum+=SceneMath.luma(p);return (float)(sum/(255.0*rgb.length));}
}
