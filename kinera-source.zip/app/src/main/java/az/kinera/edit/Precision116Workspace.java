package az.kinera.edit;
/** One time-navigation surface, persistent blur control; stable during a gesture. */
final class Precision116Workspace {
 static boolean filmstrip(int h,int mode,boolean focus,float font){return Professional115Workspace.filmstrip(h,mode,focus,font)&&h>=760;}
 static boolean seek(int h,int mode,boolean focus,float font){return !focus&&h>=420&&mode<=0&&!filmstrip(h,mode,focus,font);}
 static int valueWidth(int w,float font){return font>1.4f?64:w<360?48:56;}
 static int liveInterval(boolean playing,boolean pressure){return pressure?220:playing?75:100;}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return last<0||now<last||now-last>=liveInterval(playing,pressure);}
 static int previewHeight(int h,boolean pressure){return pressure?Math.min(h,480):h;}
 private Precision116Workspace(){}
}
