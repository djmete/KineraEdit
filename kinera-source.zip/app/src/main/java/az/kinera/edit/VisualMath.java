package az.kinera.edit;
/** Presentation geometry only; does not alter rendered video or source content. */
final class VisualMath {
 private VisualMath() {}
 static int[] centerCrop(int sw,int sh,float dw,float dh){
  if(sw<=0||sh<=0||!Float.isFinite(dw)||!Float.isFinite(dh)||dw<=0||dh<=0)return new int[]{0,0,Math.max(0,sw),Math.max(0,sh)};
  double ratio=(double)dw/dh;
  int w=sw,h=sh;
  if((double)sw/sh>ratio)w=Math.max(1,Math.min(sw,(int)Math.round(sh*ratio)));
  else h=Math.max(1,Math.min(sh,(int)Math.round(sw/ratio)));
  int l=(sw-w)/2,t=(sh-h)/2;return new int[]{l,t,l+w,t+h};
 }
 static int timelineHeight(int screenHeightDp){return screenHeightDp<640?40:screenHeightDp<760?48:54;}
 static int galleryHeight(int widthDp,int columns){int count=Math.max(2,Math.min(3,columns));int cell=Math.max(1,(widthDp-24-count*12)/count);return Math.max(92,Math.min(220,Math.round(cell*1.05f)));}
 static int squareTile(int widthDp,int columns){return Math.max(1,(Math.max(1,widthDp)-2*Math.max(2,Math.min(4,columns)))/Math.max(2,Math.min(4,columns)));}
 static int thumbnailCacheBytes(int heapMb){return Math.max(4,Math.min(16,heapMb/24))*1024*1024;}
 static int readableToolWidth(int textPx,int densityDp,int minPx){return Math.max(minPx,Math.max(0,textPx)+Math.max(0,densityDp));}
 static int readableToolHeight(int fontHeight,int extra,int minimum){return Math.max(minimum,Math.max(0,fontHeight)+Math.max(0,extra));}
}
