package az.kinera.edit;
import java.util.Locale;
/** Conservative semantic preference. Model labels never override an existing draft or mask. */
final class CreativePolicy {
 static final int UNKNOWN=0,PERSON=1,LANDSCAPE=2,DOCUMENT=3;
 static int category(String label,float confidence){if(label==null||!Float.isFinite(confidence)||confidence<.78f)return UNKNOWN;
  switch(label.trim().toLowerCase(Locale.ROOT)){case "person":case "people":case "portrait":case "selfie":case "face":return PERSON;
   case "landscape":case "mountain":case "nature":case "sky":case "beach":case "forest":return LANDSCAPE;
   case "text":case "document":case "screenshot":case "receipt":return DOCUMENT;default:return UNKNOWN;}}
 static int choose(int fallback,float aspect,int kind){if(fallback<0||fallback>=138)return fallback;if(!Float.isFinite(aspect)||aspect<=0)return fallback;int family=fallback%6;
  if(kind==PERSON&&aspect<=1.05f)return 126+family;
  if(kind==LANDSCAPE&&aspect>=1.25f)return 132+family;
  if(kind==DOCUMENT)return (aspect>=1.25f?132:126)+4;
  return fallback;}
 static boolean significantFace(int l,int t,int r,int b,int w,int h){if(w<=0||h<=0)return false;double width=Math.max(0L,(long)Math.min(w,r)-Math.max(0,l)),height=Math.max(0L,(long)Math.min(h,b)-Math.max(0,t));return width/w>=.12&&height/h>=.12&&width*height/((double)w*h)>=.025;}
 /** Never request a timestamp outside the decoded video or maximum horizon. */
 static long nextTrackTime(long previous,long step,long start,long duration,long horizon){if(previous<start||start<0||duration<=0||step<=0||horizon<=0)return -1;long max= Math.min(duration-1,start>Long.MAX_VALUE-horizon?Long.MAX_VALUE:start+horizon);if(previous>=max)return -1;return previous+Math.min(step,max-previous);}
}
