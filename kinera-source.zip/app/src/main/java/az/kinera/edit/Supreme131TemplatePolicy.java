package az.kinera.edit;
/** Composition windows and optional aspect-aware choice for new editorial presets. */
final class Supreme131TemplatePolicy {
 static final int FIRST=3484,TOTAL=3534;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=k%10*.0013f;float[][] a={{.013f,.033f,.987f,.967f},{.019f,.102f,.981f,.898f},{.031f,.164f,.969f,.836f},{.024f,.228f,.976f,.772f},{.036f,.289f,.964f,.711f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,31)!=19)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Supreme131TemplatePolicy(){}
}
