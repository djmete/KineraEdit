package az.kinera.edit;
final class EditorWorkspacePolicy {
 static boolean scrollTools(int width,float font){return width<400||font>1.15f;}
 static int toolWidth(float font){return Math.max(86,Math.min(152,Math.round(86*Math.max(1,Float.isFinite(font)?font:1))));}
 static int blurMenuWidth(int width){return width<400?52:72;}
 static int toolExtra(int availableDp,boolean compact){return compact||availableDp<720?6:16;}
 static boolean showMetadata(int height,float font){return height>=900&&font<=1.15f;}
 static boolean showSeparateSeek(int height,int mode,boolean focus){return !focus&&height>=470&&(mode==2?height>=540:DeepEditorLayout.showSeek(height,mode,false))&&!DeepEditorLayout.showFilmstrip(height,mode,focus);}
}
