package az.kinera.edit;
final class EditorWorkspacePolicy {
 static boolean scrollTools(int width,float font){return width<380||font>1.15f;}
 static int toolWidth(float font){return Math.max(86,Math.min(152,Math.round(86*Math.max(1,Float.isFinite(font)?font:1))));}
 static int blurMenuWidth(int width){return width<380?56:72;}
 static boolean showMetadata(int height,float font){return height>=850&&font<=1.15f;}
 static boolean showSeparateSeek(int height,int mode,boolean focus){return !focus&&DeepEditorLayout.showSeek(height,mode,false)&&height>=470;}
}
