package az.kinera.edit;
/** Suppress accents during dense montage without changing timing or user-selected effects. */
final class Adaptive122Director {
 static float density(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(left<=0||right<=0)return 0;long span=left+right;return span<5000000L?.70f:span<9000000L?.70f+.30f*(span-5000000L)/4000000f:1f;}
 private Adaptive122Director(){}
}
