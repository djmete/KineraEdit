package az.kinera.edit;
/** Conservative geometry suggestion for a user-confirmed edit of authorized material. */
final class CaptionRegionMath {
 static float[] include(float[] current,float l,float t,float r,float b){
  if(!Float.isFinite(l)||!Float.isFinite(t)||!Float.isFinite(r)||!Float.isFinite(b)||l<0||r>1.01f||l>=r||t<.55f||b>1.01f||b-t<=0||b-t>.16f||r-l<.12f)return current;
  l=Math.max(0,l);t=Math.max(0,t);r=Math.min(1,r);b=Math.min(1,b);
  float[] next=RegionMath.active(current)?new float[]{Math.min(current[0],l),Math.min(current[1],t),Math.max(current[2],r),Math.max(current[3],b)}:new float[]{l,t,r,b};
  if(RegionMath.active(current)){float gap=Math.max(0,Math.max(t-current[3],current[1]-b));float overlap=Math.min(r,current[2])-Math.max(l,current[0]);if(gap>.04f||overlap<.20f*Math.min(r-l,current[2]-current[0]))return current;}
  // Do not combine scattered lines into a large unrelated region.
  return next[3]-next[1]>.24f?current:next;
 }
 /** Prefer the strongest compact cluster, not OCR enumeration order. Bounded at 64 lines. */
 static float[] best(java.util.List<float[]> lines){float[] best=RegionMath.empty();float score=-1;if(lines==null)return best;int n=Math.min(64,lines.size());for(int i=0;i<n;i++){float[] seed=lines.get(i);if(!RegionMath.active(seed))continue;float[] r=include(RegionMath.empty(),seed[0],seed[1],seed[2],seed[3]);if(!RegionMath.active(r))continue;int count=1;for(int k=0;k<n;k++){if(k==i)continue;float[] c=lines.get(k);if(!RegionMath.active(c))continue;float[] joined=include(r,c[0],c[1],c[2],c[3]);if(joined!=r){boolean grows=joined[0]<r[0]||joined[1]<r[1]||joined[2]>r[2]||joined[3]>r[3];r=joined;if(grows)count++;}}float v=(r[2]-r[0])+.08f*Math.min(count,3)-.4f*(r[3]-r[1]);if(v>score){score=v;best=r;}}return best;}
 /** Legacy v2.7 lower-band suggestion, using current source-normalized crop coordinates. */
 static float[] legacyBand(float start,float[] crop){
  if(!RegionMath.active(crop)||!Float.isFinite(start))return RegionMath.empty();
  int amount=CaptionBandMath.blurPercent(start,crop[1],1f-crop[3]);
  if(amount<=0)return RegionMath.empty();
  float y=crop[3]-(crop[3]-crop[1])*amount/100f;
  return new float[]{crop[0],Math.max(crop[1],y),crop[2],crop[3]};
 }
 static float[] padded(float[] r){if(!RegionMath.active(r))return RegionMath.empty();return RegionMath.rect(r[0]-.012f,r[1]-.008f,r[2]+.012f,r[3]+.008f,.001f);}
}
