package az.kinera.edit;
/** Respect source pacing: bounded effect width and amplitude, no source reordering. */
final class Supreme131Rhythm {
 static long width(long[] cuts,int i,long duration,long desired){long base=Director124Rhythm.width(cuts,i,duration,desired);if(base<=0)return 0;long l=cuts[i]-(i==0?0:cuts[i-1]),r=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];long shortest=Math.min(l,r);if(shortest<=0)return 0;return Math.min(base,Math.max(1,shortest/6));}
 static float scale(long[] cuts,int i,long duration){float prior=Ultimate130Rhythm.scale(cuts,i,duration);if(prior<=0)return 0;long l=cuts[i]-(i==0?0:cuts[i-1]),r=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];float shortShot=Math.min(1f,Math.min(l,r)/1800000f);return prior*(.82f+.18f*shortShot);}
 private Supreme131Rhythm(){}
}
