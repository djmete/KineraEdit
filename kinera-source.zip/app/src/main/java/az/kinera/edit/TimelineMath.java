package az.kinera.edit;
import java.util.Locale;
final class TimelineMath {
 private TimelineMath(){}
 static long position(int value,int max,long duration){if(max<=0||duration<=0)return 0;return Math.round((double)Math.max(0,Math.min(max,value))/max*duration);}
 static int progress(long position,long duration,int max){if(duration<=0||max<=0)return 0;return (int)Math.round((double)Math.max(0,Math.min(duration,position))/duration*max);}
 static boolean shouldSeek(long lastMs,long nowMs,boolean finalEvent){return finalEvent||lastMs<0||nowMs<lastMs||nowMs-lastMs>=80;}
 static String[] rulerLabels(long duration){if(duration<=0)return new String[0];int n=duration<4000?2:duration<15000?3:5;String[] labels=new String[n];for(int i=0;i<n;i++)labels[i]=time(position(i,n-1,duration));return labels;}
 static String time(long millis){long t=Math.max(0,millis)/1000;return t>=3600?String.format(Locale.ROOT,"%d:%02d:%02d",t/3600,t/60%60,t%60):String.format(Locale.ROOT,"%02d:%02d",t/60,t%60);}
}
