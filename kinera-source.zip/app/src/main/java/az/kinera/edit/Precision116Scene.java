package az.kinera.edit;
/** Conservative translation veto on uncertain cuts; does not change timestamps or invent cuts. */
final class Precision116Scene {
 static float guard(int[] a,int[] b,float score,boolean pressure){
  if(pressure||!Float.isFinite(score)||score<.28f||score>.62f||a==null||b==null||a.length!=2304||b.length!=2304)return score;
  double base=error(a,b,0,0),best=base;int bx=0,by=0;
  if(base<.045)return score;
  for(int y=-3;y<=3;y++)for(int x=-3;x<=3;x++){if(x==0&&y==0)continue;double e=error(a,b,x,y);if(e<best){best=e;bx=x;by=y;}}
  if((bx!=0||by!=0)&&best<.075&&best<base*.43&&consistent(a,b,bx,by))return score*.78f;
  return score;
 }
 private static double error(int[] a,int[] b,int dx,int dy){double e=0;int n=0;for(int y=4;y<44;y+=2)for(int x=4;x<44;x+=2){int u=a[y*48+x],v=b[(y+dy)*48+x+dx];e+=Math.abs(SceneMath.luma(u)-SceneMath.luma(v))+Math.abs(((u>>16)&255)-((v>>16)&255))*.25;n++;}return e/(n*318.75);}
 private static boolean consistent(int[] a,int[] b,int dx,int dy){int good=0;for(int yy=4;yy<44;yy+=20)for(int xx=4;xx<44;xx+=20){double e=0,z=0;for(int y=yy;y<yy+20;y+=2)for(int x=xx;x<xx+20;x+=2){int u=SceneMath.luma(a[y*48+x]);z+=Math.abs(u-SceneMath.luma(b[y*48+x]));e+=Math.abs(u-SceneMath.luma(b[(y+dy)*48+x+dx]));}if(z>500&&e<z*.58&&e<1900)good++;}return good>=3;}
 private Precision116Scene(){}
}
