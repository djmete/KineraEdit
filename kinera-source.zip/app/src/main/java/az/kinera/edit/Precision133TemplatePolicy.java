package az.kinera.edit;
/** Five composition families, ten contrasting palettes. Previous IDs remain stable. */
final class Precision133TemplatePolicy {
 static final int FIRST=3584,TOTAL=3634;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=k%10*.0012f;float[][] a={{.012f,.038f,.988f,.962f},{.022f,.102f,.978f,.898f},{.034f,.189f,.966f,.811f},{.042f,.251f,.958f,.749f},{.052f,.325f,.948f,.675f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,41)!=29)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Precision133TemplatePolicy(){}
}
