package az.kinera.edit;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import androidx.media3.common.MimeTypes;
/** Conservative codec advertisement preflight; actual encoding can still fail. */
final class CodecCheck {
 static String[] sourceTypes(android.content.Context c,android.net.Uri u){String[] types={"",""};android.media.MediaExtractor e=new android.media.MediaExtractor();try{e.setDataSource(c,u,null);for(int i=0;i<e.getTrackCount();i++){String m=e.getTrackFormat(i).getString(android.media.MediaFormat.KEY_MIME);if(m==null)continue;if(m.startsWith("video/")&&types[0].isEmpty())types[0]=m;if(m.startsWith("audio/")&&types[1].isEmpty())types[1]=m;}}catch(Exception ignored){}finally{try{e.release();}catch(Exception ignored){}}return types;}
 static boolean supported(EditSpec s){
  String mime=s.hevc?MimeTypes.VIDEO_H265:MimeTypes.VIDEO_H264;
  try {for(MediaCodecInfo info:new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()){
   if(!info.isEncoder())continue;
   for(String type:info.getSupportedTypes())if(type.equalsIgnoreCase(mime))try{
    MediaCodecInfo.VideoCapabilities v=info.getCapabilitiesForType(type).getVideoCapabilities();
    if(v!=null&&v.areSizeAndRateSupported(s.width,s.height,s.fps))return true;
   }catch(RuntimeException ignored){}
  }}catch(RuntimeException ignored){}return false;
 }
}
