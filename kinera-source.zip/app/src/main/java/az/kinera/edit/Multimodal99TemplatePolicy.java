package az.kinera.edit;
final class Multimodal99TemplatePolicy {
 static final int FIRST=1734,TOTAL=1784;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.024f,.988f,.976f};case 1:return new float[]{.024f,.075f,.976f,.925f};case 2:return new float[]{.024f,.23225f,.976f,.76775f};case 3:return new float[]{.024f,.2935f,.976f,.7065f};default:return new float[]{.024f,.3256f,.976f,.6744f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,43)!=31)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/43,10),10);}
}
