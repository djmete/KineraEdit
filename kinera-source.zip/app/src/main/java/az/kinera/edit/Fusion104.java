package az.kinera.edit;
import java.nio.FloatBuffer;
import java.util.List;
/** Subject evidence and caption candidate ranking. No per-frame allocation for segmentation. */
final class Fusion104 {
 static boolean subject(FloatBuffer f,int w,int h){if(f==null||w<8||h<8||(long)w*h>1048576||f.remaining()<(long)w*h)return false;int base=f.position(),n=0,fg=0,central=0,minX=w,minY=h,maxX=-1,maxY=-1;int step=Math.max(1,Math.max(w,h)/128);for(int y=0;y<h;y+=step)for(int x=0;x<w;x+=step){float v=f.get(base+y*w+x);if(!Float.isFinite(v)||v<0||v>1)return false;n++;if(v>=.85f){fg++;if(x>=w*.15&&x<w*.85)central++;minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}}return fg>=n*.10&&fg<=n*.90&&central>=fg*.65&&(maxX-minX+step)>=w*.18&&(maxY-minY+step)>=h*.30;}
 static float rank(float[] r){if(!RegionMath.active(r))return -10;float w=r[2]-r[0],h=r[3]-r[1],center=Math.abs((r[0]+r[2])*.5f-.5f);return Math.min(.6f,w)+.26f*(1-Math.min(1,center*3))-.6f*h-(center>.22f?.18f:0);}
 static float[] caption(float[] legacy,List<float[]> lines,List<float[]> shorts){float[] best=legacy;float score=rank(best);if(lines!=null)for(int i=0;i<Math.min(64,lines.size());i++){float[] seed=lines.get(i);if(!RegionMath.active(seed)||Math.abs((seed[0]+seed[2])*.5f-.5f)>.20f)continue;float[] group=seed;for(int j=0;j<Math.min(64,lines.size());j++){if(i!=j) {float[] q=lines.get(j);if(RegionMath.active(q)&&Math.abs((q[0]+q[2])*.5f-.5f)<=.20f)group=CaptionRegionMath.include(group,q[0],q[1],q[2],q[3]);}}if(RegionMath.active(legacy)&&group[1]+.05f<legacy[1])continue;float v=rank(group);if(v>score+.045f){best=group;score=v;}}if(shorts!=null&&(!RegionMath.active(best)||Math.abs((best[0]+best[2])*.5f-.5f)>.22f))for(float[] q:shorts){if(!RegionMath.active(q)||Math.abs((q[0]+q[2])*.5f-.5f)>.075f)continue;if(RegionMath.active(legacy)&&q[1]+.05f<legacy[1])continue;float v=rank(q);if(v>score+.045f){best=q;score=v;}}return best;}
 static float[] rescueChoice(float[] first,float[] second){if(RegionMath.active(first)&&RegionMath.active(second)&&second[1]+.05f<first[1])return first;return Deep103.choose(first,second);}
 static long scrubInterval(boolean pressure){return pressure?160:100;}
 static boolean seek(long last,long now,boolean end,boolean pressure){return end||last<0||now<last||now-last>=scrubInterval(pressure);}
 private Fusion104(){}
}
