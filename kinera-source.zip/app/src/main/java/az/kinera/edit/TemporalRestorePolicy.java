package az.kinera.edit;
import java.util.List;
/** Up to two previous frames, bounded memory and no reuse across cuts or seeks. */
final class TemporalRestorePolicy {
 static final long MAX_GAP_US=250000L;
 static boolean eligible(long previous,long now,long[] cuts){if(previous<0||now<=previous||now-previous>MAX_GAP_US)return false;if(cuts==null)return false;for(long cut:cuts)if(cut>previous&&cut<=now)return false;return true;}
 static boolean recent(long previous,long now,long[] cuts,int fps){return eligible(previous,now,cuts)&&now-previous<=Math.min(MAX_GAP_US,Math.max(50000L,2000000L/Math.max(12,fps)));}
 static boolean coherentPair(long older,long previous,long now,long[] cuts,int fps){return recent(older,previous,cuts,fps)&&recent(previous,now,cuts,fps)&&recent(older,now,cuts,fps)&&now-older<=Math.min(MAX_GAP_US,Math.max(50000L,3000000L/Math.max(12,fps)));}
 static boolean fits(int w,int h){return w>0&&h>0&&(long)w*h<=1920L*1080;}
 static boolean fitsPair(int w,int h){return w>0&&h>0&&(long)w*h<=1280L*720;}
 static boolean capture(List<TimedRegions.Mask> masks,long now){if(now<0||masks==null)return false;for(TimedRegions.Mask m:masks)if(m.restore&&m.until>now&&(m.from<=now||m.from-now<=MAX_GAP_US))return true;return false;}
}
