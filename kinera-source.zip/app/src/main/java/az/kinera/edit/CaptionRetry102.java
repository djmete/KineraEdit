package az.kinera.edit;
/** No additional decoder work. Eight crop OCR attempts at most, only with headroom. */
final class CaptionRetry102 {
 static boolean allowed(int count,int edge,long at,long previous,long now,long deadline){return count<8&&edge>=960&&(previous==Long.MIN_VALUE||at>=previous&&at-previous>=1500000L)&&deadline-now>=15000;}
 private CaptionRetry102(){}
}
