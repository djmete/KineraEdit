package az.kinera.edit;
final class Context111TemplatePolicy {
 static final int FIRST=2734,TOTAL=2784;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.020f,.988f,.980f};case 1:return new float[]{.026f,.055f,.974f,.945f};case 2:return new float[]{.022f,.228f,.978f,.772f};case 3:return new float[]{.030f,.268f,.970f,.732f};default:return new float[]{.018f,.327f,.982f,.673f};}}
 static int choose(int prior,float aspect,int semantic,int palette){if(prior<2684||prior>=2734||!Float.isFinite(aspect)||aspect<=0||semantic!=CreativePolicy.PERSON)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Context111TemplatePolicy(){}
}
