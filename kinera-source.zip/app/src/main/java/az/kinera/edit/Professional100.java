package az.kinera.edit;
/** Bounded mobile work, independent of the selected export resolution. */
final class Professional100 {
 static int ocrEdge(boolean pressure){return pressure?720:960;}
 static int filmSlots(int availableDp,boolean pressure){return pressure?0:availableDp<720?6:10;}
 static int filmHeight(int availableDp){return availableDp<720?54:66;}
 static float accentScale(long[] cuts,int i,long duration){if(!Production84Math.validCut(cuts,i,duration))return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];float gap=Math.min(left,right)/1000000f;return .70f+.30f*Math.max(0,Math.min(1,(gap-1f)/2f));}
 static boolean placeholder(int count,boolean loading){return count==0&&!loading;}
 static boolean restorePreview(boolean active,boolean editor,boolean blocked,boolean missing){return active&&editor&&!blocked&&missing;}
}
