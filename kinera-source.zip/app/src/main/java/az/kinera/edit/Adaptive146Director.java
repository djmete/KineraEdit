package az.kinera.edit;
/** Short-side restraint with a smooth onset; source chronology is never changed. */
final class Adaptive146Director {
 static float side(long[] cuts,int i,long duration,long time){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 1;long l=cuts[i]-(i==0?0:cuts[i-1]),r=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(l<=0||r<=0)return 1;long shortSide=Math.min(l,r),longSide=Math.max(l,r);if(shortSide>=2500000L||longSide<2.5*shortSide)return 1;boolean onShort=time<cuts[i]?l<r:r<l;if(!onShort)return 1;float x=Math.max(0,Math.min(1,Math.abs(time-cuts[i])/220000f));return 1-.24f*x*x*(3-2*x);}
 private Adaptive146Director(){}
}
