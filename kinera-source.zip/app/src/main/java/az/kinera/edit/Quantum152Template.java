package az.kinera.edit;
final class Quantum152Template {
 static final int FIRST=4484,TOTAL=4534;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0013f;float[][] a={{.024f,.108f,.976f,.892f},{.04f,.162f,.96f,.838f},{.055f,.217f,.945f,.783f},{.072f,.276f,.928f,.724f},{.087f,.324f,.913f,.676f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,113)!=103)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Quantum152Template(){}
}
