package az.kinera.edit;
/** Maintain current-frame text coverage while rejecting excessive neighbor expansion. */
final class Visual121Caption {
 static float[] stabilize(float[] anchor,float[] candidate){float[] r=Vision120Caption.stabilize(anchor,candidate);if(!RegionMath.active(anchor)||!RegionMath.active(r))return r;float[] u={Math.min(anchor[0],r[0]),Math.min(anchor[1],r[1]),Math.max(anchor[2],r[2]),Math.max(anchor[3],r[3])};float a=(anchor[2]-anchor[0])*(anchor[3]-anchor[1]);float b=(u[2]-u[0])*(u[3]-u[1]);return b<=a*1.25f?u:anchor.clone();}
 private Visual121Caption(){}
}
