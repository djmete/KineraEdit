package az.kinera.edit;
final class Spatial137Workspace {
 static boolean redraw(long prev,long pos,long oldDuration,long duration,int oldWidth,int width){return width>0&&(oldWidth!=width||Deep136Workspace.redraw(prev,pos,oldDuration,duration,width));}
 private Spatial137Workspace(){}
}
