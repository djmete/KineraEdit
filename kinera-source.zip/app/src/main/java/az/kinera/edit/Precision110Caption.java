package az.kinera.edit;
/** Only join compatible OCR observations inside one known shot. Never propagate through a cut. */
final class Precision110Caption {
 static float[] sameShotUnion(float[] a,float[] b,long t1,long t2,long[] cuts,boolean restore){
  if(t2<t1||cuts==null||!PrecisionCaptionPlan.compatible(a,b))return RegionMath.empty();
  for(long c:cuts)if(c>t1&&c<=t2)return RegionMath.empty();
  float[] u=DenseCaptionPlan.union(a,b);
  if(!Context111Caption.safeArea(a,b,u))return RegionMath.empty();
  if(restore&&(!RestorePolicy.usable(a)||!RestorePolicy.usable(b)||!RestorePolicy.usable(u)||!Temporal97.safeUnion(a,b)))return RegionMath.empty();
  return u;
 }
 private Precision110Caption(){}
}
