package az.kinera.edit;
/** Fine absolute zoom; 1000 steps, anchor retained on no-op and ratio preserved. */
final class Performance142Crop {
 static final int STEPS=1000;
 static float span(float[] r){return Math.max(r[2]-r[0],r[3]-r[1]);}
 static float minSpan(float[] r){float max=span(r),min=Math.min(r[2]-r[0],r[3]-r[1]);return Math.min(max,.035f*max/min);}
 static int progress(float[] r){if(!RegionMath.active(r))return 0;float min=minSpan(r);if(min>=.999999f)return 0;return Math.round(STEPS*EditMath.clamp((1-span(r))/(1-min),0,1));}
 static float[] zoom(float[] r,int p){if(!RegionMath.active(r))r=RegionMath.full();p=Math.max(0,Math.min(STEPS,p));if(p==progress(r))return r.clone();float min=minSpan(r);return Crop139.pinch(r,(1-(1-min)*p/STEPS)/span(r),0,0);}
 /** Pick near corners or edges with a generous touch band, retaining a central move target. */
 static int hit(float l,float t,float r,float b,float x,float y,float d,boolean free){if(!(r>l&&b>t&&d>0))return 0;float w=r-l,h=b-t,cx=(l+r)*.5f,cy=(t+b)*.5f;float rad=Math.min(30*d,Math.min(w,h)*.40f);if(x<l-rad||x>r+rad||y<t-rad||y>b+rad)return 0;if(Math.abs(x-cx)<w*.16f&&Math.abs(y-cy)<h*.16f)return 5;float[] xs={l,r,l,r,cx,cx,l,r},ys={t,t,b,b,t,b,cy,cy};int[] ids={1,2,3,4,6,7,8,9};int best=0;float dist=rad*rad;for(int i=0;i<(free?8:4);i++){float dx=x-xs[i],dy=y-ys[i],q=dx*dx+dy*dy;if(q<=dist){best=ids[i];dist=q;}}if(best!=0)return best;if(free){if(Math.abs(x-l)<=rad&&y>=t&&y<=b)return 8;if(Math.abs(x-r)<=rad&&y>=t&&y<=b)return 9;if(Math.abs(y-t)<=rad&&x>=l&&x<=r)return 6;if(Math.abs(y-b)<=rad&&x>=l&&x<=r)return 7;}return x>=l&&x<=r&&y>=t&&y<=b?5:0;}
 private Performance142Crop(){}
}
