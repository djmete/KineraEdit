package az.kinera.edit;
import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.BaseAudioProcessor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
/** Attenuates the entire mix; this does not separate speech from music. */
@androidx.media3.common.util.UnstableApi
final class GainProcessor extends BaseAudioProcessor {
 private final int percent;
 GainProcessor(int percent){this.percent=KAiEdit.gainPercent(percent);}
 @Override protected AudioFormat onConfigure(AudioFormat input) throws AudioProcessor.UnhandledAudioFormatException {
  if(input.encoding!=C.ENCODING_PCM_16BIT&&input.encoding!=C.ENCODING_PCM_FLOAT)throw new AudioProcessor.UnhandledAudioFormatException(input);
  return input;
 }
 @Override public void queueInput(ByteBuffer input){int bytes=input.remaining();int sampleBytes=inputAudioFormat.encoding==C.ENCODING_PCM_FLOAT?4:2;int frames=inputAudioFormat.bytesPerFrame;if(frames<=0||bytes%frames!=0)throw new IllegalArgumentException("Unaligned PCM frame");ByteBuffer out=replaceOutputBuffer(bytes).order(ByteOrder.nativeOrder());input.order(ByteOrder.nativeOrder());while(input.remaining()>=sampleBytes){if(sampleBytes==4)out.putFloat(KAiEdit.scaleFloat(input.getFloat(),percent));else out.putShort(KAiEdit.scalePcm(input.getShort(),percent));}out.flip();}
}
