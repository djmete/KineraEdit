package az.kinera.edit;
/** Downsampled luminance alignment; only vetoes refinement of a preexisting marker. */
final class SemanticMotionMath {
 static final int MAX_PROBES=28;static final long BUDGET_MS=26000L;
 static int[] indices(int count){if(count<=0)return new int[0];int n=Math.min(count,MAX_PROBES);int[] a=new int[n];if(n>1)for(int i=0;i<n;i++)a[i]=(int)((long)i*(count-1)/(n-1));return a;}
 static final int[][] SHIFTS={{0,1},{0,-1},{1,0},{-1,0},{0,2},{0,-2},{2,0},{-2,0},{1,1},{1,-1},{-1,1},{-1,-1}};
 static int pixel(int[] a,int y,int x){return a[(y*3+1)*48+x*3+1];}
 static double[] features(int[] a,int[] b){if(a==null||b==null||a.length!=2304||b.length!=2304)return null;double ma=0,mb=0,aa=0,bb=0,raw=0;for(int y=2;y<14;y++)for(int x=2;x<14;x++){double v=pixel(a,y,x)/255.,w=pixel(b,y,x)/255.;ma+=v;mb+=w;aa+=v*v;bb+=w*w;raw+=Math.abs(v-w);}ma/=144;mb/=144;raw/=144;double sa=Math.sqrt(Math.max(0,aa/144-ma*ma)),sb=Math.sqrt(Math.max(0,bb/144-mb*mb)),best=raw,center=0;for(int y=2;y<14;y++)for(int x=2;x<14;x++)center+=Math.abs((pixel(a,y,x)-pixel(b,y,x))/255.-ma+mb);for(int[] shift:SHIFTS){double e=0;for(int y=2;y<14;y++)for(int x=2;x<14;x++)e+=Math.abs(pixel(a,y,x)-pixel(b,y+shift[0],x+shift[1]))/255.;best=Math.min(best,e/144);}return new double[]{raw,best,raw-best,Math.abs(ma-mb),center/144,sa,sb,Math.abs(sa-sb)};}
 static boolean veto(int[] a,int[] b,double distance){return distance>=.16&&SemanticMotionConfidence.reject(features(a,b));}
 /** Agreement across three import frames; disagreements leave template selection neutral. */
 static int consensus(int[] kinds){if(kinds==null||kinds.length!=3)return 0;int[] votes=new int[4];for(int k:kinds)if(k>0&&k<4)votes[k]++;for(int k=1;k<4;k++)if(votes[k]>=2)return k;return kinds[0]==0&&kinds[2]==0&&kinds[1]>0&&kinds[1]<4?kinds[1]:0;}
}
