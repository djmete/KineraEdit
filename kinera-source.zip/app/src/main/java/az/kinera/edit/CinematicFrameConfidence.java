package az.kinera.edit;
final class CinematicFrameConfidence {
 static final boolean ENABLED=false; static final double SCALE=1.9099999917671084e-05;
 private static final short[] W={12562,4925,32767,22951,-10614,17718,-11773,25777,10575,-49,-17732,23240,12353,7085,-14555,-5090,7923,-10252,-15544,-15527,-12826,27148,14740,3735,1520,-5518,-5357,12351,10311,-81,1697,-13942,18930,12929,-23475,-29618,1794,29453,28317,16482,11909,-22674,-25904,7351,18202,-20878,-1980,15524,-15627,12352,-12573,-16710,2535,22119,-9719,17330,-1538,-15288,504,-32608,23012,25142,23648,28692,758,-13489,667,-29912,2346,24369,21428,-22590,-23785,13612,15079,-17827,-19171,-27225,10742,13794,-3079,25821,-18781,3676,4447};
 static double score(double a,double b,double c,double d,double e){double[] x={a,b,c,d,e};double sum=W[84]*SCALE;for(int j=0;j<12;j++){double h=W[60+j]*SCALE;for(int i=0;i<5;i++)h+=x[i]*W[i*12+j]*SCALE;sum+=Math.tanh(h)*W[72+j]*SCALE;}return Math.max(0,Math.min(1,a+.5*Math.max(-.03,Math.min(.03,sum))));}
}
