package az.kinera.edit;
import java.util.TreeSet;
/** Complete sequential pass may add only clear, isolated scene cuts, never delete old edits. */
final class Precision116FramePlan {
 static final int MAX_FRAMES=420;
 static boolean eligible(long duration,long remaining,boolean pressure){return !pressure&&duration>=1800000L&&duration<=12000000L&&remaining>=4000L;}
 static double delta(int[] a,int[] b){if(a==null||b==null||a.length!=2304||b.length!=2304)return 0;long sum=0;for(int i=0;i<a.length;i++)sum+=Math.abs(a[i]-b[i]);return sum/(2304d*255);}
 static boolean pulse(int[] a,int[] b,int[] c,double x,double y){return a!=null&&x>.26&&y>.26&&delta(a,c)<.11;}
 static long[] merge(long[] base,long[] pts,double[] score,boolean[] blocked,int n,long duration,boolean complete){
  if(!complete||pts==null||score==null||blocked==null||n<5||n>pts.length||n>score.length||n>blocked.length)return base;
  for(int i=0;i<n;i++)if(!Double.isFinite(score[i])||(i>0&&(pts[i]<=pts[i-1]||pts[i]-pts[i-1]>150000)))return base;
  TreeSet<Long> accepted=new TreeSet<>();for(long v:base)accepted.add(v);
  for(int i=1;i<n-1;i++){long t=pts[i];if(t<900000||t>duration-900000||blocked[i-1]||blocked[i]||blocked[i+1]||score[i]<.34||score[i-1]>.13||score[i+1]>.13||accepted.size()>=120)continue;
   Long before=accepted.floor(t),after=accepted.ceiling(t);if(before!=null&&t-before<2200000||after!=null&&after-t<2200000)continue;accepted.add(t);}
  long[] out=new long[accepted.size()];int k=0;for(long v:accepted)out[k++]=v;return out;
 }
 private Precision116FramePlan(){}
}
