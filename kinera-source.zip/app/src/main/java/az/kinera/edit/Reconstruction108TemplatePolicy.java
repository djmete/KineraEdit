package az.kinera.edit;
final class Reconstruction108TemplatePolicy {
 static final int FIRST=2584,TOTAL=2634;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.025f,.988f,.975f};case 1:return new float[]{.018f,.09f,.982f,.91f};case 2:return new float[]{.022f,.231f,.978f,.769f};case 3:return new float[]{.022f,.272f,.978f,.728f};default:return new float[]{.02f,.325f,.98f,.675f};}}
 static int choose(int prior,float aspect,int semantic,int palette){if(prior<2534||prior>=2584||semantic!=CreativePolicy.PERSON||!Float.isFinite(aspect)||aspect<=0)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Reconstruction108TemplatePolicy(){}
}
