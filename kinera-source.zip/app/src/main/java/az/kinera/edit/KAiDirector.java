package az.kinera.edit;
import android.content.Context;
import android.net.Uri;
import java.util.List;
/** One offline orchestration boundary for import, OtoEdit, OCR, tracking and export. */
final class KAiDirector {
 private KAiDirector(){}
 static AutoPlan plan(Context c,Uri u,long duration,AutoPlan.Progress p)throws Exception{return AutoPlan.analyze(c,u,duration,p);}
 static long[] scenes(Context c,Uri u,long duration)throws Exception{return plan(c,u,duration,null).cuts;}
 static int palette(int[] rgb){return KineraAI.paletteFor(rgb);}
 static int template(int[] rgb,int palette,float aspect,int seed){return VisionMath.chooseTemplate(rgb,palette,aspect,seed);}
 static int template(int[] rgb,int palette,float aspect,int seed,int semantic){int fallback=template(rgb,palette,aspect,seed);return UltimateTemplatePolicy.choose(AdvancedTemplatePolicy.choose(UltraTemplatePolicy.choose(ReactiveMotionMath.choose(ExpertTemplatePolicy.choose(CreativePolicy.choose(fallback,aspect,semantic),aspect,semantic),aspect,semantic),aspect,semantic,seed),aspect,semantic,seed),aspect,semantic,seed);}
 static int semantic(android.graphics.Bitmap b){int kind=SemanticVision.classify(b);return kind==CreativePolicy.UNKNOWN&&PortraitVision.present(b)?CreativePolicy.PERSON:kind;}
 static int[] grade(int[] rgb){return ChromaGuard.guard(rgb,ExposureRisk.guard(rgb,AutonomousMath.grade(rgb)));}
 static int gain(Context c,Uri u,long duration){return AudioLevelProbe.measure(c,u,duration);}
 static CaptionReview.Suggestion blur(Context c,Uri u,long at,int w,int h,long duration)throws Exception{return CaptionReview.detectAdaptive(c,u,at,w,h,duration);}
 static List<TimedRegions.Mask> fullRestore(Context c,Uri u,long duration,int w,int h,java.util.function.BooleanSupplier cancelled,java.util.function.IntConsumer progress)throws Exception{int n=FullCaptionPlan.windows(duration);if(n==0)throw new IllegalArgumentException("duration");java.util.ArrayList<float[]> regions=new java.util.ArrayList<>();for(int i=0;i<n;i++){if(cancelled.getAsBoolean()||Thread.currentThread().isInterrupted())throw new InterruptedException();CaptionReview.Suggestion s=CaptionReview.detectSuggestion(c,u,FullCaptionPlan.sample(duration,i,n),w,h);regions.add(s.region);progress.accept((i+1)*100/n);}if(cancelled.getAsBoolean())throw new InterruptedException();return FullCaptionPlan.build(duration,regions);}
 static List<TimedRegions.Mask> denseRestore(Context c,Uri u,long duration,int w,int h,java.util.function.BooleanSupplier cancelled,java.util.function.IntConsumer progress)throws Exception{int n=FullCaptionPlan.windows(duration);if(n==0)throw new IllegalArgumentException("duration");java.util.ArrayList<float[]> left=new java.util.ArrayList<>(),right=new java.util.ArrayList<>();android.media.MediaMetadataRetriever reader=new android.media.MediaMetadataRetriever();long deadline=android.os.SystemClock.elapsedRealtime()+170000L;try{reader.setDataSource(c,u);for(int i=0;i<n;i++){if(cancelled.getAsBoolean()||Thread.currentThread().isInterrupted()||android.os.SystemClock.elapsedRealtime()>=deadline)throw new InterruptedException();long a=FullCaptionPlan.boundary(duration,i,n),b=FullCaptionPlan.boundary(duration,i+1,n),t1=DenseCaptionPlan.first(a,b),t2=DenseCaptionPlan.second(a,b);float[] r=CaptionReview.detectAt(reader,t1,w,h).region;left.add(r);if(cancelled.getAsBoolean()||Thread.currentThread().isInterrupted()||android.os.SystemClock.elapsedRealtime()>=deadline)throw new InterruptedException();right.add(t2==t1?r:CaptionReview.detectAt(reader,t2,w,h).region);progress.accept((i+1)*100/n);}if(cancelled.getAsBoolean()||android.os.SystemClock.elapsedRealtime()>=deadline)throw new InterruptedException();return DenseCaptionPlan.build(duration,left,right);}finally{try{reader.release();}catch(Exception ignored){}}}
 static List<TimedRegions.Mask> track(Context c,Uri u,long at,long duration,float[] region)throws Exception{return MotionTrack.propose(c,u,at,duration,region);}
}
