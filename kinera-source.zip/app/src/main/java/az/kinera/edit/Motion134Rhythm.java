package az.kinera.edit;
/** Attenuate accents on short shots without changing cut timing. */
final class Motion134Rhythm {
 static float accent(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];long gap=Math.min(left,right);if(gap<=0)return 0;if(gap>=2400000)return 1;float x=gap/2400000f;return .72f+.28f*x*x*(3-2*x);}
 private Motion134Rhythm(){}
}
