package az.kinera.edit;
final class NotificationPolicy {
 static final long DAY=86400000L, INACTIVE=3*DAY;
 private NotificationPolicy(){}
 static boolean reminderDue(boolean enabled,long now,long lastOpen,long lastReminder,boolean exporting){return enabled&&!exporting&&lastOpen>0&&now>=lastOpen&&now-lastOpen>=INACTIVE&&(lastReminder<=0||now>=lastReminder&&now-lastReminder>=INACTIVE);}
 static boolean dailyDue(boolean enabled,long now,long last,boolean exporting){return enabled&&!exporting&&(last<=0||now>=last&&now-last>=DAY);}
 static long progressDelay(long now,long last,boolean sameTitle,int percent){if(!sameTitle||percent>=100||last<0||now<last)return 0;return Math.max(0,1000-(now-last));}
 static long retryAwareDelay(long now,long last,boolean sameTitle,int previous,int percent){return percent<previous?0:progressDelay(now,last,sameTitle,percent);}
 static int percent(int p){return Math.max(0,Math.min(100,p));}
}
