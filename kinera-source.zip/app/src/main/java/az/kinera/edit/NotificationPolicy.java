package az.kinera.edit;
final class NotificationPolicy {
 static final long DAY=86400000L, INACTIVE=3*DAY;
 private NotificationPolicy(){}
 static boolean reminderDue(boolean enabled,long now,long lastOpen,long lastReminder,boolean exporting){return enabled&&!exporting&&lastOpen>0&&now>=lastOpen&&now-lastOpen>=INACTIVE&&(lastReminder<=0||now>=lastReminder&&now-lastReminder>=INACTIVE);}
 static boolean dailyDue(boolean enabled,long now,long last,boolean exporting){return enabled&&!exporting&&(last<=0||now>=last&&now-last>=DAY);}
 static int percent(int p){return Math.max(0,Math.min(100,p));}
}
