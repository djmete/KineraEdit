package az.kinera.edit;
/** Simulates the actual static grading shader on sampled RGB values. Never changes manual edits. */
final class ChromaGuard {
 private ChromaGuard(){}
 static boolean clipped(double r,double g,double b){return Math.min(r,Math.min(g,b))<-.005||Math.max(r,Math.max(g,b))>1.005;}
 static double addedClipping(int[] pixels,int[] grade){
  if(pixels==null||pixels.length==0||grade==null||grade.length<3)return 0;
  double c=.7+grade[1]*.006,br=(grade[0]-50)/250.,sat=grade[2]/50.;int base=0,after=0;
  for(int p:pixels){double r=(((p>>>16)&255)/255.-.5)*c+.5+br,g=(((p>>>8)&255)/255.-.5)*c+.5+br,b=((p&255)/255.-.5)*c+.5+br,y=.2126*r+.7152*g+.0722*b;
   if(clipped(r,g,b))base++;if(clipped(y+(r-y)*sat,y+(g-y)*sat,y+(b-y)*sat))after++;}
  return Math.max(0,(after-base)/(double)pixels.length);
 }
 static int[] guard(int[] pixels,int[] grade){if(grade==null||grade.length<3||pixels==null||pixels.length<16)return grade;while(grade[2]>50&&addedClipping(pixels,grade)>=.025)grade[2]--;return grade;}
}
