package az.kinera.edit;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
final class StudioNotifications {
 static final String WORK="kinera_export_work",DONE="kinera_export_done",REMINDER="kinera_reminder";
 static final int WORK_ID=3701,DONE_ID=3702,REMINDER_ID=3703;
 static void language(Context c){UiLanguage.set(c.getSharedPreferences("kinera",0).getString("ui_language_v26","system"),c.getResources().getConfiguration().getLocales().get(0).getLanguage());}
 static NotificationManager manager(Context c){return c.getSystemService(NotificationManager.class);}
 static void channels(Context c){language(c);NotificationManager m=manager(c);m.createNotificationChannel(new NotificationChannel(WORK,UiLanguage.tr("İxrac prosesi"),NotificationManager.IMPORTANCE_LOW));m.createNotificationChannel(new NotificationChannel(DONE,UiLanguage.tr("İxrac nəticələri"),NotificationManager.IMPORTANCE_DEFAULT));m.createNotificationChannel(new NotificationChannel(REMINDER,UiLanguage.tr("Montaj xatırlatmaları"),NotificationManager.IMPORTANCE_DEFAULT));}
 static PendingIntent open(Context c){Intent i=new Intent().setClassName(c,"az.kinera.edit.MainActivity").addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);return PendingIntent.getActivity(c,37,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static boolean allowed(Context c){return (Build.VERSION.SDK_INT<33||c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)&&manager(c).areNotificationsEnabled();}
 static Notification.Builder base(Context c,String channel){return new Notification.Builder(c,channel).setSmallIcon(R.drawable.ic_notify_kinera).setContentIntent(open(c)).setOnlyAlertOnce(true).setVisibility(Notification.VISIBILITY_PRIVATE);}
 static Notification working(Context c,String title,int percent){percent=NotificationPolicy.percent(percent);return base(c,WORK).setContentTitle(UiLanguage.tr("Kinera Edit • İxrac")).setContentText(title+" • "+percent+"%").setCategory(Notification.CATEGORY_PROGRESS).setShowWhen(false).setOngoing(true).setProgress(100,percent,false).build();}
 @android.annotation.SuppressLint("MissingPermission")
 static void result(Context c,String title,String detail){channels(c);if(!allowed(c))return;try{manager(c).notify(DONE_ID,base(c,DONE).setContentTitle(UiLanguage.tr(title)).setContentText(UiLanguage.tr(detail)).setStyle(new Notification.BigTextStyle().bigText(UiLanguage.tr(detail))).setAutoCancel(true).build());}catch(SecurityException ignored){}}
 @android.annotation.SuppressLint("MissingPermission")
 static boolean remind(Context c){channels(c);if(!allowed(c))return false;try{manager(c).notify(REMINDER_ID,base(c,REMINDER).setContentTitle("Kinera Edit").setContentText(DailyStudio.summary(c.getSharedPreferences("kinera",0))).setAutoCancel(true).build());return true;}catch(SecurityException ignored){return false;}}
}
