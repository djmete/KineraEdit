package az.kinera.edit;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
final class StudioNotifications {
 static final String RESULTS_ENABLED="export_result_notifications_v84";
 static final String WORK="kinera_export_work",DONE="kinera_export_done",REMINDER="kinera_reminder";
 static final int WORK_ID=3701,DONE_ID=3702,REMINDER_ID=3703;
 static void language(Context c){UiLanguage.set(c.getSharedPreferences("kinera",0).getString("ui_language_v26","system"),c.getResources().getConfiguration().getLocales().get(0).getLanguage());}
 static NotificationManager manager(Context c){return c.getSystemService(NotificationManager.class);}
 static void channels(Context c){language(c);NotificationManager m=manager(c);if(m==null)return;NotificationChannel work=new NotificationChannel(WORK,UiLanguage.tr("İxrac prosesi"),NotificationManager.IMPORTANCE_LOW);work.setDescription(UiLanguage.tr("Video ixracının gedişatı"));m.createNotificationChannel(work);NotificationChannel done=new NotificationChannel(DONE,UiLanguage.tr("İxrac nəticələri"),NotificationManager.IMPORTANCE_DEFAULT);done.setDescription(UiLanguage.tr("Video hazır olduqda və ya ixrac uğursuz olduqda"));m.createNotificationChannel(done);NotificationChannel reminder=new NotificationChannel(REMINDER,UiLanguage.tr("Montaj xatırlatmaları"),NotificationManager.IMPORTANCE_DEFAULT);reminder.setDescription(UiLanguage.tr("Gündəlik montaj xatırlatmaları"));m.createNotificationChannel(reminder);}
 static PendingIntent open(Context c){Intent i=new Intent().setClassName(c,"az.kinera.edit.MainActivity").addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);return PendingIntent.getActivity(c,37,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static boolean allowed(Context c){NotificationManager m=manager(c);try{return (Build.VERSION.SDK_INT<33||c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)&&m!=null&&m.areNotificationsEnabled();}catch(RuntimeException ignored){return false;}}
 static boolean channelAllowed(Context c,String id){try{NotificationManager m=manager(c);if(m==null||!allowed(c))return false;NotificationChannel ch=m.getNotificationChannel(id);return ch!=null&&ch.getImportance()!=NotificationManager.IMPORTANCE_NONE;}catch(RuntimeException ignored){return false;}}
 static Notification.Builder base(Context c,String channel){return new Notification.Builder(c,channel).setSmallIcon(R.drawable.ic_notify_kinera).setContentIntent(open(c)).setOnlyAlertOnce(true).setVisibility(Notification.VISIBILITY_PRIVATE).setColor(0xff9bc9ff);}
 static Notification working(Context c,String title,int percent){percent=NotificationPolicy.percent(percent);return base(c,WORK).setContentTitle(UiLanguage.tr("Kinera Edit • İxrac")).setContentText(title+" • "+percent+"%").setCategory(Notification.CATEGORY_PROGRESS).setShowWhen(false).setOngoing(true).setProgress(100,percent,false).build();}
 @android.annotation.SuppressLint("MissingPermission")
 static void result(Context c,String title,String detail){try{channels(c);}catch(RuntimeException ignored){return;}if(!c.getSharedPreferences("kinera",0).getBoolean(RESULTS_ENABLED,true)||!channelAllowed(c,DONE))return;try{manager(c).notify(DONE_ID,base(c,DONE).setOnlyAlertOnce(false).setContentTitle(UiLanguage.tr(title)).setContentText(UiLanguage.tr(detail)).setStyle(new Notification.BigTextStyle().bigText(UiLanguage.tr(detail))).setCategory(Notification.CATEGORY_STATUS).setShowWhen(true).setAutoCancel(true).build());}catch(RuntimeException ignored){}}
 @android.annotation.SuppressLint("MissingPermission")
 static boolean remind(Context c){try{channels(c);}catch(RuntimeException ignored){return false;}if(!channelAllowed(c,REMINDER))return false;try{String summary=DailyStudio.summary(c.getSharedPreferences("kinera",0));manager(c).notify(REMINDER_ID,base(c,REMINDER).setContentTitle("Kinera Edit").setContentText(summary).setStyle(new Notification.BigTextStyle().bigText(summary)).setAutoCancel(true).build());return true;}catch(RuntimeException ignored){return false;}}
}
