package az.kinera.edit;
final class Cinematic112TemplatePolicy {
 static final int FIRST=2784,TOTAL=2834;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.014f,.025f,.986f,.975f};case 1:return new float[]{.029f,.068f,.971f,.932f};case 2:return new float[]{.019f,.232f,.981f,.768f};case 3:return new float[]{.034f,.270f,.966f,.730f};default:return new float[]{.020f,.330f,.980f,.670f};}}
 static int choose(int prior,float aspect,int semantic,int palette){if(prior<2734||prior>=2784||!Float.isFinite(aspect)||aspect<=0||semantic!=CreativePolicy.PERSON||Math.floorMod(palette,2)!=0)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Cinematic112TemplatePolicy(){}
}
