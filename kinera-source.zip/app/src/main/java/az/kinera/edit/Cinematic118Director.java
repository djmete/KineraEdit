package az.kinera.edit;
final class Cinematic118Director {
 static float continuity(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(left<=0||right<=0)return 0;return (float)(.78+.22*Math.sqrt(Math.min(left,right)/(double)Math.max(left,right)));}
 private Cinematic118Director(){}
}
