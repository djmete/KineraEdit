package az.kinera.edit;
final class Ultimate130Workspace {
 static boolean compact(int h,int w,float f){return Director124Workspace.compact(h,w,f)||h<760||w<350;}
 static int valueWidth(int w,float f){return w<320?40:Director124Workspace.valueWidth(w,f);}
 static boolean metadata(int h,int mode,boolean focus,float f){return Director124Workspace.metadata(h,mode,focus,f)&&h>=960;}
 static boolean filmstrip(int h,int mode,boolean focus,float f){return Adaptive117Workspace.filmstrip(h,mode,focus,f)&&h>=900;}
 static boolean seek(int h,int mode,boolean focus,float f){return !focus&&mode<=0&&h>=480&&!filmstrip(h,mode,focus,f);}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return Director124Workspace.liveTick(last,now,playing,pressure);}
 private Ultimate130Workspace(){}
}