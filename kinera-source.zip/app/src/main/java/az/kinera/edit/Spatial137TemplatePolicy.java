package az.kinera.edit;
final class Spatial137TemplatePolicy {
 static final int FIRST=3784,TOTAL=3834;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=k%10*.0011f;float[][] a={{.019f,.034f,.981f,.966f},{.031f,.112f,.969f,.888f},{.041f,.181f,.959f,.819f},{.052f,.264f,.948f,.736f},{.063f,.323f,.937f,.677f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,59)!=29)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Spatial137TemplatePolicy(){}
}
