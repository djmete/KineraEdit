package az.kinera.edit;
import androidx.media3.common.C;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.common.audio.BaseAudioProcessor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
/** Export-only PCM dynamics and a low-level generated accent at selected long-scene cuts. */
@androidx.media3.common.util.UnstableApi
final class DirectorAudioProcessor extends BaseAudioProcessor {
 private final int gain; private final long[] cuts; private final long duration; private final AudioAccentCursor accentCursor;private final DirectorMath.SoundPlan soundPlan; private long frame;private final RhythmMath rhythm=new RhythmMath();private float[] channelsBuffer=new float[0];
 DirectorAudioProcessor(int gain,long[] cuts,long duration){this.gain=KAiEdit.gainPercent(gain);this.cuts=DirectorMath.clean(cuts,duration);this.duration=duration;accentCursor=new AudioAccentCursor(this.cuts);soundPlan=new DirectorMath.SoundPlan(this.cuts,duration);}
 @Override protected AudioFormat onConfigure(AudioFormat input) throws AudioProcessor.UnhandledAudioFormatException {if((input.encoding!=C.ENCODING_PCM_16BIT&&input.encoding!=C.ENCODING_PCM_FLOAT)||input.channelCount<=0||input.sampleRate<=0)throw new AudioProcessor.UnhandledAudioFormatException(input);channelsBuffer=new float[input.channelCount];return input;}
 @Override protected void onFlush(){frame=0;rhythm.reset();accentCursor.reset();}
 @Override public void queueInput(ByteBuffer input){int bytes=input.remaining(),stride=inputAudioFormat.bytesPerFrame,channels=inputAudioFormat.channelCount;boolean floats=inputAudioFormat.encoding==C.ENCODING_PCM_FLOAT;if(stride<=0||bytes%stride!=0)throw new IllegalArgumentException("Unaligned PCM");ByteBuffer out=replaceOutputBuffer(bytes).order(ByteOrder.nativeOrder());input.order(ByteOrder.nativeOrder());while(input.remaining()>=stride){long time=(long)(frame++*(1000000d/inputAudioFormat.sampleRate));float peak=0;for(int c=0;c<channels;c++){float v=floats?input.getFloat():input.getShort()/32768f;channelsBuffer[c]=Float.isFinite(v)?Math.max(-1f,Math.min(1f,v)):0;peak=Math.max(peak,Math.abs(channelsBuffer[c]));}float gate=cuts.length==0?0:rhythm.push(peak,inputAudioFormat.sampleRate);float effect=accentCursor.active(time)?DirectorMath.sourceAccent(soundPlan.at(time)*gate,peak):0;float linked=effect==0f?DirectorMath.linkedGainFromPeak(peak,gain):DirectorMath.linkedGain(channelsBuffer,effect,gain);for(int c=0;c<channels;c++){float mixed=DirectorMath.linkedSample(channelsBuffer[c],effect,linked);if(floats)out.putFloat(mixed);else out.putShort((short)Math.round(Math.max(-1,Math.min(.999969f,mixed))*32768));}}out.flip();}
}
