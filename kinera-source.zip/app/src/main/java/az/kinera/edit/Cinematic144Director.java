package az.kinera.edit;
/** Deterministic cadence; no semantic or dialogue inference. Avoid repeated dark dips. */
final class Cinematic144Director {
 static float grade(long[] cuts,int i,long duration){float v=Hyper143Director.grade(cuts,i,duration);if(v>=0||i<=0)return v;int run=0;for(int k=i-1;k>=0&&cuts[i]-cuts[k]<=18000000L&&Hyper143Director.profile(cuts,k,duration)==Hyper143Director.DIP;k--)run++;return run%2==1?.30f:v;}
 static float soundScale(long[] cuts,int i,long duration){if(i<=0||i>=cuts.length)return 1;return cuts[i]-cuts[i-1]<5000000L?.70f:1f;}
 private Cinematic144Director(){}
}
