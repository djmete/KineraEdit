package az.kinera.edit;
/** Pure decision policy: no manual one/three-frame mode. */
final class EvolutionMath {
 static long[] captionTimes(long at,long duration){long end=Math.max(0,duration-1);at=Math.max(0,Math.min(end,at));if(duration<600000)return new long[]{at};long a=Math.max(0,at-400000),b=Math.min(end,at+400000);if(a==at&&b==at)return new long[]{at};if(a==at)return new long[]{at,b};if(b==at)return new long[]{at,a};return new long[]{at,a,b};}
 static float[] reviewedMask(java.util.List<float[]> candidates,int requested){if(requested<=0||candidates==null)return RegionMath.empty();java.util.ArrayList<float[]> valid=new java.util.ArrayList<>();for(float[] r:candidates)if(RegionMath.active(r))valid.add(r);if(requested>1&&valid.size()<2)return RegionMath.empty();return adaptiveMask(valid);}
 static float[] adaptiveMask(java.util.List<float[]> candidates){if(candidates==null||candidates.isEmpty())return RegionMath.empty();if(candidates.size()==1)return candidates.get(0).clone();return PrecisionMath.consensus(candidates);}
}
