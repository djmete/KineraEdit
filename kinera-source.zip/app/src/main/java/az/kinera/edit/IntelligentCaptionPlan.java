package az.kinera.edit;
import java.util.*;
/** Quarter-second windows on short clips; 248 samples max. Never claims per-frame OCR. */
final class IntelligentCaptionPlan {
 static final int MAX_WINDOWS=124;static final long SCAN_TIMEOUT_MS=500000L,UI_TIMEOUT_MS=514000L;
 static int windows(long duration){return duration<=0?0:(int)Math.min(MAX_WINDOWS,1+(duration-1)/250000L);}
 static List<TimedRegions.Mask> build(long duration,List<float[]> left,List<float[]> right){return PrecisionCaptionPlan.build(duration,windows(duration),left,right);}
}
