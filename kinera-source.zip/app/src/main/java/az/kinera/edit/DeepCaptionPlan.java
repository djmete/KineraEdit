package az.kinera.edit;
import java.util.*;
/** At most 93 windows, two samples per window; never claim every frame is OCR-checked. */
final class DeepCaptionPlan {
 static int windows(long duration){return duration<=0?0:(int)Math.min(93,1+(duration-1)/333333L);}
 static List<TimedRegions.Mask> build(long duration,List<float[]> left,List<float[]> right){return PrecisionCaptionPlan.build(duration,windows(duration),left,right);}
}
