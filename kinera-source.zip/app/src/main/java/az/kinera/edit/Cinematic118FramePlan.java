package az.kinera.edit;
final class Cinematic118FramePlan {
 static final int MAX_FRAMES=2048;
 static boolean eligible(long d,long remaining,boolean pressure){return !pressure&&d>=1800000L&&d<=60000000L&&remaining>=minimum(d);}
 static long minimum(long d){return d<=12000000L?4000:d<=30000000L?9000:16000;}
 static long budget(long d){return d<=12000000L?6000:d<=30000000L?12000:22000;}
 static long refineDeadline(long now,long deadline,long duration,boolean pressure){return eligible(duration,deadline-now,pressure)?Math.max(now,deadline-minimum(duration)):deadline;}
 static boolean blocked(int[] a,int[] b,double d){return Adaptive117FramePlan.blocked(a,b,d);}
 private Cinematic118FramePlan(){}
}
