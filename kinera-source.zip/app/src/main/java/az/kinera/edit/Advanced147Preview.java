package az.kinera.edit;
import java.util.List;
final class Advanced147Preview {
 static boolean hasMasks(float[] rect,float strength,List<TimedRegions.Mask> extra){return (strength>0&&RegionMath.active(rect))||(extra!=null&&!extra.isEmpty());}
 static boolean raw(int mode,boolean fallback,boolean stable,boolean masks){return mode==1||fallback||(stable&&mode!=2&&!masks);}
 static boolean keep(boolean apply,int mode,boolean ready,boolean raw,boolean error,boolean frame,boolean brand){return apply&&mode==2&&ready&&!raw&&!error&&frame&&brand;}
 private Advanced147Preview(){}
}
