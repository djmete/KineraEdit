package az.kinera.edit;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.SystemClock;
import java.util.*;
/** Bounded translation tracking. A low-confidence or timed-out interval is never fabricated. */
final class MotionTrack {
 static final long STEP_US=500000L, MAX_US=48000000L;
 static List<TimedRegions.Mask> propose(Context c,Uri uri,long at,long duration,float[] initial) throws Exception {
  ArrayList<TimedRegions.Mask> out=new ArrayList<>();if(!RegionMath.active(initial)||at<0||duration<=at||duration-at<100000L)return out;
  MediaMetadataRetriever r=new MediaMetadataRetriever();final int W=96,H=96;long deadline=SystemClock.elapsedRealtime()+29000;
  try{r.setDataSource(c,uri);int[] prev=frame(r,at,W,H);if(prev==null)return out;float[] region=initial.clone(),lastRegion=region;final int[] anchor=prev;final float[] anchorRect=initial.clone();long previous=at;boolean cautious=false;
   for(long t=CreativePolicy.nextTrackTime(at,STEP_US,at,duration,MAX_US);t>=0&&out.size()<TimedRegions.MAX;t=CreativePolicy.nextTrackTime(previous,cautious?STEP_US:TemporalPolicy.recentTrackingStep(out.size(),lastRegion,region,initial),at,duration,MAX_US)){
    if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(SystemClock.elapsedRealtime()>=deadline)break;
    int[] next=frame(r,t,W,H);if(next==null)break;
    boolean longGap=t-previous>STEP_US;float[] midRect=region;int[] reference=prev;long midTime=previous;
    if(longGap){if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(SystemClock.elapsedRealtime()>=deadline)break;long mid=previous+(t-previous)/2;midTime=mid;int[] middle=frame(r,mid,W,H);if(middle==null)break;
      MotionTrackMath.Match first=verified(prev,middle,W,H,region,true);if(first==null||!TemporalPolicy.safeTrack(region,first.rect)||!AppearanceGuard.agrees(anchor,middle,W,H,anchorRect,first.rect))break;midRect=first.rect;reference=middle;}
    MotionTrackMath.Match m=verified(reference,next,W,H,midRect,longGap);
    if(m!=null&&!TemporalPolicy.safeTrack(midRect,m.rect))m=null;
    if(m!=null&&longGap){MotionTrackMath.Match whole=verified(prev,next,W,H,region,true);if(whole==null||PrecisionMath.overlap(whole.rect,m.rect)<.80f)m=null;}
    if(m!=null&&(!TemporalPolicy.safeTrack(region,m.rect)||!AppearanceGuard.agrees(anchor,next,W,H,anchorRect,m.rect)))m=null;
    if(m==null){if(longGap&&midTime>previous&&TemporalPolicy.safeTrack(region,midRect))out.add(new TimedRegions.Mask(VisionMath.sweptMask(region,midRect),previous,midTime));
     else if(!longGap&&SystemClock.elapsedRealtime()+300<deadline){if(Thread.currentThread().isInterrupted())throw new InterruptedException();long partial=SupremeTrackPolicy.partialTime(previous,t);if(partial>previous){int[] middle=frame(r,partial,W,H);if(middle!=null){MotionTrackMath.Match first=verified(prev,middle,W,H,region,true);if(first!=null&&TemporalPolicy.safeTrack(region,first.rect)&&AppearanceGuard.agrees(anchor,middle,W,H,anchorRect,first.rect))out.add(new TimedRegions.Mask(VisionMath.sweptMask(region,first.rect),previous,partial));}}}break;}
    cautious=m.margin<.09||SupremeTrackPolicy.cautious(SupremeTrackPolicy.features(anchor,next,W,H,anchorRect,m.rect));
    float[] swept=VisionMath.sweptMask(region,m.rect);if(longGap)swept=VisionMath.sweptThree(region,midRect,m.rect);
    out.add(new TimedRegions.Mask(swept,previous,t));lastRegion=region;region=m.rect;prev=next;previous=t;
   }
  }finally{r.release();}return out;
 }
 private static MotionTrackMath.Match verified(int[] a,int[] b,int w,int h,float[] region,boolean strict){
  if(SceneMath.distance(a,b)>.55f)return null;
  MotionTrackMath.Match m=MotionTrackMath.match(a,b,w,h,region);if(m==null)return null;
  MotionTrackMath.Match back=MotionTrackMath.match(b,a,w,h,m.rect);if(back==null||m.score<.86||back.score<.86||PrecisionMath.overlap(region,back.rect)<.75f)return null;
  if(strict&&(m.margin<.055||back.margin<.055||PrecisionMath.overlap(region,back.rect)<.85f))return null;return m;
 }
 static int[] frame(MediaMetadataRetriever r,long t,int w,int h){Bitmap b=AnalysisFrameReader.read(r,t,w,h);if(b==null)return null;Bitmap scaled=null;try{scaled=b.getWidth()==w&&b.getHeight()==h?b:Bitmap.createScaledBitmap(b,w,h,true);int[] p=new int[w*h];scaled.getPixels(p,0,w,0,0,w,h);return p;}finally{if(scaled!=null&&scaled!=b)scaled.recycle();b.recycle();}}
}
