package az.kinera.edit;
final class Studio141Policy {
 static boolean raw(int mode,boolean fallback,boolean stable){return mode==1||fallback||stable&&mode!=2;}
 static boolean audioLane(int height,int mode,boolean focus,float font){return height>=760&&mode==0&&!focus&&Float.isFinite(font)&&font<=1.25f;}
 static int gain(int gain,boolean automatic){return automatic&&gain!=0?Math.max(5,Math.min(20,gain)):Math.max(0,Math.min(100,gain));}
 private Studio141Policy(){}
}
