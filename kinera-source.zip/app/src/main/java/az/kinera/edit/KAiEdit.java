package az.kinera.edit;
/** 2.3: deterministic, offline export-quality policy. Not a trained model or platform classifier. */
final class KAiEdit {
 private KAiEdit() {}
 static int analysisSamples(long durationUs){return (int)Math.max(1,Math.min(72,durationUs/650000L));}
 static int recommendedFps(float source){if(!Float.isFinite(source)||source<=0)return 30;if(source<=24.1f)return 24;if(source<=25.1f)return 25;if(source<=30.1f)return 30;if(source<=50.1f)return 50;return 60;}
 static int previewHeight(boolean lowRam,int heapMb){return lowRam||heapMb<192?480:heapMb<256?640:854;}
 static int prepPercent(int done,int total){return total<=0?0:(int)(9L*Math.max(0,Math.min(done,total))/total);}
 static int gainPercent(int percent){return Math.max(0,Math.min(100,percent));}
 static short scalePcm(short sample,int percent){return (short)Math.round(sample*(gainPercent(percent)/100f));}
 static float scaleFloat(float sample,int percent){return Float.isFinite(sample)?Math.max(-1,Math.min(1,sample*(gainPercent(percent)/100f))):0;}
}
