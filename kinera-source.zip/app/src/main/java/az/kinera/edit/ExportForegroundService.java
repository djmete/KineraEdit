package az.kinera.edit;
import android.app.Service;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
/** Keeps the process in foreground importance during an process-owned export. */
public final class ExportForegroundService extends Service {
 static String title=""; static int percent; static boolean requested; static ExportForegroundService running; static Runnable interrupted;
 PowerManager.WakeLock lock; long lastPosted; String lastTitle=""; int lastPercent=-1;
 static void begin(Context c,Runnable onTimeout){requested=true;title=UiLanguage.tr("Avtomatik montaj");percent=0;interrupted=onTimeout;try{c.startForegroundService(new Intent(c,ExportForegroundService.class));}catch(RuntimeException e){requested=false;interrupted=null;throw e;}}
 static void update(String t,int p){title=t;percent=NotificationPolicy.percent(p);if(running!=null&&requested)running.refresh();}
 static void end(Context c){requested=false;interrupted=null;if(running!=null){running.stopForeground(STOP_FOREGROUND_REMOVE);running.stopSelf();}else c.stopService(new Intent(c,ExportForegroundService.class));}
 @Override public void onCreate(){super.onCreate();StudioNotifications.channels(this);}
 @Override public int onStartCommand(Intent i,int flags,int id){if(!requested){stopSelf();return START_NOT_STICKY;}running=this;try{if(Build.VERSION.SDK_INT>=35)startForeground(StudioNotifications.WORK_ID,StudioNotifications.working(this,title,percent),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING);else if(Build.VERSION.SDK_INT>=29)startForeground(StudioNotifications.WORK_ID,StudioNotifications.working(this,title,percent),ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);else startForeground(StudioNotifications.WORK_ID,StudioNotifications.working(this,title,percent));if(lock==null){PowerManager p=getSystemService(PowerManager.class);lock=p.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Kinera:Export");lock.setReferenceCounted(false);lock.acquire(6*60*60*1000L);}}catch(RuntimeException e){abort();}return START_NOT_STICKY;}
 @android.annotation.SuppressLint("MissingPermission")
 private void refresh(){long now=SystemClock.elapsedRealtime();if(title.equals(lastTitle)&&(percent==lastPercent||now-lastPosted<1000))return;lastPosted=now;lastTitle=title;lastPercent=percent;if(StudioNotifications.allowed(this))try{StudioNotifications.manager(this).notify(StudioNotifications.WORK_ID,StudioNotifications.working(this,title,percent));}catch(SecurityException ignored){}}
 private void abort(){Runnable callback=interrupted;requested=false;interrupted=null;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();if(callback!=null)callback.run();}
 @Override public void onTimeout(int id,int type){abort();}
 @Override public IBinder onBind(Intent i){return null;}
 @Override public void onDestroy(){if(lock!=null&&lock.isHeld())lock.release();lock=null;if(running==this)running=null;super.onDestroy();}
}
