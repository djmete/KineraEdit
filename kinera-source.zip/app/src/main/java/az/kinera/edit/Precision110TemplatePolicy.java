package az.kinera.edit;
final class Precision110TemplatePolicy {
 static final int FIRST=2684,TOTAL=2734;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.016f,.016f,.984f,.984f};case 1:return new float[]{.025f,.062f,.975f,.938f};case 2:return new float[]{.024f,.23f,.976f,.77f};case 3:return new float[]{.028f,.272f,.972f,.728f};default:return new float[]{.022f,.324f,.978f,.676f};}}
 static int choose(int prior,float aspect,int semantic,int palette){if(prior<2634||prior>=2684||!Float.isFinite(aspect)||aspect<=0||semantic!=CreativePolicy.PERSON)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Precision110TemplatePolicy(){}
}
