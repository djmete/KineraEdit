package az.kinera.edit;
/** Conservative composition guard for ambiguous cuts, no decoder or allocation. */
final class Vision93 {
 private Vision93(){}
 static float score(int[] a,int[] b,float score){
  if(a==null||b==null||a.length!=2304||b.length!=2304||!Float.isFinite(score)||score<.30f||score>=.37f)return score;
  int stable=0,edges=0,match=0;long error=0;
  for(int y=2;y<46;y+=3)for(int x=2;x<46;x+=3){int i=y*48+x,la=SceneMath.luma(a[i]),lb=SceneMath.luma(b[i]);int da=SceneMath.luma(a[i+1])-SceneMath.luma(a[i-1]),db=SceneMath.luma(b[i+1])-SceneMath.luma(b[i-1]);int va=SceneMath.luma(a[i+48])-SceneMath.luma(a[i-48]),vb=SceneMath.luma(b[i+48])-SceneMath.luma(b[i-48]);if(Math.abs(la-lb)<=12)stable++;error+=Math.abs(la-lb);if(Math.abs(da)>=20){edges++;if(Math.abs(da-db)<=10)match++;}if(Math.abs(va)>=20){edges++;if(Math.abs(va-vb)<=10)match++;}}
  return stable>=210&&error<=1800&&edges>=40&&match>=edges*.96?score*.94f:score;
 }
}
