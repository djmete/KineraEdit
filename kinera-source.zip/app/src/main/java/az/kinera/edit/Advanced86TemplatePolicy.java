package az.kinera.edit;
/** Appended permanent IDs, never remapping old drafts. */
final class Advanced86TemplatePolicy {
 static final int FIRST=1084,TOTAL=1134;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.02f,.045f,.98f,.955f};case 1:return new float[]{.04f,.105f,.96f,.90f};case 2:return new float[]{.045f,.24f,.955f,.76f};case 3:return new float[]{.035f,.28f,.965f,.72f};default:return new float[]{.025f,.30f,.975f,.70f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,23)!=7)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
}
