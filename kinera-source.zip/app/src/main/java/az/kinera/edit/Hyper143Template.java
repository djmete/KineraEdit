package az.kinera.edit;
final class Hyper143Template {
 static final int FIRST=4084,TOTAL=4134;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0014f;float[][] a={{.019f,.045f,.981f,.955f},{.030f,.125f,.970f,.875f},{.041f,.182f,.959f,.818f},{.052f,.245f,.948f,.755f},{.065f,.305f,.935f,.695f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,83)!=43)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Hyper143Template(){}
}
