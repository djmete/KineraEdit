package az.kinera.edit;
final class Hyper143Live {
 static long interval(boolean playing,boolean pressure){return pressure?550:playing?85:140;}
 static long delay(long last,long now,boolean playing,boolean pressure){return last<0||now<last?0:Math.max(0,interval(playing,pressure)-(now-last));}
 static long target(long anchor,long current,long duration,float fps){long end=Math.max(0,duration-1);anchor=Math.max(0,Math.min(end,anchor));current=Math.max(0,Math.min(end,current));if(current!=anchor)return anchor;long frame=Math.max(1,Math.min(100,Math.round(1000f/(Float.isFinite(fps)&&fps>0?fps:25f))));if(anchor+frame<=end)return anchor+frame;if(anchor>0)return Math.max(0,anchor-frame);return end;}
 // Preserve the on/off side of a timed manual mask whenever a neighboring millisecond exists.
 static long target(long anchor,long current,long duration,float fps,long fromUs,long untilUs){long next=target(anchor,current,duration,fps);long a=Math.max(0,Math.min(Math.max(0,duration-1),anchor));long low=Math.max(0,Math.min(duration-1,(fromUs+999)/1000)),high=Math.max(low,Math.min(duration-1,(untilUs-1)/1000));if(a>=low&&a<=high){if(next>=low&&next<=high)return next;if(current!=a)return a;if(a<high)return Math.min(high,next>a?next:a+1);if(a>low)return Math.max(low,next<a?next:a-1);}return next;}
 private Hyper143Live(){}
}
