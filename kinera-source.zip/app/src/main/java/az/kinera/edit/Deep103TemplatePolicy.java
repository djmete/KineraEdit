package az.kinera.edit;
final class Deep103TemplatePolicy {
 static final int FIRST=2334,TOTAL=2384;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.025f,.04f,.975f,.96f};case 1:return new float[]{.025f,.095f,.975f,.905f};case 2:return new float[]{.025f,.225f,.975f,.775f};case 3:return new float[]{.02f,.28f,.98f,.72f};default:return new float[]{.02f,.33f,.98f,.67f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,19)!=7)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
}
