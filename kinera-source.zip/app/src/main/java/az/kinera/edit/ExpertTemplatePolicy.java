package az.kinera.edit;
/** New stable IDs. Old 0..137 IDs are never remapped in a saved draft. */
final class ExpertTemplatePolicy {
 static final int FIRST=138, COUNT=156, TOTAL=1084;
 private ExpertTemplatePolicy(){}
 static float[] window(int style){int layout=(style-FIRST)/6;
  if(layout==0)return new float[]{.026f,.135f,.974f,.91f};
  if(layout==1)return new float[]{.018f,.31f,.982f,.615f};
  return new float[]{.035f,.22f,.965f,.745f};}
 static int choose(int fallback,float aspect,int semantic){
  if(fallback<0||fallback>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==0)return fallback;
  if(semantic==2&&aspect>=1.6f)return COUNT+Math.floorMod(fallback,6);
  int layout=aspect<=.82f?0:aspect>=1.30f?1:2;
  return FIRST+layout*6+(semantic==3?4:Math.floorMod(fallback,6));}
}
