package az.kinera.edit;
import java.util.List;
/** Stabilize suggestion geometry without widening to unrelated neighbours. */
final class Precision116Caption {
 static float[] review(float[] center,List<float[]> neighbors,int requested){
  float[] prior=Professional115Caption.review(center,neighbors,requested);if(!RegionMath.active(prior)||requested<=1)return prior;
  float area=(center[2]-center[0])*(center[3]-center[1]),next=(prior[2]-prior[0])*(prior[3]-prior[1]);
  // Keep requested-frame box if a neighbour would add too much area.
  if(next>area*1.38f)return center.clone();return prior;
 }
 private Precision116Caption(){}
}
