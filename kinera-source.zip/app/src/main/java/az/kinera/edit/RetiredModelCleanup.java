package az.kinera.edit;
import java.io.File;
/** Remove only files created by the retired audio model importer. */
final class RetiredModelCleanup {
 private RetiredModelCleanup(){}
 static boolean clean(File dir){
  if(dir==null||!dir.isDirectory())return false;
  boolean ok=true;
  for(String name:new String[]{"htdemucs_fp16weights.onnx","voice_model.part"}){
   File f=new File(dir,name);
   try{if(f.exists()&&(!f.isFile()||!f.delete()))ok=false;}catch(SecurityException e){ok=false;}
  }
  return ok;
 }
}
