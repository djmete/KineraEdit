package az.kinera.edit;
import java.util.concurrent.locks.ReentrantLock;
/** Serialize scene/audio native analysis; interrupts do not allow a second decoder to race a releasing one. */
final class DecodeGate87 {
 private static final ReentrantLock LOCK=new ReentrantLock(true);
 static void enter() throws InterruptedException{LOCK.lockInterruptibly();}
 static void leave(){LOCK.unlock();}
}
