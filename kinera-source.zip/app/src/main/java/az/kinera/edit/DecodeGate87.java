package az.kinera.edit;
import java.util.concurrent.locks.ReentrantLock;
/** Serialize scene/audio native analysis; interrupts do not allow a second decoder to race a releasing one. */
final class DecodeGate87 {
 private static final ReentrantLock LOCK=new ReentrantLock(true);
 static void enter() throws InterruptedException{LOCK.lockInterruptibly();}
 static void enter(java.util.function.BooleanSupplier cancelled,long timeoutMs) throws InterruptedException{long start=System.nanoTime();while(true){if(cancelled.getAsBoolean()||Thread.currentThread().isInterrupted()||System.nanoTime()-start>=java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(timeoutMs))throw new InterruptedException("Decoder busy or cancelled");if(LOCK.tryLock(100,java.util.concurrent.TimeUnit.MILLISECONDS)){if(cancelled.getAsBoolean()){LOCK.unlock();throw new InterruptedException("Decoder cancelled");}return;}}}
 static void leave(){LOCK.unlock();}
}
