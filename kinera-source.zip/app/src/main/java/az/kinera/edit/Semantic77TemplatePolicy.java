package az.kinera.edit;
final class Semantic77TemplatePolicy {
 static final int FIRST=634,TOTAL=684;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.045f,.988f,.963f};case 1:return new float[]{.022f,.110f,.978f,.908f};case 2:return new float[]{.027f,.184f,.973f,.786f};case 3:return new float[]{.019f,.272f,.981f,.657f};default:return new float[]{.021f,.327f,.979f,.630f};}}
 static int choose(int prior,float a,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(a)||a<=0||semantic<=0||semantic==3||Math.floorMod(seed,23)!=11)return prior;return FIRST+10*Director72TemplatePolicy.family(a)+Math.floorMod(palette+Math.floorMod(seed/23,10),10);}
}
