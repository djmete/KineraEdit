package az.kinera.edit;
final class Cinematic118Workspace {
 static int sliderPadding(int width){return width<340?4:8;}
 static int liveInterval(boolean playing,boolean pressure){return pressure?320:playing?100:65;}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return last<0||now<last||now-last>=liveInterval(playing,pressure);}
 static int valueWidth(int w,float font){return w<320?44:w<380?48:font>1.4f?64:56;}
 private Cinematic118Workspace(){}
}
