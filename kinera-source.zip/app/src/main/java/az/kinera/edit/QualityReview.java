package az.kinera.edit;
final class QualityReview {
 static boolean durationOk(long us){return us>60_000_000L;}
 static boolean validSource(int w,int h,long us){return w>0&&h>0&&us>0;}
 static boolean heavySource(int w,int h){return (long)w*h>=3840L*2160;}
 static String report(int w,int h,long us,EditSpec s){StringBuilder b=new StringBuilder();b.append(durationOk(us)?"Müddət: 1 dəqiqədən uzundur.":"Müddət: 1 dəqiqədən uzun video seçin.");b.append("\nMənbə: ").append(w).append(" × ").append(h).append("\nİxrac: ").append(s.width).append(" × ").append(s.height);if(StudioMath.sourceUpscaled(w,h,s.height))b.append("\nBöyüdülən ölçü əlavə real detal yaratmır.");if(s.crop+s.top>.30f)b.append("\nKadrın böyük hissəsi kəsilib; önizləməni yoxlayın.");if(s.mute)b.append("\nMənbə səsi söndürülüb; səsləndirməni yoxlayın.");b.append("\n9:16 şablon. Orijinallıq və istifadə hüququ avtomatik təsdiqlənmir.");return b.toString();}
}
