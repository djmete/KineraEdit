package az.kinera.edit;
final class Studio140Timing {
 static boolean whole(long from,long until,long duration){return duration>0&&from<=0&&until>=duration;}
 static boolean active(long time,long from,long until,long duration){return whole(from,until,duration)||until>from&&time>=from&&time<until;}
 static int filmHeight(int h){return h<550?48:h<720?60:80;}
 static boolean seek(boolean film,boolean original,int mode){return original&&(mode>0||!film);}
 static boolean prep(boolean autoStyle,boolean autoScene,int cuts,boolean audio){return audio||autoStyle||autoScene&&cuts==0;}
 private Studio140Timing(){}
}
