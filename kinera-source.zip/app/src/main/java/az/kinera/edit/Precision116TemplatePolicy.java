package az.kinera.edit;
/** 50 distinct composition variants; existing IDs stay stable. */
final class Precision116TemplatePolicy {
 static final int FIRST=2984,TOTAL=3034;
 static float[] window(int id){int f=Math.max(0,Math.min(4,(id-FIRST)/10));float v=Math.floorMod(id-FIRST,10)*.0015f;float[][] w={{.015f,.035f,.985f,.965f},{.025f,.105f,.975f,.895f},{.026f,.225f,.974f,.775f},{.020f,.305f,.980f,.695f},{.014f,.365f,.986f,.635f}};float[] a=w[f];return new float[]{a[0]+v,a[1]+v,a[2]-v,a[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,5)!=0)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Precision116TemplatePolicy(){}
}
