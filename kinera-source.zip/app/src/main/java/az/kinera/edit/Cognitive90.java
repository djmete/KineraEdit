package az.kinera.edit;
/** Bounded exposure guard; no new decoder pass. */
final class Cognitive90 {
 static float sceneScore(int[] a,int[] b,float score){
  if(a==null||b==null||a.length!=2304||b.length!=2304||!Float.isFinite(score)||score<.22f||score>=.46f)return score;
  int sum=0,absolute=0,edges=0,stable=0,n=0;
  for(int y=0;y<48;y+=2)for(int x=0;x<48;x+=2){int i=y*48+x,la=SceneMath.luma(a[i]),lb=SceneMath.luma(b[i]),d=lb-la;sum+=d;absolute+=Math.abs(d);n++;if(x<46){int aa=SceneMath.luma(a[i+2])-la,bb=SceneMath.luma(b[i+2])-lb;if(Math.abs(aa)>=18){edges++;if(Math.abs(aa-bb)<=8)stable++;}}}
  if(absolute<n*18||Math.abs(sum)<absolute*.92||edges<50||stable<edges*.92)return score;
  float mean=sum/(float)n;int residual=0;for(int y=0;y<48;y+=2)for(int x=0;x<48;x+=2){int i=y*48+x;if(Math.abs(SceneMath.luma(b[i])-SceneMath.luma(a[i])-mean)<=7)residual++;}
  return residual>=n*.92f?score*.82f:score;
 }
 static boolean recentSorted(long previous,long now,long[] cuts,int fps){if(cuts==null||previous<0||now<=previous||now-previous>Math.min(TemporalRestorePolicy.MAX_GAP_US,Math.max(50000L,2000000L/Math.max(12,fps))))return false;int i=java.util.Arrays.binarySearch(cuts,previous);if(i<0)i=-i-1;else while(i<cuts.length&&cuts[i]<=previous)i++;return i==cuts.length||cuts[i]>now;}
 static int blurValueWidth(int width,float font){return font>1.2f?54:width<360?40:46;}
 static int blurMenuWidth(int width,float font){return width<360&&font<=1.2f?48:52;}
}
