package az.kinera.edit;
final class Reconstruction123Director {
 static float accent(long[] cuts,int i,long duration){
  if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;
  long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];
  long gap=Math.min(left,right);if(gap<=0)return 0;
  if(gap>=4500000L)return 1f;float x=Math.max(0,Math.min(1,(gap-800000L)/3700000f));return .48f+.52f*x*x*(3-2*x);
 }
 private Reconstruction123Director(){}
}
