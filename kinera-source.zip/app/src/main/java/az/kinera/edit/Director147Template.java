package az.kinera.edit;
final class Director147Template {
 static final int FIRST=4284,TOTAL=4334;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0011f;float[][] a={{.021f,.091f,.979f,.909f},{.038f,.154f,.962f,.846f},{.044f,.207f,.956f,.793f},{.061f,.263f,.939f,.737f},{.079f,.321f,.921f,.679f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,101)!=83)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Director147Template(){}
}
