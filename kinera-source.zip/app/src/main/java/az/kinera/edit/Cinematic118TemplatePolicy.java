package az.kinera.edit;
final class Cinematic118TemplatePolicy {
 static final int FIRST=3084,TOTAL=3134;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST)),f=k/10;float v=(k%10)*.0016f;float[][] w={{.014f,.034f,.986f,.966f},{.023f,.092f,.977f,.908f},{.041f,.203f,.959f,.797f},{.037f,.282f,.963f,.718f},{.025f,.337f,.975f,.663f}};float[] a=w[f];return new float[]{a[0]+v,a[1]+v,a[2]-v,a[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,11)!=4)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Cinematic118TemplatePolicy(){}
}
