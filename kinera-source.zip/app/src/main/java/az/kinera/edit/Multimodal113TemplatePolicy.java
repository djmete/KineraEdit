package az.kinera.edit;
final class Multimodal113TemplatePolicy {
 static final int FIRST=2834,TOTAL=2884;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.018f,.034f,.982f,.966f};case 1:return new float[]{.027f,.062f,.973f,.938f};case 2:return new float[]{.022f,.228f,.978f,.772f};case 3:return new float[]{.032f,.266f,.968f,.734f};default:return new float[]{.018f,.326f,.982f,.674f};}}
 static int choose(int prior,float aspect,int semantic,int palette){if(prior<2784||prior>=2834||!Float.isFinite(aspect)||aspect<=0||semantic!=CreativePolicy.PERSON||Math.floorMod(palette,4)!=0)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Multimodal113TemplatePolicy(){}
}
