package az.kinera.edit;
/** Automatic export envelope. No frame-rate inflation; pressure and expensive masks cap work. */
final class Studio94 {
 static int height(int w,int h,boolean pressure,boolean lowRam,int memoryClass,boolean restore){int max=Math.max(w,h);if(pressure||lowRam||memoryClass<=128||restore||max<1600)return 1280;return 1920;}
 static int fps(float source){if(!Float.isFinite(source)||source<=0)return 30;if(source<23.5f)return Math.max(1,Math.min(24,Math.round(source)));int f=KAiEdit.recommendedFps(source);return Math.min(30,f);}
 // Stored 0..2 are legacy presets. New values occupy 100..200 for backward-compatible drafts/history.
 static int percent(int encoded){if(encoded==0)return 5;if(encoded==1)return 8;if(encoded==2)return 18;return Math.max(0,Math.min(100,encoded-100));}
 static int encode(int percent){return 100+Math.max(0,Math.min(100,percent));}
 static int normalize(int encoded){return encoded>=100?encode(percent(encoded)):Math.max(0,Math.min(2,encoded));}
 static float strength(int encoded){if(encoded<100)return new float[]{.65f,1f,2.1f}[normalize(encoded)];return 12f*percent(encoded)/100f;}
 static float clampStrength(float strength){return Float.isFinite(strength)?Math.max(0f,Math.min(12f,strength)):1f;}
}
