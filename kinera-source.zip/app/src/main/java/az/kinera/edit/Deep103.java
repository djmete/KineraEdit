package az.kinera.edit;
/** Bounded OCR rescue and editorial safeguards; no new native dependencies. */
final class Deep103 {
 static boolean rescue(float[] r){if(!RegionMath.active(r))return true;float c=(r[0]+r[2])*.5f;return Math.abs(c-.5f)>.22f&&r[2]-r[0]<.40f;}
 static int rescueEdge(int w,int h){return Math.min(1280,Math.round(Math.max(w,h)*1.5f));}
 static int scaled(int side,int longest,int edge){return Math.max(2,(int)Math.round((double)side*edge/Math.max(1,longest)));}
 static float[] choose(float[] first,float[] second){if(!RegionMath.active(second))return first;if(!RegionMath.active(first))return second;float a=Math.abs((first[0]+first[2])*.5f-.5f),b=Math.abs((second[0]+second[2])*.5f-.5f);return rescue(first)&&b<=.15f&&a-b>=.10f?second:first;}
 static long waitMs(long now,long deadline){return deadline<=0?12000:Math.max(0,Math.min(12000,deadline-now));}
 static float transitionScale(long[] cuts,int index,long duration){if(cuts==null||index<0||index>=cuts.length)return 0;long left=cuts[index]-(index==0?0:cuts[index-1]),right=(index==cuts.length-1?duration:cuts[index+1])-cuts[index];double ratio=Math.min(left,right)/(double)Math.max(1,Math.max(left,right));return (float)(.72+.28*Math.sqrt(Math.max(0,ratio)));}
 private Deep103(){}
}
