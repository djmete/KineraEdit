package az.kinera.edit;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;
/** One semantic inference in flight, including a timed-out asynchronous task. */
final class VisualInferenceGate {
 private static final Semaphore GATE=new Semaphore(1,true);
 static Lease tryEnter(){return GATE.tryAcquire()?new Lease():null;}
 static final class Lease implements AutoCloseable {private final AtomicBoolean closed=new AtomicBoolean();public void close(){if(closed.compareAndSet(false,true))GATE.release();}}
 private VisualInferenceGate(){}
}
