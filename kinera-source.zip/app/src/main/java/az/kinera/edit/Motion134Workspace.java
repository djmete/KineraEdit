package az.kinera.edit;
/** Reserve readable slider percentage and allow scrolling at large font scales. */
final class Motion134Workspace {
 static int valueWidth(int w,float f){return Math.max(Precision133Workspace.valueWidth(w,f),f>=1.5f?60:48);}
 static int sliderPadding(int w){return w<400?2:Advanced132Workspace.sliderPadding(w);}
 static boolean scrollTools(int w,float f){return Precision133Workspace.scrollTools(w,f)||w<480&&f>=1.5f;}
 static boolean metadata(int h,int mode,boolean focus,float f){return Advanced132Workspace.metadata(h,mode,focus,f)&&!(h<940&&f>=1.5f);}
 private Motion134Workspace(){}
}
