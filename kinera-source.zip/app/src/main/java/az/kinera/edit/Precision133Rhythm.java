package az.kinera.edit;
/** Preserve established pacing, attenuate leading accents on strongly asymmetric shots. */
final class Precision133Rhythm {
 static float envelope(long[] cuts,int i,long duration,long time,long desired){float prior=Advanced132Rhythm.envelope(cuts,i,duration,time,desired);if(prior<=0||time>=cuts[i])return prior;long l=cuts[i]-(i==0?0:cuts[i-1]),r=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(l<=0||r<=0||l>=r/3)return prior;return prior*(.86f+.14f*prior);}
 private Precision133Rhythm(){}
}
