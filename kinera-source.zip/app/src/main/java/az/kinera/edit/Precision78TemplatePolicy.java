package az.kinera.edit;
/** New immutable IDs; existing project selections remain valid. */
final class Precision78TemplatePolicy {
 static final int FIRST=684,TOTAL=734;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.018f,.105f,.982f,.956f};case 1:return new float[]{.028f,.145f,.972f,.887f};case 2:return new float[]{.032f,.220f,.968f,.760f};case 3:return new float[]{.020f,.275f,.980f,.681f};default:return new float[]{.018f,.325f,.982f,.635f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,7)!=3)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/7,10),10);}
}
