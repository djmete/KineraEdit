package az.kinera.edit;
/** Limit effect duration on a busy local edit; never change source chronology. */
final class Director124Rhythm {
 static long width(long[] cuts,int i,long duration,long requested){
  long base=DirectorMath.effectWidth(cuts,i,duration,requested);if(base<=0)return 0;
  int neighbors=0;for(int k=Math.max(0,i-4);k<=Math.min(cuts.length-1,i+4);k++)if(k!=i&&Math.abs(cuts[k]-cuts[i])<=3500000L)neighbors++;
  // A cluster receives shorter accents. Isolated shots retain the existing envelope.
  return neighbors>=3?Math.max(1,base*2/3):neighbors==2?Math.max(1,base*5/6):base;
 }
 private Director124Rhythm(){}
}
