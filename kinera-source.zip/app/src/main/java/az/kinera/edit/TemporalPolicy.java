package az.kinera.edit;
/** Defensive timeline and adaptive tracker policy; never fabricates a missing sample. */
final class TemporalPolicy {
 private TemporalPolicy(){}
 static boolean contiguous(long[] times,int a,int b){
  if(times==null||a<0||b<0||a>=times.length||b>=times.length)return false;
  if(a==b)return true;
  long typical=Long.MAX_VALUE;for(int i=Math.max(1,a-3);i<=Math.min(times.length-1,a+3);i++){long d=times[i]-times[i-1];if(d>0)typical=Math.min(typical,d);}
  if(typical==Long.MAX_VALUE)return false;
  for(int i=Math.min(a,b)+1;i<=Math.max(a,b);i++){long d=times[i]-times[i-1];if(d<=0||d>1.8*typical)return false;}return true;
 }
 static boolean safeTrack(float[] a,float[] b){
  if(!RegionMath.active(a)||!RegionMath.active(b))return false;
  float w=a[2]-a[0],h=a[3]-a[1];float dx=Math.abs((a[0]+a[2]-b[0]-b[2])*.5f),dy=Math.abs((a[1]+a[3]-b[1]-b[3])*.5f);
  return dx<=Math.max(.06f,w*.8f)&&dy<=Math.max(.06f,h*.8f);
 }
 // Shorten the next interval after recent motion, even if the target returns to its start.
 static long recentTrackingStep(int count,float[] before,float[] after,float[] initial){
  long base=trackingStep(count,after,initial);if(!RegionMath.active(before)||!RegionMath.active(after))return 500000L;
  float dx=Math.abs((before[0]+before[2]-after[0]-after[2])*.5f),dy=Math.abs((before[1]+before[3]-after[1]-after[3])*.5f);
  if(dx+dy>.055f)return 500000L;if(dx+dy>.025f)return Math.min(base,1000000L);return base;
 }
 static long trackingStep(int count,float[] region,float[] initial){
  if(count<8||!RegionMath.active(region)||!RegionMath.active(initial))return 500000L;
  float dx=Math.abs((region[0]+region[2]-initial[0]-initial[2])*.5f),dy=Math.abs((region[1]+region[3]-initial[1]-initial[3])*.5f);
  return dx+dy>.18f?1000000L:2000000L;
 }
}
