package az.kinera.edit;
/** User-selected region safeguard: do not widen the request when adjacent regions disagree. */
final class Cinematic118Caption {
 static float[] stabilize(float[] center,float[] candidate){
  if(!RegionMath.active(center)||!RegionMath.active(candidate))return candidate;
  float area=(center[2]-center[0])*(center[3]-center[1]);
  float expanded=(candidate[2]-candidate[0])*(candidate[3]-candidate[1]);
  return expanded>area*1.22f?center.clone():candidate;
 }
 private Cinematic118Caption(){}
}
