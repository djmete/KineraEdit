package az.kinera.edit;
/** Fifty appended compositions, with no migration of prior IDs. */
final class StableTemplatePolicy {
 static final int FIRST=334,TOTAL=384;
 static int family(float a){if(!Float.isFinite(a)||a<=0)return 0;return a<=.68f?0:a<=.92f?1:a<=1.20f?2:a<=2f?3:4;}
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.01f,.10f,.99f,.94f};case 1:return new float[]{.025f,.145f,.975f,.875f};case 2:return new float[]{.025f,.22f,.975f,.755f};case 3:return new float[]{.015f,.315f,.985f,.623f};default:return new float[]{.015f,.36f,.985f,.598f};}}
 static int choose(int prior,float a,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(a)||a<=0||semantic<=0||semantic==3||Math.floorMod(seed,7)!=1)return prior;return FIRST+10*family(a)+Math.floorMod(palette+Math.floorMod(seed/7,10),10);}
}
