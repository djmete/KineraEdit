package az.kinera.edit;
final class Evolution150Template {
 static final int FIRST=4384,TOTAL=4434;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0014f;float[][] a={{.023f,.115f,.977f,.885f},{.035f,.181f,.965f,.819f},{.057f,.231f,.943f,.769f},{.075f,.287f,.925f,.713f},{.091f,.346f,.909f,.654f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,107)!=97)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Evolution150Template(){}
}
