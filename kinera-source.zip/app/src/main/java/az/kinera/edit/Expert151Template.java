package az.kinera.edit;
final class Expert151Template {
 static final int FIRST=4434,TOTAL=4484;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0012f;float[][] a={{.031f,.126f,.969f,.874f},{.048f,.194f,.952f,.806f},{.062f,.244f,.938f,.756f},{.079f,.303f,.921f,.697f},{.095f,.354f,.905f,.646f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,109)!=101)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Expert151Template(){}
}
