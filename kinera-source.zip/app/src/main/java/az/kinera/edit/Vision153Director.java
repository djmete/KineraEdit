package az.kinera.edit;
final class Vision153Director {
 static float rhythm(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 1f;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(left<=0||right<=0)return 1f;long near=Math.min(left,right);float pace=Math.min(1f,near/3000000f);if(i>0){long prior=cuts[i-1]-(i==1?0:cuts[i-2]);if(prior>0)pace=Math.min(pace,Math.min(prior,left)/(float)Math.max(prior,left));}if(i+2<cuts.length){long next=cuts[i+2]-cuts[i+1];if(next>0)pace=Math.min(pace,Math.min(next,right)/(float)Math.max(next,right));}return .65f+.35f*pace;}
 private Vision153Director(){}
}
