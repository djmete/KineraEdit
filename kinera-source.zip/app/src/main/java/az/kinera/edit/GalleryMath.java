package az.kinera.edit;
import java.util.Locale;
final class GalleryMath {
 static String resolution(int w,int h){if(w<=0||h<=0)return "—";int small=Math.min(w,h);return small>=2160?"4K":small>=1440?"2K":small>=1080?"FHD":small>=720?"HD":w+"×"+h;}
 static String size(long bytes){if(bytes<=0)return "—";if(bytes>=1073741824L)return String.format(Locale.ROOT,"%.1f GB",bytes/1073741824.0);if(bytes>=1048576L)return String.format(Locale.ROOT,"%.1f MB",bytes/1048576.0);return Math.max(1,bytes/1024)+" KB";}
}
