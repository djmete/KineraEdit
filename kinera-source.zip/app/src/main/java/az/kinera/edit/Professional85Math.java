package az.kinera.edit;
final class Professional85Math {
 static float safeAmount(float amount){return Float.isFinite(amount)?Math.max(0f,Math.min(.18f,amount)):0f;}
 static boolean validTimestamp(long previous,long now,long duration){return duration>0&&previous>=0&&now>previous&&now<duration;}
 static boolean historyCadence(long older,long previous,long now,int fps){if(!Production84Math.balanced(older,previous,now,fps))return false;long a=previous-older,b=now-previous;return Math.max(a,b)<=Math.max(22000L,Math.min(90000L,1800000L/Math.max(12,fps)));}
}
