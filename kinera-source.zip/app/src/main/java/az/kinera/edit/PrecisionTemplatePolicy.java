package az.kinera.edit;
final class PrecisionTemplatePolicy {
 static final int FIRST=198,COUNT=204;
 static int choose(int previous,float aspect,int semantic,int seed){if(previous<0||previous>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==0||semantic==3||Math.floorMod(seed,7)!=3)return previous;return FIRST+2*(aspect<=.82f?0:aspect>=1.30f?1:2)+Math.floorMod(seed/7,2);}
 static float[] window(int style){int family=(style-FIRST)/2;return family==0?new float[]{.016f,.14f,.984f,.90f}:family==1?new float[]{.012f,.25f,.988f,.72f}:new float[]{.022f,.19f,.978f,.80f};}
}
