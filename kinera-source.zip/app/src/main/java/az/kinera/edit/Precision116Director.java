package az.kinera.edit;
final class Precision116Director {
 static float shortShotScale(long[] cuts,int i,long d){if(cuts==null||i<0||i>=cuts.length||d<=0)return 0;long left=cuts[i]-(i==0?0:cuts[i-1]),right=(i+1==cuts.length?d:cuts[i+1])-cuts[i];if(left<=0||right<=0)return 0;float x=Math.min(1,Math.min(left,right)/2200000f);return .55f+.45f*x*x*(3-2*x);}
 private Precision116Director(){}
}
