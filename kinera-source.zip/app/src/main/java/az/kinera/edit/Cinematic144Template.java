package az.kinera.edit;
final class Cinematic144Template {
 static final int FIRST=4134,TOTAL=4184;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0015f;float[][] a={{.018f,.052f,.982f,.948f},{.027f,.137f,.973f,.863f},{.039f,.194f,.961f,.806f},{.047f,.252f,.953f,.748f},{.061f,.312f,.939f,.688f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,89)!=47)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Cinematic144Template(){}
}
