package az.kinera.edit;
import android.content.Context;import android.net.Uri;import android.media.*;import android.os.SystemClock;import java.nio.*;
/** Optional local PCM decode, first 30 seconds, at most 5 seconds of wall clock. */
final class ExpertAudioProbe {
 static ExpertAudioEnvelope read(Context c,Uri uri,long deadline)throws InterruptedException{
  ExpertAudioEnvelope out=new ExpertAudioEnvelope();MediaExtractor ex=new MediaExtractor();MediaCodec codec=null;boolean started=false;
  long stop=Math.min(deadline,SystemClock.elapsedRealtime()+5000);try{ex.setDataSource(c,uri,null);MediaFormat f=null;for(int i=0;i<ex.getTrackCount();i++){MediaFormat a=ex.getTrackFormat(i);String mime=a.getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("audio/")){ex.selectTrack(i);f=a;break;}}if(f==null)return out;
   int rate=f.getInteger(MediaFormat.KEY_SAMPLE_RATE),channels=f.getInteger(MediaFormat.KEY_CHANNEL_COUNT),encoding=AudioFormat.ENCODING_PCM_16BIT;codec=MediaCodec.createDecoderByType(f.getString(MediaFormat.KEY_MIME));codec.configure(f,null,null,0);codec.start();started=true;MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();boolean eos=false;
   while(SystemClock.elapsedRealtime()<stop){if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(!eos){int i=codec.dequeueInputBuffer(2000);if(i>=0){ByteBuffer b=codec.getInputBuffer(i);if(b==null)break;b.clear();long t=ex.getSampleTime();int n=t<0||t>=30000000L?-1:ex.readSampleData(b,0);if(n<0){codec.queueInputBuffer(i,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM);eos=true;}else{codec.queueInputBuffer(i,0,n,t,0);ex.advance();}}}
    int o=codec.dequeueOutputBuffer(info,2000);if(o==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){MediaFormat g=codec.getOutputFormat();rate=g.getInteger(MediaFormat.KEY_SAMPLE_RATE);channels=g.getInteger(MediaFormat.KEY_CHANNEL_COUNT);encoding=g.containsKey(MediaFormat.KEY_PCM_ENCODING)?g.getInteger(MediaFormat.KEY_PCM_ENCODING):AudioFormat.ENCODING_PCM_16BIT;continue;}if(o<0)continue;
    try{ByteBuffer b=codec.getOutputBuffer(o);int size=encoding==AudioFormat.ENCODING_PCM_FLOAT?4:encoding==AudioFormat.ENCODING_PCM_16BIT?2:0;if(b!=null&&size>0&&rate>0&&channels>0&&channels<=32&&info.size>0&&info.offset>=0&&info.offset<=b.capacity()-info.size){b.position(info.offset);b.limit(info.offset+info.size);b.order(ByteOrder.nativeOrder());long frame=0;while(b.remaining()>=size*channels){long time=info.presentationTimeUs+frame*1000000L/rate;for(int ch=0;ch<channels;ch++){float v=size==4?b.getFloat():b.getShort()/32768f;out.add(time,v);}frame++;}}}finally{codec.releaseOutputBuffer(o,false);}if((info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0)break;
   }
  }catch(java.io.IOException|RuntimeException ignored){return new ExpertAudioEnvelope();}finally{if(codec!=null){if(started)try{codec.stop();}catch(RuntimeException ignored){}try{codec.release();}catch(RuntimeException ignored){}}try{ex.release();}catch(RuntimeException ignored){}}return out;
 }
}
