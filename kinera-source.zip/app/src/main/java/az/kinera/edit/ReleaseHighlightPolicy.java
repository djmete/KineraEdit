package az.kinera.edit;
/** Release-local announcement, never a queue of old highlights. Set MAJOR=false for minor releases. */
final class ReleaseHighlightPolicy {
 static final int CURRENT_RELEASE=98, ID=98;
 static final boolean MAJOR=false;
 static final String KEY="seen_major_feature";
 static boolean shouldShowForRelease(int seen,boolean setup,boolean home,boolean ready,int current,int feature,boolean major){return major&&current>0&&feature==current&&seen<feature&&!setup&&home&&ready;}
 static boolean shouldShow(int seen,boolean setup,boolean home,boolean ready){return shouldShowForRelease(seen,setup,home,ready,CURRENT_RELEASE,ID,MAJOR);}
 static int mark(int seen,int current){return Math.max(seen,current);}
 static int mark(int seen){return mark(seen,CURRENT_RELEASE);}
}
