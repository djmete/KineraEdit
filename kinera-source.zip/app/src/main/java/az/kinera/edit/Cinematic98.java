package az.kinera.edit;
/** Editorial restraint: scale long-shot zoom by available room around the cut. */
final class Cinematic98 {
 private Cinematic98(){}
 static float zoomScale(long[] cuts,int i,long duration){if(!Production84Math.validCut(cuts,i,duration))return 0;long l=cuts[i]-(i==0?0:cuts[i-1]),r=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];return .65f+.35f*Math.max(0,Math.min(1,(Math.min(l,r)-9000000L)/6000000f));}
}
