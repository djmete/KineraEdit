package az.kinera.edit;
/** Restrained accents for clustered shots: no additional flash or crop during quick cuts. */
final class Adaptive117Director {
 static float scale(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long a=cuts[i]-(i==0?0:cuts[i-1]),b=(i==cuts.length-1?duration:cuts[i+1])-cuts[i];if(a<=0||b<=0)return 0;long gap=Math.min(a,b);return gap>=4000000L?1f: .45f+.55f*Math.min(1f,gap/4000000f);}
 private Adaptive117Director(){}
}
