package az.kinera.edit;
final class Vision120Director {
 static float edge(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 0;long t=cuts[i],a=t-(i==0?0:cuts[i-1]),b=(i==cuts.length-1?duration:cuts[i+1])-t;if(a<=0||b<=0)return 0;return Math.min(1f,Math.max(.25f,Math.min(a,b)/900000f));}
 private Vision120Director(){}
}
