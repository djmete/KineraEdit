package az.kinera.edit;
import java.util.*;
/** Local named profiles, independent of account services. */
final class ChannelProfiles {
 static boolean valid(String s){return s!=null&&!s.replaceAll("[\\p{Cntrl}]"," ").trim().isEmpty()&&s.length()<=48;}
 static String[] sorted(Set<String> saved,String current){TreeSet<String> names=new TreeSet<>(String.CASE_INSENSITIVE_ORDER.thenComparing(Comparator.naturalOrder()));if(saved!=null)for(String n:saved)if(valid(n))names.add(BrandName.clean(n));if(valid(current))names.add(BrandName.clean(current));return names.toArray(new String[0]);}
 static boolean canRename(Set<String> saved,String old,String raw){if(!valid(raw))return false;String n=BrandName.clean(raw);if(saved!=null)for(String x:saved)if(!x.equals(old)&&x.equalsIgnoreCase(n))return false;return true;}
 static String[] remaining(Set<String> saved,String old){Set<String> copy=new HashSet<>();if(saved!=null)copy.addAll(saved);copy.remove(old);return sorted(copy,null);}
}
