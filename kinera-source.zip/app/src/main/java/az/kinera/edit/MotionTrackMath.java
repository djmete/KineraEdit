package az.kinera.edit;
/** Bounded translation-only patch matching. Reject weak texture and ambiguous matches. */
final class MotionTrackMath {
 static final class Match {final float[] rect;final double score,margin;Match(float[] r,double s,double m){rect=r;score=s;margin=m;}}
 static Match match(int[] a,int[] b,int w,int h,float[] rect){
  if(a==null||b==null||w<8||h<8||a.length!=(long)w*h||b.length!=(long)w*h||!RegionMath.active(rect))return null;
  for(float v:rect)if(!Float.isFinite(v)||v<0||v>1)return null;
  int l=Math.round(rect[0]*w),t=Math.round(rect[1]*h),r=Math.round(rect[2]*w),bottom=Math.round(rect[3]*h);if(r-l<4||bottom-t<4)return null;
  int[] al=new int[a.length],bl=new int[b.length];for(int i=0;i<a.length;i++){al[i]=SceneMath.luma(a[i]);bl[i]=SceneMath.luma(b[i]);}
  int n=0;double sum=0,sq=0;for(int y=t;y<bottom;y+=2)for(int x=l;x<r;x+=2){double v=al[y*w+x];sum+=v;sq+=v*v;n++;}if(n<9||sq/n-(sum/n)*(sum/n)<64)return null;
  double best=-2,second=-2;int bx=0,by=0;int limit=Math.min(12,Math.max(3,Math.min(w,h)/8));
  int stride=2*limit+1;double[] scores=new double[stride*stride];java.util.Arrays.fill(scores,-2);for(int dy=-limit;dy<=limit;dy++)for(int dx=-limit;dx<=limit;dx++){if(l+dx<0||r+dx>w||t+dy<0||bottom+dy>h)continue;double sb=0,bb=0,ab=0;for(int y=t;y<bottom;y+=2)for(int x=l;x<r;x+=2){double av=al[y*w+x],bv=bl[(y+dy)*w+x+dx];sb+=bv;bb+=bv*bv;ab+=av*bv;}double den=Math.sqrt(Math.max(0,(sq-sum*sum/n)*(bb-sb*sb/n)));if(den<1)continue;double score=(ab-sum*sb/n)/den;scores[(dy+limit)*stride+dx+limit]=score; if(score>best){best=score;bx=dx;by=dy;}}
  if(best<.80)return null;
  // Ignore immediate adjacent offsets when checking for a second plausible peak.
  for(int dy=-limit;dy<=limit;dy++)for(int dx=-limit;dx<=limit;dx++){if(Math.abs(dx-bx)<=2&&Math.abs(dy-by)<=2)continue;second=Math.max(second,scores[(dy+limit)*stride+dx+limit]);}
  if(best-second<.035||!TrackConfidence.accept(best,best-second))return null;return new Match(RegionMath.move(rect,bx/(float)w,by/(float)h),best,best-second);
 }
}
