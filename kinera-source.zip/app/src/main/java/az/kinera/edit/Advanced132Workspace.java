package az.kinera.edit;
/** Preserve the preview, readable tool buttons and one navigation surface. */
final class Advanced132Workspace {
 static boolean compact(int h,int w,float f){return Supreme131Workspace.compact(h,w,f)||h<860&&w<380;}
 static int valueWidth(int w,float f){return Supreme131Workspace.valueWidth(w,f);}
 static boolean metadata(int h,int mode,boolean focus,float f){return Supreme131Workspace.metadata(h,mode,focus,f);}
 static boolean filmstrip(int h,int mode,boolean focus,float f){return Supreme131Workspace.filmstrip(h,mode,focus,f);}
 static boolean seek(int h,int mode,boolean focus,float f){return Supreme131Workspace.seek(h,mode,focus,f);}
 static int toolLines(boolean compact,float font){return Supreme131Workspace.toolLines(compact,font);}
 static boolean scrollTools(int w,float f){return w<360||Motion102Layout.scrollTools(w,f);}
 static int sliderPadding(int w){return w<360?2:8;}
 static boolean liveTick(long last,long now,boolean playing,boolean pressure){return Supreme131Workspace.liveTick(last,now,playing,pressure);}
 private Advanced132Workspace(){}
}
