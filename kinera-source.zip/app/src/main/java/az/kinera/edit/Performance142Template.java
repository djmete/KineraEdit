package az.kinera.edit;
final class Performance142Template {
 static final int FIRST=4034,TOTAL=4084;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0013f;float[][] a={{.017f,.032f,.983f,.968f},{.028f,.112f,.972f,.888f},{.04f,.17f,.96f,.83f},{.052f,.235f,.948f,.765f},{.064f,.298f,.936f,.702f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,79)!=41)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Performance142Template(){}
}
