package az.kinera.edit;
final class Expert151Audio {
 static boolean validRange(int capacity,int offset,int size){return capacity>=0&&offset>=0&&size>=0&&offset<=capacity&&size<=capacity-offset;}
 private Expert151Audio(){}
}
