package az.kinera.edit;
final class Studio141TemplatePolicy {
 static final int FIRST=3984,TOTAL=4034;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.0011f;float[][] a={{.012f,.025f,.988f,.975f},{.028f,.105f,.972f,.895f},{.037f,.162f,.963f,.838f},{.045f,.225f,.955f,.775f},{.058f,.288f,.942f,.712f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,73)!=39)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Studio141TemplatePolicy(){}
}
