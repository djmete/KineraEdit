package az.kinera.edit;
/** Five composition families, ten contrasting palettes. Previous IDs remain stable. */
final class Motion134TemplatePolicy {
 static final int FIRST=3634,TOTAL=3684;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=k%10*.0009f;float[][] a={{.008f,.028f,.992f,.972f},{.018f,.116f,.982f,.884f},{.027f,.196f,.973f,.804f},{.037f,.259f,.963f,.741f},{.048f,.337f,.952f,.663f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,43)!=31)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Motion134TemplatePolicy(){}
}
