package az.kinera.edit;
/** UI colors are independent of the video rendering API. */
final class StudioPalette {
 static int BG=0xff111217,PANEL=0xff23252e,GOLD=0xffa9e8d8,FG=0xfff6f8fc,MUTED=0xffb2b8c5;
 static boolean black;
 static void select(boolean useBlack){black=useBlack;BG=black?0xff000000:0xff111217;PANEL=black?0xff161616:0xff23252e;GOLD=black?0xffa9e8d8:0xffa9e8d8;FG=0xfff6f8fc;MUTED=black?0xffc5c5c5:0xffb2b8c5;}
 static int surface(int c){return ThemePolicy.surface(c,black);}
 private StudioPalette() {}
}
