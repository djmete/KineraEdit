package az.kinera.edit;
/** UI colors are independent of the video rendering API. */
final class StudioPalette {
 static int BG=0xff10171f,PANEL=0xff202e3a,GOLD=0xff9fe2ec,FG=0xfff6f8fc,MUTED=0xffc0d0dd;
 static boolean black;
 static void select(boolean useBlack){black=useBlack;BG=black?0xff000000:0xff10171f;PANEL=black?0xff161616:0xff202e3a;GOLD=black?0xff9fe2ec:0xff9fe2ec;FG=0xfff6f8fc;MUTED=black?0xffc5c5c5:0xffc0d0dd;}
 static int surface(int c){return ThemePolicy.surface(c,black);}
 private StudioPalette() {}
}
