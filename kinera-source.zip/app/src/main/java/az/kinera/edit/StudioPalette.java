package az.kinera.edit;
/** UI colors are independent of the video rendering API. */
final class StudioPalette {
 static int BG=0xff10141a,PANEL=0xff1d252e,GOLD=0xffa4e9df,FG=0xfff6f8fc,MUTED=0xffb7c3cf;
 static boolean black;
 static void select(boolean useBlack){black=useBlack;BG=black?0xff000000:0xff10141a;PANEL=black?0xff161616:0xff1d252e;GOLD=black?0xffa4e9df:0xffa4e9df;FG=0xfff6f8fc;MUTED=black?0xffc5c5c5:0xffb7c3cf;}
 static int surface(int c){return ThemePolicy.surface(c,black);}
 private StudioPalette() {}
}
