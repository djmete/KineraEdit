package az.kinera.edit;
/** UI colors are independent of the video rendering API. */
final class StudioPalette {
 static int BG=0xff101418,PANEL=0xff20272e,GOLD=0xff8ce5cf,FG=0xfff6f8fc,MUTED=0xffb6c3c9;
 static boolean black;
 static void select(boolean useBlack){black=useBlack;BG=black?0xff000000:0xff101418;PANEL=black?0xff161616:0xff20272e;GOLD=black?0xff8ce5cf:0xff8ce5cf;FG=0xfff6f8fc;MUTED=black?0xffc5c5c5:0xffb6c3c9;}
 static int surface(int c){return ThemePolicy.surface(c,black);}
 private StudioPalette() {}
}
