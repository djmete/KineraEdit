package az.kinera.edit;
/** UI colors are independent of the video rendering API. */
final class StudioPalette {
 static int BG=0xff0e141d,PANEL=0xff17212d,GOLD=0xff8fe4cf,FG=0xfff6f8fc,MUTED=0xffbbcbd9;
 static boolean black;
 static void select(boolean useBlack){black=useBlack;BG=black?0xff000000:0xff0e141d;PANEL=black?0xff161616:0xff17212d;GOLD=black?0xff8fe4cf:0xff8fe4cf;FG=0xfff6f8fc;MUTED=black?0xffc5c5c5:0xffbbcbd9;}
 static int surface(int c){return ThemePolicy.surface(c,black);}
 private StudioPalette() {}
}
