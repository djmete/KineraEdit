package az.kinera.edit;
/** Append-only original composition presets. No source fingerprint manipulation. */
final class Expert79TemplatePolicy {
 static final int FIRST=734,TOTAL=784;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.082f,.988f,.977f};case 1:return new float[]{.023f,.123f,.977f,.902f};case 2:return new float[]{.026f,.205f,.974f,.780f};case 3:return new float[]{.018f,.270f,.982f,.700f};default:return new float[]{.014f,.315f,.986f,.650f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,11)!=4)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/11,10),10);}
}
