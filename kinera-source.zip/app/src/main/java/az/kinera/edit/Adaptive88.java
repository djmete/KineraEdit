package az.kinera.edit;
final class Adaptive88 {
 static final long MIB=1048576L;
 static boolean pressure(int thermal,long available,long threshold){return thermal>=2||(available>0&&threshold>0&&available<=threshold+Math.min(256*MIB,threshold/2));}
 static int samples(long duration,boolean efficient,boolean pressure){int normal=Performance86.samples(duration,efficient);return pressure?Math.min(normal,Math.max(1,1+(int)Math.min(47,Math.max(0,duration-1)/1250000L))):normal;}
 static int refineLimit(boolean efficient,boolean pressure){return pressure?2:Performance87.refineLimit(efficient);}
 static int previewHeight(int height,boolean automatic,boolean pressure){return automatic&&pressure?Math.min(height,480):height;}
 static boolean enoughCoverage(int processed,int count,int decoded){return count>0&&processed==count&&decoded>=Math.max(1,(count*3+3)/4);}
 static boolean captureHistory(long pixels,boolean pressure){return pixels>0&&pixels<= (pressure?1280L*720:1920L*1080);}
 static int tick(boolean playing,boolean dragging){return dragging?200:playing?250:600;}
}
