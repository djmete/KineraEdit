package az.kinera.edit;
/** Local scene context. Retain editorial cuts and bound accents around isolated short inserts. */
final class Evolution150Director {
 static float balance(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 1f;long a=cuts[i]-(i==0?0:cuts[i-1]),b=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(a<=0||b<=0)return 1f;long shortShot=Math.min(a,b),longShot=Math.max(a,b);if(shortShot>=1800000L||longShot<3*shortShot)return 1f;float x=1f-shortShot/1800000f;return 1f-.25f*x*x;}
 private Evolution150Director(){}
}
