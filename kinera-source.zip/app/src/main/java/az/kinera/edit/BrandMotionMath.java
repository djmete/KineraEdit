package az.kinera.edit;
/** Stable, content-aware editorial palettes and time-based decorative motion. */
final class BrandMotionMath {
 private BrandMotionMath() {}
 private static final long[] PERIODS={5400000L,6400000L,7200000L,4800000L,8000000L,6600000L,6200000L,7600000L,6800000L,5800000L,8400000L,7200000L,6400000L,7800000L,7200000L,6100000L,9000000L,6900000L,7600000L,8200000L,6800000L,9000000L,7400000L,7800000L,8400000L,7200000L,9600000L,8000000L,6800000L,9200000L,8200000L,7800000L,9400000L,8600000L,7200000L,10000000L,7300000L,8400000L,9100000L,6700000L,9700000L,8100000L,8800000L,7600000L,10200000L,7100000L,9300000L,8500000L,10400000L,7900000L,9600000L,8700000L,11200000L,7400000L,6200000L,8600000L,7100000L,9300000L,7900000L,10500000L,6800000L,8800000L,10200000L,7400000L,9600000L,11000000L,7600000L,8900000L,9400000L,10500000L,8100000L,11600000L,7400000L,9900000L,8300000L,10700000L,9200000L,11300000L,6900000L,8300000L,9700000L,7400000L,10100000L,8800000L,7600000L,9100000L,10400000L,8200000L,11500000L,9600000L,7800000L,10200000L,8800000L,11200000L,9300000L,12400000L,8000000L,9200000L,10500000L,8700000L,11600000L,9800000L,7800000L,9100000L,10400000L,8400000L,9600000L,11200000L,8200000L,9500000L,10800000L,8900000L,10000000L,11800000L,8600000L,9400000L,10200000L,11300000L,9700000L,12200000L,8400000L,9600000L,10800000L,7800000L,11200000L,9000000L};
 static float phase(long timeUs){return Math.floorMod(timeUs,6000000L)/6000000f;}
 static float motionPhase(long timeUs,int style){long period=periodUs(style);return Math.floorMod(timeUs,period)/(float)period;}
 static long periodUs(int style){return PERIODS[motionKind(style)];}
 static int motionKind(int style){return style>=1584&&style<1634?120+Math.floorMod(style-1584,6):style>=1534&&style<1584?120+Math.floorMod(style-1534,6):style>=1484&&style<1534?120+Math.floorMod(style-1484,6):style>=1434&&style<1484?120+Math.floorMod(style-1434,6):style>=1384&&style<1434?120+Math.floorMod(style-1384,6):style>=1334&&style<1384?120+Math.floorMod(style-1334,6):style>=1284&&style<1334?120+Math.floorMod(style-1284,6):style>=1234&&style<1284?120+Math.floorMod(style-1234,6):style>=1184&&style<1234?120+Math.floorMod(style-1184,6):style>=1134&&style<1184?120+Math.floorMod(style-1134,6):style>=1084&&style<1134?120+Math.floorMod(style-1084,6):style>=1034&&style<1084?120+Math.floorMod(style-1034,6):style>=984&&style<1034?114+Math.floorMod(style-984,6):style>=934&&style<984?108+Math.floorMod(style-934,6):style>=884&&style<934?102+Math.floorMod(style-884,6):style>=834&&style<884?96+Math.floorMod(style-834,6):style>=784&&style<834?90+Math.floorMod(style-784,6):style>=734&&style<784?84+Math.floorMod(style-734,6):style>=684&&style<734?78+Math.floorMod(style-684,6):style>=634&&style<684?60+Math.floorMod(style-634,18):style>=584&&style<634?60+Math.floorMod(style-584,18):style>=534&&style<584?60+Math.floorMod(style-534,18):style>=484&&style<534?60+Math.floorMod(style-484,18):style>=434&&style<484?60+Math.floorMod(style-434,18):style>=384&&style<434?60+Math.floorMod(style-384,18):style>=334&&style<384?60+Math.floorMod(style-334,18):style>=284&&style<334?60+Math.floorMod(style-284,18):style>=234&&style<284?60+Math.floorMod(style-234,18):style>=228&&style<234?72+style-228:style>=222&&style<228?72+style-222:style>=216&&style<222?72+style-216:style>=210&&style<216?66+style-210:style>=204&&style<210?60+style-204:style>=198&&style<204?60+style-198:style>=192&&style<198?60+style-192:style>=180&&style<192?60+(style-180)%6:style>=174&&style<180?54+style-174:style>=162&&style<174?54+(style-162)%6:style>=156&&style<162?48+style-156:style>=90&&style<156?42+(style-90)%6:style>=78&&style<=89?36+(style-78)%6:style>=72&&style<=77?style-42:style>=66&&style<=71?style-42:style>=60&&style<=65?style-48:style>=54&&style<=59?style-36:style>=42&&style<=53?style-42:Math.floorMod(style,6);}
 static int layoutFor(int colorStyle,float aspect){
  boolean portrait=Float.isFinite(aspect)&&aspect>0&&aspect<=1.05f;
  switch(colorStyle){case 28:case 36:case 42:return portrait?42:28;case 29:case 37:case 43:return portrait?43:29;case 30:case 38:case 44:return portrait?44:30;case 32:case 39:case 45:return portrait?45:32;case 33:case 40:case 46:return portrait?46:33;case 35:case 41:case 47:return portrait?47:35;default:return portrait?46:colorStyle;}
 }
 // Choose new wide-window families for wide/square-ish material, retaining previous portrait layouts.
 static int creativeLayoutFor(int colorStyle,float aspect){
  int family=layoutFor(colorStyle,.75f);
  if(family>=42&&family<=47&&Float.isFinite(aspect)&&aspect>1.05f)return family+6;
  return layoutFor(colorStyle,aspect);
 }
 static int studioLayoutFor(int colorStyle,float aspect){int family=layoutFor(colorStyle,.75f);if(family>=42&&family<=47&&Float.isFinite(aspect)&&aspect>0&&aspect<=.70f)return family+12;if(family>=42&&family<=47&&Float.isFinite(aspect)&&aspect>.70f&&aspect<=1.05f)return family+18;return creativeLayoutFor(colorStyle,aspect);}
 static int styleFor(int[] pixels){
  if(pixels==null||pixels.length==0)return 0;
  double[] votes=new double[5];int valid=0,colored=0;
  for(int p:pixels){int r=(p>>>16)&255,g=(p>>>8)&255,b=p&255;int max=Math.max(r,Math.max(g,b)),min=Math.min(r,Math.min(g,b)),delta=max-min;
   if(max<28||min>235)continue;valid++;if(delta<18||delta/(double)max<.16)continue;colored++;
   double hue;if(max==r)hue=60*((g-b)/(double)delta);else if(max==g)hue=60*(2+(b-r)/(double)delta);else hue=60*(4+(r-g)/(double)delta);if(hue<0)hue+=360;
   int bin=hue<18||hue>=315?3:hue<75?0:hue<165?2:hue<205?4:1;
   // Bounded weighting: colorful details matter, but a tiny saturated object cannot dominate a scene.
   votes[bin]+=.45+.55*delta/255.;
  }
  if(valid==0||colored<Math.max(1,(int)Math.ceil(valid*.12)))return 33;
  int best=0;double sum=0;for(int i=0;i<votes.length;i++){sum+=votes[i];if(votes[i]>votes[best])best=i;}
  if(sum<=0||votes[best]/sum<.31)return 33;
  return new int[]{28,29,30,32,35}[best];
 }
}
