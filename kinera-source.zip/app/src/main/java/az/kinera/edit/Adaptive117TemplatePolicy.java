package az.kinera.edit;
/** Append 5 aspect-specific collections, each with 10 distinct margin/color variants. */
final class Adaptive117TemplatePolicy {
 static final int FIRST=3034,TOTAL=3084;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST)),f=k/10;float v=(k%10)*.0018f;float[][] a={{.020f,.047f,.980f,.953f},{.026f,.116f,.974f,.884f},{.030f,.232f,.970f,.768f},{.025f,.295f,.975f,.705f},{.018f,.368f,.982f,.632f}};float[] w=a[f];return new float[]{w[0]+v,w[1]+v,w[2]-v,w[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT||Math.floorMod(seed,7)!=3)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Adaptive117TemplatePolicy(){}
}
