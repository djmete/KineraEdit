package az.kinera.edit;
/** Bounded contrast guard and workspace workload rules. */
final class Precision92 {
 static int foreground(int rgb){return SceneMath.luma(rgb)>=152?0xff211e20:0xfff7f4ef;}
 static boolean thumbnails(boolean visible,boolean pressure,boolean playing,boolean adjusting){return visible&&!pressure&&!playing&&!adjusting;}
 static float sceneScore(int[] a,int[] b,float score){
  if(a==null||b==null||a.length!=2304||b.length!=2304||!Float.isFinite(score)||score<.30f||score>=.39f)return score;
  double sa=0,sb=0,saa=0,sab=0;int n=0;
  for(int y=0;y<48;y+=3)for(int x=0;x<48;x+=3){int i=y*48+x,aa=SceneMath.luma(a[i]),bb=SceneMath.luma(b[i]);sa+=aa;sb+=bb;saa+=aa*aa;sab+=aa*bb;n++;}
  double var=saa-sa*sa/n;if(var<n*160)return score;double gain=(sab-sa*sb/n)/var,offset=(sb-gain*sa)/n;
  if(gain<.55||gain>1.65||Math.abs(gain-1)<.13)return score;
  int stable=0,edges=0,matched=0;for(int y=0;y<48;y+=3)for(int x=0;x<48;x+=3){int i=y*48+x,aa=SceneMath.luma(a[i]),bb=SceneMath.luma(b[i]);if(Math.abs(bb-gain*aa-offset)<=8)stable++;
   if(x<45){int da=SceneMath.luma(a[i+3])-aa,db=SceneMath.luma(b[i+3])-bb;if(Math.abs(da)>=16){edges++;if(Math.abs(db-gain*da)<=9)matched++;}}
   if(y<45){int da=SceneMath.luma(a[i+144])-aa,db=SceneMath.luma(b[i+144])-bb;if(Math.abs(da)>=16){edges++;if(Math.abs(db-gain*da)<=9)matched++;}}
  }return edges>=40&&matched>=edges*.94&&stable>=n*.95?score*.90f:score;
 }
 static boolean coherentPair(long older,long previous,long now,long[] cuts,int fps){return Professional85Math.historyCadence(older,previous,now,fps)&&Cognitive90.recentSorted(older,previous,cuts,fps)&&Cognitive90.recentSorted(previous,now,cuts,fps)&&Cognitive90.recentSorted(older,now,cuts,fps)&&Math.max(previous-older,now-previous)<=3L*Math.min(previous-older,now-previous)&&now-older<=Math.min(TemporalRestorePolicy.MAX_GAP_US,Math.max(50000L,3000000L/Math.max(12,fps)));}
}
