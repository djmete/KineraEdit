package az.kinera.edit;
final class Creative101 {
 /** Once constrained, avoid expanding OCR bitmaps again within this session. */
 static int ocrEdge(int current,boolean pressure){return pressure?Math.min(720,current):current;}
 static int filmHeight(int dp){return dp<550?48:dp<720?54:66;}
 static int filmSlots(int dp,boolean pressure){return pressure?0:dp<550?4:dp<720?6:10;}
}
