package az.kinera.edit;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import java.io.File;
import java.io.IOException;
import java.util.Locale;
/** Inspect an actual video track, including orientation, before publishing the MP4. */
final class ExportInspection {
 static final class Result {final boolean valid;final String detail;Result(boolean ok,String d){valid=ok;detail=d;}}
 static Result inspect(File f,int requestedHeight,long expectedUs)throws IOException{
  if(!f.isFile()||f.length()==0)return new Result(false,"MP4: 0 bytes");
  MediaExtractor ex=new MediaExtractor();MediaMetadataRetriever mm=new MediaMetadataRetriever();
  int w=0,h=0,rot=0;long trackUs=0,containerUs=0;boolean rotationKnown=false,sample=false;long firstPts=-1;
  try{
   ex.setDataSource(f.getAbsolutePath());
   for(int i=0;i<ex.getTrackCount();i++){
    MediaFormat format=ex.getTrackFormat(i);String mime=format.getString(MediaFormat.KEY_MIME);if(mime==null||!mime.startsWith("video/"))continue;
    w=format.getInteger(MediaFormat.KEY_WIDTH);h=format.getInteger(MediaFormat.KEY_HEIGHT);
    if(format.containsKey(MediaFormat.KEY_ROTATION)){rot=format.getInteger(MediaFormat.KEY_ROTATION);rotationKnown=true;}
    if(format.containsKey(MediaFormat.KEY_DURATION))trackUs=format.getLong(MediaFormat.KEY_DURATION);
    ex.selectTrack(i);sample=ex.getSampleTrackIndex()==i&&ex.getSampleTime()>=0;firstPts=ex.getSampleTime();break;
   }
   try{mm.setDataSource(f.getAbsolutePath());if(!rotationKnown)rot=integer(mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));containerUs=Long.parseLong(mm.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION))*1000L;}catch(Exception ignored){}
   long actual=trackUs>0?trackUs:containerUs;int[] display=ExportValidationMath.displayDimensions(w,h,rot);
   String technical=String.format(Locale.ROOT,"%d × %d → %d × %d (%d°) • %.3f / %.3f s • %s",w,h,display[0],display[1],rot,actual/1e6,expectedUs/1e6,GalleryMath.size(f.length()));
   boolean shape=ExportValidationMath.geometry(w,h,rot,requestedHeight),duration=ExportValidationMath.duration(actual,expectedUs);
   // Never accept an absent video track or a truncated file merely because metadata parses.
   boolean tail=false;
   if(sample&&actual>0){long target=firstPts+Math.max(0,actual-1_000_000L);ex.seekTo(target,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);long pts=ex.getSampleTime(),last=pts;int n=0;while(pts>=0&&n++<12000){last=Math.max(last,pts);if(last>=firstPts+actual-ExportValidationMath.tolerance(actual)){tail=true;break;}if(!ex.advance())break;pts=ex.getSampleTime();}}
   boolean valid=sample&&tail&&shape&&duration;
   return new Result(valid,valid?display[0]+" × "+display[1]+" • "+TimelineMath.time(actual/1000):technical+"\nvideo="+sample+", tail="+tail+", dimensions="+shape+", duration="+duration);
  }finally{try{ex.release();}finally{try{mm.release();}catch(Exception ignored){}}}
 }
 private static int integer(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
}
