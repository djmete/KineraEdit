package az.kinera.edit;
/** Direct anchor appearance check; not an identity model. Neutral for low texture. */
final class AppearanceGuard {
 static boolean agrees(int[] anchor,int[] now,int w,int h,float[] a,float[] b){
  if(anchor==null||now==null||w<=0||h<=0||anchor.length!=(long)w*h||now.length!=(long)w*h||!RegionMath.active(a)||!RegionMath.active(b))return false;
  double sx=0,sy=0,xx=0,yy=0,xy=0,chroma=0;int n=0;
  for(int i=0;i<8;i++)for(int k=0;k<8;k++){
   int p=sample(anchor,w,h,a,k,i),q=sample(now,w,h,b,k,i);double x=SceneMath.luma(p),y=SceneMath.luma(q);sx+=x;sy+=y;xx+=x*x;yy+=y*y;xy+=x*y;n++;
   int pr=(p>>>16)&255,pg=(p>>>8)&255,pb=p&255,qr=(q>>>16)&255,qg=(q>>>8)&255,qb=q&255;chroma+=Math.abs((pr-pg)-(qr-qg))+Math.abs((pb-pg)-(qb-qg));
  }
  double vx=xx-sx*sx/n,vy=yy-sy*sy/n;if(vx/n<64||vy/n<64)return true;
  double correlation=(xy-sx*sy/n)/Math.sqrt(vx*vy);return !(correlation<.28&&chroma/(n*1020.)>.07);
 }
 private static int sample(int[] pixels,int w,int h,float[] r,int x,int y){int px=Math.min(w-1,Math.max(0,(int)((r[0]+(r[2]-r[0])*(x+.5f)/8)*w)));int py=Math.min(h-1,Math.max(0,(int)((r[1]+(r[3]-r[1])*(y+.5f)/8)*h)));return pixels[py*w+px];}
}
