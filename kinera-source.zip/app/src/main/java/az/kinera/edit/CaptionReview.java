package az.kinera.edit;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.concurrent.TimeUnit;
/** User-triggered geometry suggestion for authorized caption editing; no transcript. */
final class CaptionReview {
 static final class Suggestion { final float[] region; final float lowerStart; Suggestion(float[] r,float t){region=r;lowerStart=t;} }
 static Suggestion detectAdaptive(Context context,Uri uri,long at,int w,int h,long duration) throws Exception {
  long end=Math.max(0,duration-1),center=Math.max(0,Math.min(end,at));
  long[] times=EvolutionMath.captionTimes(center,duration);
  java.util.ArrayList<float[]> candidates=new java.util.ArrayList<>();float[] centerMask=RegionMath.empty();
  MediaMetadataRetriever reader=new MediaMetadataRetriever();try(ScanSession session=new ScanSession()){reader.setDataSource(context,uri);for(long t:times){if(Thread.currentThread().isInterrupted())throw new InterruptedException();try{Suggestion r=detectAt(reader,t,w,h,session);if(t==center)centerMask=r.region;else if(RegionMath.active(r.region))candidates.add(r.region);}catch(InterruptedException e){throw e;}catch(Exception ignored){if(session.pending!=null&&!session.pending.isComplete())break;}}}finally{try{reader.release();}catch(Exception ignored){}}
  float[] region=Precision133Caption.stabilize(centerMask,Adaptive117Caption.review(centerMask,candidates,times.length));return new Suggestion(region,RegionMath.active(region)?region[1]:Float.NaN);
 }
 static Suggestion detectConsensus(Context context,Uri uri,long at,int w,int h,long duration) throws Exception {
  long[] times={Math.max(0,at-400000L),at,Math.min(Math.max(0,duration-1),at+400000L)};
  java.util.ArrayList<float[]> candidates=new java.util.ArrayList<>();long last=-1;
  MediaMetadataRetriever reader=new MediaMetadataRetriever();try(ScanSession session=new ScanSession()){reader.setDataSource(context,uri);for(long time:times){if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(time==last)continue;last=time;session.cropRetries=0;session.sourceRetries=0;session.lastCropUs=Long.MIN_VALUE;Suggestion s=detectAt(reader,time,w,h,session);if(RegionMath.active(s.region))candidates.add(s.region);}}finally{try{reader.release();}catch(Exception ignored){}}
  float[] region=PrecisionMath.consensus(candidates);return new Suggestion(region,RegionMath.active(region)?region[1]:Float.NaN);
 }
 static Suggestion detectSuggestion(Context context,Uri uri,long atUs,int width,int height) throws Exception {
  MediaMetadataRetriever r=new MediaMetadataRetriever();try{r.setDataSource(context,uri);return detectAt(r,atUs,width,height);}finally{try{r.release();}catch(Exception ignored){}}
 }
 static Suggestion detectAt(MediaMetadataRetriever r,long atUs,int width,int height)throws Exception{
  try(ScanSession session=new ScanSession()){return detectAt(r,atUs,width,height,session);}
 }
 static final class ScanSession implements AutoCloseable {
  private static final java.util.concurrent.Semaphore SESSIONS=new java.util.concurrent.Semaphore(1,true);
  final TextRecognizer client;final java.util.function.BooleanSupplier cancelled;final VisualInferenceGate.Lease visionLease;
  ScanSession()throws Exception{this(()->false);}
  ScanSession(java.util.function.BooleanSupplier stop)throws Exception{cancelled=stop;long end=android.os.SystemClock.elapsedRealtime()+12000;while(!SESSIONS.tryAcquire(250,TimeUnit.MILLISECONDS)){if(stop.getAsBoolean()||android.os.SystemClock.elapsedRealtime()>=end)throw new InterruptedException("OCR busy");}if(stop.getAsBoolean()){SESSIONS.release();throw new InterruptedException("OCR cancelled");}VisualInferenceGate.Lease acquired=null;try{while((acquired=VisualInferenceGate.tryEnter())==null){if(stop.getAsBoolean()||android.os.SystemClock.elapsedRealtime()>=end)throw new InterruptedException("Visual AI busy");Thread.sleep(100);}if(stop.getAsBoolean()||Thread.currentThread().isInterrupted())throw new InterruptedException("OCR cancelled");client=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);visionLease=acquired;}catch(Exception|Error e){if(acquired!=null)acquired.close();SESSIONS.release();throw e;}}
  void closeClient(){try{client.close();}finally{try{visionLease.close();}finally{SESSIONS.release();}}}
  Task<Text> pending;Bitmap owned;boolean closed;int maxEdge=960;Integer rotation;int cropRetries,sourceRetries;long lastCropUs=Long.MIN_VALUE;long scanDeadline=0;
  Text recognize(Bitmap bitmap)throws Exception{if(closed||pending!=null){bitmap.recycle();throw new IllegalStateException("OCR session not available");}owned=bitmap;try{pending=client.process(InputImage.fromBitmap(bitmap,0));long now=android.os.SystemClock.elapsedRealtime();long end=now+Deep103.waitMs(now,scanDeadline);while(true){if(cancelled.getAsBoolean()||Thread.currentThread().isInterrupted())throw new InterruptedException("OCR cancelled");long remaining=end-android.os.SystemClock.elapsedRealtime();if(remaining<=0)throw new java.util.concurrent.TimeoutException("OCR timeout");try{return Tasks.await(pending,Math.min(250,remaining),TimeUnit.MILLISECONDS);}catch(java.util.concurrent.TimeoutException retry){}}}catch(Exception e){throw e;}}
  void releaseFrame(){if(pending!=null&&!pending.isComplete())return;pending=null;if(owned!=null){owned.recycle();owned=null;}}
  public void close(){if(closed)return;closed=true;if(pending!=null&&!pending.isComplete()){final Bitmap bitmap=owned;pending.addOnCompleteListener(Runnable::run,t->{try{if(bitmap!=null)bitmap.recycle();}finally{closeClient();}});owned=null;pending=null;}else{releaseFrame();closeClient();}}
 }
 static Suggestion detectAt(MediaMetadataRetriever r,long atUs,int width,int height,ScanSession session)throws Exception{
  if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(session.cancelled.getAsBoolean())throw new InterruptedException();if(session.rotation==null){session.rotation=0;try{session.rotation=Integer.parseInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));}catch(Exception ignored){}}int rotation=session.rotation;if(rotation==90||rotation==270){int tmp=width;width=height;height=tmp;}
  float scale=Math.min(1f,(float)session.maxEdge/Math.max(1,Math.max(width,height)));int w=Math.max(2,Math.round(width*scale)),h=Math.max(2,Math.round(height*scale));Bitmap frame=AnalysisFrameReader.read(r,atUs,w,h);
  if(frame==null)throw new IllegalStateException("Kadr oxunmadı");
  if(Thread.currentThread().isInterrupted()){frame.recycle();throw new InterruptedException();}
  final Bitmap bitmap=frame;
  Bitmap rescue=null;
  try{Text result=session.recognize(bitmap);Suggestion first=extract(result,bitmap.getWidth(),bitmap.getHeight(),0f,1f);
   if(!Deep103.rescue(first.region)||!CaptionRetry102.allowed(session.cropRetries,session.maxEdge,atUs,session.lastCropUs,android.os.SystemClock.elapsedRealtime(),session.scanDeadline)||session.cancelled.getAsBoolean())return first;
   int top=Math.round(bitmap.getHeight()*.48f);if(top<=0||bitmap.getHeight()-top<16)return first;
   float offset=top/(float)bitmap.getHeight(),span=1f-offset;
   rescue=Bitmap.createBitmap(bitmap,0,top,bitmap.getWidth(),bitmap.getHeight()-top);
   session.releaseFrame();
   int sourceEdge=Vision107.rescueSourceEdge(width,height,session.maxEdge,session.sourceRetries,android.os.SystemClock.elapsedRealtime(),session.scanDeadline);
   if(sourceEdge>0&&!session.cancelled.getAsBoolean()&&!Thread.currentThread().isInterrupted()){
    session.sourceRetries++;int originalEdge=Math.max(width,height);Bitmap high=AnalysisFrameReader.read(r,atUs,Vision107.rescueSide(width,originalEdge,sourceEdge),Vision107.rescueSide(height,originalEdge,sourceEdge));
    if(high!=null){try{int hiTop=Math.round(high.getHeight()*.48f);if(hiTop>0&&high.getHeight()-hiTop>=16&&Math.max(high.getWidth(),high.getHeight())>session.maxEdge){Bitmap hiCrop=Bitmap.createBitmap(high,0,hiTop,high.getWidth(),high.getHeight()-hiTop);if(hiCrop!=high){rescue.recycle();rescue=hiCrop;offset=hiTop/(float)high.getHeight();span=1f-offset;}}}finally{high.recycle();}}
   }
   int longest=Math.max(rescue.getWidth(),rescue.getHeight()),edge=Deep103.rescueEdge(rescue.getWidth(),rescue.getHeight());
   if(edge>longest){Bitmap scaled=Bitmap.createScaledBitmap(rescue,Deep103.scaled(rescue.getWidth(),longest,edge),Deep103.scaled(rescue.getHeight(),longest,edge),true);if(scaled!=rescue){rescue.recycle();rescue=scaled;}}
   // The first OCR task has completed, so its bitmap can be released before the second.
   session.releaseFrame();session.cropRetries++;session.lastCropUs=atUs;
   if(session.cancelled.getAsBoolean()||Thread.currentThread().isInterrupted())throw new InterruptedException();
   Bitmap ownedRescue=rescue;rescue=null;Text second=session.recognize(ownedRescue);Suggestion candidate=extract(second,ownedRescue.getWidth(),ownedRescue.getHeight(),offset,span);return Fusion104.rescueChoice(first.region,candidate.region)==candidate.region?candidate:first;
  }finally{if(rescue!=null)rescue.recycle();session.releaseFrame();}
 }
 private static Suggestion extract(Text result,int width,int height,float yOffset,float ySpan){java.util.ArrayList<float[]> lines=new java.util.ArrayList<>(),shortLines=new java.util.ArrayList<>();float start=Float.NaN;
   for(Text.TextBlock block:result.getTextBlocks())for(Text.Line line:block.getLines()){
    Rect box=line.getBoundingBox();if(box==null)continue;
    float y=yOffset+ySpan*box.top/height,bottom=yOffset+ySpan*box.bottom/height;
    float lineWidth=box.width()/(float)width;if(y>=.55f&&bottom<=1.01f&&bottom-y<=.16f&&lineWidth>=.12f)start=Float.isNaN(start)?y:Math.min(start,y);
    float[] lineRegion=CaptionRegionMath.include(RegionMath.empty(),box.left/(float)width,y,box.right/(float)width,bottom);if(RegionMath.active(lineRegion)&&lines.size()<64)lines.add(lineRegion);else if(shortLines.size()<16){float[] narrow=CaptionRegionMath.shortCaption(box.left/(float)width,y,box.right/(float)width,bottom,line.getText());if(RegionMath.active(narrow))shortLines.add(narrow);}
   }
   float[] region=Fusion104.caption(Ultra95.caption(CaptionRegionMath.best(lines),shortLines),lines,shortLines);region=Unified106.caption(region,shortLines);float[] padded=CaptionRegionMath.adaptivePadding(region);if(RegionMath.active(padded)){float px=Math.min(.006f,(padded[2]-padded[0])*.03f),py=Math.min(.004f,(padded[3]-padded[1])*.12f);padded=RegionMath.rect(padded[0]-px,padded[1]-py,padded[2]+px,padded[3]+py,.001f);}return new Suggestion(padded,RegionMath.active(region)?region[1]:start);

 }
}
