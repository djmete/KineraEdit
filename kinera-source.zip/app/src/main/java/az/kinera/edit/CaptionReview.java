package az.kinera.edit;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.concurrent.TimeUnit;
/** User-triggered geometry suggestion for authorized caption editing; no transcript. */
final class CaptionReview {
 static final class Suggestion { final float[] region; final float lowerStart; Suggestion(float[] r,float t){region=r;lowerStart=t;} }
 static Suggestion detectAdaptive(Context context,Uri uri,long at,int w,int h,long duration) throws Exception {
  long end=Math.max(0,duration-1),center=Math.max(0,Math.min(end,at));
  long[] times=EvolutionMath.captionTimes(center,duration);
  java.util.ArrayList<float[]> candidates=new java.util.ArrayList<>();
  MediaMetadataRetriever reader=new MediaMetadataRetriever();try(ScanSession session=new ScanSession()){reader.setDataSource(context,uri);for(long t:times){if(Thread.currentThread().isInterrupted())throw new InterruptedException();try{Suggestion r=detectAt(reader,t,w,h,session);if(RegionMath.active(r.region))candidates.add(r.region);}catch(InterruptedException e){throw e;}catch(Exception ignored){if(session.pending!=null&&!session.pending.isComplete())break;}}}finally{try{reader.release();}catch(Exception ignored){}}
  float[] region=EvolutionMath.reviewedMask(candidates,times.length);return new Suggestion(region,RegionMath.active(region)?region[1]:Float.NaN);
 }
 static Suggestion detectConsensus(Context context,Uri uri,long at,int w,int h,long duration) throws Exception {
  long[] times={Math.max(0,at-400000L),at,Math.min(Math.max(0,duration-1),at+400000L)};
  java.util.ArrayList<float[]> candidates=new java.util.ArrayList<>();long last=-1;
  for(long time:times){if(Thread.currentThread().isInterrupted())throw new InterruptedException();if(time==last)continue;last=time;Suggestion s=detectSuggestion(context,uri,time,w,h);if(RegionMath.active(s.region))candidates.add(s.region);}
  float[] region=PrecisionMath.consensus(candidates);return new Suggestion(region,RegionMath.active(region)?region[1]:Float.NaN);
 }
 static Suggestion detectSuggestion(Context context,Uri uri,long atUs,int width,int height) throws Exception {
  MediaMetadataRetriever r=new MediaMetadataRetriever();try{r.setDataSource(context,uri);return detectAt(r,atUs,width,height);}finally{try{r.release();}catch(Exception ignored){}}
 }
 static Suggestion detectAt(MediaMetadataRetriever r,long atUs,int width,int height)throws Exception{
  try(ScanSession session=new ScanSession()){return detectAt(r,atUs,width,height,session);}
 }
 static final class ScanSession implements AutoCloseable {
  final TextRecognizer client=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
  Task<Text> pending;Bitmap owned;boolean closed;
  Text recognize(Bitmap bitmap)throws Exception{if(closed||pending!=null){bitmap.recycle();throw new IllegalStateException("OCR session not available");}owned=bitmap;try{pending=client.process(InputImage.fromBitmap(bitmap,0));return Tasks.await(pending,12,TimeUnit.SECONDS);}catch(Exception e){throw e;}}
  void releaseFrame(){if(pending!=null&&!pending.isComplete())return;pending=null;if(owned!=null){owned.recycle();owned=null;}}
  public void close(){if(closed)return;closed=true;if(pending!=null&&!pending.isComplete()){final Bitmap bitmap=owned;pending.addOnCompleteListener(Runnable::run,t->{try{if(bitmap!=null)bitmap.recycle();}finally{client.close();}});owned=null;pending=null;}else{releaseFrame();client.close();}}
 }
 static Suggestion detectAt(MediaMetadataRetriever r,long atUs,int width,int height,ScanSession session)throws Exception{
  if(Thread.currentThread().isInterrupted())throw new InterruptedException();int rotation=0;try{rotation=Integer.parseInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));}catch(Exception ignored){}if(rotation==90||rotation==270){int tmp=width;width=height;height=tmp;}
  float scale=Math.min(1f,960f/Math.max(1,Math.max(width,height)));int w=Math.max(2,Math.round(width*scale)),h=Math.max(2,Math.round(height*scale));Bitmap frame=AnalysisFrameReader.read(r,atUs,w,h);
  if(frame==null)throw new IllegalStateException("Kadr oxunmadı");
  if(Thread.currentThread().isInterrupted()){frame.recycle();throw new InterruptedException();}
  final Bitmap bitmap=frame;
  try{Text result=session.recognize(bitmap);java.util.ArrayList<float[]> lines=new java.util.ArrayList<>(),shortLines=new java.util.ArrayList<>();float start=Float.NaN;
   for(Text.TextBlock block:result.getTextBlocks())for(Text.Line line:block.getLines()){
    Rect box=line.getBoundingBox();if(box==null)continue;
    float y=box.top/(float)bitmap.getHeight(),bottom=box.bottom/(float)bitmap.getHeight();
    float lineWidth=box.width()/(float)bitmap.getWidth();if(y>=.55f&&bottom<=1.01f&&bottom-y<=.16f&&lineWidth>=.12f)start=Float.isNaN(start)?y:Math.min(start,y);
    float[] lineRegion=CaptionRegionMath.include(RegionMath.empty(),box.left/(float)bitmap.getWidth(),y,box.right/(float)bitmap.getWidth(),bottom);if(RegionMath.active(lineRegion)&&lines.size()<64)lines.add(lineRegion);else if(shortLines.size()<16){float[] narrow=CaptionRegionMath.shortCaption(box.left/(float)bitmap.getWidth(),y,box.right/(float)bitmap.getWidth(),bottom,line.getText());if(RegionMath.active(narrow))shortLines.add(narrow);}
   }
   float[] region=CaptionRegionMath.best(lines);if(!RegionMath.active(region)&&!shortLines.isEmpty()){float best=Float.POSITIVE_INFINITY;for(float[] candidate:shortLines){float score=Math.abs((candidate[0]+candidate[2])/2-.5f);if(score<best){region=candidate;best=score;}}}float[] padded=CaptionRegionMath.adaptivePadding(region);if(RegionMath.active(padded)){float px=Math.min(.006f,(padded[2]-padded[0])*.03f),py=Math.min(.004f,(padded[3]-padded[1])*.12f);padded=RegionMath.rect(padded[0]-px,padded[1]-py,padded[2]+px,padded[3]+py,.001f);}return new Suggestion(padded,RegionMath.active(region)?region[1]:start);}
  finally{session.releaseFrame();}
 }
}
