package az.kinera.edit;
/** Reject off-anchor proposals even if the area is similar. Missing anchor remains explicit. */
final class Studio119Caption {
 static float[] stabilize(float[] anchor,float[] candidate){float[] c=Cinematic118Caption.stabilize(anchor,candidate);if(!RegionMath.active(anchor))return c;if(!RegionMath.active(c))return anchor.clone();float intersection=Math.max(0,Math.min(anchor[2],c[2])-Math.max(anchor[0],c[0]))*Math.max(0,Math.min(anchor[3],c[3])-Math.max(anchor[1],c[1]));float a=(anchor[2]-anchor[0])*(anchor[3]-anchor[1]);return intersection<a*.68f?anchor.clone():c;}
 private Studio119Caption(){}
}
