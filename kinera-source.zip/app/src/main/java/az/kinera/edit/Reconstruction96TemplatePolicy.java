package az.kinera.edit;
final class Reconstruction96TemplatePolicy {
 static final int FIRST=1584,TOTAL=1634;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.018f,.032f,.982f,.968f};case 1:return new float[]{.026f,.087f,.974f,.913f};case 2:return new float[]{.032f,.23675f,.968f,.76325f};case 3:return new float[]{.026f,.2945f,.974f,.7055f};default:return new float[]{.028f,.327f,.972f,.673f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic<=0||semantic==3||Math.floorMod(seed,31)!=19)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette+Math.floorMod(seed/31,10),10);}
}
