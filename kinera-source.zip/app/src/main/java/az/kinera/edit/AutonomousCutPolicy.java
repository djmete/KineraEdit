package az.kinera.edit;
/** Distributed candidate refinement; preserve original markers on incomplete probes. */
final class AutonomousCutPolicy {
 static final int MAX_PROBES=8;static final long BUDGET_MS=10000L;
 static int[] indices(int count){if(count<=0)return new int[0];int n=Math.min(MAX_PROBES,count);int[] a=new int[n];if(n==1)return a;for(int i=0;i<n;i++)a[i]=(int)((long)i*(count-1)/(n-1));return a;}
 static double mean(int[] v){if(v==null||v.length!=2304)return Double.NaN;long sum=0;for(int x:v)sum+=x;return sum/(255.*v.length);}
 static boolean pulse(int[] a,int[] b,int[] c,double incoming,double outgoing){if(!AutonomousPulseConfidence.ENABLED||a==null||b==null||c==null||incoming<.16||outgoing<.16)return false;double ret=SequentialCutMath.distance(a,c),ma=mean(a),mb=mean(b),mc=mean(c);return AutonomousPulseConfidence.pulse(incoming,outgoing,ret,mb-ma,mc-mb);}
}
