package az.kinera.edit;
/** Coded dimensions are not necessarily the dimensions presented to the viewer. */
final class ExportValidationMath {
 private ExportValidationMath(){}
 static int[] displayDimensions(int w,int h,int rotation){int r=((rotation%360)+360)%360;if(r==90||r==270)return new int[]{h,w};return new int[]{w,h};}
 static boolean geometry(int w,int h,int rotation,int requestedHeight){int[] p=displayDimensions(w,h,rotation);return p[0]>0&&p[1]>0&&(requestedHeight<1280||p[1]>=1280)&&p[1]<=requestedHeight+2&&Math.abs(p[0]/(double)p[1]-9d/16)<.012;}
 static long tolerance(long expectedUs){long rounding=Math.max(100_000L,Math.min(2_000_000L,Math.round(expectedUs*.01)));return Math.max(1L,Math.min(Math.max(1L,expectedUs/5),rounding));}
 static boolean duration(long actualUs,long expectedUs){return actualUs>0&&expectedUs>0&&Math.abs((double)actualUs-expectedUs)<=tolerance(expectedUs);}
}
