package az.kinera.edit;
import java.util.Arrays;
import java.util.Objects;
/** A render identity independent of output-only quality and audio settings. */
final class PreviewKey {
 private final EditSpec s;
 PreviewKey(EditSpec s){this.s=s;}
 EditSpec blurSnapshot(float[] region,float strength,long from,long until){EditSpec copy=new EditSpec(s.name,s.template,s.height,s.fps,s.crop,s.blur,s.flip,s.fade,s.hevc,s.durationUs,s.top,s.brightness,s.contrast,s.saturation,s.dip,s.cuts,s.mute,s.animated).withRegions(s.cropRect,region).withBlurStrength(strength).withBlurTiming(from,until);copy.extraMasks=s.extraMasks;return copy;}
 EditSpec strengthSnapshot(float strength){return s.withHeight(s.height).withBlurStrength(strength); }
 boolean samePipeline(PreviewKey other){if(other==null)return false;EditSpec b=other.s;return Performance86.restoration(s)==Performance86.restoration(b)&&Objects.equals(s.name,b.name)&&s.template==b.template&&s.height==b.height&&s.durationUs==b.durationUs&&Float.compare(s.crop,b.crop)==0&&Float.compare(s.top,b.top)==0&&Float.compare(s.brightness,b.brightness)==0&&Float.compare(s.contrast,b.contrast)==0&&Float.compare(s.saturation,b.saturation)==0&&Float.compare(s.dip,b.dip)==0&&s.flip==b.flip&&s.fade==b.fade&&s.animated==b.animated&&Arrays.equals(s.cuts,b.cuts)&&Arrays.equals(s.cropRect,b.cropRect);}
 @Override public boolean equals(Object other){if(!(other instanceof PreviewKey))return false;EditSpec b=((PreviewKey)other).s;return Performance86.restoration(s)==Performance86.restoration(b)&&Objects.equals(s.name,b.name)&&s.template==b.template&&s.height==b.height&&s.durationUs==b.durationUs&&s.blurFromUs==b.blurFromUs&&s.blurUntilUs==b.blurUntilUs&&Float.compare(s.crop,b.crop)==0&&Float.compare(s.top,b.top)==0&&Float.compare(s.blur,b.blur)==0&&Float.compare(s.blurStrength,b.blurStrength)==0&&Float.compare(s.brightness,b.brightness)==0&&Float.compare(s.contrast,b.contrast)==0&&Float.compare(s.saturation,b.saturation)==0&&Float.compare(s.dip,b.dip)==0&&s.flip==b.flip&&s.fade==b.fade&&s.animated==b.animated&&Arrays.equals(s.cuts,b.cuts)&&Arrays.equals(s.cropRect,b.cropRect)&&Arrays.equals(s.blurRect,b.blurRect)&&s.extraMasks.equals(b.extraMasks);}
 @Override public int hashCode(){return 31*Objects.hash(s.name,s.template,s.height,s.durationUs,s.blurFromUs,s.blurUntilUs,s.crop,s.top,s.blur,s.blurStrength,s.brightness,s.contrast,s.saturation,s.dip,s.flip,s.fade,s.animated)+Arrays.hashCode(s.cuts)+31*Arrays.hashCode(s.cropRect)+Arrays.hashCode(s.blurRect)+s.extraMasks.hashCode();}
}
