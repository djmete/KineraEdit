package az.kinera.edit;
final class Deep148Template {
 static final int FIRST=4334,TOTAL=4384;
 static float[] window(int id){int k=Math.max(0,Math.min(49,id-FIRST));float v=(k%10)*.00125f;float[][] a={{.028f,.103f,.972f,.897f},{.046f,.169f,.954f,.831f},{.053f,.218f,.947f,.782f},{.068f,.279f,.932f,.721f},{.085f,.333f,.915f,.667f}};float[] b=a[k/10];return new float[]{b[0]+v,b[1]+v,b[2]-v,b[3]-v};}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||Math.floorMod(seed,103)!=89)return prior;if(semantic!=CreativePolicy.PERSON&&semantic!=CreativePolicy.LANDSCAPE)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Deep148Template(){}
}
