package az.kinera.edit;
final class Quantum152Director {
 static float balance(long[] cuts,int i,long duration){if(cuts==null||i<0||i>=cuts.length||duration<=0)return 1f;long a=cuts[i]-(i==0?0:cuts[i-1]),b=(i+1==cuts.length?duration:cuts[i+1])-cuts[i];if(a<=0||b<=0)return 1f;float ratio=Math.min(a,b)/(float)Math.max(a,b);return .6f+.4f*ratio;}
 private Quantum152Director(){}
}
