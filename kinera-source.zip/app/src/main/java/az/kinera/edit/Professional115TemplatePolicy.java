package az.kinera.edit;
/** Fifty stable new IDs. Composition follows source aspect; old draft IDs are unchanged. */
final class Professional115TemplatePolicy {
 static final int FIRST=2934,TOTAL=2984;
 static float[] window(int id){switch(Math.max(0,Math.min(4,(id-FIRST)/10))){case 0:return new float[]{.012f,.045f,.988f,.955f};case 1:return new float[]{.018f,.105f,.982f,.895f};case 2:return new float[]{.020f,.225f,.980f,.775f};case 3:return new float[]{.016f,.305f,.984f,.695f};default:return new float[]{.010f,.365f,.990f,.635f};}}
 static int choose(int prior,float aspect,int semantic,int palette,int seed){if(prior<0||prior>=FIRST||!Float.isFinite(aspect)||aspect<=0||semantic==CreativePolicy.UNKNOWN||semantic==CreativePolicy.DOCUMENT)return prior;if(semantic==CreativePolicy.PERSON&&aspect>1.2f||semantic==CreativePolicy.LANDSCAPE&&aspect<1.25f)return prior;if(Math.floorMod(seed,4)!=0)return prior;return FIRST+10*Director72TemplatePolicy.family(aspect)+Math.floorMod(palette,10);}
 private Professional115TemplatePolicy(){}
}
