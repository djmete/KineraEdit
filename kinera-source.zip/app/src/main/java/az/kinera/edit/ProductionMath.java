package az.kinera.edit;
import java.util.*;
/** Bounded edit history and progress estimates, independent of Android. */
final class ProductionMath {
 static final class Regions {
  final float[] crop,blur; final long from,until; final List<TimedRegions.Mask> masks;
  Regions(float[] c,float[] b,long f,long u,List<TimedRegions.Mask> m){crop=c.clone();blur=b.clone();from=f;until=u;masks=TimedRegions.snapshot(m);}
  boolean same(Regions other){return Arrays.equals(crop,other.crop)&&Arrays.equals(blur,other.blur)&&from==other.from&&until==other.until&&masks.equals(other.masks);}
 }
 static final class History {
  private final ArrayDeque<Regions> undo=new ArrayDeque<>(),redo=new ArrayDeque<>();private Regions current;
  void reset(float[] c,float[] b){reset(c,b,0,Long.MAX_VALUE,Collections.emptyList());}
  void reset(float[] c,float[] b,long f,long u,List<TimedRegions.Mask> m){undo.clear();redo.clear();current=new Regions(c,b,f,u,m);}
  void push(float[] c,float[] b){push(c,b,0,Long.MAX_VALUE,Collections.emptyList());}
  void push(float[] c,float[] b,long f,long u,List<TimedRegions.Mask> m){Regions next=new Regions(c,b,f,u,m);if(current==null){current=next;return;}if(current.same(next))return;undo.addLast(current);while(undo.size()>40)undo.removeFirst();redo.clear();current=next;}
  boolean canUndo(){return !undo.isEmpty();} boolean canRedo(){return !redo.isEmpty();}
  Regions undo(){if(canUndo()){redo.addLast(current);current=undo.removeLast();}return copy();}
  Regions redo(){if(canRedo()){undo.addLast(current);current=redo.removeLast();}return copy();}
  private Regions copy(){return current==null?null:new Regions(current.crop,current.blur,current.from,current.until,current.masks);}
 }
 static long etaSeconds(long elapsedMs,int percent){if(elapsedMs<4000||percent<3||percent>=100)return -1;return Math.min(86400,Math.max(1,Math.round(elapsedMs/1000.0*(100-percent)/percent)));}
 static double speed(long elapsedMs,int percent,long durationUs){if(elapsedMs<4000||percent<3||durationUs<=0)return 0;return durationUs/1000.0*percent/100/elapsedMs;}
 static boolean validFileName(String n){return n!=null&&n.matches("kinera_[0-9]+\\.mp4");}
 static int recommendedHeight(int requested,boolean lowRam,int memoryClass){return lowRam||memoryClass<=128?Math.min(1280,requested):requested;}
 static ArrayList<String> boundedQueue(Collection<String> input){LinkedHashSet<String> unique=new LinkedHashSet<>();for(String s:input){if(s!=null&&s.startsWith("content://")&&s.length()<=4096)unique.add(s);if(unique.size()>=30)break;}return new ArrayList<>(unique);}
}
