package az.kinera.edit;
import java.util.*;
/** Bounded edit history and progress estimates, independent of Android. */
final class ProductionMath {
 static final class Regions {
  final float[] crop,blur; final long from,until; final List<TimedRegions.Mask> masks; final int[] settings; final long[] cuts;
  Regions(float[] c,float[] b,long f,long u,List<TimedRegions.Mask> m){this(c,b,f,u,m,new int[0],new long[0]);}
  Regions(float[] c,float[] b,long f,long u,List<TimedRegions.Mask> m,int[] settings,long[] cuts){crop=c.clone();blur=b.clone();from=f;until=u;masks=TimedRegions.snapshot(m);this.settings=settings.clone();this.cuts=cuts.clone();}
  boolean same(Regions other){return Arrays.equals(crop,other.crop)&&Arrays.equals(blur,other.blur)&&from==other.from&&until==other.until&&masks.equals(other.masks)&&Arrays.equals(settings,other.settings)&&Arrays.equals(cuts,other.cuts);}
 }
 static final class History {
  private final ArrayDeque<Regions> undo=new ArrayDeque<>(),redo=new ArrayDeque<>();private Regions current;
  void reset(float[] c,float[] b){reset(c,b,0,Long.MAX_VALUE,Collections.emptyList());}
  void reset(float[] c,float[] b,long f,long u,List<TimedRegions.Mask> m){reset(new Regions(c,b,f,u,m));}
  void reset(Regions value){undo.clear();redo.clear();current=value;}
  void push(float[] c,float[] b){push(c,b,0,Long.MAX_VALUE,Collections.emptyList());}
  void push(float[] c,float[] b,long f,long u,List<TimedRegions.Mask> m){push(new Regions(c,b,f,u,m));}
  void push(Regions next){if(current==null){current=next;return;}if(current.same(next))return;undo.addLast(current);while(undo.size()>40)undo.removeFirst();redo.clear();current=next;}
  boolean canUndo(){return !undo.isEmpty();} boolean canRedo(){return !redo.isEmpty();}
  Regions undo(){if(canUndo()){redo.addLast(current);current=undo.removeLast();}return copy();}
  Regions redo(){if(canRedo()){undo.addLast(current);current=redo.removeLast();}return copy();}
  private Regions copy(){return current==null?null:new Regions(current.crop,current.blur,current.from,current.until,current.masks,current.settings,current.cuts);}
 }
 static long etaSeconds(long elapsedMs,int percent){if(elapsedMs<4000||percent<3||percent>=100)return -1;return Math.min(86400,Math.max(1,Math.round(elapsedMs/1000.0*(100-percent)/percent)));}
 static double speed(long elapsedMs,int percent,long durationUs){if(elapsedMs<4000||percent<3||durationUs<=0)return 0;return durationUs/1000.0*percent/100/elapsedMs;}
 static boolean validFileName(String n){return n!=null&&n.matches("kinera_[0-9]+\\.mp4");}
 static int recommendedHeight(int requested,boolean lowRam,int memoryClass){return lowRam||memoryClass<=128?Math.min(1280,requested):requested;}
 static ArrayList<String> boundedQueue(Collection<String> input){LinkedHashSet<String> unique=new LinkedHashSet<>();for(String s:input){if(s!=null&&s.startsWith("content://")&&s.length()<=4096)unique.add(s);if(unique.size()>=30)break;}return new ArrayList<>(unique);}
}
