package az.kinera.edit;
import java.nio.file.*;
final class Generative56Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] a)throws Exception{
 check(ExpertTemplatePolicy.TOTAL==934);for(int i=162;i<174;i++){float[] w=ReactiveMotionMath.window(i);check(w[0]>=0&&w[1]>=0&&w[2]<=1&&w[3]<=1&&w[0]<w[2]&&w[1]<w[3]);check(BrandMotionMath.motionKind(i)==54+(i-162)%6);check(BrandMotionMath.periodUs(i)>0);}
 check(ReactiveMotionMath.choose(138,.6f,1)==164);check(ReactiveMotionMath.choose(156,1.8f,2)==166);check(ReactiveMotionMath.choose(154,1f,3)==154);check(ReactiveMotionMath.choose(138,Float.NaN,1)==138);long[] cuts={3000000};check(ReactiveMotionMath.phase(3000000,162,cuts,6000000)!=BrandMotionMath.motionPhase(3000000,162));check(ReactiveMotionMath.phase(1000000,162,cuts,6000000)==BrandMotionMath.motionPhase(1000000,162));check(ReactiveMotionMath.phase(3000000,156,cuts,6000000)==BrandMotionMath.motionPhase(3000000,156));
 float[] small={.05f,.58f,.22f,.62f},line1={.2f,.78f,.8f,.83f},line2={.22f,.84f,.78f,.89f};float[] selected=CaptionRegionMath.best(java.util.List.of(small,line1,line2));check(selected[1]==.78f&&selected[3]==.89f);
 int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai56_motion_parity.csv"))){if(line.startsWith("f0,"))continue;String[] x=line.split(",");double[] f=new double[4];for(int i=0;i<4;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(MotionRestoreConfidence.blend(f)-Double.parseDouble(x[4])));n++;}check(n==32&&max<1e-8&&MotionRestoreConfidence.ENABLED);
 System.out.println("Generative56Test OK: 12 layouts, 6 motion families, cut response, 32 parity rows; max error="+max);}
}
