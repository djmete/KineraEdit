from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();d=(p/'KAiDirector.java').read_text();n=(p/'StudioNotifications.java').read_text();g=Path('app/build.gradle').read_text();home=s[s.index('root=page(HOME,true)'):s.index('root=page(PROFILE,true)')];settings=s[s.index('root=page(SETTINGS,true)'):s.index('root=page(ABOUT,true)')]
assert 'chooseAppearance' not in home and 'this::chooseAppearance' in settings and 'currentPage!=SETTINGS' in s
assert 'ReminderJob.ENABLE,on' in settings and 'ACTION_APP_NOTIFICATION_SETTINGS' in s and 'Notification.BigTextStyle' in n
assert 'FullCaptionPlan.sample(duration,i,n)' in d and 'cancelled.getAsBoolean()' in d and 'FullCaptionPlan.fixed(durationUs,blurRegion)' in s and 'Nümunə kadrlar əsasında təklif' in s
assert 'playGalleryVideo(Uri uri){playLocalVideo(uri);}' in s and 'localPlaybackError(uri)' in s and 'FLAG_GRANT_READ_URI_PERMISSION' in s
assert 'versionCode 93' in g and 'useLegacyPackaging = true' in g and 'abiFilters' not in g
print('v80 source integration audit OK: settings only, notifications, full duration paths, shared player and universal build')
