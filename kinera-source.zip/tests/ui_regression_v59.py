from pathlib import Path
s=Path('app/src/main/java/az/kinera/edit/MainActivity.java').read_text()
r=Path('app/src/main/java/az/kinera/edit/RegionOverlay.java').read_text()
manifest=Path('app/src/main/AndroidManifest.xml').read_text()
gradle=Path('app/build.gradle').read_text()
director=Path("app/src/main/java/az/kinera/edit/KAiDirector.java").read_text()
checks={
 'mirror default enabled': 'flip=toggle("Üfüqi güzgü",true)' in s and 'v58_mirror_migrated' in s,
 'mirror preference safe default': 'prefs.getBoolean("mirror_default_v29",false)' not in s,
 'single AutoBlur controller': 'detectCaption(true)' in s and 'autoblur_mode_v57' not in s,
 'AutoBlur includes multi and motion': 'KAiDirector.blur(this,uri,at,w,h,durationUs)' in s and 'CaptionReview.detectAdaptive(c,u,at,w,h,duration)' in director and 'else startTrack()' in s,
 '3-frame remains physical consensus': 'KAiDirector.blur(this,uri,at,w,h,durationUs)' in s and 'CaptionReview.detectAdaptive(c,u,at,w,h,duration)' in director,
 'android back registered': 'registerOnBackInvokedCallback' in s and 'enableOnBackInvokedCallback="true"' in manifest,
 'back closes region first': 'if(currentPage==EDITOR&&regionMode>0){selectRegion(0);return;}' in s,
 'timeline remains visible during blur': 'timelineSeek.setVisibility(editorFocus||regionMode>0?' not in s,
 'stable player fallback': 'player_stable_v57' in s and 'boolean raw=sourcePlayback()' in s,
 'dual surfaces exist': Path('app/src/main/res/layout/kinera_source_player.xml').exists(),
 'blur handles preserve interactions': 'BlurGestureMath.drag(original,drag,ax,ay,x,y,min)' in r and 'if(mode==2&&drag==5)return false' not in r,
 'app identity and upgrade version': "applicationId 'meteapps.kineraedit'" in gradle and 'versionCode 92' in gradle,
 'no manual templates': '()->openTemplates(' not in s,
 'saved draft mirror retained': 'flip.setChecked(Boolean.parseBoolean(fields[7]))' in s,
 'crop reset invalidates preview': 'recordRegions();invalidatePreview();selectRegion(regionMode);store();saveDraft();' in s,
 'no draft for missing source': 'void saveDraft(){if(source==null||loading)return;' in s,
 'no last project home card': 'add(root,projectCard' not in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
assert all(checks.values()),'v5.9 UI regression detected'
