package az.kinera.edit;
import java.util.*;
final class Precision92Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  ok(Precision92.foreground(0xffe6e0d9)==0xff211e20);ok(Precision92.foreground(0xff19202c)==0xfff7f4ef);
  for(int i=0;i<16;i++)ok(Precision92.thumbnails((i&1)!=0,(i&2)!=0,(i&4)!=0,(i&8)!=0)==(i==1));
  int[] a=new int[2304],b=new int[2304];for(int y=0;y<48;y++)for(int x=0;x<48;x++){int v=(x/3+y/3)%2==0?70:160;int w=Math.round(128+(v-128)*.65f);a[y*48+x]=0xff000000|v*0x10101;b[y*48+x]=0xff000000|w*0x10101;}
  ok(Precision92.sceneScore(a,b,.35f)<.35f);ok(Precision92.sceneScore(a,b,.5f)==.5f);Arrays.fill(b,0xff888888);ok(Precision92.sceneScore(a,b,.35f)==.35f);
  Random rnd=new Random(92);for(int i=0;i<50000;i++){long[] c=DirectorMath.clean(new long[]{rnd.nextInt(3000000),rnd.nextInt(3000000),rnd.nextInt(3000000)},4000000);long p=rnd.nextInt(3000000),o=p-rnd.nextInt(180000),n=p+rnd.nextInt(180000);int f=12+rnd.nextInt(49);ok(Precision92.coherentPair(o,p,n,c,f)==TemporalRestorePolicy.coherentPair(o,p,n,c,f));}
  for(int i=1384;i<1434;i++){ok(RegionMath.active(Precision92TemplatePolicy.window(i)));ok(BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);}
  System.out.println("Precision92: 50,000 pair equivalence checks, thumbnail gating, contrast guard, template colors and 50 windows passed");
 }
}
