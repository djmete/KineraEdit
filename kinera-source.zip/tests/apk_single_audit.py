import sys, zipfile, hashlib, json, pathlib, collections
p,o=map(pathlib.Path,sys.argv[1:]); sha=lambda x:hashlib.sha256(x).hexdigest()
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 entries=[i for i in z.infolist() if not i.is_dir()];assert len({i.filename for i in entries})==len(entries)
 cats=collections.Counter();raw=collections.Counter();hashes={}
 for i in entries:
  n=i.filename;cat='/'.join(n.split('/')[:2]) if n.startswith('lib/') else 'assets' if n.startswith('assets/') else 'dex' if n.endswith('.dex') else 'other';cats[cat]+=i.compress_size;raw[cat]+=i.file_size
  if n.startswith(('assets/','lib/')):hashes[n]=sha(z.read(i))
 assert any(n.startswith('lib/arm64-v8a/') for n in hashes),'Missing ARM64 native libs'
 result=dict(apk_bytes=p.stat().st_size,compressed_by_category=dict(cats),uncompressed_by_category=dict(raw),asset_and_native_sha256=hashes,abis=sorted(k.split('/')[1] for k in cats if k.startswith('lib/')))
 o.write_text(json.dumps(result,indent=2));print('APK bytes:',result['apk_bytes'],'ABIs:',result['abis'])
