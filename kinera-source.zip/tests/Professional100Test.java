package az.kinera.edit;
import java.util.concurrent.*;
final class Professional100Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] a)throws Exception{
 for(int i=1784;i<1834;i++)ok(RegionMath.active(Professional100TemplatePolicy.window(i))&&BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);
 ok(Professional100.ocrEdge(true)==720&&Professional100.ocrEdge(false)==960);ok(Professional100.filmSlots(500,false)==6&&Professional100.filmSlots(800,false)==10&&Professional100.filmSlots(800,true)==0);
 ok(Professional100.accentScale(new long[]{1000000},0,2000000)<.8f);ok(Professional100.accentScale(new long[]{4000000},0,8000000)==1f);DecodeGate87.enter();ExecutorService pool=Executors.newSingleThreadExecutor();try{Future<Boolean> f=pool.submit(()->{try{DecodeGate87.enter(()->false,120);DecodeGate87.leave();return false;}catch(InterruptedException e){return true;}});ok(f.get(2,TimeUnit.SECONDS));Future<Boolean> c=pool.submit(()->{try{DecodeGate87.enter(()->true,1000);DecodeGate87.leave();return false;}catch(InterruptedException e){return true;}});ok(c.get(2,TimeUnit.SECONDS));}finally{DecodeGate87.leave();pool.shutdownNow();}DecodeGate87.enter(()->false,1000);DecodeGate87.leave();
 System.out.println("Professional100: 50 templates, adaptive OCR dimensions, timeline slots, decoder timeout/cancellation passed");}
}
