package az.kinera.edit;
import java.util.*;
final class Adaptive117Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  HashSet<String> seen=new HashSet<>();for(int i=3034;i<3084;i++){float[] w=Adaptive117TemplatePolicy.window(i);ok(RegionMath.active(w)&&seen.add(Arrays.toString(w)));ok(BrandMotionMath.motionKind(i)>=136&&BrandMotionMath.motionKind(i)<146);}
  int layouts=0;for(int w=240;w<=480;w+=20)for(int h=300;h<=1000;h+=20)for(int m=-1;m<=2;m++)for(boolean focus:new boolean[]{false,true})for(float font:new float[]{1,1.3f,1.8f}){ok(!(Adaptive117Workspace.seek(h,m,focus,font)&&Adaptive117Workspace.filmstrip(h,m,focus,font)));ok(m<=0||!Adaptive117Workspace.seek(h,m,focus,font)&&!Adaptive117Workspace.filmstrip(h,m,focus,font));ok(w-48-Adaptive117Workspace.valueWidth(w,font)-2*Adaptive117Workspace.blurPadding(w)>=100);layouts++;}
  ok(Adaptive117FramePlan.eligible(30000000,9000,false));ok(!Adaptive117FramePlan.eligible(30000001,12000,false));ok(!Adaptive117FramePlan.eligible(30000000,8999,false));ok(!Adaptive117FramePlan.eligible(12000000,9000,true));ok(Adaptive117FramePlan.MAX_FRAMES>=900);
  Random r=new Random(117);for(int z=0;z<100;z++){int[] a=new int[2304],b=new int[2304],c=new int[2304];for(int i=0;i<a.length;i++){a[i]=r.nextInt(130);b[i]=a[i]+60;c[i]=r.nextInt(256);}ok(Adaptive117FramePlan.exposureOnly(a,b));ok(!Adaptive117FramePlan.exposureOnly(a,c));ok(Adaptive117FramePlan.blocked(a,b,60/255.));}
  long[] t=new long[899];double[] s=new double[899];boolean[] blocked=new boolean[899];for(int i=0;i<t.length;i++)t[i]=(i+1)*33333L;s[200]=.55;s[400]=.6;s[600]=.55;ok(Precision116FramePlan.merge(new long[0],t,s,blocked,t.length,30000000L,true).length==3);long[] base={t[200]};ok(Precision116FramePlan.merge(base,t,s,blocked,t.length,30000000L,false)==base);blocked[400]=true;ok(Precision116FramePlan.merge(base,t,s,blocked,t.length,30000000L,true).length==2);
  ok(Adaptive117Director.scale(new long[]{1000000},0,2000000)<1);ok(Adaptive117Director.scale(new long[]{5000000},0,10000000)==1);
  float[] center={.2f,.7f,.6f,.8f};float[] region=Adaptive117Caption.review(center,List.of(new float[]{.2f,.69f,.65f,.81f}),3);ok(RegionMath.active(region));ok(region[2]<=.640001f&&region[0]<=center[0]&&region[3]>=center[3]);ok(!RegionMath.active(Adaptive117Caption.review(center,List.of(),3)));
  System.out.println("Adaptive117: 50 compositions, "+layouts+" layout policy cases, 300 exposure decisions, 30s synthetic timeline, caption and accent checks passed");
 }
}
