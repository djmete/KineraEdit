package az.kinera.edit;
import java.nio.file.*;
final class Semantic77Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ExpertTemplatePolicy.TOTAL==984);for(int i=634;i<684;i++){check(RegionMath.active(Semantic77TemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)>=60&&BrandMotionMath.motionKind(i)<78);EditSpec s=new EditSpec("Test",i,720,30,0,0,false,false,false,1000000,0,0,1,1,0,new long[0],false);check(s.template==i&&s.withEncoding(480,24,false).template==i);}
  for(int f=0;f<5;f++)for(int p=0;p<10;p++)check(Semantic77TemplatePolicy.choose(180,new float[]{.56f,.8f,1f,1.77f,2.3f}[f],1,p,11)==634+10*f+p);
  for(int n=0;n<=120;n++){int[] ix=SemanticMotionMath.indices(n);check(ix.length==Math.min(n,40));if(n>0){check(ix[0]==0&&ix[ix.length-1]==n-1);for(int i=1;i<ix.length;i++)check(ix[i]>ix[i-1]);}}
  int[] a=new int[2304],b=new int[2304];java.util.Random rng=new java.util.Random(77);for(int i=0;i<a.length;i++)a[i]=rng.nextInt(256);for(int y=0;y<48;y++)for(int x=0;x<48;x++)b[y*48+x]=a[y*48+Math.floorMod(x-3,48)];double[] z=SemanticMotionMath.features(a,b);check(z[0]>.16&&z[1]<1e-10&&Math.abs(z[0]-z[2])<1e-10);check(SemanticMotionMath.veto(a,b,.3));check(SemanticMotionMath.features(a,null)==null);
  check(SemanticMotionMath.consensus(new int[]{1,2,1})==1&&SemanticMotionMath.consensus(new int[]{1,2,3})==0&&SemanticMotionMath.consensus(new int[]{0,2,0})==2&&SemanticMotionMath.consensus(new int[]{1,0,0})==0);
  double max=0;int n=0;for(String l:Files.readAllLines(Path.of("tests/kai77_motion_parity.csv"))){String[] v=l.split(",");double[] q=new double[8];for(int i=0;i<8;i++)q[i]=Double.parseDouble(v[i]);max=Math.max(max,Math.abs(SemanticMotionConfidence.score(q)-Double.parseDouble(v[8])));n++;}check(n==32&&max<1e-10);
  float[] old=CaptionRegionMath.padded(new float[]{.4f,.7f,.6f,.73f}),now=CaptionRegionMath.adaptivePadding(new float[]{.4f,.7f,.6f,.73f});check(now[0]>old[0]&&now[1]>old[1]&&now[2]<old[2]&&now[3]<old[3]);
  System.out.println("Semantic77Test OK: 50 template IDs, 121 schedules, alignment, consensus, adaptive OCR padding, model parity="+max);
 }
}
