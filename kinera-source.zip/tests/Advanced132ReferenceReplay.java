package az.kinera.edit;
import java.nio.file.*;import java.util.*;
/** Human approximate text bounds with controlled candidate perturbations, not OCR execution. */
public final class Advanced132ReferenceReplay {
 static float area(float[] b){return (b[2]-b[0])*(b[3]-b[1]);}
 static boolean covers(float[] a,float[] b){return RegionMath.active(b)&&b[0]<=a[0]+1e-6&&b[1]<=a[1]+1e-6&&b[2]>=a[2]-1e-6&&b[3]>=a[3]-1e-6;}
 public static void main(String[] args)throws Exception{int n=0,oldC=0,newC=0;double oldEx=0,newEx=0;for(String l:Files.readAllLines(Path.of(args[0])).subList(1,12)){String[] s=l.split(",");float[] a=new float[4];for(int k=0;k<4;k++)a[k]=Float.parseFloat(s[k+2]);for(float dx:new float[]{-.03f,-.012f,0,.012f,.03f})for(float dy:new float[]{-.018f,-.007f,0,.007f,.018f}){float[] b={Math.max(0,a[0]+dx),Math.max(0,a[1]+dy),Math.min(1,a[2]+dx),Math.min(1,a[3]+dy)};float[] p=Supreme131Caption.stabilize(a,b),q=Advanced132Caption.stabilize(a,b);if(covers(a,p))oldC++;if(covers(a,q))newC++;if(RegionMath.active(p))oldEx+=Math.max(0,area(p)/area(a)-1);if(RegionMath.active(q))newEx+=Math.max(0,area(q)/area(a)-1);n++;}}
 if(newC!=n)throw new AssertionError("anchor coverage lost");System.out.printf(Locale.ROOT,"{\"manual_anchor_frames\":11,\"synthetic_candidate_cases\":%d,\"old_anchor_coverage_cases\":%d,\"new_anchor_coverage_cases\":%d,\"old_mean_extra_area_ratio\":%.6f,\"new_mean_extra_area_ratio\":%.6f}%n",n,oldC,newC,oldEx/n,newEx/n);}
}
