import os,subprocess,tempfile,pathlib,json
with tempfile.TemporaryDirectory() as td:
 p=pathlib.Path(td);(p/'archive.log').write_text('SHA256 check mismatch\nlast source log line\n');env=dict(os.environ,KINERA_STEP_OUTCOMES=json.dumps({'archive':'failure','assemble':'skipped','sign':'skipped'}));env.pop('GITHUB_STEP_SUMMARY',None)
 subprocess.run(['python3','tests/ci_diagnostics.py',td],env=env,check=True,capture_output=True);s=(p/'FIRST_ERROR.txt').read_text();assert 'Failed stage(s): archive' in s and 'last source log line' in s and 'SHA256 check mismatch' in s
with tempfile.TemporaryDirectory() as td:
 env=dict(os.environ,KINERA_STEP_OUTCOMES=json.dumps({'setup_gradle':'failure'}));env.pop('GITHUB_STEP_SUMMARY',None);subprocess.run(['python3','tests/ci_diagnostics.py',td],env=env,check=True,capture_output=True);assert 'Failed stage(s): setup_gradle' in (pathlib.Path(td)/'FIRST_ERROR.txt').read_text()
print('CI diagnostics: non-Gradle source failure and setup failure classified')
