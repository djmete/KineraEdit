from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();b=(p/'BrandEffect.java').read_text();a=(p/'KAiDirector.java').read_text();u=(p/'UiLanguage.java').read_text();r=Path('app/src/main/res/values/styles.xml').read_text()
assert 'new android.app.Dialog(this,R.style.KineraHighlightTheme)' in s and 'win.setLayout(-1,-1)' in s and 'WindowInsets.Type.displayCutout()' in s and 'sc.setFillViewport(true)' in s and 'dialog.setOnShowListener' in s and 'freshInstallForHighlight()' in s and 'installedReleaseCode(),ReleaseHighlightPolicy.ID,ReleaseHighlightPolicy.MAJOR' in s
assert 'windowIsFloating">false' in r and 'StringBuilder data=new StringBuilder' in s and 'putString(key,data.toString())' in s
assert 'StableCaptionPlan.SCAN_TIMEOUT_MS' in a and 'StableCaptionPlan.UI_TIMEOUT_MS' in s and 'StableCaptionPlan.build(duration,left,right)' in a
assert 'INTELLIGENT_FRAG' in b and 'cornerFallback' in b and 'cornerUnsupported' in b and 'TimedRegions.fillBoth' in b
assert 'TABLE.put("Daha ağıllı künc bərpası"' in u and 'TABLE.put("Əsas sərhədlər bloklananda OtoBlurPro' in u
print('v85 source integration audit OK: full-screen highlight, insets, latest release, dense scan, corner shader fallback, mask update, localized text')
