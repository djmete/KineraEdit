package az.kinera.edit;
final class Creative101Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] a){int[] count=new int[10];for(int i=1834;i<1984;i++){ok(RegionMath.active(Creative101TemplatePolicy.window(i)));int kind=BrandMotionMath.motionKind(i);if(i>=1884){ok(kind>=126&&kind<136);count[kind-126]++;}else ok(kind>=120&&kind<126);long p=BrandMotionMath.periodUs(i);ok(p>0&&BrandMotionMath.motionPhase(p,i)==0&&BrandMotionMath.motionPhase(p/2,i)>.49f);}for(int n:count)ok(n==10);ok(Creative101.ocrEdge(960,true)==720&&Creative101.ocrEdge(720,false)==720);ok(Creative101.filmSlots(500,false)==4&&Creative101.filmSlots(800,true)==0);System.out.println("Creative101: 150 new templates, 100 animated / 10 new motion families, period and resource rules passed");}
}
