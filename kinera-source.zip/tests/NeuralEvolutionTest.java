package az.kinera.edit;
final class NeuralEvolutionTest {public static void main(String[] a){
 if(EvolutionMath.captionTimes(10,100).length!=1)throw new AssertionError("short");
 if(EvolutionMath.captionTimes(0,3000000).length!=2)throw new AssertionError("edge");
 if(EvolutionMath.captionTimes(1500000,3000000).length!=3)throw new AssertionError("center");
 float[] x={.2f,.6f,.8f,.7f},y={.21f,.61f,.79f,.71f},z={.2f,.85f,.8f,.95f};
 if(!RegionMath.active(EvolutionMath.adaptiveMask(java.util.Arrays.asList(x,y))))throw new AssertionError("consensus");
 if(RegionMath.active(EvolutionMath.adaptiveMask(java.util.Arrays.asList(x,z))))throw new AssertionError("conflict");
 if(!java.util.Arrays.equals(x,EvolutionMath.adaptiveMask(java.util.Collections.singletonList(x))))throw new AssertionError("single");
 for(int[] bounds:new int[][]{{1080,1920},{400,300},{691,514},{691,850}}){int[] d=VisionMath.fit(bounds[0],bounds[1],9f/16);if(d[0]>bounds[0]||d[1]>bounds[1]||Math.abs(d[0]-d[1]*9f/16)>1)throw new AssertionError("ratio");}
 System.out.println("NeuralEvolutionTest OK");}}
