package az.kinera.edit;
import java.util.*;import java.nio.file.*;
final class Professional63Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ProfessionalCaptionPlan.windows(180000000)==62);check(ProfessionalCaptionPlan.windows(2000000)==4);check(ProfessionalCaptionPlan.windows(0)==0);
  float[] a={.2f,.76f,.8f,.83f},b={.2f,.92f,.8f,.98f};List<TimedRegions.Mask> masks=ProfessionalCaptionPlan.build(62000000,Collections.nCopies(62,a),Collections.nCopies(62,b));check(masks.size()==124&&FullCaptionPlan.covered(masks)==62000000);float[] out=new float[12];TimedRegions.fill(masks,61999999,out);check(out[1]==b[1]);
  for(int i=162;i<210;i++){EditSpec s=new EditSpec("Test",i,720,30,0,0,false,false,false,1000000,0,0,1,1,0,new long[0],false);check(s.template==i&&s.withHeight(480).template==i&&s.withEncoding(480,24,false).template==i);}
  for(int i=204;i<210;i++){check(RegionMath.active(ProfessionalTemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)==60+i-204);}
  double max=0;int rows=0;for(String line:Files.readAllLines(Path.of("tests/kai63_spatial_parity.csv"))){String[] v=line.split(",");double[] x=new double[6];for(int i=0;i<6;i++)x[i]=Double.parseDouble(v[i]);max=Math.max(max,Math.abs(ProfessionalRestoreConfidence.blend(x)-Double.parseDouble(v[6])));rows++;}check(rows==32&&max<1e-9);check(!ProfessionalRestoreConfidence.ENABLED);System.out.println("Professional63Test OK: 124 masks, template IDs 162..209, candidate parity "+max);
 }
}
