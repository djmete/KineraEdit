from pathlib import Path
import re
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();a=(p/'TemplateArt.java').read_text();b=(p/'BrandEffect.java').read_text();g=Path('app/build.gradle').read_text()
for key in ['NAMES','BG','ACC']:
 vals=re.search(r'\b'+key+r'=\{([^\n]+)\};',a).group(1).split(',');assert len(vals)==1034,key
assert all(k in s for k in ['appearance_v79','this::chooseAppearance','R.style.AmoledTheme','appearance_settings','closeResultPlayer();','new PlayerView(this)'])
assert 'TextureRestoreConfidence.ENABLED?PROFESSIONAL_FRAG:HISTORY_FRAG' in b and 'historySpec==active&&historyTime==time' in b
assert 'versionCode 95' in g and "applicationId 'meteapps.kineraedit'" in g and 'minifyEnabled false' in g and 'abiFilters' not in g
print('v79 source integration audit OK: 1034 template entries in all arrays, theme wiring, result lifecycle, shader fallback, universal build')
