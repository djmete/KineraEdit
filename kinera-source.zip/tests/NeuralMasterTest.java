package az.kinera.edit;
public final class NeuralMasterTest {
 static void check(boolean x){if(!x)throw new AssertionError("master regression");}
 public static void main(String[] args){
  for(int i=90;i<114;i++){check(BrandMotionMath.motionKind(i)>=42&&BrandMotionMath.motionKind(i)<48);check(BrandMotionMath.periodUs(i)>0);}
  for(int i=-500;i<500;i++)for(float a:new float[]{.5f,.75f,1.5f}){int t=PrecisionMath.masterTemplate(28,a,i);check(t>=0&&t<114);check(t==PrecisionMath.masterTemplate(28,a,i));}
  int w=96,h=96;int[] a=new int[w*h],b=new int[w*h];java.util.Random rnd=new java.util.Random(54);for(int i=0;i<a.length;i++)a[i]=0xff000000|rnd.nextInt(0x1000000);for(int y=0;y<h-3;y++)for(int x=0;x<w-4;x++)b[(y+3)*w+x+4]=a[y*w+x];float[] r={.25f,.25f,.55f,.55f};MotionTrackMath.Match m=MotionTrackMath.match(a,b,w,h,r);check(m!=null&&Math.abs(m.rect[0]-r[0]-4f/w)<.001&&Math.abs(m.rect[1]-r[1]-3f/h)<.001);check(MotionTrackMath.match(new int[w*h],b,w,h,r)==null);
  AudioLevelMath.Meter quiet=new AudioLevelMath.Meter(),burst=new AudioLevelMath.Meter();for(int i=0;i<8192;i++){quiet.add(.01f);burst.add(i<512?.25f:.01f);}check(burst.gain()<quiet.gain());System.out.println("NeuralMasterTest OK");
 }
}
