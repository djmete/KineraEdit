package az.kinera.edit;
import java.util.*;
final class Contextual91Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  ProductionMath.History h=new ProductionMath.History();float[] empty=RegionMath.empty(),full=RegionMath.full(),box={.1f,.6f,.8f,.9f};
  ProductionMath.Regions clean=new ProductionMath.Regions(full,empty,0,1000000L,List.of(),new int[]{1},new long[0]);
  ProductionMath.Regions manual=new ProductionMath.Regions(full,box,0,1000000L,List.of(),new int[]{2},new long[0]);
  ProductionMath.Regions restore=new ProductionMath.Regions(full,empty,0,1000000L,List.of(new TimedRegions.Mask(box,0,1000000,true)),new int[]{2},new long[0]);
  h.reset(clean);h.push(manual);h.push(restore);ok(h.undo().same(manual));ok(h.undo().same(clean));ok(h.canRedo());h.push(clean);ok(h.canRedo());ok(h.redo().same(manual));ok(h.redo().same(restore));h.undo();h.push(clean);ok(!h.canRedo());h.reset(clean);ok(!h.canUndo()&&!h.canRedo());
  for(int i=1334;i<1384;i++){ok(RegionMath.active(Contextual91TemplatePolicy.window(i)));ok(BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);}
  int[] a=new int[2304],b=new int[2304];for(int y=0;y<48;y++)for(int x=0;x<48;x++){int v=(x/3%2==0?65:145);a[y*48+x]=0xff000000|(v<<16)|(v<<8)|v;b[y*48+x]=0xff000000|((v+20)<<16)|(v<<8)|(v-20);}ok(Contextual91.sceneScore(a,b,.32f)<.32f);ok(Contextual91.sceneScore(a,b,.50f)==.50f);Arrays.fill(b,0xff808080);ok(Contextual91.sceneScore(a,b,.32f)==.32f);
  System.out.println("Contextual91: manual and Pro mask history, no-op redo, 50 templates and chroma guard passed");
 }
}
