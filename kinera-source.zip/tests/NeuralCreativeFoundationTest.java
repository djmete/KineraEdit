package az.kinera.edit;
public class NeuralCreativeFoundationTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
 check(OutputFolder.contains("Movies/Kinera Edit/"));check(!OutputFolder.contains("Movies/"));check(!OutputFolder.contains("Download/Kinera Edit/"));check(!OutputFolder.contains("Movies/Kinera Edit/Other/"));
 check(PreviewRecovery.previewHeight(960,0)==960);check(PreviewRecovery.previewHeight(960,1)==480);check(PreviewRecovery.previewHeight(480,2)==480);
 int[] p=new int[320];java.util.Arrays.fill(p,0,192,0xff000000);java.util.Arrays.fill(p,192,320,0xff29a24a);check(KineraAI.paletteFor(p)==30);
 System.out.println("NeuralCreativeFoundationTest: folder scope, recovery resolution, dark-frame palette passed");
 }
}
