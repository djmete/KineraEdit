package az.kinera.edit;
public final class MotionTest {public static void main(String[] a){
 if(BrandMotionMath.phase(0)!=0f||BrandMotionMath.phase(6000000)!=0f||BrandMotionMath.phase(-1)<0f)throw new AssertionError("phase");
 if(BrandMotionMath.styleFor(new int[]{0xff2020aa})!=29||BrandMotionMath.styleFor(new int[]{0xff20aa20})!=30||BrandMotionMath.styleFor(new int[]{0xffaa2020})!=32||BrandMotionMath.styleFor(new int[]{0xff555555})!=33||BrandMotionMath.styleFor(null)!=0)throw new AssertionError("palette");
 System.out.println("PASS: motion phase and editorial palette selection");}}
