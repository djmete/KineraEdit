from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit'); a=(p/'AutoPlan.java').read_text(); q=(p/'SequentialCutReader.java').read_text(); s=(p/'MainActivity.java').read_text(); t=(p/'TemplateArt.java').read_text()
assert a.count('Precision116Scene.guard(')==2 and 'SequentialCutReader.wholeShort(' in a
assert 'complete=last>=duration-200000L' in q and 'Precision116FramePlan.merge(' in q and 'codec.releaseOutputBuffer(ix,false)' in q
assert 'blurAdjustPanel.setVisibility(regionMode==2?View.VISIBLE:View.GONE)' in s and 'pendingBlurStrength=-1;MotionEvent cancelled' in s
assert 'Precision116Workspace.previewHeight(' in s and 'Precision116TemplatePolicy.window(style)' in t
assert 'versionCode 127' in Path('app/build.gradle').read_text()
print('Precision116 source wiring: complete-EOS gate, bounded sequential decode, live blur rollback, focus controls and template paths; Android runtime unverified')
