package az.kinera.edit;
public final class DeepCreativeIntelligenceTest {
 static void check(boolean value){if(!value)throw new AssertionError();}
 public static void main(String[] args){
  check(PreviewRecovery.next(0,false)==PreviewRecovery.RETRY);
  check(PreviewRecovery.next(1,false)==PreviewRecovery.RAW);
  check(PreviewRecovery.next(1,true)==PreviewRecovery.RETRY);
  check(PreviewRecovery.next(2,true)==PreviewRecovery.STOP);
  check(PreviewRecovery.next(2,false)==PreviewRecovery.STOP);
  check(CutConfidence.accept(.82f,.08f,.13f));check(!CutConfidence.accept(.82f,.51f,.79f));check(!CutConfidence.accept(Float.NaN,0,0));
  check(KineraAI.refinedCut(300,new long[]{210,260,310,360},new float[]{.05f,.68f,.06f,.10f})==260);
  check(KineraAI.refinedCut(300,new long[]{210,260,310,360},new float[]{.44f,.48f,.46f,.40f})==300);
  check(KineraAI.refinedCut(300,new long[]{210,260},new float[]{.05f,.68f})==300);
  check(SceneMath.zoom(2000000,new long[]{2000000})==1f);
  check(SceneMath.zoom(2180000,new long[]{2000000})>1.03f);
  check(SceneMath.zoom(2360000,new long[]{2000000})==1f);
  int[] palette=new int[64*5];java.util.Arrays.fill(palette,0,64*3,0xff29a24a);java.util.Arrays.fill(palette,64*3,64*5,0xffe73924);check(KineraAI.paletteFor(palette)==30);
  System.out.println("DeepCreativeIntelligenceTest: retry limits, learned confidence, cut refinement, smooth transition passed");
 }
}