package az.kinera.edit;
import java.nio.file.*;import java.util.*;
final class Autonomous50Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
 float[] r={.1f,.6f,.9f,.7f};check(!RegionMath.active(EvolutionMath.reviewedMask(Collections.singletonList(r),3)));check(RegionMath.active(EvolutionMath.reviewedMask(Collections.singletonList(r),1)));check(RegionMath.active(EvolutionMath.reviewedMask(Arrays.asList(r,r),3)));check(!RegionMath.active(EvolutionMath.reviewedMask(Arrays.asList(null,r),2)));
 AudioLevelMath.Meter a=new AudioLevelMath.Meter();for(int i=0;i<4096;i++)a.add(.01f);check(AudioLevelMath.completedGain(new AudioLevelMath.Meter[]{a},1)==AudioLevelMath.AUTO_FALLBACK);a.complete=true;check(AudioLevelMath.completedGain(new AudioLevelMath.Meter[]{a},1)==20);
 check(DirectorMath.nearest(null,0)==-1);check(DirectorMath.visual(new long[]{1000000},2000000,2000000,.1f)==0);check(DirectorMath.zoom(null,1000000,2000000,.1f,false)==1);check(DirectorMath.sound(null,0,2000000)==0);
 int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai50_appearance_parity.csv"))){if(line.startsWith("f0,"))continue;String[] x=line.split(",");double[] f=new double[6];for(int i=0;i<6;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(ReacquireConfidence.probability(f)-Double.parseDouble(x[6])));n++;}check(n==32&&max<1e-8);check(!ReacquireConfidence.ENABLED);System.out.println("Autonomous50Test OK: 32 parity rows; max error="+max);
 }
}
