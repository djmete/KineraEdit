package az.kinera.edit;
import java.nio.file.*;
import java.util.Arrays;
final class Advanced49Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(CreativePolicy.significantFace(20,20,75,75,100,100));check(!CreativePolicy.significantFace(0,0,10,10,100,100));check(!CreativePolicy.significantFace(-100,-100,0,0,100,100));check(!CreativePolicy.significantFace(0,0,100,100,0,100));
  int[] a=new int[64],b=new int[64],bright=new int[64];for(int i=0;i<64;i++){a[i]=(i%2==0?0xffff0000:0xff002200);b[i]=(i%2==0?0xff003399:0xffffff00);bright[i]=(i%2==0?0xffff2222:0xff224422);}
  check(AppearanceGuard.agrees(a,a,8,8,RegionMath.full(),RegionMath.full()));check(AppearanceGuard.agrees(a,bright,8,8,RegionMath.full(),RegionMath.full()));check(!AppearanceGuard.agrees(a,b,8,8,RegionMath.full(),RegionMath.full()));check(!AppearanceGuard.agrees(a,b,8,8,null,RegionMath.full()));
  PlaybackWatchdog watch=new PlaybackWatchdog();watch.stalled(0,0,true,true);watch.stalled(500,1,true,true);watch.stalled(1000,2,true,true);watch.stalled(4100,3,true,true);check(!watch.stable(4100));for(int i=4600;i<=7100;i+=500)watch.stalled(i,i,true,true);check(watch.stable(7100));
  int count=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai49_appearance_parity.csv"))){if(line.startsWith("f0,"))continue;String[] x=line.split(",");double[] f=new double[6];for(int i=0;i<6;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(AppearanceConfidence.probability(f)-Double.parseDouble(x[6])));count++;}check(count==32&&max<1e-8);check(!AppearanceConfidence.ENABLED);check(AppearanceConfidence.probability(new double[]{Double.NaN,0,0,0,0,0})==0);
  System.out.println("Advanced49Test OK: 32 parity rows; max error="+max);
 }
}
