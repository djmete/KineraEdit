package az.kinera.edit;
final class Cinematic98Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
 for(int a=0;a<=1000;a++)for(int b=0;b<=1000;b+=10){int gain=AudioLevelMath.recommend(a/1000.,b/1000.,48000);ok(gain>=5&&gain<=20);}
 ok(AudioLevelMath.recommend(.08,.4,48000)>=15);ok(AudioLevelMath.recommend(.22,.6,48000)>=10&&AudioLevelMath.recommend(.22,.6,48000)<=15);ok(AudioLevelMath.recommend(.45,.98,48000)>=5&&AudioLevelMath.recommend(.45,.98,48000)<=10);
 AudioLevelMath.Meter quiet=new AudioLevelMath.Meter(),loud=new AudioLevelMath.Meter();for(int i=0;i<8192;i++){quiet.add(.08f);loud.add(.60f);}quiet.complete=true;loud.complete=true;ok(quiet.gain()>=15&&loud.gain()==5);ok(AudioLevelMath.completedGain(new AudioLevelMath.Meter[]{quiet,loud},2)==5);ok(AudioLevelMath.completedGain(new AudioLevelMath.Meter[]{quiet},2)==10);
 ok(AudioLevelMath.recommend(.01,1,48000)==15);ok(AudioLevelMath.restoredGain(1,true,true,108)==10);ok(AudioLevelMath.restoredGain(1,false,true,108)==1);ok(AudioLevelMath.restoredGain(0,true,true,109)==0);ok(!AudioLevelMath.currentGain(1,true,109));ok(AudioLevelMath.currentGain(20,true,109));
 ok(Cinematic98.zoomScale(new long[]{10000000},0,20000000)<.75f);ok(Cinematic98.zoomScale(new long[]{16000000},0,32000000)==1f);
 for(int i=1684;i<1734;i++)ok(RegionMath.active(Cinematic98TemplatePolicy.window(i))&&BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);
 System.out.println("Cinematic98: 101101 gain bounds, loudness bands, partial coverage, 50 template layouts passed");}
}
