package az.kinera.edit;
import java.nio.file.*;
import java.util.Arrays;
final class Creative48Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(CreativePolicy.category("Portrait",.90f)==CreativePolicy.PERSON);check(CreativePolicy.category("Portrait",.6f)==0);check(CreativePolicy.category("landscape",Float.NaN)==0);check(CreativePolicy.category(null,1)==0);
  check(CreativePolicy.choose(66,.56f,1)==126);check(CreativePolicy.choose(72,1.77f,2)==132);check(CreativePolicy.choose(88,.8f,0)==88);check(CreativePolicy.choose(72,Float.NaN,2)==72);check(CreativePolicy.choose(90,.5f,3)==130);
  check(CreativePolicy.nextTrackTime(900000,500000,0,1000000,48000000)==999999);check(CreativePolicy.nextTrackTime(999999,500000,0,1000000,48000000)==-1);check(CreativePolicy.nextTrackTime(47500000,2000000,0,90000000,48000000)==48000000);check(CreativePolicy.nextTrackTime(48000000,2000000,0,90000000,48000000)==-1);
  int[] pixels=new int[192];Arrays.fill(pixels,0xffff0000);int[] grade={50,50,54};check(ChromaGuard.addedClipping(pixels,grade)>.9);check(ChromaGuard.guard(pixels,grade)[2]==50);int[] grey=new int[192];Arrays.fill(grey,0xff808080);check(ChromaGuard.guard(grey,new int[]{50,50,54})[2]==54);check(ChromaGuard.guard(null,new int[]{50,50,54})[2]==54);
  int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai48_chroma_parity.csv"))){if(line.startsWith("f0,"))continue;String[] x=line.split(",");double[] f=new double[8];for(int i=0;i<8;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(ChromaRisk.probability(f)-Double.parseDouble(x[8])));n++;}check(n==32&&max<1e-8);
  System.out.println("Creative48Test OK: 32 parity rows, max error="+max);
 }
}
