#!/usr/bin/env bash
set -euo pipefail
# Download actual POMs (GET, not HEAD); log HTTP status and curl diagnostics.
# This checks network availability, not the entire Gradle dependency graph.
coordinates=(org/jetbrains/kotlin/kotlin-stdlib-jdk8/1.9.20/kotlin-stdlib-jdk8-1.9.20.pom org/apache/httpcomponents/httpmime/4.5.6/httpmime-4.5.6.pom commons-io/commons-io/2.13.0/commons-io-2.13.0.pom org/ow2/asm/asm/9.6/asm-9.6.pom org/ow2/asm/asm-analysis/9.6/asm-analysis-9.6.pom org/ow2/asm/asm-commons/9.6/asm-commons-9.6.pom org/ow2/asm/asm-util/9.6/asm-util-9.6.pom org/bouncycastle/bcpkix-jdk18on/1.77/bcpkix-jdk18on-1.77.pom)
probe(){ local url=$1; printf 'GET %s\n' "$url"; curl --fail --location --silent --show-error --proto '=https' --proto-redir '=https' --connect-timeout 12 --max-time 35 --retry 2 --retry-delay 2 --retry-max-time 70 --output /dev/null --write-out 'HTTP %{http_code}, remote %{remote_ip}, time %{time_total}s\n' "$url"; }
central(){ local base=$1; local c; for c in "${coordinates[@]}"; do probe "$base/$c" || return 1; done; }
if central https://repo.maven.apache.org/maven2; then endpoint=apache; elif central https://repo1.maven.org/maven2; then endpoint=repo1; else echo '::error::Both official Maven Central endpoints failed. Inspect HTTP/DNS/TLS details above; do not change signing keys or library versions.'; exit 1; fi
printf 'KINERA_CENTRAL_ENDPOINT=%s\n' "$endpoint" >> "${GITHUB_ENV:?GITHUB_ENV required}"
probe https://dl.google.com/dl/android/maven2/com/android/tools/build/gradle/8.7.3/gradle-8.7.3.pom
printf 'Maven preflight passed: %s\n' "$endpoint"
