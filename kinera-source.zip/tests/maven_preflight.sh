#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' 'Cache-first CI: no external POM probes; Gradle reports actual resolution failures.'
printf 'KINERA_CENTRAL_ENDPOINT=apache\n' >> "${GITHUB_ENV:?GITHUB_ENV required}"
