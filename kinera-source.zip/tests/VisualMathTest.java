package az.kinera.edit;
import java.util.Arrays;
public final class VisualMathTest {
 static void eq(int[] got,int... want){if(!Arrays.equals(got,want))throw new AssertionError(Arrays.toString(got));}
 public static void main(String[] args){
  eq(VisualMath.centerCrop(160,90,80,80),35,0,125,90);
  eq(VisualMath.centerCrop(90,160,80,80),0,35,90,125);
  eq(VisualMath.centerCrop(160,90,160,90),0,0,160,90);
  eq(VisualMath.centerCrop(90,160,0,80),0,0,90,160);
  eq(VisualMath.centerCrop(1,1,100,1),0,0,1,1);
  for(int width:new int[]{240,320,360,411,600,1000})for(int cols:new int[]{2,3}){int h=VisualMath.galleryHeight(width,cols);if(h<92||h>220)throw new AssertionError("tile height");}
  if(VisualMath.galleryHeight(411,2)<=VisualMath.galleryHeight(411,3))throw new AssertionError("tile columns");
  if(VisualMath.thumbnailCacheBytes(64)!=4*1024*1024||VisualMath.thumbnailCacheBytes(1024)!=16*1024*1024)throw new AssertionError("cache bounds");
  if(VisualMath.readableToolWidth(160,32,92)!=192||VisualMath.readableToolWidth(10,32,92)!=92||VisualMath.readableToolHeight(54,48,76)!=102)throw new AssertionError("tool size");
  if(VisualMath.timelineHeight(520)!=40||VisualMath.timelineHeight(700)!=48||VisualMath.timelineHeight(850)!=54)throw new AssertionError("responsive timeline");
  System.out.println("VisualMathTest passed (including responsive timeline)");
 }
}
