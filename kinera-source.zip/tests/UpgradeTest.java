package az.kinera.edit;
public class UpgradeTest { public static void main(String[] args){
 if(EditMath.widthForHeight(2560)!=1440||EditMath.widthForHeight(3840)!=2160)throw new AssertionError("UHD dimensions");
 if(!EditMath.matchesDimensions(2160,3840,3840)||EditMath.matchesDimensions(1080,1920,3840))throw new AssertionError("exact output");
 if(EditMath.bitrate(3840,30,2)<=EditMath.bitrate(1920,30,2)||EditMath.bitrate(3840,60,2)>100000000)throw new AssertionError("bitrate");
 if(EditMath.progress(-1,100)!=0||EditMath.progress(50,100)!=.5f||EditMath.progress(110,100)!=1||EditMath.progress(1,0)!=0)throw new AssertionError("progress animation");
 EditSpec s=new EditSpec("BayEfendiFilm",0,3840,60,0,0,false,true,true,100000000,0,0,1,1,.12f,new long[]{1000000},false,true);
 if(!s.withHeight(854).animated||s.withHeight(854).width!=480||s.width!=2160)throw new AssertionError("preview consistency");
 System.out.println("PASS: 2K/4K dimensions, strict export size, bitrate, progress animation, preview settings");
}}
