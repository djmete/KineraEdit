package az.kinera.edit;
import java.util.*;
final class Temporal97Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
 int[] hs={1280,1920,2560,3840,1280,1280,1280};for(int i=0;i<hs.length;i++){ok(Temporal97.height(i)==hs[i]);for(int f:new int[]{15,24,25,30})for(int[] a:Reconstruction96.fallbacks(hs[i],f))ok(a[0]==hs[i]&&a[1]<f);}
 ok(Temporal97.height(-1)==1920&&Temporal97.height(7)==1920);ok(Temporal97.historySafe(3,false,921600));ok(!Temporal97.historySafe(4,false,921600));ok(!Temporal97.historySafe(2,true,2073600));
 List<TimedRegions.Mask> list=new ArrayList<>();for(int i=0;i<5;i++)list.add(new TimedRegions.Mask(new float[]{.1f,.2f,.4f,.3f},i*10,100+i*10,true));MaskTimeline87 idx=new MaskTimeline87(list);for(int t=-1;t<151;t++){int n=0;for(TimedRegions.Mask m:list)if(t>=m.from&&t<m.until)n++;ok(idx.activeCount(t)==n);ok(idx.fill(t,new float[12],new float[3])==n);}ok(!Temporal97.historySafe(idx.activeCount(50),false,640000));
 ok(Temporal97.accentScale(new long[]{1000000,1500000},0,5000000)<.6f);ok(Temporal97.accentScale(new long[]{4000000},0,8000000)==1f);
 ok(Temporal97.safeUnion(new float[]{.2f,.7f,.8f,.75f},new float[]{.22f,.71f,.8f,.76f}));for(int i=1634;i<1684;i++)ok(RegionMath.active(Temporal97TemplatePolicy.window(i))&&BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);
 System.out.println("Temporal97: HD-only migration, exact resolution fallback, mask overflow history guard, restrained shot accents, 50 layouts passed");}
}
