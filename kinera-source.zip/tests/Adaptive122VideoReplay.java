package az.kinera.edit;
import java.nio.file.*;import java.util.*;
/** Desktop luma replay of real encoded input; Android decoder and OCR not exercised. */
public final class Adaptive122VideoReplay {
 public static void main(String[] args)throws Exception{byte[] raw=Files.readAllBytes(Path.of(args[0]));int frames=raw.length/2304;if(raw.length%2304!=0||frames<6)throw new IllegalArgumentException("bad raw frames");long step=Long.parseLong(args[1]),duration=frames*step;int n=frames-1;long[] pts=new long[n];double[] scores=new double[n];boolean[] old=new boolean[n],now=new boolean[n];int[] prev=null,older=null;int localized=0;
 for(int f=0;f<frames;f++){int[] y=new int[2304];for(int k=0;k<2304;k++)y[k]=raw[f*2304+k]&255;if(prev!=null){int i=f-1;double d=Precision116FramePlan.delta(prev,y);pts[i]=f*step;scores[i]=d;old[i]=Visual121Scene.blocked(prev,y,d);now[i]=Adaptive122Scene.blocked(prev,y,d);if(now[i]&&!old[i])localized++;if(i>0&&Precision116FramePlan.pulse(older,prev,y,scores[i-1],d)){old[i-1]=old[i]=now[i-1]=now[i]=true;}}older=prev;prev=y;}
 long[] before=Precision116FramePlan.merge(new long[0],pts,scores,old,n,duration,true),after=Precision116FramePlan.merge(new long[0],pts,scores,now,n,duration,true);System.out.println("{\"frames\":"+frames+",\"pairs\":"+n+",\"localized_vetoes_added\":"+localized+",\"old_policy_markers_us\":"+Arrays.toString(before)+",\"new_policy_markers_us\":"+Arrays.toString(after)+",\"complete\":true}");}
}
