package az.kinera.edit;
import java.util.Arrays;
public final class NeuralFusionTest {
 static void check(boolean ok){if(!ok)throw new AssertionError("v5.8 regression");}
 public static void main(String[] args){
  float[] crop={.1f,.1f,.9f,.9f},mask={.16f,.30f,.37f,.46f};
  float[] normal=PrecisionMath.toLocal(mask,crop,false),mirror=PrecisionMath.toLocal(mask,crop,true);
  check(Math.abs(normal[0]+mirror[2]-1)<.0001f);check(Math.abs(normal[2]+mirror[0]-1)<.0001f);
  float[] back=PrecisionMath.toSource(mirror,crop,true);for(int i=0;i<4;i++)check(Math.abs(back[i]-mask[i])<.0001f);
  check(!RegionMath.active(RegionMath.pinch(null,1,0,0)));check(Arrays.equals(mask,RegionMath.pinch(mask,1,Float.NaN,0)));
  check(PrecisionMath.overlap(mask,null)==0);check(!RegionMath.active(PrecisionMath.consensus(null)));
  check(RegionMath.active(PrecisionMath.consensus(Arrays.asList(null,mask,mask))));
  check(KineraAI.editorialCuts(null,null,100).length==0);check(KineraAI.editorialCuts(new long[]{1},new float[0],100).length==0);
  System.out.println("NeuralFusionTest OK: asymmetric mirrored mask, invalid regions, invalid scene input");
 }
}
