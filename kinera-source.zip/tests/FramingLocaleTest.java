package az.kinera.edit;
public final class FramingLocaleTest {
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);}
 static void near(float a,float b){check(Math.abs(a-b)<.0001f,a+" != "+b);}
 public static void main(String[] args){
  float[] window={.025f,.14f,.975f,.79f};float canvas=9f/16;
  for(float aspect:new float[]{.5625f,.75f,1f,1.3333f,1.7778f,2.4f})for(float[] crop:new float[][]{{0,0,1,1},{.1f,.15f,.85f,.9f}}){
   float[] r=EditMath.coverCrop(crop,window,aspect,canvas);
   check(r[0]>=crop[0]-.00001f&&r[1]>=crop[1]-.00001f&&r[2]<=crop[2]+.00001f&&r[3]<=crop[3]+.00001f,"bounds");
   near((r[2]-r[0])*aspect/(r[3]-r[1]),(window[2]-window[0])*canvas/(window[3]-window[1]));
   near((r[0]+r[2])/2,(crop[0]+crop[2])/2);near((r[1]+r[3])/2,(crop[1]+crop[3])/2);
  }
  check(UiLanguage.resolve("system","tr-TR").equals("tr"),"system");check(UiLanguage.resolve("system","fr").equals("en"),"fallback");check(UiLanguage.resolve("ru","az").equals("ru"),"manual");
  UiLanguage.set("en","az");check(UiLanguage.tr("Qalereya").equals("Gallery"),"English");UiLanguage.set("ru","az");check(UiLanguage.tr("Qalereya").equals("Галерея"),"Russian");UiLanguage.set("tr","az");check(UiLanguage.tr("Qalereya").equals("Galeri"),"Turkish");UiLanguage.set("az","en");check(UiLanguage.tr("Qalereya").equals("Qalereya"),"Azerbaijani");
  System.out.println("PASS: 12 center-cover geometry cases, language preference, fallback and four translations");
 }
}
