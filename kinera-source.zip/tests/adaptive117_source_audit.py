from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit'); a=(p/'AutoPlan.java').read_text(); q=(p/'SequentialCutReader.java').read_text(); s=(p/'MainActivity.java').read_text(); t=(p/'TemplateArt.java').read_text(); d=(p/'DirectorMath.java').read_text()
assert 'Cinematic118FramePlan.eligible(' in a and 'Cinematic118FramePlan.budget(duration)' in q and 'Cinematic118FramePlan.blocked(prev,y,d)' in q
assert 'complete=last>=duration-200000L' in q and 'Precision116FramePlan.merge(' in q
assert 'Cinematic118Workspace.sliderPadding(' in s and 'Cinematic118Workspace.liveTick(' in s and 'Adaptive117TemplatePolicy.window(style)' in t
assert 'Adaptive117Director.scale(cuts,i,duration)' in d and 'Adaptive117Caption.review(' in (p/'CaptionReview.java').read_text()
assert 'versionCode 129' in Path('app/build.gradle').read_text()
print('Adaptive117 source integration audit passed; device runtime not checked')
