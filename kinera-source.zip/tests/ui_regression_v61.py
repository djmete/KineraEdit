from pathlib import Path
s=Path('app/src/main/java/az/kinera/edit/MainActivity.java').read_text()
l=Path('app/src/main/java/az/kinera/edit/UiLanguage.java').read_text()
checks={
 'exit prompt home and setup': 'case HOME: confirmExit();' in s and 'if(firstSetup)confirmExit()' in s,
 'exit confirmation localized': all('TABLE.put("'+x+'"' in l for x in ['Proqramdan çıxmaq istəyirsiniz?','Xeyr','Bəli, çıx']),
 'blur panel responsive widths': 'heading.addView(durationButton,new LinearLayout.LayoutParams(0,dp(44),1))' in s,
 'fixed blur strip outside scroll': 'buildBlurAdjust(editorDock)' in s and 'adjustments=new ScrollView' not in s,
 'auto grade on new source': 'if(!restoreRequested){bright.setProgress(grade[0])' in s,
 'grade persisted per draft': 'draftKey(u)+":bright"' in s and 'putInt(key+":bright"' in s,
 'auto audio deferred to export': 'autoAudio=!restoreRequested' in s and 'autoAudio&&!autoAudioMeasured,audioPercent' in s and 'automatic audio measured during export' in s,
 'blur text localized': all('TABLE.put("'+x+'"' in l for x in ['Bulanıqlaşdırma','Vaxt','Güc','Sahələr']),
 'tracking status translated': 'UiLanguage.tr("OtoBlurPro • izlənir…")' in s,
 'no disallowed home shortcuts': 'add(root,projectCard' not in s and '()->openTemplates(' not in s and '()->showPage(QUEUE)' not in s,
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+': '+k)
assert all(checks.values())
