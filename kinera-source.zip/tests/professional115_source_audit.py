from pathlib import Path
import re
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();a=(p/'TemplateArt.java').read_text();d=(p/'KAiDirector.java').read_text();ocr=(p/'CaptionReview.java').read_text();g=(p/'DirectorMath.java').read_text()
assert 'chooser.addView(blurAdjust,new LinearLayout.LayoutParams(0,dp(48),1f))' in s
assert 'blurAdjustPanel.addView(blurAdjust' not in s
assert 'pendingBlurStrength=-1;MotionEvent cancelled' in s
assert 'Precision116Workspace.liveTick(lastLiveBlur,now,playing,blurPressure)' in s
assert 'blurPressure=DeviceLoad87.pressure(MainActivity.this)' in s
assert 'new PlayerView[]{composedPlayerView,sourcePlayerView}' in s and 'surface.getPlayer()==previous' in s
assert 'Precision116Caption.review(centerMask,candidates,times.length)' in ocr
assert 'Professional115TemplatePolicy.choose(' in d and 'Professional115TemplatePolicy.window(style)' in a
assert g.count('Professional115Director.continuity(')==3
assert 'Precision116Workspace.seek(' in s and 'Precision116Workspace.filmstrip(' in s
assert '0.9.1 Stable' in Path('app/build.gradle').read_text()
print('v126 source audit: persistent one-row blur, multi-touch cancellation, pressure cadence, dual surface detach, requested-frame OCR anchor, 50 appended template paths, transition continuity and version wiring')
