package az.kinera.edit;
import java.nio.file.*;
final class Dynamic57Test {
 public static void main(String[] a)throws Exception{int n=0;double max=0;for(String l:Files.readAllLines(Path.of("tests/kai57_diagonal_parity.csv"))){if(l.startsWith("f0,"))continue;String[] x=l.split(",");double[] f=new double[4];for(int i=0;i<4;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(DiagonalRestoreConfidence.blend(f)-Double.parseDouble(x[4])));n++;}if(n!=32||max>1e-8||!DiagonalRestoreConfidence.ENABLED||TemporalRestorePolicy.eligible(0,1000,null))throw new AssertionError();System.out.println("Dynamic57Test OK: 32 parity rows, null cut safety, max error="+max);}
}
