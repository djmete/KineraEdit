package az.kinera.edit;
public final class NeuralProductionArchitectureTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
 check(KineraAI.VERSION.equals("9.1"));
 check(!RegionMath.active(new float[]{Float.NaN,0,1,1}));check(!RegionMath.active(new float[]{0,0,1.01f,1}));
 check(RegionMath.active(CaptionRegionMath.include(RegionMath.empty(),.2f,.9f,.8f,1.005f)));
 long[] t={1000000,2000000,3000000,4000000,5000000,6000000,7000000};float[] s={.01f,.51f,.01f,.85f,.01f,.01f,.01f};long[] cuts=KineraAI.editorialCuts(t,s,9000000);check(cuts.length==1&&cuts[0]==4000000);
 System.out.println("NeuralProductionArchitectureTest: strongest editorial cut, region bounds, version passed");
 }
}
