package az.kinera.edit;
import java.util.*;import java.nio.file.*;
final class Hyper54Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
 float[] r={.1f,.5f,.9f,.6f};TimedRegions.Mask normal=new TimedRegions.Mask(r,0,10);TimedRegions.Mask pro=new TimedRegions.Mask(r,0,10,true);check(!normal.equals(pro));
 List<TimedRegions.Mask> converted=RestorePolicy.convert(Arrays.asList(normal,new TimedRegions.Mask(r,10,20)));check(converted.size()==2&&converted.get(0).restore&&converted.get(1).restore&&converted.get(1).until==20);
 check(!RestorePolicy.usable(new float[]{0,0,1,1}));check(RestorePolicy.usable(new float[]{0,.4f,1,.5f}));check(RestorePolicy.convert(Arrays.asList(normal,new TimedRegions.Mask(new float[]{0,0,1,1},10,20))).size()==1);
 float[] modes=new float[3];float[] rects=new float[12];List<TimedRegions.Mask> mixed=Arrays.asList(normal,new TimedRegions.Mask(r,10,20,true));TimedRegions.fillModes(mixed,10,modes);TimedRegions.fill(mixed,10,rects);check(modes[0]==1&&modes[1]==0&&rects[0]==r[0]);TimedRegions.fillModes(mixed,20,modes);check(modes[0]==0);check(RestorePolicy.legacy("video/3gpp",176,144,15)&&RestorePolicy.legacy("video/mp4v-es",640,480,25)&&!RestorePolicy.legacy("video/avc",1920,1080,30));check(RestorePolicy.previewHeight(854,true)==480&&RestorePolicy.previewHeight(360,true)==360);
 int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai54_restore_parity.csv"))){if(line.startsWith("f0,"))continue;String[] x=line.split(",");double[] f=new double[4];for(int i=0;i<4;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(RestoreConfidence.blend(f)-Double.parseDouble(x[4])));n++;}check(n==32&&max<1e-8&&RestoreConfidence.ENABLED);
 System.out.println("Hyper54Test OK: mask modes, bounds, legacy preview, 32 parity rows; max error="+max);
 }
}
