package az.kinera.edit;
import java.util.*;
final class Performance87Test {
 static void ok(boolean x){if(!x)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  ok(!Performance87.refuseStart(2,false)&&Performance87.refuseStart(3,false)&&Performance87.refuseStart(0,true));
  ok(!Performance87.stop(3,14999,false)&&Performance87.stop(3,15000,false)&&Performance87.stop(4,0,false)&&Performance87.stop(0,0,true));
  ok(!Performance87.publish(1199,0,false)&&Performance87.publish(1200,0,false)&&Performance87.publish(0,0,true));
  ok(Arrays.equals(Performance87.probes(10,3),new int[]{0,4,9}));
  for(int i=1134;i<1184;i++){ok(RegionMath.active(Performance87TemplatePolicy.window(i)));ok(BrandMotionMath.periodUs(i)>0);}
  List<TimedRegions.Mask> masks=new ArrayList<>();Random random=new Random(87);for(int i=0;i<384;i++){long t=i*100000L;masks.add(new TimedRegions.Mask(new float[]{.1f,.6f,.9f,.8f},t,t+190000L,i%2==0));}Collections.shuffle(masks,random);masks=TimedRegions.snapshot(masks);MaskTimeline87 index=new MaskTimeline87(masks);float[] a=new float[12],b=new float[3],c=new float[12],d=new float[3];
  for(int i=0;i<50000;i++){long t=i<768?i*50000L:random.nextInt(40000000)-50000;TimedRegions.fillBoth(masks,t,a,b);index.fill(t,c,d);ok(Arrays.equals(a,c)&&Arrays.equals(b,d));}
  long start=System.nanoTime();for(int i=0;i<300000;i++)TimedRegions.fillBoth(masks,(i*17003L)%40000000,a,b);long old=System.nanoTime()-start;start=System.nanoTime();for(int i=0;i<300000;i++)index.fill((i*17003L)%40000000,c,d);long newer=System.nanoTime()-start;
  DecodeGate87.enter();java.util.concurrent.atomic.AtomicBoolean interrupted=new java.util.concurrent.atomic.AtomicBoolean(false);Thread t=new Thread(()->{try{DecodeGate87.enter();try{}finally{DecodeGate87.leave();}}catch(InterruptedException e){interrupted.set(true);}});t.start();t.interrupt();t.join(2000);DecodeGate87.leave();ok(interrupted.get()&&!t.isAlive());
  System.out.printf(java.util.Locale.ROOT,"Performance87: thermal gates, progress throttle, bounded refinement, 50 templates, 50000 mask parity cases, interruptible decoder gate; host mask lookup 300k baseline %.2f ms indexed %.2f ms (not device export benchmark)%n",old/1e6,newer/1e6);
 }
}
