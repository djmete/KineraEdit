package az.kinera.edit;
import java.util.*;import java.nio.file.*;
final class Deep64Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ReleaseHighlightPolicy.shouldShowForRelease(0,false,true,true,75,75,true));check(!ReleaseHighlightPolicy.shouldShowForRelease(75,false,true,true,75,75,true));check(!ReleaseHighlightPolicy.shouldShowForRelease(76,false,true,true,76,76,true));check(!ReleaseHighlightPolicy.shouldShow(0,true,true,true));check(!ReleaseHighlightPolicy.shouldShow(0,false,false,true));check(!ReleaseHighlightPolicy.shouldShow(0,false,true,false));check(ReleaseHighlightPolicy.mark(76,76)==76);
  check(DeepEditorLayout.adjustmentHeight(500)==90);check(DeepEditorLayout.adjustmentHeight(900)==210);check(DeepEditorLayout.adjustmentHeight(0)==72);
  check(DeepCaptionPlan.windows(180000000)==93);check(DeepCaptionPlan.windows(2000000)==7);check(DeepCaptionPlan.windows(0)==0);
  float[] a={.2f,.76f,.8f,.83f},b={.2f,.92f,.8f,.98f};List<TimedRegions.Mask> masks=DeepCaptionPlan.build(93000000,Collections.nCopies(93,a),Collections.nCopies(93,b));check(masks.size()==186&&FullCaptionPlan.covered(masks)==93000000);float[] out=new float[12];TimedRegions.fill(masks,92999999,out);check(out[1]==b[1]);
  for(int i=210;i<216;i++){check(RegionMath.active(DeepTemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)==66+i-210);check(BrandMotionMath.periodUs(i)>0);EditSpec s=new EditSpec("Test",i,720,30,0,0,false,false,false,1000000,0,0,1,1,0,new long[0],false);check(s.template==i&&s.withHeight(480).template==i&&s.withEncoding(480,24,false).template==i);}
  double max=0;int rows=0;for(String line:Files.readAllLines(Path.of("tests/kai64_edge_parity.csv"))){String[] v=line.split(",");max=Math.max(max,Math.abs(DeepEdgeConfidence.score(Double.parseDouble(v[0]),Double.parseDouble(v[1]))-Double.parseDouble(v[2])));rows++;}check(rows==32&&max<1e-9);check(DeepEdgeConfidence.ENABLED);System.out.println("Deep64Test OK: one-time highlight policy, responsive layout, 186 masks, six template/animation IDs, candidate parity "+max);
 }
}
