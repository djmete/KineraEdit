package az.kinera.edit;
import java.util.Arrays;
final class Dynamic89Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
 ok(Dynamic89.poll(0,-1));ok(!Dynamic89.poll(1499,0));ok(Dynamic89.poll(1500,0));ok(Dynamic89.latch(true,false));ok(Dynamic89.latch(false,true));ok(!Dynamic89.latch(false,false));ok(!Dynamic89.useSecondHistory(true,true));ok(Dynamic89.useSecondHistory(false,true));
 int[] a=new int[2304],b=new int[2304];Arrays.fill(a,0xff111111);Arrays.fill(b,0xff111111);for(int y=0;y<16;y++)for(int x=0;x<16;x++)b[y*48+x]=0xffffffff;
 ok(Dynamic89.sceneScore(a,b,.3f)<.3f);Arrays.fill(b,0xffffffff);ok(Dynamic89.sceneScore(a,b,.3f)==.3f);ok(Dynamic89.sceneScore(a,b,.5f)==.5f);
 for(int i=1234;i<1284;i++){ok(RegionMath.active(Dynamic89TemplatePolicy.window(i)));ok(BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);}
 ok(Dynamic89TemplatePolicy.choose(2,.6f,1,0,4)>=1234);ok(Dynamic89TemplatePolicy.choose(2,.6f,3,0,4)==2);ok(Dynamic89.blurValueWidth(320,1)==38);
 System.out.println("Dynamic89: localized motion, latched GPU pressure, 50 templates and slider sizing passed");
 }
}
