from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();c=(p/'CaptionReview.java').read_text();d=(p/'KAiDirector.java').read_text()
a=s[s.index('void startFullCaptionPlan(boolean restore)'):s.index('void reviewTrack()')]
assert a.index('captionBusy=true;captionDecoding=true')<a.index('handler.postDelayed(()->')<a.index('releasePlayer()')<a.index('captionWork.submit')
assert 'captionToken!=job' in a and 'job==captionToken' in a and 'captionDecoding=false;captionJob=null' in a
assert 'captionPanel.bringToFront()' in s and 'captionCancel=button("Ləğv et",()->cancelCaption(true))' in s and 'syncPreviewLoading()' in s
assert 'SESSIONS.tryAcquire' in c and 'pending.addOnCompleteListener' in c and 'closeClient()' in c and 'Math.min(250,remaining)' in c
assert 'CaptionBudget99.windows(duration,DeviceLoad87.pressure(c))' in d and 'CaptionBudget99.SCAN_MS' in d
print('Multimodal99 source lifecycle audit: progress before release, cancellation token, deferred cleanup, loading state and single OCR session wiring passed (not device test)')
