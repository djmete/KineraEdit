#!/usr/bin/env python3
"""Compare two APKs without extracting or executing their contents."""
import argparse, hashlib, json, zipfile, os
from collections import defaultdict

def inventory(path):
    totals=defaultdict(lambda: {'entries':0,'compressed':0,'uncompressed':0})
    entries={}
    with zipfile.ZipFile(path) as z:
        for i in z.infolist():
            if i.is_dir(): continue
            n=i.filename
            if n in entries: raise ValueError('Duplicate ZIP entry: '+n)
            group='/'.join(n.split('/')[:2]) if n.startswith('lib/') else ('assets' if n.startswith('assets/') else 'other')
            h=hashlib.sha256()
            with z.open(i) as f:
                for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
            entries[n]={'sha256':h.hexdigest(),'bytes':i.file_size,'compressed':i.compress_size,'method':i.compress_type}
            t=totals[group];t['entries']+=1;t['compressed']+=i.compress_size;t['uncompressed']+=i.file_size
    return {'apk_bytes':os.path.getsize(path),'groups':dict(totals),'entries':entries}

def compare(a,b):
    x,y=inventory(a),inventory(b);p,q=x['entries'],y['entries'];common=p.keys()&q.keys()
    return {'old':x,'new':y,'delta_bytes':y['apk_bytes']-x['apk_bytes'],'missing':sorted(p.keys()-q.keys()),'added':sorted(q.keys()-p.keys()),'content_changed':sorted(n for n in common if p[n]['sha256']!=q[n]['sha256']),'same_content_different_compression':sorted(n for n in common if p[n]['sha256']==q[n]['sha256'] and (p[n]['method'],p[n]['compressed'])!=(q[n]['method'],q[n]['compressed']))}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('old');parser.add_argument('new');parser.add_argument('-o','--output');args=parser.parse_args();s=json.dumps(compare(args.old,args.new),indent=2,ensure_ascii=False)
    if args.output:
        with open(args.output,'w',encoding='utf8') as f:f.write(s+'\n')
    else: print(s)
