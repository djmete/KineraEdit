package az.kinera.edit;
import java.util.Arrays;
public final class ProjectMathTest {
 static void check(boolean x){if(!x)throw new AssertionError();}
 public static void main(String[] args){
 long[] t={400000,2100000,4000000};check(Arrays.equals(t,ProjectMath.decode(ProjectMath.encode(t),5000000)));
 check(Arrays.equals(new long[]{400000,1200000},ProjectMath.decode("bad,1200000,400000,1200000,-1,6000000,5",5000000)));
 check(ProjectMath.decode(null,5000000).length==0);check(ProjectMath.decode("400000",0).length==0);
 long[] many=new long[500];for(int i=0;i<many.length;i++)many[i]=400000+i*10000;check(ProjectMath.decode(ProjectMath.encode(many),10000000).length==120);
 System.out.println("PASS: persisted marker round trip, validation, ordering, limits");
 }
}
