package az.kinera.edit;
final class CaptionBandTest {
 public static void main(String[] args){
  assert CaptionBandMath.blurPercent(Float.NaN,0,0)==0;
  assert CaptionBandMath.blurPercent(.8f,0,0)>=21 && CaptionBandMath.blurPercent(.8f,0,0)<=23;
  assert CaptionBandMath.blurPercent(.8f,0,.25f)==0;
  assert CaptionBandMath.blurPercent(.56f,.35f,0)==0;
  assert CaptionBandMath.blurPercent(.3f,0,0)==0;
  System.out.println("Caption geometry tests passed");
 }
}
