package az.kinera.edit;
import java.nio.file.*;
import java.util.Arrays;
public final class IntelligentVisualTest {
 static void check(boolean x,String m){if(!x)throw new AssertionError(m);}
 public static void main(String[] args)throws Exception{
  Path folder=Files.createTempDirectory("kinera-cleanup-test");
  try{
   Path model=Files.write(folder.resolve("htdemucs_fp16weights.onnx"),new byte[]{1});
   Path partial=Files.write(folder.resolve("voice_model.part"),new byte[]{2});
   Path video=Files.write(folder.resolve("kinera_important.mp4"),new byte[]{3});
   Path other=Files.write(folder.resolve("another.onnx"),new byte[]{4});
   check(RetiredModelCleanup.clean(folder.toFile()),"cleanup");check(!Files.exists(model)&&!Files.exists(partial),"only retired files deleted");check(Files.exists(video)&&Files.exists(other),"unrelated files preserved");check(RetiredModelCleanup.clean(folder.toFile()),"idempotent startup");
   Path unexpected=Files.createDirectory(folder.resolve("voice_model.part"));Files.write(unexpected.resolve("keep"),new byte[]{5});check(!RetiredModelCleanup.clean(folder.toFile()),"refuse recursive deletion");check(Files.exists(unexpected.resolve("keep")),"unexpected contents preserved");Files.delete(unexpected.resolve("keep"));Files.delete(unexpected);
  }finally{try(var files=Files.list(folder)){for(Path f:files.toList())Files.deleteIfExists(f);}Files.deleteIfExists(folder);}
  float[] crop={.1f,.1f,.9f,.95f};float[] band=CaptionRegionMath.legacyBand(.70f,crop);
  check(RegionMath.active(band)&&band[0]==crop[0]&&band[2]==crop[2]&&band[3]==crop[3]&&band[1]<=.70f,"legacy geometry");
  check(!RegionMath.active(CaptionRegionMath.legacyBand(Float.NaN,crop)),"no text");check(!RegionMath.active(CaptionRegionMath.legacyBand(.30f,crop)),"upper text excluded");
  check(!RegionMath.active(CaptionRegionMath.legacyBand(.9f,new float[]{0,0,1,.8f})),"outside crop");
  int[] family={28,29,30,32,33,35};for(int i=0;i<6;i++){
   int style=BrandMotionMath.creativeLayoutFor(family[i],1.78f);check(style==48+i,"wide family");check(BrandMotionMath.creativeLayoutFor(family[i],.75f)==42+i,"portrait family");check(BrandMotionMath.motionKind(style)==6+i,"new motion");long period=BrandMotionMath.periodUs(style);check(BrandMotionMath.motionPhase(period,style)==0&&Math.abs(BrandMotionMath.motionPhase(period/2,style)-.5)<.0001,"loop");}
  check(SceneMath.transientSpike(.6f,.5f,.05f),"flash rejected");check(!SceneMath.transientSpike(.6f,.5f,.6f),"separate shot kept");check(!SceneMath.transientSpike(.6f,.1f,.05f),"one edge kept");
  UiLanguage.set("tr","az");check(UiLanguage.tr("Dəqiq sahə").equals("Hassas alan"),"tr");UiLanguage.set("en","az");check(UiLanguage.tr("Aşağı zolaq (klassik)").equals("Lower band (classic)"),"en");
  System.out.println("IntelligentVisualTest: scoped model deletion, legacy band, 6 new motion families, flash rejection and translations passed");
 }
}
