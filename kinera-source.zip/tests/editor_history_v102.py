from pathlib import Path
s=Path('app/src/main/java/az/kinera/edit/MainActivity.java').read_text()
assert 'final boolean restoreRequested=restoreNextDraft;' in s
assert 'boolean markers=restoreRequested&&restoreMarkers(u)' in s
assert 'resume=button("Saxlanılan layihələr",this::openDrafts)' in s
assert 'header.addView(editorHistory' in s and 'actions.addView(undoButton' not in s
assert 'history.push(editSnapshot());if(redo?!history.canRedo():!history.canUndo())' in s
assert 'regionMode==2&&!RegionMath.active(blurRegion)){regionMode=0;' in s
assert 'handler.postDelayed(refreshPreview,150)' in s
print('v102 history wiring regression passed (source checks; device pending)')
