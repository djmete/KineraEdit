package az.kinera.edit;
import java.util.*;
final class Adaptive88Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
 ok(!Adaptive88.pressure(1,1024*Adaptive88.MIB,256*Adaptive88.MIB));ok(Adaptive88.pressure(2,0,0));ok(Adaptive88.pressure(0,330*Adaptive88.MIB,256*Adaptive88.MIB));ok(!Adaptive88.pressure(0,0,0));
 ok(Adaptive88.samples(60000000L,true,false)==93);ok(Adaptive88.samples(60000000L,true,true)==48);ok(Adaptive88.samples(1,true,true)==1);ok(Adaptive88.refineLimit(false,true)==2);ok(Adaptive88.previewHeight(854,true,true)==480);ok(Adaptive88.previewHeight(854,false,true)==854);ok(!Adaptive88.captureHistory(1920L*1080,true));ok(Adaptive88.captureHistory(1920L*1080,false));ok(Adaptive88.tick(false,false)==600);ok(Adaptive88.enoughCoverage(100,100,75));ok(!Adaptive88.enoughCoverage(99,100,99));
 for(int i=1184;i<1234;i++){ok(RegionMath.active(Adaptive88TemplatePolicy.window(i)));ok(BrandMotionMath.periodUs(i)>0);}
 Random rng=new Random(88);ArrayList<TimedRegions.Mask> masks=new ArrayList<>();for(int i=0;i<80;i++){long start=rng.nextInt(10000000);masks.add(new TimedRegions.Mask(new float[]{.1f,.2f,.3f,.4f},start,start+1+rng.nextInt(900000),rng.nextBoolean()));}MaskTimeline87 index=new MaskTimeline87(masks);for(int i=0;i<50000;i++){long t=rng.nextInt(12000000)-100000;ok(index.capture(t)==TemporalRestorePolicy.capture(masks,t));}
 System.out.println("Adaptive88: pressure profiles, coverage, 50 templates and 50000 temporal-capture parity cases passed");
 }
}
