package az.kinera.edit;
import java.util.Arrays;
public final class AdaptiveMotionTest {
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);}
 public static void main(String[] args){
  int[] family={28,29,30,32,33,35};int[] colors={0xffc79942,0xff304cdb,0xff27a45b,0xffd94455,0xff808080,0xff27a6b3};
  for(int i=0;i<family.length;i++){int[] pixels=new int[128];Arrays.fill(pixels,colors[i]);check(BrandMotionMath.styleFor(pixels)==family[i],"family "+i);int style=BrandMotionMath.layoutFor(family[i],.75f);check(style==42+i,"portrait "+i);check(BrandMotionMath.layoutFor(style,1.78f)==family[i],"wide "+i);check(BrandMotionMath.motionKind(style)==i,"motion "+i);long period=BrandMotionMath.periodUs(style);check(BrandMotionMath.motionPhase(0,style)==0&&BrandMotionMath.motionPhase(period,style)==0,"loop "+i);check(Math.abs(BrandMotionMath.motionPhase(period/2,style)-.5f)<.00001,"midpoint "+i);}
  int[] mixed=new int[100];Arrays.fill(mixed,0xffa0a0a0);mixed[0]=0xffff0000;check(BrandMotionMath.styleFor(mixed)==33,"tiny colored detail");Arrays.fill(mixed,0,65,0xff304cdb);Arrays.fill(mixed,65,100,0xffd94455);check(BrandMotionMath.styleFor(mixed)==29,"dominant blue, not average purple");check(StemMath.recommendedGain(new float[]{.2f},100)>=.05f,"bounded gain sample count");check(StemMath.recommendedGain(null,0)==.10f,"missing samples");
  System.out.println("PASS: six color families, portrait/landscape mapping, seamless motion phase and bounded audio input");
 }
}
