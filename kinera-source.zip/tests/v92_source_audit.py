from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();a=(p/'AutoPlan.java').read_text();o=(p/'RegionOverlay.java').read_text();e=(p/'ExportTask.java').read_text();c=(p/'CaptionReview.java').read_text()
assert 'if(page!=EDITOR)header.setVisibility(View.VISIBLE)' in s and 'blurAdjustPanel.addView(chooser);blurAdjustPanel.addView(heading)' in s
assert 'requestDisallowInterceptTouchEvent(true)' in s and 'if(blurSliderDragging||scrubbing' in s and 'BlurGestureMath.drag' in o
assert 'if((mode==1||mode==2)&&e.getPointerCount()==2' in o and 'if(mode==2&&drag==5)return false' not in o
assert 'KAiEdit.SCENE_UI_TIMEOUT_MS' in s and 'KAiEdit.EXPORT_PREP_TIMEOUT_MS' in e and 'KAiEdit.SCENE_BUDGET_MS' in a
assert 'ProfessionalSceneConfidence.ENABLED&&' in a and 'CaptionRegionMath.shortCaption' in c
print('v92 source integration audit OK: persistent slider, gesture routing, navigation reset, aligned analysis budgets, short-caption OCR fallback')
