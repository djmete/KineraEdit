package az.kinera.edit;
import java.nio.file.*;import java.util.*;
final class Supreme51Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai51_appearance_parity.csv"))){if(line.startsWith("f0,"))continue;String[] x=line.split(",");double[] f=new double[6];for(int i=0;i<6;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(SupremeConfidence.probability(f)-Double.parseDouble(x[6])));n++;}check(n==32&&max<1e-8);check(!SupremeConfidence.ENABLED&&SupremeConfidence.SCHEDULING_ENABLED);
  int[] a=new int[64],b=new int[64];for(int i=0;i<64;i++){int v=i*4;a[i]=(v<<16)|(v<<8)|v;int u=255-v;b[i]=(u<<16)|(u<<8)|u;}
  float[] full={0,0,1,1};double[] same=SupremeTrackPolicy.features(a,a,8,8,full,full),opposite=SupremeTrackPolicy.features(a,b,8,8,full,full);check(Math.abs(same[0]-1)<1e-10&&same[1]==0&&same[2]==0&&same[3]==0);check(Math.abs(opposite[0]+1)<1e-10);check(!SupremeTrackPolicy.cautious(same));check(SupremeTrackPolicy.features(null,b,8,8,full,full)==null);check(SupremeTrackPolicy.partialTime(0,500000)==250000&&SupremeTrackPolicy.partialTime(0,100000)==-1);
  float[] r={.1f,.6f,.8f,.8f},s={.15f,.6f,.85f,.8f},t={.08f,.6f,.78f,.8f},out=PrecisionMath.consensus(Arrays.asList(r,s,t));check(out[0]<=.08f&&out[2]>=.85f);check(PrecisionMath.consensus(Arrays.asList(r,s,new float[]{0,0,.1f,.1f}))[1]>=.6f);
  check(Float.isFinite(DirectorMath.linkedGain(new float[]{Float.MAX_VALUE,-Float.MAX_VALUE},.01f,100)));check(Math.abs(DirectorMath.linkedSample(Float.MAX_VALUE,.01f,1))<=.96f);
  System.out.println("Supreme51Test OK: 32 parity rows; max error="+max);
 }
}
