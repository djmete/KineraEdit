package az.kinera.edit;
final class CinematicIntelligenceTest {
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 public static void main(String[] args){
  float[] onsets=new float[250];for(int i=0;i<250;i+=25)onsets[i]=.4f;check(RhythmMath.estimateLag(onsets,0,250)==25,"120 BPM period");check(RhythmMath.estimateLag(new float[250],0,250)==0,"silence");
  RhythmMath r=new RhythmMath();for(int i=0;i<6000;i++)r.push(i%500<20?.8f:.01f,1000);check(r.bpm()>=115&&r.bpm()<=125,"streaming pulse");check(r.push(.95f,1000)<=.25f,"protect loud sample");r.reset();check(r.bpm()==0,"reset");
  check(!TrackConfidence.ENABLED,"candidate is experimental");check(TrackConfidence.probability(.98,.2)>TrackConfidence.probability(.80,.035),"model ranking");check(!TrackConfidence.accept(Double.NaN,.5),"invalid match");
  check(DirectorMath.sound(new long[]{6000000},6000000,12000000)<=.018f,"audio cap");System.out.println("CinematicIntelligenceTest OK");
 }
}
