#!/usr/bin/env bash
set -euo pipefail
log=${1:?log path}; shift
mkdir -p "$(dirname "$log")"
: > "$log"
attempt_log=$(mktemp); trap 'rm -f "$attempt_log"' EXIT
for attempt in 1 2 3; do
  echo "Gradle attempt $attempt: $*" | tee -a "$log"
  set +e
  gradle --no-daemon --max-workers=2 --console=plain --stacktrace "$@" 2>&1 | tee "$attempt_log" | tee -a "$log"
  rc=${PIPESTATUS[0]}
  set -e
  if [[ $rc == 0 ]]; then exit 0; fi
  if [[ $attempt == 3 ]] || ! grep -Eqi 'Could not (GET|HEAD|download|resolve)|UnknownHostException|Connection reset|Connection refused|Read timed out|Connect timed out|status code (429|5[0-9][0-9])|PKIX path building failed|SSLHandshakeException' "$attempt_log"; then exit "$rc"; fi
  sleep "$((attempt * 12))"
done
