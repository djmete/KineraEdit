#!/usr/bin/env bash
set -euo pipefail
log=${1:?log path}; shift
mkdir -p "$(dirname "$log")"
: > "$log"
attempt_log=$(mktemp); trap 'rm -f "$attempt_log"' EXIT
run_gradle(){
  set +e
  gradle --no-daemon --max-workers=2 --console=plain --stacktrace "$@" 2>&1 | tee "$attempt_log" | tee -a "$log"
  rc=${PIPESTATUS[0]}
  set -e
}
echo "Gradle cache-only attempt: $*" | tee -a "$log"
run_gradle --offline "$@"
if [[ $rc == 0 ]]; then exit 0; fi
if ! grep -Eqi 'No cached (version|resource)|offline mode|not available for offline|Could not resolve.*offline|Plugin .* was not found in any of the following sources' "$attempt_log"; then exit "$rc"; fi
for attempt in 1 2; do
  echo "Gradle online attempt $attempt: $*" | tee -a "$log"
  run_gradle "$@"
  if [[ $rc == 0 ]]; then exit 0; fi
  if [[ $attempt == 2 ]] || ! grep -Eqi 'Could not (GET|HEAD|download)|UnknownHostException|Connection reset|Connection refused|Read timed out|Connect timed out|status code (429|5[0-9][0-9])|HTTP 429|Too Many Requests' "$attempt_log"; then exit "$rc"; fi
  if grep -Eqi '429|Too Many Requests' "$attempt_log"; then echo 'Central rate limited: cooling down for 90 seconds; no alternate IP or repository bypass.' | tee -a "$log"; sleep 90; else sleep 20; fi
done
