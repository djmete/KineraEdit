package az.kinera.edit;
import java.nio.file.*;
final class Expert79Test {
 static void check(boolean x){if(!x)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ExpertTemplatePolicy.TOTAL==934);for(int i=734;i<784;i++){check(RegionMath.active(Expert79TemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)>=84&&BrandMotionMath.motionKind(i)<90);check(BrandMotionMath.periodUs(i)>0);}
  for(String l:Files.readAllLines(Path.of("tests/kai79_av_parity.csv"))){String[] a=l.split(",");double[] x=new double[4];for(int i=0;i<4;i++)x[i]=Double.parseDouble(a[i]);check(Math.abs(ExpertAVConfidence.score(x)-Double.parseDouble(a[4]))<1e-8);}
  ExpertAudioEnvelope e=new ExpertAudioEnvelope();check(e.features(500000)==null);for(int i=0;i<100;i++){e.add(300000+i,.05f);e.add(400000+i,.05f);e.add(600000+i,.4f);e.add(700000+i,.4f);}double[] a=e.features(500000);check(a!=null&&a[0]>.3);check(ExpertAudioEnvelope.bonus(.3,.3,a)>0&&ExpertAudioEnvelope.bonus(.1,.3,a)==0&&ExpertAudioEnvelope.bonus(.3,.05,a)==0);check(e.features(31000000)==null);
  check(!TemporalRestorePolicy.recent(0,80000,new long[0],60));check(!TemporalRestorePolicy.recent(0,200000,new long[0],60));check(!TemporalRestorePolicy.recent(0,80000,new long[]{40000},60));
  PlaybackWatchdog w=new PlaybackWatchdog();check(!w.stalled(0,1000,true,true));w.reset();check(!w.stalled(13000,500,true,true));
  check(BlurGestureMath.compact(600,400,1));check(!DeepEditorLayout.showFilmstrip(600,0,false));System.out.println("Expert 7.9 templates, model parity, PCM bins, fallback, temporal and layout tests passed");
 }
}
