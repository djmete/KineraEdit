package az.kinera.edit;
import java.util.*;
final class Multimodal99Test {static void ok(boolean b){if(!b)throw new AssertionError();}public static void main(String[] args){
 for(long d=1;d<1000000000L;d+=100003){int n=CaptionBudget99.windows(d,false);ok(n>0&&n<=72);ok(CaptionBudget99.windows(d,true)<=36);ok(FullCaptionPlan.boundary(d,n,n)==d);}
 ok(CaptionBudget99.windows(159000000,false)==72);ok(CaptionBudget99.windows(159000000,true)==36);ok(CaptionBudget99.active(false,true));ok(!CaptionBudget99.active(false,false));ok(!CaptionBudget99.valid(1,2,3,3));ok(CaptionBudget99.progress(72,72)==100);
 float[] a={.2f,.76f,.8f,.83f};for(boolean restore:new boolean[]{false,true}){List<TimedRegions.Mask> m=Studio94CaptionPlan.build(159000000L,72,Collections.nCopies(72,a),Collections.nCopies(72,a),restore);ok(FullCaptionPlan.covered(m)==159000000L);ok(m.get(0).restore==restore);}
 for(int i=1734;i<1784;i++)ok(RegionMath.active(Multimodal99TemplatePolicy.window(i))&&BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);
 System.out.println("Multimodal99: bounded scan, full timeline boundaries, cancellation state, both caption modes and 50 new template layouts passed");}}
