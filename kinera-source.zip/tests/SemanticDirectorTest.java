package az.kinera.edit;
import java.nio.file.*;
final class SemanticDirectorTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  int n=0;double error=0;for(String line:Files.readAllLines(Path.of("tests/kai44_temporal_parity.csv"))){if(line.startsWith("a,"))continue;String[] s=line.split(",");float[] x=new float[5];for(int i=0;i<5;i++)x[i]=Float.parseFloat(s[i]);error=Math.max(error,Math.abs(TemporalConfidence.probability(x,2)-Double.parseDouble(s[5])));n++;}
  check(n==32&&error<1e-5);check(!TemporalConfidence.ENABLED);check(TemporalConfidence.probability(null,2)==1);
  check(TemporalPolicy.contiguous(new long[]{100,200,300,700,800},1,2));check(!TemporalPolicy.contiguous(new long[]{100,200,300,700,800},2,3));
  check(KineraAI.editorialCuts(new long[]{2000000,1000000},new float[]{.7f,.8f},8000000).length==0);
  float[] a={.2f,.2f,.4f,.4f},b={.23f,.22f,.43f,.42f},c={.7f,.7f,.9f,.9f};check(TemporalPolicy.safeTrack(a,b));check(!TemporalPolicy.safeTrack(a,c));check(TemporalPolicy.trackingStep(9,c,a)==1000000L);check(TemporalPolicy.trackingStep(9,a,a)==2000000L);
  System.out.println("SemanticDirectorTest OK; 32 parity rows, max error="+error);
 }
}
