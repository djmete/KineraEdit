package az.kinera.edit;
public final class ExportSafetyTest {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 static void near(float a,float b){ok(Math.abs(a-b)<.0001f);}
 public static void main(String[] args){ok(ExportSafety.reserveForTwoCopies(100)==200);ok(ExportSafety.reserveForTwoCopies(Long.MAX_VALUE)==Long.MAX_VALUE);ok(ExportSafety.ceilMiB(Long.MAX_VALUE)==8796093022208L);ok(ExportSafety.ceilMiB(1048577)==2);int[][] f=ExportSafety.fallbacks(1920,60);ok(f[0][0]==1920&&f[0][1]==30&&f.length==5&&f[2][0]==1920&&f[3][0]==1280&&f[4][0]==1280&&f[4][1]==24);float[] r={.2f,.3f,.6f,.8f};float[] m=RegionMath.move(r,.8f,-1);near(m[0],.6f);near(m[1],0);near(m[2],1);near(m[3],.5f);float[] a=RegionMath.resize(r,1,.9f,.9f,.25f);near(a[0],.35f);near(a[1],.55f);near(a[2],.6f);near(a[3],.8f);a=RegionMath.resize(r,4,-1,-1,.25f);near(a[2],.45f);near(a[3],.55f);System.out.println("PASS: storage overflow, fallback ladder, movable and resizable regions");}
}
