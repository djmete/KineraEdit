package az.kinera.edit;
import java.io.*;
public final class Vision107Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
 ok(Vision107.rescueSourceEdge(1080,1920,960,0,1000,25000)==1280);ok(Vision107.rescueSourceEdge(1080,1920,720,0,1000,25000)==0);ok(Vision107.rescueSourceEdge(1080,1920,960,4,1000,25000)==0);ok(Vision107.rescueSourceEdge(1080,1920,960,0,1000,20000)==0);ok(Vision107.rescueSourceEdge(480,720,960,0,1000,25000)==0);ok(Vision107.sliderCommit(150,180,true)==150);ok(Vision107.sliderCommit(150,180,false)==180);ok(Vision107.zoomGuard(new long[]{1000000},0,10000000)<.34f);ok(Vision107.zoomGuard(new long[]{5000000},0,10000000)==1f);
 for(int i=2534;i<2584;i++){ok(RegionMath.active(Vision107TemplatePolicy.window(i)));ok(BrandMotionMath.motionKind(i)>=136&&BrandMotionMath.motionKind(i)<146);}
 try(InputStream w=new FileInputStream(args[0]);InputStream f=new FileInputStream(args[1])){System.out.println("Vision107 bundled CNN fixture max error="+Vision107Diagnostics.check(w,f));}
 System.out.println("Vision107 bounded source rescue, gesture cancellation, asymmetric transition and 50 templates passed");
 }
}
