package az.kinera.edit;
final class Production84Test {
 static void check(boolean ok){if(!ok)throw new AssertionError();}
 public static void main(String[] args){
  for(int i=984;i<1034;i++){check(RegionMath.active(Production84TemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)>=114&&BrandMotionMath.motionKind(i)<120);check(BrandMotionMath.periodUs(i)>0);}
  check(ExpertTemplatePolicy.TOTAL==1534);check(Production84Math.scale(new long[]{1000000,1500000},0,4000000)<.3f);check(Production84Math.scale(new long[]{2000000},0,4000000)==1f);
  check(Production84Math.scale(new long[]{-1},0,3000000)==0);check(Production84Math.scale(new long[]{3000000},0,3000000)==0);check(Production84Math.scale(new long[]{2000000,1000000},0,4000000)==0);
  check(Production84Math.balanced(0,33000,66000,30));check(!Production84Math.balanced(0,5000,45000,30));check(!Production84Math.balanced(30,20,10,30));
  check(EditorWorkspacePolicy.scrollTools(390,1));check(!EditorWorkspacePolicy.scrollTools(411,1));
  System.out.println("Production84: 50 templates, 6 motion IDs, transition bounds and history cadence passed");
 }
}
