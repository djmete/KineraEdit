from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();e=(p/'ExportTask.java').read_text();o=(p/'RegionOverlay.java').read_text()
assert 'buildCropPanel(editorDock)' in s and 'Crop109.zoom(cropZoomTracking?cropZoomBase:cropRegion' in s
assert 'if(regionMode==1&&draft!=null){cropRegion=draft;' in s and 'cancelCropZoom();syncEditorWorkspace();syncCropPanel();configureRegionOverlay();' in s
assert 'mode==1?drag!=0' in o and 'mode==1?Crop109.drag' in o and 'mode==1?Crop109.pinch' in o
assert '!Crop109.keepTemplate(initial.cropRect)' in e
assert 'cropRegion=Crop109.reset(sourceAspect())' in s and 'cropRegion=Crop109.fit(cropRegion,sourceAspect())' in s
print('Crop109 source wiring: dedicated slider, draft/cancel, locked gesture, manual crop template preservation, reset passed; Android runtime pending')
