from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');m=(p/'MainActivity.java').read_text();a=(p/'Architecture105Inference.java').read_text();k=(p/'PreviewKey.java').read_text()
assert 'updateLiveBlur();' in m and 'Cinematic118Workspace.liveTick' in m and 'appliedPreviewKey=new PreviewKey(live)' in m
assert 'if(!playing)player.seekTo(player.getCurrentPosition())' in m and 'strengthSnapshot' in k
assert 'Architecture105Inference' not in m and 'Architecture105Inference' not in (p/'BrandEffect.java').read_text()
assert 'Architecture105.filmHeight(rootHeightDp())' in m and 'Architecture105.actionHeight' in m
print('Architecture105 source wiring: throttled live blur, compact filmstrip, research model isolated')

c=(p/"CaptionReview.java").read_text()
assert "VisualInferenceGate.tryEnter()" in c and "visionLease.close()" in c and "pending.addOnCompleteListener" in c
print("Architecture105 OCR shares visual inference gate; deferred release retained")
