package az.kinera.edit;
public final class StudioMathTest {
 static void check(boolean x){if(!x)throw new AssertionError();}
 public static void main(String[] args){
  check(StudioMath.estimatedBytes(60_000_000,8_000_000,true)==60_000_000);
  check(StudioMath.estimatedBytes(60_000_000,8_000_000,false)==61_920_000);
  check(StudioMath.artHeight(3840,4096)==1920);check(StudioMath.artHeight(3840,1024)==1024);
  check(StudioMath.artHeight(854,4096)==854);
  check(StudioMath.keepPrevious(false,true,true));check(StudioMath.keepPrevious(true,false,true));check(StudioMath.keepPrevious(true,true,false));check(!StudioMath.keepPrevious(true,true,true));
  check(StudioMath.sourceUpscaled(512,662,1920));check(!StudioMath.sourceUpscaled(1920,1080,1920));
  long[] a=StudioMath.toggleCut(new long[]{1000000,3000000},2000000,5000000);check(java.util.Arrays.equals(a,new long[]{1000000,2000000,3000000}));
  check(java.util.Arrays.equals(StudioMath.toggleCut(a,2120000,5000000),new long[]{1000000,3000000}));
  check(StudioMath.toggleCut(a,100000,5000000).length==3);
  System.out.println("PASS: file estimate, overlay texture cap, prior export preservation, manual scene markers");
 }
}
