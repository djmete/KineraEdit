package az.kinera.edit;
import java.nio.file.*;
import java.util.*;
final class Precision78Test {
 static void check(boolean ok){if(!ok)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ExpertTemplatePolicy.TOTAL==1634);for(int i=684;i<734;i++){check(RegionMath.active(Precision78TemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)>=78&&BrandMotionMath.motionKind(i)<84);check(BrandMotionMath.periodUs(i)>0);}
  for(String line:Files.readAllLines(Path.of("tests/kai78_precision_parity.csv"))){String[] fields=line.split(",");double[] x=new double[6];for(int i=0;i<6;i++)x[i]=Double.parseDouble(fields[i]);check(Math.abs(PrecisionPulseConfidence.score(x)-Double.parseDouble(fields[6]))<1e-5);}
  int[] a=new int[2304],b=a.clone(),c=a.clone();Arrays.fill(a,70);Arrays.fill(b,180);Arrays.fill(c,71);double[] x=PrecisionPulseMath.features(a,b,c);check(x[0]>.4&&x[2]<.01&&x[3]>0&&x[4]<0);check(!PrecisionPulseMath.pulse(null,b,c));check(!PrecisionPulseMath.pulse(a,a,c));
  check(!DeepEditorLayout.showFilmstrip(500,0,false)&&DeepEditorLayout.showFilmstrip(760,0,false));System.out.println("Precision 7.8 template, triple-frame, parity and workspace tests passed");
 }
}
