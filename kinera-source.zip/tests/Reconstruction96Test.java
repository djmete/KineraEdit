package az.kinera.edit;
final class Reconstruction96Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
 int[] hs={1280,1920,2560,3840,480,640,960};for(int i=0;i<hs.length;i++){int h=Reconstruction96.height(i);ok(h==hs[i]);for(int f:new int[]{15,24,25,30})for(int[] a:Reconstruction96.fallbacks(h,f)){ok(a[0]==h&&a[1]<f);}}
 ok(ExportValidationMath.exactGeometry(1080,1920,0,1920));ok(!ExportValidationMath.exactGeometry(720,1280,0,1920));ok(ExportValidationMath.exactGeometry(1920,1080,90,1920));ok(Reconstruction96.fps(60,1920,false,false)==30);ok(Reconstruction96.fps(60,3840,false,false)==24);ok(Reconstruction96.fps(60,1920,true,false)==24);ok(Reconstruction96.fps(15,1920,true,true)==15);ok(Reconstruction96.height(-1)==1920);ok(Reconstruction96.index(6)==6);
 float[] a={.2f,.7f,.8f,.75f},b={.2f,.71f,.8f,.76f},c={.2f,.722f,.8f,.772f};ok(Reconstruction96.safeUnion(a,b));ok(!Reconstruction96.safeUnion(a,c));for(int i=1584;i<1634;i++)ok(RegionMath.active(Reconstruction96TemplatePolicy.window(i))&&BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);System.out.println("Reconstruction96: user dimensions preserved, automatic FPS, safer temporal mask union, 50 layouts passed");}
}
