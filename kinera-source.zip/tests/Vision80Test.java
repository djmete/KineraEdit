package az.kinera.edit;
import java.nio.file.*;
final class Vision80Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  ok(ExpertTemplatePolicy.TOTAL==1034);for(int i=784;i<834;i++){ok(RegionMath.active(Vision80TemplatePolicy.window(i)));ok(BrandMotionMath.motionKind(i)>=90&&BrandMotionMath.motionKind(i)<96);ok(BrandMotionMath.periodUs(i)>0);}
  for(String l:Files.readAllLines(Path.of("tests/kai80_parity.csv"))){String[] v=l.split(",");double[] a=new double[8];for(int i=0;i<8;i++)a[i]=Double.parseDouble(v[i]);ok(Math.abs(Vision80Confidence.score(a)-Double.parseDouble(v[8]))<1e-8);}
  for(String l:Files.readAllLines(Path.of("tests/kai80_frame_parity.csv"))){String[] v=l.split(",");int[] a=new int[2304],b=new int[2304];for(int i=0;i<2304;i++){a[i]=(int)Double.parseDouble(v[i]);b[i]=(int)Double.parseDouble(v[i+2304]);}double[] f=Vision80Features.features(a,b);for(int i=0;i<8;i++)ok(Math.abs(f[i]-Double.parseDouble(v[4608+i]))<1e-8);}
  ok(!Vision80Features.aligned(null,null));ok(TemporalRestorePolicy.coherentPair(0,33000,66000,new long[0],30));ok(!TemporalRestorePolicy.coherentPair(0,160000,180000,new long[0],30));ok(!TemporalRestorePolicy.coherentPair(0,33000,66000,new long[]{50000},30));
  ok(!DeepEditorLayout.showFilmstrip(690,0,false));ok(DeepEditorLayout.showFilmstrip(760,0,false));ok(BlurGestureMath.compact(700,450,1));System.out.println("Vision 8.0: 50 IDs, 6 motion families, 64 score and 8 frame parity cases, temporal and responsive layout checks passed");
 }
}
