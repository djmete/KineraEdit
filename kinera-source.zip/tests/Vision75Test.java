package az.kinera.edit;
import java.nio.file.*;import java.util.*;
final class Vision75Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ExpertTemplatePolicy.TOTAL==1034);for(int i=534;i<584;i++){check(RegionMath.active(Vision75TemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)>=60&&BrandMotionMath.motionKind(i)<78);EditSpec s=new EditSpec("Test",i,720,30,0,0,false,false,false,1000000,0,0,1,1,0,new long[0],false);check(s.template==i&&s.withEncoding(480,24,false).template==i);}
  for(int f=0;f<5;f++)for(int p=0;p<10;p++)check(Vision75TemplatePolicy.choose(180,new float[]{.56f,.8f,1f,1.77f,2.3f}[f],1,p,7)==534+10*f+p);
  for(int n=0;n<=120;n++){int[] ix=VisionCutPolicy.indices(n);check(ix.length==Math.min(n,12));if(n>0){check(ix[0]==0&&ix[ix.length-1]==n-1);for(int i=1;i<ix.length;i++)check(ix[i]>ix[i-1]);}}
  long[] pts={800000,900000,1000000,1100000,1200000};double[] scores={.03,.06,.38,.05,.04};boolean[] blocked=new boolean[5];check(VisionCutPolicy.refine(1050000,pts,scores,blocked,5,350000)==1000000);blocked[2]=true;check(VisionCutPolicy.refine(1050000,pts,scores,blocked,5,350000)==1050000);
  int[] a=new int[2304],b=new int[2304];for(int i=0;i<a.length;i++){a[i]=40+i%100;b[i]=a[i]+65;}double[] x=VisionCutPolicy.features(a,b);check(Math.abs(x[0]-65./255)<1e-10&&Math.abs(x[1]-65./255)<1e-10&&x[2]<1e-10&&Math.abs(x[3]-1)<1e-10);check(VisionCutPolicy.features(a,new int[1])==null);
  double max=0;int n=0;for(String l:Files.readAllLines(Path.of("tests/kai75_light_parity.csv"))){String[] v=l.split(",");double[] z=new double[6];for(int i=0;i<6;i++)z[i]=Double.parseDouble(v[i]);max=Math.max(max,Math.abs(VisionLightConfidence.score(z)-Double.parseDouble(v[6])));n++;}check(n==32&&max<1e-10&&VisionLightConfidence.ENABLED);
  check(BlurGestureMath.compact(549,450,1)&&BlurGestureMath.compact(700,360,1)&&BlurGestureMath.compact(700,450,1.3f)&&!BlurGestureMath.compact(760,450,1));check(!DeepEditorLayout.showSeek(679,2,false)&&DeepEditorLayout.showSeek(680,2,false));
  float[] orig={.03f,.70f,.23f,.80f};float[] wide=RegionMath.sliderRegion(orig,2,900);float[] restored=RegionMath.sliderRegion(orig,2,200);check(Math.abs(restored[0]-orig[0])<.00001&&Math.abs(restored[2]-orig[2])<.00001);check(wide[0]==0&&RegionMath.active(wide));
  check(RegionMath.active(CaptionRegionMath.shortCaption(.455f,.75f,.545f,.79f,"OK")));check(!RegionMath.active(CaptionRegionMath.shortCaption(.02f,.75f,.11f,.79f,"OK")));check(!ReleaseHighlightPolicy.shouldShow(85,false,true,true));
  check(KAiEdit.SCENE_BUDGET_MS<KAiEdit.SCENE_UI_TIMEOUT_MS&&KAiEdit.SCENE_UI_TIMEOUT_MS<KAiEdit.EXPORT_PREP_TIMEOUT_MS);
  System.out.println("Vision75Test OK: 50 templates, 121 distributed schedules, refinement veto, feature calculation, compact layout, stable slider origin, two-letter captions, model parity="+max);
 }
}
