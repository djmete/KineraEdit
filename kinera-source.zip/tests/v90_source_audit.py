from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();a=(p/'AutoPlan.java').read_text();d=(p/'KAiDirector.java').read_text();t=(p/'TemplateArt.java').read_text()
assert 'DeepEditorLayout.showTools(regionMode,editorFocus)' in s and 'PreviewRecovery.relativePosition(' in s
assert 'MasterTemplatePolicy.choose(' in d and 'MasterTemplatePolicy.window(style)' in t and 'style>=284&&style<334' in t
assert 'Adaptive88.enoughCoverage(processed,count,n/64)' in a and 'MasterMotionConfidence.translation' in a
assert 'StableCaptionPlan.windows(duration)' in d and 'StableCaptionPlan.UI_TIMEOUT_MS' in s
assert 'Kinera Edit v0.6.9 Stable' in s
print('v90 source integration audit OK: dedicated adjustment workspace, safe relative seek, coverage gate, template and OCR wiring')
