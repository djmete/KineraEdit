package az.kinera.edit;
public final class ImportMathTest {
 public static void main(String[] args){for(long d:new long[]{-1,0,1000000,2000000,60000000,103000000,3600000000L,Long.MAX_VALUE}){long step=ImportMath.sampleStep(d);int n=ImportMath.sampleCount(d);if(step<750000||n<0||n>64||n>0&&(n-1)*step>=d)throw new AssertionError("sample bounds");}System.out.println("ImportMath: OK");}
}
