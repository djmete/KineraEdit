package az.kinera.edit;
public final class NeuralCreativeEvolutionTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
 check(KineraAI.VERSION.equals("8.5"));check(AudioLevelMath.sampleCount(90000000)==7);check(AudioLevelMath.sampleCount(3000000)==1);
 AudioLevelMath.Meter quiet=new AudioLevelMath.Meter();for(int i=0;i<2048;i++)quiet.add(.01f);check(AudioLevelMath.measuredGain(new AudioLevelMath.Meter[]{quiet},1)==15);check(AudioLevelMath.measuredGain(new AudioLevelMath.Meter[]{quiet},7)==5);
 check(!RegionMath.active(RegionMath.rect(Float.NaN,0,1,1,.01f)));check(CutConfidence.probability(.5f,.4f,.2f)==0);check(CutConfidence.probability(2,0,0)==0);check(CutConfidence.probability(.7f,.02f,.03f)>.5);
 System.out.println("NeuralCreativeEvolutionTest: audio coverage, geometry, model input bounds passed");
 }
}
