package az.kinera.edit;
public final class ToolAccessTest {
 public static void main(String[] args){
  float[] r=CaptionRegionMath.include(RegionMath.empty(),.2f,.65f,.8f,.7f);
  r=CaptionRegionMath.include(r,.3f,.71f,.7f,.76f);float[] a=CaptionRegionMath.padded(r);
  if(!RegionMath.active(a)||a[0]<=0||a[2]>=1||a[3]-a[1]>.15f)throw new AssertionError("Tight region");
  if(RegionMath.active(CaptionRegionMath.include(RegionMath.empty(),.1f,.2f,.8f,.3f)))throw new AssertionError("Upper region");
  if(RegionMath.active(CaptionRegionMath.padded(RegionMath.empty())))throw new AssertionError("Empty");
  if(!VoiceSettingsMath.useForClip(true,true,102000000)||VoiceSettingsMath.useForClip(true,false,102000000)||VoiceSettingsMath.useForClip(false,true,102000000)||VoiceSettingsMath.useForClip(true,true,600000001)||VoiceSettingsMath.useForClip(true,true,0))throw new AssertionError("Voice settings");
  UiLanguage.set("tr","az");if(!UiLanguage.tr("Yeni videolarda OtoSes").equals("Yeni videolarda OtoSes"))throw new AssertionError("Locale");
  UiLanguage.set("en","az");if(!UiLanguage.tr("Model əlavə edilməyib").equals("Model not imported"))throw new AssertionError("Locale");
  System.out.println("ToolAccessTest passed");
 }
}
