package az.kinera.edit;
import java.util.*;
public final class AdvancedMotionIntelligenceTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  ProductionMath.History h=new ProductionMath.History();float[] c={0,0,1,1},b={.1f,.2f,.4f,.6f};List<TimedRegions.Mask> m=new ArrayList<>();h.reset(c,b,0,100,m);m.add(new TimedRegions.Mask(b,5,50));h.push(c,b,20,80,m);m.clear();ProductionMath.Regions a=h.undo();check(a.from==0&&a.until==100&&a.masks.isEmpty());a=h.redo();check(a.from==20&&a.until==80&&a.masks.size()==1);h.push(c,b,30,90,Collections.emptyList());check(h.undo().masks.size()==1);check(h.redo().masks.isEmpty());
  for(int i=0;i<5;i++)check(KineraAI.exportIndex(i)==Math.max(0,i-1));for(int height:new int[]{1280,1920,2560,3840})for(int[] f:ExportSafety.fallbacks(height,60))check(f[0]>=1280&&f[0]<=height);
  check(KineraAI.safeCount(99999)==100000&&KineraAI.safeCount(100000)==100000&&KineraAI.safeCount(-1)==1);
  long[] t={1000000,2000000,3000000,4000000,5000000,6000000,7000000};float[] s={.03f,.05f,.65f,.04f,.05f,.67f,.02f};long[] cuts=KineraAI.editorialCuts(t,s,9000000);check(cuts.length>=1);for(int i=1;i<cuts.length;i++)check(cuts[i]-cuts[i-1]>=3000000);
  for(int i=66;i<72;i++){check(BrandMotionMath.motionKind(i)==i-42);check(BrandMotionMath.motionPhase(BrandMotionMath.periodUs(i),i)==0);}check(KineraAI.layoutFor(28,.56f)==66);check(!ExportValidationMath.geometry(480,854,0,1920));System.out.println("AdvancedMotionIntelligenceTest passed");
 }
}
