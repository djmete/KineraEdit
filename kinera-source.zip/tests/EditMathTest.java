package az.kinera.edit;
public class EditMathTest {
 static void near(float a,float b){if(Math.abs(a-b)>0.0001)throw new AssertionError(a+" != "+b);}
 public static void main(String[] args){float[] box={0.05f,0.2f,0.95f,0.7f};for(float a:new float[]{.5f,1f,1.7778f,2.4f}){float[] f=EditMath.fit(box,a,9f/16);near((f[2]-f[0])*9f/16/(f[3]-f[1]),a);if(f[0]<box[0]-.00001||f[2]>box[2]+.00001||f[1]<box[1]-.00001||f[3]>box[3]+.00001)throw new AssertionError("bounds");}near(EditMath.fade(0,2000000,true),0);near(EditMath.fade(1000000,2000000,true),1);near(EditMath.fade(2000000,2000000,true),0);near(EditMath.fade(0,2000000,false),1);if(EditMath.widthForHeight(1280)!=720||EditMath.widthForHeight(1920)!=1080||EditMath.widthForHeight(854)!=480)throw new AssertionError("size");System.out.println("PASS: fit, aspect ratio, bounds, fade, output width");}
}
