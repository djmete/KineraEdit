package az.kinera.edit;
final class NeuralGenerationTest {public static void main(String[] args){
 long[] cuts=DirectorMath.clean(new long[]{12000000,100,12000000,24000000},40000000);
 if(cuts.length!=2||cuts[0]!=12000000)throw new AssertionError("markers");
 if(DirectorMath.visual(cuts,12000000,40000000,.12f)<=0||DirectorMath.visual(cuts,13000000,40000000,.12f)!=0)throw new AssertionError("grade");
 if(DirectorMath.zoom(cuts,12000000,40000000,.12f,true)!=1||DirectorMath.zoom(cuts,12000000,40000000,.12f,false)<=1)throw new AssertionError("mask-safe zoom");
 if(DirectorMath.mix(.8f,.01f,0)!=0||Math.abs(DirectorMath.mix(1f,.1f,100))>.96f)throw new AssertionError("audio gain/limit");
 if(DirectorMath.sound(cuts,10000000,40000000)!=0||Math.abs(DirectorMath.sound(cuts,12030000,40000000))>.01801f)throw new AssertionError("audio envelope");
 System.out.println("NeuralGenerationTest OK");}}
