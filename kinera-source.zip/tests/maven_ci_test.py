from pathlib import Path
import os, subprocess, tempfile
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as d:
 p=Path(d); env=dict(os.environ,PATH=str(p)+':'+os.environ['PATH'],GITHUB_ENV=str(p/'env'),MOCK_COUNTER=str(p/'counter'))
 def stub(name, body):
  f=p/name; f.write_text('#!/bin/bash\n'+body+'\n'); f.chmod(0o755)
 stub('sleep','exit 0');stub('curl','echo forbidden_probe; exit 99')
 r=subprocess.run(['bash',str(root/'maven_preflight.sh')],env=env,capture_output=True,text=True);assert r.returncode==0 and 'forbidden_probe' not in r.stdout
 assert (p/'env').read_text()=='KINERA_CENTRAL_ENDPOINT=apache\n'
 def grad(body):
  stub('gradle',body);return subprocess.run(['bash',str(root/'gradle_ci.sh'),str(p/'gradle.log'),'help'],env=env,capture_output=True,text=True)
 r=grad('[[ "$*" == *--offline* ]] && exit 0; exit 99');assert r.returncode==0 and 'online attempt' not in r.stdout
 r=grad('if [[ "$*" == *--offline* ]]; then echo "No cached version available for offline mode"; exit 1; fi; n=0; [[ ! -f "$MOCK_COUNTER" ]] || n=$(cat "$MOCK_COUNTER"); n=$((n+1)); echo "$n" > "$MOCK_COUNTER"; if [[ $n == 1 ]]; then echo "Received status code 429"; exit 1; fi; echo success');assert r.returncode==0 and '90 seconds' in r.stdout and (p/'counter').read_text().strip()=='2'
 r=grad('echo "MainActivity.java:42: error: cannot find symbol"; exit 7');assert r.returncode==7 and 'online attempt' not in r.stdout
 r=grad('if [[ "$*" == *--offline* ]]; then echo "No cached version available for offline mode"; else echo "HTTP 429"; fi; exit 1');assert r.returncode==1 and 'online attempt 2' in r.stdout and 'online attempt 3' not in r.stdout
print('Cache-first CI: no curl probe, warm cache, cold cache+429 recovery, compiler error, persistent 429 bounded (mocked).')
