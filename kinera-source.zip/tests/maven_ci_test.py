from pathlib import Path
import os, subprocess, tempfile
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as d:
 p=Path(d); env=dict(os.environ,PATH=str(p)+':'+os.environ['PATH'],GITHUB_ENV=str(p/'env'),MOCK_COUNTER=str(p/'counter'))
 def stub(name, body):
  f=p/name; f.write_text('#!/bin/bash\n'+body+'\n'); f.chmod(0o755)
 stub('sleep','exit 0')
 stub('curl','[[ "${*: -1}" != *repo.maven.apache.org* ]]')
 r=subprocess.run(['bash',str(root/'maven_preflight.sh')],env=env,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr
 assert (p/'env').read_text()=='KINERA_CENTRAL_ENDPOINT=repo1\n'
 stub('curl','exit 6');r=subprocess.run(['bash',str(root/'maven_preflight.sh')],env=env,capture_output=True,text=True);assert r.returncode!=0 and 'Both official Maven' in r.stdout
 stub('curl','exit 0');(p/'env').unlink();r=subprocess.run(['bash',str(root/'maven_preflight.sh')],env=env,capture_output=True,text=True);assert r.returncode==0 and (p/'env').read_text()=='KINERA_CENTRAL_ENDPOINT=apache\n'
 stub('gradle','n=0; [[ ! -f "$MOCK_COUNTER" ]] || n=$(cat "$MOCK_COUNTER"); n=$((n+1)); echo "$n" > "$MOCK_COUNTER"; if [[ $n == 1 ]]; then echo "Could not GET Maven POM"; exit 1; fi; echo success')
 r=subprocess.run(['bash',str(root/'gradle_ci.sh'),str(p/'gradle.log'),'help'],env=env,capture_output=True,text=True);assert r.returncode==0 and (p/'counter').read_text().strip()=='2'
 stub('gradle','echo "MainActivity.java:42: error: cannot find symbol"; exit 7');r=subprocess.run(['bash',str(root/'gradle_ci.sh'),str(p/'gradle.log'),'help'],env=env,capture_output=True,text=True);assert r.returncode==7 and 'attempt 2' not in r.stdout
print('Maven CI: primary, alternate, both-down, transient retry and compiler-failure exit checks passed (mocked).')
