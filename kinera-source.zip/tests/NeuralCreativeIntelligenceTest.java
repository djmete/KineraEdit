package az.kinera.edit;
public final class NeuralCreativeIntelligenceTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  check(KineraAI.VERSION.equals("8.7"));
  check(CutConfidence.probability(.8f,.02f,.04f)>CutConfidence.probability(.8f,.6f,.9f));
  check(CutConfidence.probability(Float.POSITIVE_INFINITY,0,0)==0);
  int[] p=new int[64*4];java.util.Arrays.fill(p,0,128,0xff000000);java.util.Arrays.fill(p,128,192,0xff30a147);java.util.Arrays.fill(p,192,256,0xff3656c8);int v=KineraAI.paletteFor(p);check(v==29||v==30||v==33);
  java.util.Arrays.fill(p,0xff000000);check(KineraAI.paletteFor(p)==33);
  System.out.println("NeuralCreativeIntelligenceTest: model, finite inputs, palette fallback passed");
 }
}
