package az.kinera.edit;
public final class BackgroundStudioTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  check(AudioLevelMath.recommend(.3,.9,100)==10);check(AudioLevelMath.recommend(.16,.6,100)==14);check(AudioLevelMath.recommend(.06,.2,100)==18);check(AudioLevelMath.recommend(.01,.1,100)==20);check(AudioLevelMath.recommend(0,0,0)==10);check(AudioLevelMath.recommend(Double.NaN,0,2)==10);check(AudioLevelMath.recommend(.01,1,100)==15);
  AudioLevelMath.Meter m=new AudioLevelMath.Meter();for(int i=0;i<1000;i++)m.add(i%2==0?.1f:-.1f);check(m.gain()==16);m.add(Float.NaN);check(m.n==1000);
  long d=NotificationPolicy.DAY;check(!NotificationPolicy.dailyDue(false,5*d,0,false));check(!NotificationPolicy.dailyDue(true,5*d,0,true));check(!NotificationPolicy.dailyDue(true,5*d,5*d-1000,false));check(NotificationPolicy.dailyDue(true,5*d,4*d,false));check(!NotificationPolicy.dailyDue(true,5*d,6*d,false));
  for(String l:new String[]{"az","tr","en","ru"}){UiLanguage.set(l,l);String t=String.format(java.util.Locale.ROOT,UiLanguage.tr("Bu gün %d video hazırdır. Şəxsi hədəfə qalan: %d."),3,2);check(t.contains("3")&&t.contains("2"));}
  long[] times={1000000,2000000,3000000,4000000,5000000,6000000,7000000};
  check(SceneMath.studioCandidates(times,new float[]{.02f,.03f,.60f,.02f,.03f,.02f,.01f},9000000).length==1);
  check(SceneMath.studioCandidates(times,new float[]{.4f,.4f,.4f,.4f,.4f,.4f,.4f},9000000).length==0);
  System.out.println("PASS: auto audio thresholds, PCM meter, opt-in daily reminders, four localized summaries");
 }
}
