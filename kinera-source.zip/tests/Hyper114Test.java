package az.kinera.edit;
final class Hyper114Test {
 static void ok(boolean x){if(!x)throw new AssertionError();}
 public static void main(String[] a){for(int i=0;i<32;i++)ok(Hyper114Workspace.publish((i&1)!=0,(i&2)!=0,(i&4)!=0,(i&8)!=0,(i&16)!=0)==(i==3));for(int i=0;i<10;i++){ok(Hyper114Workspace.cancelTouch(i)==(i==3||i==5));ok(Hyper114Workspace.terminal(i)==(i==1||i==3));}ok(Hyper114Workspace.transportWidth(320,1,true)==48);ok(Hyper114Workspace.transportWidth(400,1,true)==56);ok(Hyper114Workspace.transportWidth(400,1.4f,true)==48);for(int i=2884;i<2934;i++){ok(RegionMath.active(Hyper114TemplatePolicy.window(i)));ok(BrandMotionMath.motionKind(i)>=136&&BrandMotionMath.motionKind(i)<146);}ok(Hyper114TemplatePolicy.choose(132,1.7f,CreativePolicy.LANDSCAPE,4)>=2884);ok(Hyper114TemplatePolicy.choose(2784,1.7f,CreativePolicy.PERSON,4)==2784);System.out.println("Hyper114: 32 lifecycle states, touch policy, compact transport and 50 templates passed");}
}
