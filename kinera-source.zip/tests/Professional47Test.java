package az.kinera.edit;
import java.nio.file.*;
final class Professional47Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
 int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai47_anchor_parity.csv"))){if(line.startsWith("corr,"))continue;String[] x=line.split(",");double[] f=new double[6];for(int i=0;i<6;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(AnchorRisk.probability(f)-Double.parseDouble(x[6])));n++;}check(n==32&&max<1e-8&&!AnchorRisk.ENABLED);
 long[] c={1000000,1100000,5000000};check(DirectorMath.effectWidth(c,0,6000000,220000)==33333);check(DirectorMath.visual(c,1000000,6000000,Float.NaN)==0);check(DirectorMath.visual(c,1040000,6000000,.1f)==0);check(DirectorMath.zoom(c,1000000,6000000,Float.NaN,false)==1);check(DirectorMath.effectWidth(c,-1,6000000,220000)==0);
 float[] r={.2f,.2f,.5f,.5f};check(java.util.Arrays.equals(RegionMath.move(r,Float.NaN,0),r));check(!RegionMath.active(RegionMath.display(20,20,0)));check(!RegionMath.active(RegionMath.move(null,0,0)));
 System.out.println("Professional47Test OK; 32 anchor parity rows, max error="+max);
 }}
