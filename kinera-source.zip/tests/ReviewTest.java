package az.kinera.edit;
import java.util.Arrays;
public class ReviewTest {
 static EditSpec s(int height,int fps,boolean mute,float crop){return new EditSpec("BayEfendiFilm",0,height,fps,crop,0,false,true,false,80000000,0,0,1,1,.1f,new long[]{4000000},mute);}
 public static void main(String[] args){
  PreviewKey a=new PreviewKey(s(854,30,false,0)),b=new PreviewKey(s(854,60,true,0));if(!a.equals(b)||a.hashCode()!=b.hashCode()||a.equals(new PreviewKey(s(854,30,false,.1f))))throw new AssertionError("render key");
  if(QualityReview.durationOk(60000000)||!QualityReview.durationOk(60000001)||QualityReview.validSource(0,720,100)||!QualityReview.validSource(720,1280,100)||!QualityReview.heavySource(3840,2160))throw new AssertionError("quality boundaries");
  long[] cuts=SceneMath.adaptiveCandidates(new long[]{1000000,2000000,3000000,4000000,5000000,6000000,7000000,8000000,9000000},new float[]{.05f,.4f,.05f,.8f,.05f,Float.NaN,.05f,.05f,.05f},11000000);if(!Arrays.equals(cuts,new long[]{4000000}))throw new AssertionError(Arrays.toString(cuts));
  if(SceneMath.adaptiveCandidates(new long[]{1000000},new float[]{Float.NaN},3000000).length!=0)throw new AssertionError("invalid scores");
  System.out.println("PASS: preview identity, quality checks, strongest cut spacing, invalid samples");
 }
}
