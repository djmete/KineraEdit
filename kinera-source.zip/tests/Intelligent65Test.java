package az.kinera.edit;
import java.util.*;import java.nio.file.*;
final class Intelligent65Test {
 static void check(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ReleaseHighlightPolicy.shouldShowForRelease(0,false,true,true,76,76,true));check(ReleaseHighlightPolicy.shouldShowForRelease(75,false,true,true,76,76,true));check(!ReleaseHighlightPolicy.shouldShowForRelease(76,false,true,true,76,76,true));check(!ReleaseHighlightPolicy.shouldShowForRelease(77,false,true,true,77,76,true));
  check(!ReleaseHighlightPolicy.shouldShowForRelease(70,false,true,true,76,75,true));check(!ReleaseHighlightPolicy.shouldShowForRelease(70,false,true,true,77,76,true));check(ReleaseHighlightPolicy.mark(70,77)==77);check(!ReleaseHighlightPolicy.shouldShowForRelease(70,false,true,true,76,76,false));check(!ReleaseHighlightPolicy.shouldShowForRelease(70,true,true,true,76,76,true));check(!ReleaseHighlightPolicy.shouldShowForRelease(70,false,false,true,76,76,true));
  check(IntelligentCaptionPlan.windows(1)==1&&IntelligentCaptionPlan.windows(1000000)==4&&IntelligentCaptionPlan.windows(Long.MAX_VALUE)==124);check(IntelligentCaptionPlan.UI_TIMEOUT_MS>IntelligentCaptionPlan.SCAN_TIMEOUT_MS+12000);
  float[] a={.2f,.76f,.8f,.83f},b={.2f,.92f,.8f,.98f};List<TimedRegions.Mask> masks=IntelligentCaptionPlan.build(124000000,Collections.nCopies(124,a),Collections.nCopies(124,b));check(masks.size()==248&&FullCaptionPlan.covered(masks)==124000000);
  for(long pos:new long[]{-1,0,499999,500000,123999999,124000000}){float[] r=new float[12],m=new float[3],r2=new float[12],m2=new float[3];TimedRegions.fillBoth(masks,pos,r,m);TimedRegions.fill(masks,pos,r2);TimedRegions.fillModes(masks,pos,m2);check(Arrays.equals(r,r2)&&Arrays.equals(m,m2));}
  int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai65_corner_parity.csv"))){String[] v=line.split(",");max=Math.max(max,Math.abs(CornerRestoreConfidence.score(Double.parseDouble(v[0]),Double.parseDouble(v[1]))-Double.parseDouble(v[2])));n++;}check(n==32&&max<1e-9);System.out.println("Intelligent65Test OK: latest-only major feature, skipped releases, 248 masks, one-pass rectangle/mode parity, corner model parity "+max);
 }
}
