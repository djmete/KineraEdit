package az.kinera.edit;
public class GalleryRenderTest {public static void main(String[] args){
 if(!GalleryMath.resolution(1920,1080).equals("FHD")||!GalleryMath.resolution(2160,3840).equals("4K")||!GalleryMath.size(1048576).equals("1.0 MB"))throw new AssertionError("gallery metadata");
 if(ExportSafety.lower(854,24,false,1280,24)||ExportSafety.lower(854,24,false,854,24)||!ExportSafety.lower(854,24,true,854,24))throw new AssertionError("fallback");
 EditSpec s=new EditSpec("Test",0,1920,30,0,0,true,true,true,61000000,0,0,1,1,0,new long[0],false,true).withBlurStrength(2.1f);
 if(s.withEncoding(1280,24,false).blurStrength!=2.1f||s.withHeight(854).blurStrength!=2.1f)throw new AssertionError("blur snapshot");
 if(new PreviewKey(s).equals(new PreviewKey(s.withHeight(1920).withBlurStrength(.65f))))throw new AssertionError("preview identity");
 if(BrandMotionMath.layoutFor(29,.56f)!=43||BrandMotionMath.layoutFor(29,1.77f)!=29||BrandMotionMath.layoutFor(37,1.77f)!=29)throw new AssertionError("portrait composition");
 System.out.println("PASS: gallery metadata, non-upscaling retry, blur snapshot and preview identity");}}
