package az.kinera.edit;
import java.nio.file.*;
final class Creative67Test {
 static void check(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ExpertTemplatePolicy.TOTAL==1634);check(!ReleaseHighlightPolicy.shouldShowForRelease(0,false,true,true,78,78,false));
  for(int i=222;i<228;i++){check(RegionMath.active(CreativeTemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)==72+i-222);check(BrandMotionMath.periodUs(i)>0);EditSpec s=new EditSpec("Test",i,720,30,0,0,false,false,false,1000000,0,0,1,1,0,new long[0],false);check(s.template==i&&s.withEncoding(480,24,false).template==i);}
  check(CreativeTemplatePolicy.choose(180,.56f,1,5)==222);check(CreativeTemplatePolicy.choose(180,1.77f,2,5)==224);check(CreativeTemplatePolicy.choose(180,1f,3,5)==180);
  int n=0;double max=0;for(String l:Files.readAllLines(Path.of("tests/kai67_texture_parity.csv"))){String[] v=l.split(",");double[] x=new double[8];for(int i=0;i<8;i++)x[i]=Double.parseDouble(v[i]);max=Math.max(max,Math.abs(CreativeRestoreConfidence.blend(x)-Double.parseDouble(v[8])));n++;}check(n==32&&max<1e-9);check(!CreativeRestoreConfidence.ENABLED);System.out.println("Creative67Test OK: new template IDs, retained inactive candidate, parity="+max);
 }
}
