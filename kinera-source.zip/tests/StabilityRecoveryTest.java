package az.kinera.edit;
public final class StabilityRecoveryTest {
 public static void main(String[] args){
  if(KAiEdit.prepPercent(0,64)!=0||KAiEdit.prepPercent(64,64)!=9||KAiEdit.prepPercent(100,64)!=9||KAiEdit.prepPercent(-1,64)!=0||KAiEdit.prepPercent(1,0)!=0||KAiEdit.prepPercent(32,64)!=4)throw new AssertionError("Preparation progress");
  int last=0;for(int i=0;i<=64;i++){int v=KAiEdit.prepPercent(i,64);if(v<last||v>9)throw new AssertionError("Progress order");last=v;}
  System.out.println("StabilityRecoveryTest passed");
 }
}
