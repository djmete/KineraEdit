package az.kinera.edit;
import java.nio.file.*;
final class DeepVisionTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
 int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai46_exposure_parity.csv"))){if(line.startsWith("mean,"))continue;String[] x=line.split(",");double[] f=new double[6];for(int i=0;i<6;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(ExposureRisk.probability(f)-Double.parseDouble(x[6])));n++;}check(n==32&&max<1e-8);
 int[] rgb=new int[100];java.util.Arrays.fill(rgb,0xffffff);double[] f=ExposureRisk.features(rgb);check(f[0]==1&&f[3]==1&&f[4]==1&&f[1]==0);check(ExposureRisk.features(null)==null);check(ExposureRisk.probability(new double[]{Double.NaN,0,0,0,0,0})==0);
 int[] g={60,55,52};int[] result=ExposureRisk.guard(rgb,g);check(result[0]<=60&&result[1]<=55&&result[2]==52);
 float[] a={.1f,.2f,.4f,.5f},b={.2f,.2f,.5f,.5f};check(TemporalPolicy.recentTrackingStep(12,a,b,a)==500000L);check(TemporalPolicy.recentTrackingStep(12,b,b,b)==2000000L);
 System.out.println("DeepVisionTest OK; 32 model parity rows, max error="+max);
 }
}
