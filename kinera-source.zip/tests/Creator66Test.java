package az.kinera.edit;
import java.util.*;import java.nio.file.*;
final class Creator66Test {
 static void check(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(!ReleaseHighlightPolicy.shouldShowForRelease(0,false,true,true,77,77,false));check(ReleaseHighlightPolicy.CURRENT_RELEASE==127);
  check(ExpertTemplatePolicy.TOTAL==3034);for(int i=216;i<222;i++){check(RegionMath.active(CreatorTemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)==72+i-216);check(BrandMotionMath.periodUs(i)>0);EditSpec s=new EditSpec("Test",i,720,30,0,0,false,false,false,1000000,0,0,1,1,0,new long[0],false);check(s.template==i&&s.withEncoding(480,24,false).template==i);}
  check(CreatorTemplatePolicy.choose(180,.56f,1,4)==216);check(CreatorTemplatePolicy.choose(180,1.77f,2,4)==218);check(CreatorTemplatePolicy.choose(180,1f,3,4)==180);
  float[] a={.1f,.2f,.5f,.4f};Random rng=new Random(66);for(int test=0;test<400;test++){List<TimedRegions.Mask> masks=new ArrayList<>();for(int i=0;i<rng.nextInt(30);i++){long start=rng.nextInt(100);masks.add(new TimedRegions.Mask(a,start,start+1+rng.nextInt(10),true));}boolean expected=true;for(TimedRegions.Mask m:masks){int n=0;for(TimedRegions.Mask v:masks)if(v.from<=m.from&&v.until>m.from)n++;if(n>3)expected=false;}boolean accepted=true;try{check(TimedRegions.snapshot(masks).equals(masks));}catch(IllegalArgumentException e){accepted=false;}check(accepted==expected);}
  int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai66_perimeter_parity.csv"))){String[] v=line.split(",");max=Math.max(max,Math.abs(PerimeterRestoreConfidence.score(Double.parseDouble(v[0]),Double.parseDouble(v[1]))-Double.parseDouble(v[2])));n++;}check(n==32&&max<1e-9);System.out.println("Creator66Test OK: minor highlight suppressed, template IDs, 400 randomized mask concurrency comparisons, neural parity "+max);
 }
}
