package az.kinera.edit;
import java.nio.file.*;
final class Expert52Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ExpertTemplatePolicy.COUNT==156);for(int i=138;i<156;i++){float[] w=ExpertTemplatePolicy.window(i);check(RegionMath.active(w));check(BrandMotionMath.motionKind(i)>=42&&BrandMotionMath.motionKind(i)<48);}
  check(ExpertTemplatePolicy.choose(126,.56f,1)==138);check(ExpertTemplatePolicy.choose(132,1.77f,2)==156);check(ExpertTemplatePolicy.choose(130,1f,3)==154);check(ExpertTemplatePolicy.choose(88,.8f,0)==88);check(ExpertTemplatePolicy.choose(88,Float.NaN,2)==88);
  float[] a={.1f,.2f,.3f,.4f},b={.2f,.1f,.4f,.3f},c={.3f,.3f,.5f,.5f},r=VisionMath.sweptThree(a,b,c);check(Math.abs(r[0]-.092f)<.00001f&&Math.abs(r[3]-.508f)<.00001f);
  int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai52_appearance_parity.csv"))){if(line.startsWith("f0,"))continue;String[] x=line.split(",");double[] f=new double[6];for(int i=0;i<6;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(ExpertConfidence.probability(f)-Double.parseDouble(x[6])));n++;}check(n==32&&max<1e-8);check(!ExpertConfidence.ENABLED);
  System.out.println("Expert52Test OK: template IDs, geometry, swept masks and 32 parity rows; max error="+max);
 }
}
