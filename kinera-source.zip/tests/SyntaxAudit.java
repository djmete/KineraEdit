import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.nio.file.*;
import java.util.*;
/** Parse (not type-check) every Android Java file on hosts without an Android SDK. */
public final class SyntaxAudit {
 public static void main(String[] args) throws Exception {
  JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
  if(compiler==null)throw new IllegalStateException("JDK compiler unavailable");
  List<Path> paths=new ArrayList<>();
  try(var walk=Files.walk(Path.of("app/src/main/java"))){walk.filter(p->p.toString().endsWith(".java")).forEach(paths::add);}
  DiagnosticCollector<JavaFileObject> diag=new DiagnosticCollector<>();
  try(StandardJavaFileManager files=compiler.getStandardFileManager(diag,Locale.ROOT,null)){
   var units=files.getJavaFileObjectsFromPaths(paths);
   JavacTask task=(JavacTask)compiler.getTask(null,files,diag,List.of("-proc:none"),null,units);
   task.parse();
   long errors=diag.getDiagnostics().stream().filter(d->d.getKind()==Diagnostic.Kind.ERROR).peek(System.err::println).count();
   if(errors!=0)throw new IllegalStateException("Android Java syntax audit failed: "+errors);
  }
  System.out.println("SyntaxAudit OK: "+paths.size()+" Java source files parsed");
 }
}
