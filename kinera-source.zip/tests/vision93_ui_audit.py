from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();n=(p/'StudioNotifications.java').read_text();a=(p/'AutoPlan.java').read_text()
assert 'root.addView(stagePlayer,stageLp)' in s and 'new LinearLayout.LayoutParams(-1,0,1)' in s
assert all(x in s for x in ['editorDock.addView(playback','editorDock.addView(clipTimeline','editorDock.addView(timelineSeek','buildBlurAdjust(editorDock)','editorDock.addView(actions','header.addView(editorHistory','this::showReleaseNews','showReleaseHighlight(true)','showReleaseHighlight(false)','this::testStudioNotification'])
assert 'if(!StudioNotifications.allowed(this))' in s and 'channelAllowed(c,DONE)' in n and 'notify(3704' in n
assert a.count('Vision93.score(')==2
print('Vision93 UI source audit: weighted preview, dedicated dock, explicit news, notification permission/channel checks, scene guard wiring passed')
