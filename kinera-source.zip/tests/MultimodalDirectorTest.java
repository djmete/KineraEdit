package az.kinera.edit;
import java.nio.file.*;
final class MultimodalDirectorTest {
 static void check(boolean b,String msg){if(!b)throw new AssertionError(msg);}
 public static void main(String[] args)throws Exception{
  AccentRisk m=new AccentRisk();double error=0;int n=0;
  for(String line:Files.readAllLines(Path.of("tests/kai43_audio_parity.csv"))){if(line.startsWith("rms"))continue;String[] s=line.split(",");double p=m.probability(Float.parseFloat(s[0]),Float.parseFloat(s[1]),Float.parseFloat(s[2]),Float.parseFloat(s[3]));error=Math.max(error,Math.abs(p-Double.parseDouble(s[4])));n++;}
  check(n==32&&error<1e-5,"Python/Java inference parity: "+error);check(m.probability(Float.NaN,0,0,0)==1,"invalid audio");
  check(m.gate(.9f,1,.7f,.1f)<=1,"never amplify");check(m.gate(.9f,1,.7f,.1f)<1,"strong audio protected");
  RhythmMath r=new RhythmMath();for(int i=0;i<200;i++)r.push(.8f,1000);check(r.push(.8f,1000)<=.35f,"protect loud audio");r.reset();check(r.push(0,1000)==1,"reset");
  System.out.println("MultimodalDirectorTest OK; 32 inference parity rows, max error="+error);
 }
}
