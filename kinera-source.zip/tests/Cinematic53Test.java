package az.kinera.edit;
import java.nio.file.*;
final class Cinematic53Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ExpertTemplatePolicy.TOTAL==198);for(int i=156;i<162;i++){check(BrandMotionMath.motionKind(i)==48+i-156);check(BrandMotionMath.periodUs(i)>0);check(BrandMotionMath.motionPhase(BrandMotionMath.periodUs(i),i)==0);}
  check(ExpertTemplatePolicy.choose(132,1.77f,2)==156);check(ExpertTemplatePolicy.choose(132,1.4f,2)==144);check(DirectorMath.styleAmount(156,.1f)<.1f);check(DirectorMath.styleAmount(155,.1f)==.1f);
  check(PreviewRecovery.startPosition(5000,5000,1)==4900);check(PreviewRecovery.startPosition(5000,5000,0)==5000);check(PreviewRecovery.startPosition(-1,50,2)==0);
  check(ExportSafety.stallMs(1000000)==180000);check(ExportSafety.stallMs(2000000000L)==900000);check(!ExportSafety.stalled(179999,0,1000000));check(ExportSafety.stalled(180000,0,1000000));
  int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai53_appearance_parity.csv"))){if(line.startsWith("f0,"))continue;String[] x=line.split(",");double[] f=new double[6];for(int i=0;i<6;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(CinematicConfidence.probability(f)-Double.parseDouble(x[6])));n++;}check(n==32&&max<1e-8);check(!CinematicConfidence.ENABLED&&CinematicConfidence.SCHEDULING_ENABLED);check(!SupremeTrackPolicy.cautious(new double[]{Double.NaN,0,0,0,1,0}));
  System.out.println("Cinematic53Test OK: six new motion IDs, preview endpoint recovery, export stall boundaries and 32 parity rows; max error="+max);
 }
}
