"""Targeted javac regression against narrow Android stubs; not an Android SDK build."""
import pathlib,re,subprocess,tempfile,sys
p=pathlib.Path('app/src/main/java/az/kinera/edit');cp=sys.argv[1]
with tempfile.TemporaryDirectory() as td:
 d=pathlib.Path(td)
 def put(name,body):
  f=d/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(body);return f
 def stub(pkg,n,b):return put(pkg.replace('.','/')+'/'+n+'.java','package '+pkg+';public class '+n+b)
 g='android.graphics'
 stub(g,'Bitmap','{public enum Config{ARGB_8888}public static Bitmap createBitmap(int w,int h,Config c){return new Bitmap();}}')
 stub(g,'Canvas','{public Canvas(Bitmap b){}public void scale(float x,float y){}public void drawRect(float a,float b,float c,float d,Paint p){}public void drawRect(RectF r,Paint p){}public void drawRoundRect(float a,float b,float c,float d,float x,float y,Paint p){}public void drawRoundRect(RectF r,float x,float y,Paint p){}public void drawArc(float a,float b,float c,float d,float e,float f,boolean x,Paint p){}public void drawCircle(float a,float b,float c,Paint p){}public void drawLine(float a,float b,float c,float d,Paint p){}public void drawText(String s,float x,float y,Paint p){}public void drawPath(Path path,Paint p){}}')
 stub(g,'Paint','{public Paint(int n){}public Paint(Paint p){}public enum Style{STROKE,FILL}public enum Align{CENTER,LEFT,RIGHT}public static class FontMetricsInt{public int bottom,top;}public FontMetricsInt getFontMetricsInt(){return new FontMetricsInt();}public void setShader(Shader s){}public void setStyle(Style s){}public void setColor(int c){}public void setStrokeWidth(float w){}public void setTypeface(Typeface t){}public void setTextSize(float s){}public float getTextSize(){return 12;}public float measureText(String s){return 10;}public void setTextAlign(Align a){}public void setXfermode(PorterDuffXfermode m){}public void setAlpha(int a){}}')
 stub(g,'Shader','{public enum TileMode{CLAMP}}');stub(g,'LinearGradient',' extends Shader{public LinearGradient(float a,float b,float c,float d,int e,int f,TileMode m){}}')
 stub(g,'RectF','{public float left,top,right,bottom;public RectF(float l,float t,float r,float b){left=l;top=t;right=r;bottom=b;}public float centerY(){return (top+bottom)/2;}}')
 stub(g,'Path','{public void moveTo(float x,float y){}public void lineTo(float x,float y){}public void close(){}public void cubicTo(float a,float b,float c,float d,float e,float f){}public void quadTo(float a,float b,float c,float d){}}')
 stub(g,'Color','{public static int rgb(int a,int b,int c){return 0;}public static int red(int a){return 0;}public static int green(int a){return 0;}public static int blue(int a){return 0;}}')
 stub(g,'Typeface','{public static final int BOLD=1;public static Typeface create(String s,int i){return new Typeface();}}')
 stub(g,'PorterDuff','{public enum Mode{CLEAR}}');stub(g,'PorterDuffXfermode','{public PorterDuffXfermode(PorterDuff.Mode m){}}')
 stub('android.text','TextPaint',' extends android.graphics.Paint{public TextPaint(android.graphics.Paint p){super(p);}}')
 stub('android.text','TextUtils','{public enum TruncateAt{END}public static CharSequence ellipsize(CharSequence s,TextPaint p,float w,TruncateAt t){return s;}}')
 stub('android.graphics.drawable','Drawable','{}')
 stub('android.view','View','{public static final int VISIBLE=0,GONE=8;public int getVisibility(){return 0;}public void setVisibility(int v){}public ViewGroup.LayoutParams getLayoutParams(){return null;}public void setLayoutParams(ViewGroup.LayoutParams p){}}')
 stub('android.view','ViewGroup',' extends View{public static class LayoutParams{public int width,height;}public int getChildCount(){return 0;}public View getChildAt(int i){return null;}}')
 stub('android.widget','LinearLayout',' extends android.view.ViewGroup{public static class LayoutParams extends android.view.ViewGroup.LayoutParams{public float weight;}public void setPadding(int a,int b,int c,int d){}}')
 stub('android.widget','HorizontalScrollView',' extends android.view.ViewGroup{}')
 stub('android.widget','Button',' extends android.view.View{public android.graphics.drawable.Drawable[] getCompoundDrawablesRelative(){return new android.graphics.drawable.Drawable[4];}public void setCompoundDrawablesRelative(android.graphics.drawable.Drawable a,android.graphics.drawable.Drawable b,android.graphics.drawable.Drawable c,android.graphics.drawable.Drawable d){}public void setCompoundDrawablesRelativeWithIntrinsicBounds(android.graphics.drawable.Drawable a,android.graphics.drawable.Drawable b,android.graphics.drawable.Drawable c,android.graphics.drawable.Drawable d){}public android.graphics.Paint getPaint(){return new android.graphics.Paint(0);}}')
 src=(p/'MainActivity.java').read_text();field=re.search(r'\b(\w+) editorTools;',src).group(0);method=next(l for l in src.splitlines() if l.strip().startswith('void syncEditorWorkspace()'))
 base='package az.kinera.edit;import android.view.*;import android.widget.*;class WorkspaceProbe{boolean blurSliderDragging,editorFocus,timelineDecoding,timelineAbort,firstPreviewFrame;Object player;Runnable timelineAfterFrame;static class Handler{void removeCallbacks(Runnable r){}}Handler handler=new Handler();void scheduleTimelineAfterFrame(){}int regionMode,currentPage;static final int EDITOR=3;LinearLayout editorPlayback;HorizontalScrollView editorToolsScroll;View timelineSeek,clipTimeline,editorInfo,header;int rootHeightDp(){return 700;}int dp(int x){return x;}void syncCompactBlurControls(){}Resources getResources(){return new Resources();}static class Resources{Config getConfiguration(){return new Config();}}static class Config{int screenWidthDp;float fontScale;}'
 ws=put('az/kinera/edit/WorkspaceProbe.java',base+field+method+'} class StudioIcon extends android.graphics.drawable.Drawable{StudioIcon(Object a,int b){}}')
 art=put('az/kinera/edit/TemplateArt.java',(p/'TemplateArt.java').read_text())
 put('az/kinera/edit/TemplateProbe.java','package az.kinera.edit;public class TemplateProbe{public static void main(String[] a){if(TemplateArt.NAMES.length!=1634||TemplateArt.BG.length!=1634||TemplateArt.ACC.length!=1634)throw new AssertionError();for(int i=0;i<1634;i++){TemplateArt.make(72,128,i,"Test",true);TemplateArt.make(72,128,i,"Test",false);}System.out.println("All 1634 template code paths completed against stubs (not pixel rendering)");}}')
 def compile_all():return subprocess.run(['javac','--release','17','-cp',cp,'-d',str(d/'classes'),*map(str,d.rglob('*.java'))],capture_output=True,text=True)
 res=compile_all();assert res.returncode==0,res.stderr
 subprocess.run(['java','-cp',str(d/'classes')+':'+cp,'az.kinera.edit.TemplateProbe'],check=True)
 original=art.read_text();art.write_text(original.replace('cornerLength','k'));res=compile_all();assert res.returncode!=0 and 'variable k is already defined' in res.stderr,res.stderr;art.write_text(original)
 original=ws.read_text();ws.write_text(original.replace(field,'View editorTools;'));res=compile_all();assert res.returncode!=0 and 'getChildCount' in res.stderr and 'cannot find symbol' in res.stderr,res.stderr;ws.write_text(original)
 print('Compiler regression: fixed TemplateArt and extracted workspace method compile; both historical bugs reproduced by negative controls.')
