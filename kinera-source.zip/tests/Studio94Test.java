package az.kinera.edit;
import java.util.*;
final class Studio94Test {
 static void ok(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] args){
  ok(Studio94.height(1920,1080,false,false,256,false)==1920);ok(Studio94.height(1080,1920,true,false,512,false)==1280);ok(Studio94.height(1080,1920,false,false,512,true)==1280);ok(Studio94.height(640,480,false,false,512,false)==1280);
  ok(Studio94.fps(25)==25);ok(Studio94.fps(60)==30);ok(Studio94.fps(15)==15);ok(Studio94.fps(Float.NaN)==30);
  ok(Studio94.strength(0)==.65f&&Studio94.strength(1)==1f&&Studio94.strength(2)==2.1f);ok(Studio94.strength(Studio94.encode(100))==12f);ok(Studio94.percent(Studio94.encode(63))==63);ok(Studio94.normalize(201)==200);float prev=0;for(int i=0;i<=100;i++){float v=Studio94.strength(Studio94.encode(i));ok(v>=prev);prev=v;}
  float[] a={.2f,.7f,.8f,.75f},b={.202f,.701f,.802f,.751f},z=RegionMath.empty(),other={.01f,.86f,.25f,.93f};ok(Studio94CaptionPlan.bridge(a,b));ok(!Studio94CaptionPlan.bridge(a,other));
  long d=300000L;List<TimedRegions.Mask> p=Studio94CaptionPlan.build(d,Arrays.asList(a,b),Arrays.asList(z,b),true);ok(FullCaptionPlan.covered(p)==d);for(TimedRegions.Mask m:p)ok(m.restore);
  List<TimedRegions.Mask> q=Studio94CaptionPlan.build(d,Arrays.asList(a,b),Arrays.asList(z,b),false);ok(FullCaptionPlan.covered(q)==d);for(TimedRegions.Mask m:q)ok(!m.restore);
  d=120000000L;int n=StableCaptionPlan.windows(d);ArrayList<float[]> l=new ArrayList<>(),r=new ArrayList<>();for(int i=0;i<n;i++){l.add(a);r.add(i==0?z:b);}p=Studio94CaptionPlan.build(d,l,r,true);ok(FullCaptionPlan.covered(p)<d);ok(FullCaptionPlan.covered(p)>d-1000000L);
  ok(Studio94CaptionPlan.build(300000L,Arrays.asList(z,z),Arrays.asList(z,z),false).isEmpty());float[] edge={0f,.75f,1f,1f};ok(!RestorePolicy.usable(edge));ok(Studio94CaptionPlan.build(300000L,Arrays.asList(edge,edge),Arrays.asList(edge,edge),true).isEmpty());ok(FullCaptionPlan.covered(Studio94CaptionPlan.build(300000L,Arrays.asList(edge,edge),Arrays.asList(edge,edge),false))==300000L);
  for(int i=1484;i<1534;i++)ok(RegionMath.active(Studio94TemplatePolicy.window(i))&&BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);
  ok(ReleaseHighlightPolicy.shouldShow(104,false,true,true));ok(!ReleaseHighlightPolicy.shouldShow(105,false,true,true));
  System.out.println("Studio94: auto encoding, legacy strength, 101 monotone strength values, isolated OCR gap rule, blur/restore separation, 50 templates, release gate passed");
 }
}
