package az.kinera.edit;
public final class ExportValidationTest {
 static void require(boolean condition,String reason){if(!condition)throw new AssertionError(reason);}
 public static void main(String[] args){long duration=102_000_000L;
  require(ExportValidationMath.geometry(1920,1080,90,1920),"rotated portrait");
  require(ExportValidationMath.geometry(1920,1080,270,1920),"rotated portrait 270");
  require(ExportValidationMath.geometry(1920,1080,-90,1920),"negative rotation");
  require(ExportValidationMath.geometry(1080,1920,0,1920),"native portrait");
  require(ExportValidationMath.geometry(1280,720,90,1920),"encoder fallback");
  require(!ExportValidationMath.geometry(1920,1080,0,1920),"landscape rejected");
  require(!ExportValidationMath.geometry(1440,2560,0,1920),"larger than requested rejected");
  require(!ExportValidationMath.geometry(0,0,90,1920),"empty rejected");
  require(ExportValidationMath.duration(101_300_000,duration),"timestamp rounding");
  require(!ExportValidationMath.duration(90_000_000,duration),"truncated rejected");
  require(!ExportValidationMath.duration(0,duration),"zero duration rejected");
  System.out.println("PASS: 11 rotation, dimension, fallback and duration checks");
 }
}
