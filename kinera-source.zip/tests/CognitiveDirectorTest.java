package az.kinera.edit;
import java.nio.file.*;
final class CognitiveDirectorTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  float[] s={.95f,.3f};float g=DirectorMath.linkedGain(s,0,100);float l=DirectorMath.linkedSample(s[0],0,g),r=DirectorMath.linkedSample(s[1],0,g);check(l<=.96f&&Math.abs(l/r-s[0]/s[1])<.0001f);check(DirectorMath.linkedGain(s,0,0)==0);check(DirectorMath.linkedSample(Float.NaN,0,g)==0);
  check(KineraAI.refinedCut(100,null,new float[]{1})==100);check(KineraAI.refinedCut(100,new long[]{1,3,2},new float[]{.1f,.1f,.9f})==100);
  int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai45_cognitive_parity.csv"))){if(line.startsWith("a,"))continue;String[] x=line.split(",");float[] f=new float[5];for(int i=0;i<5;i++)f[i]=Float.parseFloat(x[i]);max=Math.max(max,Math.abs(CognitiveConfidence.probability(f)-Double.parseDouble(x[5])));n++;}check(n==32&&max<1e-5&&!CognitiveConfidence.ENABLED);System.out.println("CognitiveDirectorTest OK; 32 parity rows, max error="+max);
 }
}
