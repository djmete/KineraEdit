import sys, zipfile, hashlib, json, pathlib, collections
u,c,o=map(pathlib.Path,sys.argv[1:]); sha=lambda x:hashlib.sha256(x).hexdigest()
def scan(path):
 with zipfile.ZipFile(path) as z:
  assert z.testzip() is None
  info=[x for x in z.infolist() if not x.is_dir()]; cats=collections.Counter(); raw=collections.Counter()
  for x in info:
   n=x.filename; cat='/'.join(n.split('/')[:2]) if n.startswith('lib/') else 'assets' if n.startswith('assets/') else 'dex' if n.endswith('.dex') else 'other'; cats[cat]+=x.compress_size;raw[cat]+=x.file_size
  hashes={x.filename:sha(z.read(x)) for x in info if x.filename.startswith(('assets/','lib/arm64-v8a/'))}
  return dict(apk_bytes=path.stat().st_size,compressed_by_category=dict(cats),uncompressed_by_category=dict(raw)),hashes
U,uh=scan(u);C,ch=scan(c);assert uh==ch, 'Compact APK lost or changed bundled assets or ARM64 binaries';assert any(n.startswith('lib/arm64-v8a/') for n in uh),'No ARM64 libraries';assert not any(k.startswith('lib/') and k!='lib/arm64-v8a' for k in C['compressed_by_category']);result=dict(universal=U,compact_arm64=C,asset_and_arm64_entries_verified=len(uh),saved_bytes=U['apk_bytes']-C['apk_bytes'],saved_percent=100*(1-C['apk_bytes']/U['apk_bytes']));o.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
