package az.kinera.edit;
final class Reliability82Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  for(int i=884;i<934;i++){check(RegionMath.active(Reliability82TemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)>=102&&BrandMotionMath.motionKind(i)<108);check(BrandMotionMath.periodUs(i)>0);}
  check(ExpertTemplatePolicy.TOTAL==1084);check(EditorWorkspacePolicy.scrollTools(320,1));check(!EditorWorkspacePolicy.scrollTools(411,1));check(EditorWorkspacePolicy.scrollTools(411,1.4f));check(EditorWorkspacePolicy.toolWidth(1.4f)>=120);check(!EditorWorkspacePolicy.showSeparateSeek(420,0,false));check(EditorWorkspacePolicy.showSeparateSeek(800,0,false));
  check(!ExportValidationMath.duration(300000,1000000));check(ExportValidationMath.duration(960000,1000000));check(!ExportValidationMath.duration(1,200000));check(ExportValidationMath.duration(100000000,101000000));
  long[] t={800000,900000,1000000,1100000,1200000};double[] s={.02,.03,.42,.04,.02};boolean[] b=new boolean[5];check(ReliabilityCutMath.refine(1050000,t,s,b,5,350000)==1000000);b[1]=true;check(ReliabilityCutMath.refine(1050000,t,s,b,5,350000)==1050000);check(ReliabilityCutMath.refine(1050000,t,s,null,5,350000)==1050000);b[1]=false;s[1]=.20;check(ReliabilityCutMath.refine(1050000,t,s,b,5,350000)==1050000);
  check(!TemporalRestorePolicy.recent(0,80000,new long[0],60));check(TemporalRestorePolicy.recent(0,16667,new long[0],60));
  System.out.println("Reliability82: 50 template IDs, 6 motion families, responsive toolbar, short export and timestamp guards passed");
 }
}
