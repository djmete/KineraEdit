package az.kinera.edit;
public final class NeuralResilienceTest {
 public static void main(String[] args){
  int[] legacy=VisionMath.fit(610,860,176f/144);if(legacy[0]!=610||Math.abs(legacy[1]-499)>1)throw new AssertionError("legacy aspect");
  int[] portrait=VisionMath.fit(610,860,9f/16);if(portrait[0]!=484||portrait[1]!=860)throw new AssertionError("composition aspect");
  if(PreviewRecovery.next(0,false)!=PreviewRecovery.RETRY||PreviewRecovery.next(1,false)!=PreviewRecovery.RAW||PreviewRecovery.next(2,true)!=PreviewRecovery.STOP)throw new AssertionError("bounded recovery");
  AudioLevelMath.Meter quiet=new AudioLevelMath.Meter(),burst=new AudioLevelMath.Meter();for(int i=0;i<4160;i++){quiet.add(.01f);burst.add(i>=4096?.16f:.01f);}if(burst.gain()>=quiet.gain())throw new AssertionError("tail transient");
  System.out.println("NeuralResilienceTest OK: legacy aspect, composition geometry, bounded retries, tail transient");
 }
}
