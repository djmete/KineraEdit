package az.kinera.edit;
import java.util.*;
final class Ultra95Test {
 static void ok(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] args){
  ok(Ultra95.height(240,320,false,false,512,false)==480);ok(Ultra95.height(360,640,false,false,512,false)==640);ok(Ultra95.height(540,960,false,false,512,false)==960);ok(Ultra95.height(720,1280,false,false,512,false)==1280);ok(Ultra95.height(1080,1920,false,false,512,false)==1920);ok(Ultra95.height(1080,1920,true,false,512,false)==960);ok(Ultra95.height(1080,1920,false,false,512,true)==1280);ok(Ultra95.height(1080,1920,false,true,512,false)==960);
  ok(Ultra95.sequentialBudget(60000000,5000,false)==3600);ok(Ultra95.sequentialBudget(60000000,1000,false)==0);ok(Ultra95.sequentialBudget(100000000,5000,false)==0);ok(Ultra95.sequentialBudget(60000000,5000,true)==0);
  ok(Ultra95.fps(26)==26&&Ultra95.fps(15)==15&&Ultra95.fps(60)==30&&Ultra95.fps(Float.NaN)==30);ok(Ultra95.afterPrep(1920,true)==960&&Ultra95.afterPrep(640,true)==640);
  for(int h:new int[]{480,640,960,1280,1920})for(int f:new int[]{15,24,25,30,60})for(int[] a:Ultra95.fallbacks(h,f))ok(a[0]<=h&&a[1]<=f&&(a[0]<h||a[1]<f));
  float[] a={.2f,.7f,.8f,.75f},b={.21f,.701f,.79f,.751f},c={.2f,.73f,.8f,.78f};ok(Ultra95.safeUnion(a,b));ok(!Ultra95.safeUnion(a,c));float[] shortText={.46f,.78f,.54f,.82f},corner={.02f,.73f,.18f,.77f};ok(Ultra95.caption(corner,Arrays.asList(shortText))==shortText);ok(Ultra95.caption(a,Arrays.asList(shortText))==a);
  for(int i=1534;i<1584;i++)ok(RegionMath.active(Ultra95TemplatePolicy.window(i))&&BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);
  ok(EditorWorkspacePolicy.showSeparateSeek(580,2,false));ok(!EditorWorkspacePolicy.showSeparateSeek(579,2,false));ok(!EditorWorkspacePolicy.showSeparateSeek(900,2,true));
  System.out.println("Ultra95: adaptive dimensions and retry order, mask expansion guard, centered caption choice, compact seek policy passed");
 }
}
