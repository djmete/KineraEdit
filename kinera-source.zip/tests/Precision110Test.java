package az.kinera.edit;
import java.util.*;
final class Precision110Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){float[] a={.25f,.70f,.75f,.78f},b={.24f,.70f,.76f,.78f};ok(RegionMath.active(Precision110Caption.sameShotUnion(a,b,100,200,new long[]{50,250},true)));ok(!RegionMath.active(Precision110Caption.sameShotUnion(a,b,100,200,new long[]{200},true)));ok(!RegionMath.active(Precision110Caption.sameShotUnion(a,RegionMath.empty(),100,200,new long[]{},true)));ok(EditorWorkspacePolicy.showSeparateSeek(500,1,false));ok(!EditorWorkspacePolicy.showSeparateSeek(500,1,true));for(int i=2684;i<2734;i++){ok(RegionMath.active(Precision110TemplatePolicy.window(i)));ok(BrandMotionMath.motionKind(i)>=136&&BrandMotionMath.motionKind(i)<146);}System.out.println("Precision110 same-shot union, crop seek and 50 template paths passed");}
}
