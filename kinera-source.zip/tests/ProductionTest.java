package az.kinera.edit;
import java.util.*;
public class ProductionTest {
 static void check(boolean x){if(!x)throw new AssertionError();}
 public static void main(String[] args){
  ProductionMath.History h=new ProductionMath.History();float[] c=RegionMath.full(),b=RegionMath.empty();h.reset(c,b);check(!h.canUndo());float[] crop={.1f,.1f,.9f,.9f};h.push(crop,b);crop[0]=0;check(h.canUndo());check(h.undo().crop[0]==0);check(h.canRedo());check(h.redo().crop[0]==.1f);h.undo();h.push(c,new float[]{0,.5f,1,1});check(!h.canRedo());for(int i=0;i<100;i++)h.push(new float[]{i/200f,0,1,1},b);int count=0;while(h.canUndo()){h.undo();count++;}check(count==40);
  check(ProductionMath.etaSeconds(10000,25)==30);check(ProductionMath.etaSeconds(1000,20)==-1);check(ProductionMath.etaSeconds(10000,100)==-1);check(Math.abs(ProductionMath.speed(10000,50,40000000)-2)<.01);
  check(ProductionMath.validFileName("kinera_123.mp4"));check(!ProductionMath.validFileName("../kinera_123.mp4"));check(ProductionMath.recommendedHeight(3840,true,256)==1280);check(ProductionMath.recommendedHeight(1920,false,256)==1920);check(ProductionMath.boundedQueue(Arrays.asList("content://a","content://a","file:///x","content://b")).size()==2);
  System.out.println("Production history, ETA, storage and queue tests OK");
 }
}
