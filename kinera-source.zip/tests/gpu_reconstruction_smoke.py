"""Optional host EGL/GLES2 smoke test; Mesa is not an Android GPU."""
import ctypes as C, os, subprocess, tempfile, sys
legacy_corner="--legacy-corner" in sys.argv
legacy_perimeter="--legacy-perimeter" in sys.argv
legacy_side="--legacy-side" in sys.argv
from pathlib import Path
os.environ.setdefault('EGL_PLATFORM','surfaceless')
# Mesa llvmpipe crashed in prior host pixel runs; softpipe provides a non-JIT fallback.
if '--softpipe' in sys.argv:
 os.environ.setdefault('LIBGL_ALWAYS_SOFTWARE','1');os.environ.setdefault('GALLIUM_DRIVER','softpipe')
p=Path('app/src/main/java/az/kinera/edit');s=(p/'BrandEffect.java').read_text()
with tempfile.TemporaryDirectory() as tmp:
 t=Path(tmp);java='package az.kinera.edit; public class ShaderDump {\n'+'\n'.join(line.strip() for line in s.splitlines() if line.strip().startswith(('static final String VERT=','static final String FRAG=','static final String TEMPORAL_FRAG=','static final String MOTION_FRAG=','static final String DYNAMIC_FRAG=','static final String HISTORY_FRAG=','static final String ADVANCED_FRAG=','static final String PROFESSIONAL_FRAG=','static final String DEEP_FRAG=','static final String INTELLIGENT_FRAG=','static final String CREATOR_FRAG=','static final String CREATIVE_FRAG=','static final String COGNITIVE_FRAG=','static final String CONTEXT_FRAG=','static final String CINEMATIC_FRAG=','static final String MULTIMODAL_FRAG=')))+'\npublic static void main(String[] a){System.out.print(a[0].equals("v")?VERT:a[0].equals("f")?FRAG:a[0].equals("t")?TEMPORAL_FRAG:a[0].equals("m")?MOTION_FRAG:a[0].equals("d")?DYNAMIC_FRAG:a[0].equals("h")?HISTORY_FRAG:a[0].equals("a")?ADVANCED_FRAG:a[0].equals("p")?PROFESSIONAL_FRAG:a[0].equals("e")?DEEP_FRAG:a[0].equals("i")?INTELLIGENT_FRAG:a[0].equals("c")?CREATOR_FRAG:a[0].equals("n")?CREATIVE_FRAG:a[0].equals("k")?COGNITIVE_FRAG:a[0].equals("x")?CONTEXT_FRAG:a[0].equals("y")?CINEMATIC_FRAG:MULTIMODAL_FRAG);}}'
 (t/'ShaderDump.java').write_text(java);subprocess.run(['javac','-d',tmp,str(t/'ShaderDump.java'),str(p/'RestoreConfidence.java'),str(p/'TemporalRestoreConfidence.java'),str(p/'MotionRestoreConfidence.java'),str(p/'DiagonalRestoreConfidence.java'),str(p/'HistoryRestoreConfidence.java'),str(p/'TextureRestoreConfidence.java'),str(p/'ProfessionalRestoreConfidence.java'),str(p/'DeepEdgeConfidence.java'),str(p/'CornerRestoreConfidence.java'),str(p/'PerimeterRestoreConfidence.java'),str(p/'CognitiveSideConfidence.java'),str(p/'Context111Temporal.java'),str(p/'Cinematic112Temporal.java'),str(p/'Multimodal113Temporal.java')],check=True)
 shaders=[subprocess.check_output(['java','-cp',tmp,'az.kinera.edit.ShaderDump',x]) for x in ['v','f','t','m','d','h','a','p','e','i','c','n','k','x','y','z']]
E=C.CDLL('libEGL.so.1');G=C.CDLL('libGL.so.1');I=C.c_int;U=C.c_uint;P=C.c_void_p;F=C.c_float

def bind(lib,name,ret,*args):
 f=getattr(lib,name);f.restype=ret;f.argtypes=args;return f
get=bind(E,'eglGetDisplay',P,P);init=bind(E,'eglInitialize',U,P,C.POINTER(I),C.POINTER(I));choose=bind(E,'eglChooseConfig',U,P,C.POINTER(I),C.POINTER(P),I,C.POINTER(I));api=bind(E,'eglBindAPI',U,U);surf=bind(E,'eglCreatePbufferSurface',P,P,P,C.POINTER(I));ctx=bind(E,'eglCreateContext',P,P,P,P,C.POINTER(I));make=bind(E,'eglMakeCurrent',U,P,P,P,P)
display=get(None);major=I();minor=I();assert init(display,C.byref(major),C.byref(minor));assert api(0x30A0);cfg=P();n=I();attrs=(I*13)(0x3033,1,0x3040,4,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3038);assert choose(display,attrs,C.byref(cfg),1,C.byref(n)) and n.value>0
surface=surf(display,cfg,(I*5)(0x3057,64,0x3056,64,0x3038));context=ctx(display,cfg,None,(I*3)(0x3098,2,0x3038));assert surface and context and make(display,surface,surface,context)
create=bind(G,'glCreateShader',U,U);source=bind(G,'glShaderSource',None,U,I,C.POINTER(C.c_char_p),C.POINTER(I));compile=bind(G,'glCompileShader',None,U);getiv=bind(G,'glGetShaderiv',None,U,U,C.POINTER(I));info=bind(G,'glGetShaderInfoLog',None,U,I,C.POINTER(I),C.c_char_p);program=bind(G,'glCreateProgram',U);attach=bind(G,'glAttachShader',None,U,U);link=bind(G,'glLinkProgram',None,U);getp=bind(G,'glGetProgramiv',None,U,U,C.POINTER(I));infop=bind(G,'glGetProgramInfoLog',None,U,I,C.POINTER(I),C.c_char_p)
def sh(kind,src):
 h=create(kind);a=C.c_char_p(src);source(h,1,C.byref(a),None);compile(h);ok=I();getiv(h,0x8B81,C.byref(ok));buf=C.create_string_buffer(8192);info(h,len(buf),None,buf);assert ok.value,buf.value.decode();return h
vertex=sh(0x8B31,shaders[0]);programs=[]
for label,src in zip(['spatial','temporal','motion','dynamic','history','advanced','professional','deep','intelligent','creator','creative','cognitive','context111','cinematic112','multimodal113'],shaders[1:]):
 frag=sh(0x8B30,src);pr=program();attach(pr,vertex);attach(pr,frag);link(pr);ok=I();getp(pr,0x8B82,C.byref(ok));buf=C.create_string_buffer(8192);infop(pr,len(buf),None,buf);assert ok.value,buf.value.decode();programs.append(pr);print(label+' shader compile/link OK')
if "--ultra-blur" in sys.argv:
 import numpy as np
 # Use a buffer-backed vertex array rather than a ctypes client pointer. Only spatial shader.
 pr=programs[0]
 def gl(n,ret,*args):
  address=bind(E,'eglGetProcAddress',P,C.c_char_p)(n.encode())
  if not address: raise RuntimeError(n)
  return C.CFUNCTYPE(ret,*args)(address)
 use=gl('glUseProgram',None,U);use(pr)
 loc=gl('glGetUniformLocation',I,U,C.c_char_p)
 def u(n):return loc(pr,n.encode())
 one=gl('glUniform1f',None,I,F);sampler=gl('glUniform1i',None,I,I);two=gl('glUniform2f',None,I,F,F);four=gl('glUniform4fv',None,I,I,C.POINTER(F));array=gl('glUniform1fv',None,I,I,C.POINTER(F))
 gen=gl('glGenTextures',None,I,C.POINTER(U));active=gl('glActiveTexture',None,U);texture=gl('glBindTexture',None,U,U);param=gl('glTexParameteri',None,U,U,I);image=gl('glTexImage2D',None,U,I,I,I,I,I,U,U,P)
 cur=np.full((64,64,4),[50,50,50,255],np.uint8);cur[30:34,20:44,:3]=240;art=np.zeros_like(cur);ids=(U*2)();gen(2,ids)
 for i,a in enumerate([cur,art]):
  active(0x84C0+i);texture(0x0DE1,ids[i]);param(0x0DE1,0x2801,0x2601);param(0x0DE1,0x2800,0x2601);param(0x0DE1,0x2802,0x812F);param(0x0DE1,0x2803,0x812F);image(0x0DE1,0,0x1908,64,64,0,0x1908,0x1401,a.ctypes.data)
 sampler(u('src'),0);sampler(u('art'),1)
 for name,val in [('contrast',1),('saturation',1),('cutZoom',1),('fade',1),('motionPhase',-1),('brandProgress',-1)]:one(u(name),val)
 for name,v in [('fit',[0,0,1,1]),('cropRect',[0,0,1,1]),('blurRect',[.15,.35,.85,.65])]:four(u(name),1,(F*4)(*v))
 four(u('extraBlur[0]'),3,(F*12)(*([0]*12)));array(u('restoreMode[0]'),3,(F*3)(0,0,0));two(u('pixelStep'),1/64,1/64)
 genb=gl('glGenBuffers',None,I,C.POINTER(U));bindb=gl('glBindBuffer',None,U,U);buf=gl('glBufferData',None,U,C.c_ssize_t,P,U);verts=(F*8)(-1,-1,1,-1,-1,1,1,1);b=U();genb(1,C.byref(b));bindb(0x8892,b);buf(0x8892,C.sizeof(verts),C.cast(verts,P),0x88E4)
 attrib=gl('glGetAttribLocation',I,U,C.c_char_p);enable=gl('glEnableVertexAttribArray',None,U);ptr=gl('glVertexAttribPointer',None,U,I,U,C.c_ubyte,I,P);a=attrib(pr,b'position');assert a>=0;enable(a);ptr(a,2,0x1406,0,0,None)
 draw=gl('glDrawArrays',None,U,I,I);read=gl('glReadPixels',None,I,I,I,I,U,U,P);viewport=gl('glViewport',None,I,I,I,I);err=gl('glGetError',U);viewport(0,0,64,64)
 def render(step):
  two(u('stepSize'),step/64,step/64);draw(5,0,4);out=np.zeros((64,64,4),np.uint8);read(0,0,64,64,0x1908,0x1401,out.ctypes.data);assert err()==0;return out
 if "--motion101" in sys.argv:
  three=gl('glUniform3f',None,I,F,F,F);three(u('accentColor'),.9,.6,.3)
  four(u('fit'),1,(F*4)(.15,.30,.85,.70));four(u('blurRect'),1,(F*4)(0,0,0,0));
  art[:,:,:]=[35,45,55,255];art[19:45,9:55,3]=0;active(0x84C1);texture(0x0DE1,ids[1]);image(0x0DE1,0,0x1908,64,64,0,0x1908,0x1401,art.ctypes.data)
  signatures=set()
  for kind in range(126,146):
   one(u('motionKind'),kind);one(u('motionPhase'),.11);a=render(0);one(u('motionPhase'),.61);b=render(0)
   assert np.array_equal(a[27:37,25:39],b[27:37,25:39]),kind
   assert np.any(a[:14,:,:3]!=b[:14,:,:3]) or np.any(a[-14:,:,:3]!=b[-14:,:,:3]),kind
   signatures.add(a[:14,:,:3].tobytes()+a[-14:,:,:3].tobytes())
   print('GPU101 phase / interior guard passed:',kind,flush=True)
  assert len(signatures)==20, len(signatures)
  sys.exit(0)
 zero=render(0);strong=render(4);print('Ultra95 spatial pixel fixture:',int(zero[32,32,0]),int(strong[32,32,0]),int(zero[5,5,0]),int(strong[5,5,0]),flush=True)
 assert abs(int(zero[32,32,0])-240)<=2 and int(strong[32,32,0])<180 and int(zero[5,5,0])==int(strong[5,5,0]);print('Zero-strength and strong masked blur pixel smoke passed on host EGL; Android untested.')
 four(u('extraBlur[0]'),3,(F*12)(.25,.40,.75,.60,0,0,0,0,0,0,0,0));array(u('restoreMode[0]'),3,(F*3)(1,0,0));overlap=render(4);assert np.array_equal(strong[30:34,20:44],overlap[30:34,20:44]),'manual blur must win over restoration';print('Precision110 explicit Blur priority pixel fixture passed');sys.exit(0)
if "--compile-only" in sys.argv:
 print("Compile/link only: no pixel or device validation")
 sys.exit(0)
# Render a synthetic test: current frame white masked patch, previous frame gray clean background.
use=bind(G,'glUseProgram',None,U);gen=bind(G,'glGenTextures',None,I,C.POINTER(U));active=bind(G,'glActiveTexture',None,U);texture=bind(G,'glBindTexture',None,U,U);param=bind(G,'glTexParameteri',None,U,U,I);image=bind(G,'glTexImage2D',None,U,I,I,I,I,I,U,U,P);loc=bind(G,'glGetUniformLocation',I,U,C.c_char_p);one=bind(G,'glUniform1f',None,I,F);sampler=bind(G,'glUniform1i',None,I,I);two=bind(G,'glUniform2f',None,I,F,F);four=bind(G,'glUniform4fv',None,I,I,C.POINTER(F));array=bind(G,'glUniform1fv',None,I,I,C.POINTER(F));attrib=bind(G,'glGetAttribLocation',I,U,C.c_char_p);enable=bind(G,'glEnableVertexAttribArray',None,U);ptr=bind(G,'glVertexAttribPointer',None,U,I,U,U,I,P);draw=bind(G,'glDrawArrays',None,U,I,I);read=bind(G,'glReadPixels',None,I,I,I,I,U,U,P);viewport=bind(G,'glViewport',None,I,I,I,I);err=bind(G,'glGetError',U)
import numpy as np
cur=np.full((64,64,4),[100,100,100,255],np.uint8);cur[26:38,18:46,:3]=255;old=np.full((64,64,4),[100,100,100,255],np.uint8);old[30:34,30:34,:3]=140;art=np.zeros_like(cur)
ids=(U*4)();gen(4,ids)
for i,a in enumerate([cur,art,old,old]):
 active(0x84C0+i);texture(0x0DE1,ids[i]);param(0x0DE1,0x2801,0x2600);param(0x0DE1,0x2800,0x2600);param(0x0DE1,0x2802,0x812F);param(0x0DE1,0x2803,0x812F);image(0x0DE1,0,0x1908,64,64,0,0x1908,0x1401,a.ctypes.data)
pr=programs[7 if legacy_corner else 8 if legacy_perimeter else 9 if legacy_side else 11 if "--legacy-context" in sys.argv else 12 if "--context111" in sys.argv else 13 if "--cinematic112" in sys.argv else 14];use(pr)
def uniform(n):return loc(pr,n.encode())
for name,i in [('src',0),('art',1),('previousSrc',2),('olderSrc',3)]:sampler(uniform(name),i)
for name,val in [('contrast',1),('saturation',1),('cutZoom',1),('fade',1),('motionPhase',-1),('brandProgress',-1)]:one(uniform(name),val)
for name,v in [('fit',[0,0,1,1]),('cropRect',[0,0,1,1]),('blurRect',[0,0,0,0])]:four(uniform(name),1,(F*4)(*v))
four(uniform('extraBlur[0]'),3,(F*12)(.28125,.40625,.71875,.59375,*([0]*8)));array(uniform('restoreMode[0]'),3,(F*3)(1,0,0));two(uniform('pixelStep'),1/64,1/64);four(uniform('previousMasks[0]'),4,(F*16)(*([0]*16)));verts=(F*8)(-1,-1,1,-1,-1,1,1,1);a=attrib(pr,b'position');enable(a);ptr(a,2,0x1406,0,0,C.cast(verts,P));viewport(0,0,64,64)
def render(valid):
 one(uniform('previousValid'),valid);draw(5,0,4);out=(C.c_ubyte*4)();read(32,32,1,1,0x1908,0x1401,out);assert err()==0;return out[0]
sp=render(0);tm=render(1);four(uniform('previousMasks[0]'),4,(F*16)(.28,.4,.72,.6,*([0]*12)));blocked=render(1);assert abs(sp-100)<=2 and tm>sp+10 and blocked==sp,(sp,tm,blocked);print('Temporal shader pixel test OK: spatial=%d prior=%d masked-prior=%d'%(sp,tm,blocked))

# Known 2px horizontal translation (minimum shift at 64px). Clean ring around mask.
y,x=np.mgrid[:64,:64]; clean=np.zeros((64,64,4),np.uint8);clean[:,:,:3]=np.clip(60+10*(x%9)+4*(y%5),0,255)[...,None];clean[:,:,3]=255
cur=clean.copy();cur[26:38,18:46,:3]=255;old=np.roll(clean,2,axis=1)
for i,a in [(0,cur),(2,old)]:
 active(0x84C0+i);texture(0x0DE1,ids[i]);image(0x0DE1,0,0x1908,64,64,0,0x1908,0x1401,a.ctypes.data)
four(uniform('previousMasks[0]'),4,(F*16)(*([0]*16)));sp=render(0);mv=render(1);target=int(clean[32,32,0]);assert abs(mv-target)<abs(sp-target),(sp,mv,target);print('Motion shader translated fixture OK: spatial=%d motion=%d target=%d'%(sp,mv,target))

# Diagonal translation fixture: independent texture in both directions.
y,x=np.mgrid[:64,:64];clean=np.zeros((64,64,4),np.uint8);clean[:,:,:3]=np.random.default_rng(57).integers(25,190,(64,64,1),dtype=np.uint8);clean[30:35,30:35,:3]=220;clean[:,:,3]=255
cur=clean.copy();cur[26:38,18:46,:3]=255;old=np.roll(clean,(2,2),axis=(0,1))
for i,a in [(0,cur),(2,old)]:
 active(0x84C0+i);texture(0x0DE1,ids[i]);image(0x0DE1,0,0x1908,64,64,0,0x1908,0x1401,a.ctypes.data)
sp=render(0);mv=render(1);target=int(clean[32,32,0]);print('Dynamic diagonal fixture: spatial=%d dynamic=%d target=%d'%(sp,mv,target));assert abs(mv-target)<abs(sp-target),(sp,mv,target)

# Latest frame is masked; second previous clean frame can restore hidden pixel.
cur=np.full((64,64,4),[100,100,100,255],np.uint8);cur[26:38,18:46,:3]=255;old=np.full((64,64,4),[100,100,100,255],np.uint8);old[30:34,30:34,:3]=140
for i,a in [(0,cur),(2,cur),(3,old)]:
 active(0x84C0+i);texture(0x0DE1,ids[i]);image(0x0DE1,0,0x1908,64,64,0,0x1908,0x1401,a.ctypes.data)
four(uniform('previousMasks[0]'),4,(F*16)(.28,.4,.72,.6,*([0]*12)));four(uniform('olderMasks[0]'),4,(F*16)(*([0]*16)));one(uniform('olderValid'),0);sp=render(1);one(uniform('olderValid'),1);restored=render(1);four(uniform('olderMasks[0]'),4,(F*16)(.28,.4,.72,.6,*([0]*12)));blocked=render(1);assert restored>sp+10 and blocked==sp,(sp,restored,blocked);print('Second history pixel fixture: spatial=%d older=%d blocked=%d'%(sp,restored,blocked))
# Another current mask intersects the left interpolation boundary. The vertical axis remains clean.
cur=np.full((64,64,4),[100,100,100,255],np.uint8);cur[26:38,18:46,:3]=255;cur[28:36,14:20,:3]=255
active(0x84C0);texture(0x0DE1,ids[0]);image(0x0DE1,0,0x1908,64,64,0,0x1908,0x1401,cur.ctypes.data)
four(uniform('extraBlur[0]'),3,(F*12)(.28125,.40625,.71875,.59375,.21875,.4375,.3125,.5625,0,0,0,0));one(uniform('olderValid'),0);val=render(0);assert abs(val-100)<=2,val;print('Professional overlapping-mask guard: restored=%d target=100'%val)

# Left and top boundaries contaminated, right and bottom remain clean.
cur=np.full((64,64,4),[100,100,100,255],np.uint8);cur[26:38,18:46,:3]=255;cur[28:36,14:20,:3]=255;cur[36:42,28:36,:3]=255
active(0x84C0);texture(0x0DE1,ids[0]);image(0x0DE1,0,0x1908,64,64,0,0x1908,0x1401,cur.ctypes.data)
four(uniform('extraBlur[0]'),3,(F*12)(.28125,.40625,.71875,.59375,.21875,.4375,.3125,.5625,.4375,.34375,.5625,.4375));one(uniform('olderValid'),0);value=render(0);assert abs(value-100)<=2,value;print('Deep blocked-axis restoration: restored=%d target=100'%value)

# Corner-only source fixture. Main rectangle begins at x=0, so left edge is outside.
cur=np.full((64,64,4),[100,100,100,255],np.uint8);cur[26:38,0:40,:3]=255
active(0x84C0);texture(0x0DE1,ids[0]);image(0x0DE1,0,0x1908,64,64,0,0x1908,0x1401,cur.ctypes.data)
# Block top and bottom at x=32, and right at y=32; leave right-hand corners clean.
four(uniform('blurRect'),1,(F*4)(.60,.45,.67,.55));four(uniform('extraBlur[0]'),3,(F*12)(0,.40625,.625,.59375,.46,.34,.55,.40625,.46,.59375,.55,.66));one(uniform('olderValid'),0);value=render(0);assert (value>=250 if legacy_corner else abs(value-100)<=2),value;print(("Legacy" if legacy_corner else "Intelligent")+" corner-only fixture: restored=%d target=100"%value)

# All immediate edge/corner candidates blocked; only outer right corners clean.
if not legacy_corner:
 four(uniform('extraBlur[0]'),3,(F*12)(0,.40625,.625,.59375,.46,.34,.68,.40625,.46,.59375,.68,.66));value=render(0);assert (value>=250 if legacy_perimeter else abs(value-100)<=2),value;print(("Legacy" if legacy_perimeter else "Creator")+" outer-perimeter fixture: restored=%d target=100"%value)

# No clean axial or corner sample; the quarter-side position remains available.
if not legacy_corner and not legacy_perimeter:
 four(uniform('blurRect'),1,(F*4)(.60,.43,.90,.57));four(uniform('extraBlur[0]'),3,(F*12)(0,.40625,.625,.59375,.46,.23,.90,.40625,.46,.59375,.90,.80));value=render(0);assert (value>=250 if legacy_side else abs(value-100)<=2),value;print(("Legacy" if legacy_side else "Creative")+" side-only fixture: restored=%d target=100"%value)
