package az.kinera.edit;
public class ProfessionalTest {
 public static void main(String[] args){
 if(!BrandName.clean("  BayEfendiFilm  ").equals("BayEfendiFilm")||!BrandName.initials("Bay Efendi").equals("BE")||!BrandName.clean("  ").equals("Kinera Edit")||!BrandName.initials("🎬Film").equals("🎬F"))throw new AssertionError("brand name");
 if(!EditMath.validExport(720,1280,103000000,103000000)||EditMath.validExport(1280,720,103000000,103000000)||EditMath.validExport(720,1280,90000000,103000000)||EditMath.validExport(0,0,1,1))throw new AssertionError("export validation");
 if(SceneMath.distance(new int[]{0xff0000},new int[]{0x008300})<.15f)throw new AssertionError("chroma change");
 System.out.println("PASS: channel name normalization, Unicode initials, export dimensions and duration checks");
 }
}
