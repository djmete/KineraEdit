from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();d=(p/'KAiDirector.java').read_text();b=(p/'BrandEffect.java').read_text();e=(p/'EditSpec.java').read_text()
assert 'CaptionBudget99.windows(duration,DeviceLoad87.pressure(c))' in d and 'Studio94CaptionPlan.build(duration,n,left,right,restore)' in d
assert 'handler.postDelayed(captionTimeout,CaptionBudget99.UI_MS)' in s and '!captionBusy&&!captionDecoding' in s and 'void scrubToMs(long ms,boolean finished){if(busy||loading||captionBusy||captionDecoding||!scrubbing)return;' in s
assert 'Math.min(ExpertTemplatePolicy.TOTAL-1,template)' in e and 'ProfessionalTemplatePolicy.choose(' in d
assert 'coveredOther(vec2 p,vec4 own)' in b and 'program=link(VERT,ADVANCED_FRAG)' in b
assert 'static final boolean ENABLED=false' in (p/'ProfessionalRestoreConfidence.java').read_text()
print('v83 source integration audit OK: dense OCR, player ownership, template IDs, shader fallback, disabled candidate')
