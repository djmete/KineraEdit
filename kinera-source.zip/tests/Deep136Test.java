package az.kinera.edit;
import java.util.*;
public final class Deep136Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){Set<String> windows=new HashSet<>();for(int i=3734;i<3784;i++){ok(RegionMath.active(Deep136TemplatePolicy.window(i)));ok(windows.add(Arrays.toString(Deep136TemplatePolicy.window(i))));ok(BrandMotionMath.motionKind(i)>=136&&BrandMotionMath.motionKind(i)<146);}Random r=new Random(142);for(int k=0;k<5000;k++){long l=100000+r.nextInt(5000000),rr=100000+r.nextInt(5000000);long[] c={l};float a=Deep136Rhythm.scale(c,0,l+rr,l-100000),b=Deep136Rhythm.scale(c,0,l+rr,l+100000);ok(a>=.72f&&a<=1&&a==b);ok(Deep136Rhythm.scale(c,0,l+rr,l)==1);if(l>=1400000&&rr>=1400000)ok(a==1);}int n=0;for(int w:new int[]{240,320,360,480,720,1080})for(long d:new long[]{1000,10000,159200,3600000}){long prev=-1;int count=0;for(long t=0;t<=d;t+=Math.max(1,d/10000)){if(Deep136Workspace.redraw(prev,t,d,d,w)){prev=t;count++;}n++;}ok(count<=w+2);ok(Deep136Workspace.redraw(prev,prev,d,d+1,w));}System.out.println("Deep136: 50 windows, 5000 rhythm cases, "+n+" playhead checks passed");}
}
