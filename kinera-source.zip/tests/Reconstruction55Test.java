package az.kinera.edit;
import java.util.*;import java.nio.file.*;
final class Reconstruction55Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
 check(TemporalRestorePolicy.eligible(100000,140000,new long[0]));check(!TemporalRestorePolicy.eligible(100000,140000,new long[]{120000}));check(!TemporalRestorePolicy.eligible(100000,350001,new long[0]));check(!TemporalRestorePolicy.eligible(100000,99999,new long[0]));check(!TemporalRestorePolicy.eligible(100000,100000,new long[0]));check(TemporalRestorePolicy.fits(1920,1080)&&!TemporalRestorePolicy.fits(3840,2160));
 float[] r={.2f,.6f,.8f,.7f};List<TimedRegions.Mask> m=List.of(new TimedRegions.Mask(r,500000,1000000,true));check(!TemporalRestorePolicy.capture(m,249999)&&TemporalRestorePolicy.capture(m,250000)&&TemporalRestorePolicy.capture(m,999999)&&!TemporalRestorePolicy.capture(m,1000000));check(!TemporalRestorePolicy.capture(List.of(new TimedRegions.Mask(r,0,1000000)),0));
 int n=0;double max=0;for(String line:Files.readAllLines(Path.of("tests/kai55_temporal_parity.csv"))){if(line.startsWith("f0,"))continue;String[] x=line.split(",");double[] f=new double[3];for(int i=0;i<3;i++)f[i]=Double.parseDouble(x[i]);max=Math.max(max,Math.abs(TemporalRestoreConfidence.blend(f)-Double.parseDouble(x[3])));n++;}check(n==32&&max<1e-8&&TemporalRestoreConfidence.ENABLED);check(TemporalRestoreConfidence.blend(new double[]{.09,.1,0})==0);
 PlaybackWatchdog w=new PlaybackWatchdog();w.stalled(0,0,true,true);for(int i=1;i<=5;i++)w.stalled(i*1000,i*1000,true,true);check(w.stable(5000));w.stalled(6000,0,true,true);check(!w.stable(6000));
 System.out.println("Reconstruction55Test OK: history bounds, cut/seek isolation, capture scope, 32 parity rows, watchdog; max error="+max);
 }
}
