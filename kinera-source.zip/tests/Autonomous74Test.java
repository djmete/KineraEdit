package az.kinera.edit;
import java.nio.file.*;import java.util.*;
final class Autonomous74Test {
 static void check(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ExpertTemplatePolicy.TOTAL==3984);for(int i=484;i<534;i++){check(RegionMath.active(Autonomous74TemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)>=60&&BrandMotionMath.motionKind(i)<78);EditSpec s=new EditSpec("Test",i,720,30,0,0,false,false,false,1000000,0,0,1,1,0,new long[0],false);check(s.template==i&&s.withEncoding(480,24,false).template==i);}
  for(int f=0;f<5;f++)for(int p=0;p<10;p++)check(Autonomous74TemplatePolicy.choose(180,new float[]{.56f,.8f,1f,1.77f,2.3f}[f],1,p,5)==484+10*f+p);
  for(int n=0;n<121;n++){int[] ix=AutonomousCutPolicy.indices(n);check(ix.length==Math.min(n,8));if(n>0){check(ix[0]==0&&ix[ix.length-1]==n-1);for(int i=1;i<ix.length;i++)check(ix[i]>ix[i-1]&&ix[i]<n);}}
  check(KAiEdit.SCENE_BUDGET_MS<KAiEdit.SCENE_UI_TIMEOUT_MS&&KAiEdit.SCENE_UI_TIMEOUT_MS<KAiEdit.EXPORT_PREP_TIMEOUT_MS);
  float[] s={.46f,.78f,.54f,.81f};float[] a=CaptionRegionMath.paddedShort(s),b=CaptionRegionMath.padded(s);check(RegionMath.active(a)&&a[0]<s[0]&&a[2]>s[2]&&a[1]<s[1]&&a[3]>s[3]&&a[0]>b[0]&&a[2]<b[2]);
  check(BlurGestureMath.compact(299)&&!BlurGestureMath.compact(300));long[] cuts={2000000,7000000,17000000};AudioAccentCursor cursor=new AudioAccentCursor(cuts);int active=0,total=0;for(long time=0;time<20000000;time+=1000){boolean enabled=cursor.active(time);if(enabled)active++;total++;if(!enabled)check(DirectorMath.sound(cuts,time,20000000)==0);}check(active<total/10);check(cursor.active(2000000));cursor.reset();check(!cursor.active(0)&&cursor.active(2000000));
  double max=0;int n=0;for(String l:Files.readAllLines(Path.of("tests/kai74_pulse_parity.csv"))){String[] v=l.split(",");double[] x=new double[5];for(int i=0;i<5;i++)x[i]=Double.parseDouble(v[i]);max=Math.max(max,Math.abs(AutonomousPulseConfidence.score(x[0],x[1],x[2],x[3],x[4])-Double.parseDouble(v[5])));n++;}check(n==32&&max<1e-10);check(!AutonomousPulseConfidence.ENABLED);check(!AutonomousPulseConfidence.pulse(.5,.5,0,.5,-.5));check(!ReleaseHighlightPolicy.shouldShowForRelease(84,false,true,true,103,103,false));System.out.println("Autonomous74Test OK: 50 templates, 121 distributed probe schedules, short-caption padding, safe experimental gate, audio accent skip, parity="+max);
 }
}
