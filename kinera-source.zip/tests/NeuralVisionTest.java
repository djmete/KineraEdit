package az.kinera.edit;
import java.util.*;
public final class NeuralVisionTest {
 static void check(boolean b){if(!b)throw new AssertionError("vision regression");}
 public static void main(String[] args){
  for(int w:new int[]{280,320,360,411,691,914,1080})for(int h:new int[]{160,280,500,860,1440})for(float a:new float[]{9f/16,3f/4,1f,16f/9}){int[] d=VisionMath.fit(w,h,a);check(d[0]>0&&d[1]>0&&d[0]<=w&&d[1]<=h);check(Math.abs(d[0]-d[1]*a)<=2);check(d[0]>=w-1||d[1]>=h-1);}
  int[] size=VisionMath.fit(610,860,9f/16);check(size[0]==484&&size[1]==860);int[] shortSize=VisionMath.fit(610,502,9f/16);check(shortSize[0]==282&&shortSize[1]==501||shortSize[0]==282&&shortSize[1]==502);
  float[] crop={.2f,.1f,.8f,.9f},r=PrecisionMath.centerMask(crop);for(boolean mirror:new boolean[]{true,false}){float[] local=PrecisionMath.toLocal(r,crop,mirror);for(float aspect:new float[]{9f/16,3f/4}){float[] restored=PrecisionMath.toSource(local,crop,mirror);for(int i=0;i<4;i++)check(Math.abs(restored[i]-r[i])<.0001f);}}
  int[] colors=new int[192];Set<Integer> styles=new HashSet<>();Random random=new Random(55);for(int i=0;i<100;i++){for(int k=0;k<colors.length;k++)colors[k]=random.nextInt();int style=VisionMath.chooseTemplate(colors,28,.75f,1);check(style>=0&&style<138);check(style==VisionMath.chooseTemplate(colors,28,.75f,99));styles.add(style);}check(styles.size()>2);for(int i=114;i<126;i++)check(BrandMotionMath.motionKind(i)>=42&&BrandMotionMath.motionKind(i)<48);
  List<TimedRegions.Mask> seq=new ArrayList<>();for(int i=0;i<31;i++)seq.add(new TimedRegions.Mask(r,i*500000L,(i+1)*500000L));float[] active=new float[12];TimedRegions.fill(TimedRegions.snapshot(seq),10000000,active);check(active[0]==r[0]&&active[4]==0);TimedRegions.fill(seq,15500000,active);check(active[0]==0);
  List<TimedRegions.Mask> overlapping=Arrays.asList(new TimedRegions.Mask(r,0,100),new TimedRegions.Mask(r,0,100),new TimedRegions.Mask(r,0,100),new TimedRegions.Mask(r,0,100));boolean threw=false;try{TimedRegions.snapshot(overlapping);}catch(IllegalArgumentException ex){threw=true;}check(threw);
  float[] swept=VisionMath.sweptMask(r,RegionMath.move(r,.02f,.03f));check(swept[0]<r[0]&&swept[2]>r[2]+.02f);
  EditSpec s=new EditSpec("A",1,720,30,0,0,false,false,false,4000000,0,0,1,1,0,new long[]{1000000},false);check(VisionMath.zoom(s,1180000)>1);s.withRegions(crop,r);check(VisionMath.zoom(s,1180000)==1);
  check(new PreviewKey(s).equals(new PreviewKey(s.withHeight(720))));check(!new PreviewKey(s).equals(new PreviewKey(s.withHeight(720).withRegions(crop,RegionMath.empty()))));
  System.out.println("NeuralVisionTest OK: geometry, stable style, masks, time slots, zoom and preview identity");
 }
}
