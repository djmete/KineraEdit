from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');d=(p/'KAiDirector.java').read_text();m=(p/'MainActivity.java').read_text();s=(p/'SubjectVision104.java').read_text();c=(p/'CaptionReview.java').read_text();g=Path('app/build.gradle').read_text()
assert 'segmentation-selfie:16.0.0-beta6' in g
assert 'subjectProbe&&SubjectVision104.present(b)' in d and 'k==1&&!DeviceLoad87.pressure(this)' in m
assert 'VisualInferenceGate.tryEnter()' in s and 'task.addOnCompleteListener' in s and 'lease.close()' in s and 'SINGLE_IMAGE_MODE' in s
assert 'Fusion104.caption(Ultra95.caption' in c and 'Fusion104.rescueChoice(first.region,candidate.region)' in c
assert 'Fusion104.seek(lastScrubMs,now,finished,scrubPressure)' in m and 'scrubPressure=DeviceLoad87.pressure(this)' in m
assert 'else seekToMs(at);' in m and '10000),10000,currentDurationMs()' in m
print('Fusion104 source wiring: bundled dependency, one middle-frame fallback, deferred cleanup, caption ranking, adaptive seek and keyboard seek passed; actual ML Kit/Android execution not verified')
