package az.kinera.edit;
import java.util.*;
public final class DynamicCreativeTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  check(Arrays.equals(ChannelProfiles.sorted(new HashSet<>(Arrays.asList("Beta","Alpha"," ")),"Gamma"),new String[]{"Alpha","Beta","Gamma"}));
  check(!ChannelProfiles.valid(" ")&&ChannelProfiles.valid("My Channel"));
  check(VisualMath.squareTile(400,4)==98&&VisualMath.squareTile(400,2)==198);
  for(int c:new int[]{28,29,30,32,33,35}){int s=BrandMotionMath.studioLayoutFor(c,.85f);check(s>=60&&s<=65);}
  AudioLevelMath.Meter m=new AudioLevelMath.Meter();for(int i=0;i<4096;i++)m.add(0);for(int i=0;i<512;i++)m.add(.2f);check(m.gain()<=4);
  System.out.println("DynamicCreativeTest passed");
 }
}
