package az.kinera.edit;
import java.nio.file.*;import java.util.*;
final class Ultimate60Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(KineraAI.VERSION.equals("8.4"));check(FullCaptionPlan.windows(0)==0&&FullCaptionPlan.windows(1)==1&&FullCaptionPlan.windows(180000000)==31);
  for(long d:new long[]{1,999999,1000001,48000000,3600000000L,Long.MAX_VALUE}){int n=FullCaptionPlan.windows(d);long prev=0;for(int i=0;i<n;i++){long a=FullCaptionPlan.boundary(d,i,n),b=FullCaptionPlan.boundary(d,i+1,n),m=FullCaptionPlan.sample(d,i,n);check(a==prev&&b>a&&m>=a&&m<b);prev=b;}check(prev==d);}
  float[] a={.2f,.76f,.8f,.83f},b={.22f,.76f,.78f,.83f},c={.2f,.92f,.8f,.98f};check(FullCaptionPlan.merge(a,b));check(!FullCaptionPlan.merge(a,c));check(!FullCaptionPlan.merge(a,null));
  List<TimedRegions.Mask> m=FullCaptionPlan.build(4000000,Arrays.asList(a,b,RegionMath.empty(),c));check(m.size()==2&&m.get(0).restore&&m.get(0).from==0&&m.get(0).until==2000000&&m.get(1).from==3000000&&m.get(1).until==4000000&&FullCaptionPlan.covered(m)==3000000);
  m=FullCaptionPlan.fixed(3600000000L,a);check(m.size()==1&&m.get(0).restore&&m.get(0).until==3600000000L);float[] modes=new float[3];TimedRegions.fillModes(m,3599999999L,modes);check(modes[0]==1);TimedRegions.fillModes(m,3600000000L,modes);check(modes[0]==0);
  try{FullCaptionPlan.build(2000000,Collections.singletonList(a));throw new AssertionError();}catch(IllegalArgumentException expected){}
  check(UltimateTemplatePolicy.choose(180,.6f,1,2)==192&&UltimateTemplatePolicy.choose(180,1.6f,2,7)==195&&UltimateTemplatePolicy.choose(180,1f,3,2)==180);for(int i=192;i<198;i++){check(RegionMath.active(UltimateTemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)==60+i-192);}
  check(RhythmMath.estimateLag(null,0,150)==0&&RhythmMath.estimateLag(new float[150],0,151)==0);RhythmMath rhythm=new RhythmMath();for(int i=0;i<48000;i++)rhythm.push(.6f,48000);check(Float.isFinite(rhythm.push(.1f,44100))&&rhythm.bpm()==0);
  double max=0;int count=0;for(String l:Files.readAllLines(Path.of("tests/kai60_caption_parity.csv"))){if(l.startsWith("f0,"))continue;String[] t=l.split(",");double[] f=new double[6];for(int i=0;i<6;i++)f[i]=Double.parseDouble(t[i]);max=Math.max(max,Math.abs(CaptionLaneConfidence.score(f)-Double.parseDouble(t[6])));count++;}check(count==32&&max<1e-10&&CaptionLaneConfidence.ENABLED);check(CaptionLaneConfidence.score(new double[]{0,0,0,0,0,Double.NaN})==0);System.out.println("Ultimate60Test OK: duration partitions, fixed full-length restore, gaps, merge gating, six template IDs and 32 parity rows; max error="+max);
 }
}
