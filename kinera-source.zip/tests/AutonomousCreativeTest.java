package az.kinera.edit;
import java.util.*;
public final class AutonomousCreativeTest {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  float[] a={.1f,.2f,.3f,.4f};TimedRegions.Mask m=new TimedRegions.Mask(a,10,20);a[0]=0;check(m.rect()[0]==.1f);
  List<TimedRegions.Mask> list=new ArrayList<>();list.add(m);List<TimedRegions.Mask> snap=TimedRegions.snapshot(list);list.clear();check(snap.size()==1);float[] out=new float[12];TimedRegions.fill(snap,9,out);check(out[0]==0);TimedRegions.fill(snap,10,out);check(out[0]==.1f);TimedRegions.fill(snap,20,out);check(out[0]==0);
  EditSpec s=new EditSpec("A",1,720,30,0,0,false,false,false,100,0,0,1,1,0,new long[0],false).withExtraMasks(snap);check(s.withHeight(1080).extraMasks.equals(snap));check(s.withEncoding(1080,25,false).extraMasks.equals(snap));check(!new PreviewKey(s).equals(new PreviewKey(s.withHeight(720).withExtraMasks(Collections.emptyList()))));
  Set<String> names=new HashSet<>(Arrays.asList("Alpha","Beta"));check(!ChannelProfiles.canRename(names,"Alpha","beta"));check(ChannelProfiles.canRename(names,"Alpha","ALPHA"));check(Arrays.equals(ChannelProfiles.remaining(names,"Alpha"),new String[]{"Beta"}));
  for(int i=0;i<66;i++){check(BrandMotionMath.motionKind(i)>=0&&BrandMotionMath.motionKind(i)<24);check(BrandMotionMath.motionPhase(0,i)==0);check(BrandMotionMath.motionPhase(BrandMotionMath.periodUs(i),i)==0);}
  System.out.println("AutonomousCreativeTest passed");
 }
}
