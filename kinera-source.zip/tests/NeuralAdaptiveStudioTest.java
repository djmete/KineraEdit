package az.kinera.edit;
public final class NeuralAdaptiveStudioTest {
 static void check(boolean b){if(!b)throw new AssertionError("slider geometry");}
 static boolean close(float a,float b){return Math.abs(a-b)<.0011f;}
 public static void main(String[] args){float[] a=RegionMath.centered(.5f,.5f,.4f,.2f);float[] b=RegionMath.sliderRegion(a,0,1000);check(close(b[2],1)&&close(b[2]-b[0],.4f));b=RegionMath.sliderRegion(b,1,0);check(close(b[1],0));b=RegionMath.sliderRegion(b,2,800);check(close(b[2]-b[0],.8f)&&RegionMath.active(b));b=RegionMath.sliderRegion(b,3,0);check(close(b[3]-b[1],.035f));check(RegionMath.active(RegionMath.sliderRegion(RegionMath.empty(),0,500)));check(close(RegionMath.resize(a,6,0,.2f,.035f)[1],.2f));check(close(RegionMath.resize(a,7,0,.8f,.035f)[3],.8f));check(close(RegionMath.resize(a,8,.1f,0,.035f)[0],.1f));check(close(RegionMath.resize(a,9,.9f,0,.035f)[2],.9f));for(int axis=0;axis<4;axis++)for(int i=0;i<=1000;i++){float[] r=RegionMath.sliderRegion(a,axis,i);check(RegionMath.active(r));check(RegionMath.sliderValue(r,axis)>=0&&RegionMath.sliderValue(r,axis)<=1000);}System.out.println("NeuralAdaptiveStudioTest OK");}
}
