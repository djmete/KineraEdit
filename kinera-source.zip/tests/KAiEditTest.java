package az.kinera.edit;
public final class KAiEditTest {public static void main(String[] args){
 if(KAiEdit.recommendedFps(23.976f)!=24||KAiEdit.recommendedFps(25)!=25||KAiEdit.recommendedFps(50)!=50||KAiEdit.recommendedFps(29.97f)!=30||KAiEdit.recommendedFps(59.94f)!=60||KAiEdit.recommendedFps(Float.NaN)!=30)throw new AssertionError("fps");
 if(KAiEdit.scalePcm((short)30000,10)!=3000||KAiEdit.scalePcm((short)-30000,5)!=-1500||KAiEdit.scalePcm((short)32767,0)!=0||KAiEdit.scalePcm((short)-32768,100)!=-32768||KAiEdit.scaleFloat(.5f,10)!=.05f)throw new AssertionError("gain");
 if(EditMath.fade(0,102560000,false)!=1f)throw new AssertionError("first frame");
 System.out.println("PASS: KAiEdit export policy, PCM attenuation, first-frame preservation");}}
