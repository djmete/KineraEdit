#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
javac -d "$tmp" app/src/main/java/az/kinera/edit/BrandName.java app/src/main/java/az/kinera/edit/EditMath.java app/src/main/java/az/kinera/edit/SceneMath.java app/src/main/java/az/kinera/edit/EditSpec.java tests/EditMathTest.java tests/SceneMathTest.java tests/ProfessionalTest.java tests/UpgradeTest.java app/src/main/java/az/kinera/edit/StudioMath.java tests/StudioMathTest.java app/src/main/java/az/kinera/edit/ProjectMath.java tests/ProjectMathTest.java app/src/main/java/az/kinera/edit/TimelineMath.java tests/TimelineMathTest.java app/src/main/java/az/kinera/edit/ImportMath.java tests/ImportMathTest.java app/src/main/java/az/kinera/edit/PreviewKey.java app/src/main/java/az/kinera/edit/QualityReview.java tests/ReviewTest.java app/src/main/java/az/kinera/edit/CaptionBandMath.java tests/CaptionBandTest.java app/src/main/java/az/kinera/edit/BrandMotionMath.java tests/MotionTest.java app/src/main/java/az/kinera/edit/RegionMath.java tests/RegionTest.java app/src/main/java/az/kinera/edit/ExportSafety.java tests/ExportSafetyTest.java app/src/main/java/az/kinera/edit/ProductionMath.java tests/ProductionTest.java app/src/main/java/az/kinera/edit/GalleryMath.java tests/GalleryRenderTest.java app/src/main/java/az/kinera/edit/UiLanguage.java tests/FramingLocaleTest.java app/src/main/java/az/kinera/edit/ExportValidationMath.java tests/ExportValidationTest.java app/src/main/java/az/kinera/edit/KAiEdit.java tests/KAiEditTest.java app/src/main/java/az/kinera/edit/StemMath.java tests/StemMathTest.java tests/AdaptiveMotionTest.java app/src/main/java/az/kinera/edit/CaptionRegionMath.java app/src/main/java/az/kinera/edit/VoiceSettingsMath.java tests/ToolAccessTest.java tests/NeuralProcessingTest.java tests/StabilityRecoveryTest.java app/src/main/java/az/kinera/edit/VisualMath.java tests/VisualMathTest.java app/src/main/java/az/kinera/edit/RetiredModelCleanup.java tests/IntelligentVisualTest.java app/src/main/java/az/kinera/edit/NotificationPolicy.java tests/NotificationPolicyTest.java app/src/main/java/az/kinera/edit/AudioLevelMath.java tests/BackgroundStudioTest.java app/src/main/java/az/kinera/edit/TimeEntry.java tests/ProfessionalIntelligenceTest.java tests/NextGenerationTest.java app/src/main/java/az/kinera/edit/ProductionMetrics.java tests/AdvancedProductionTest.java app/src/main/java/az/kinera/edit/ChannelProfiles.java tests/DynamicCreativeTest.java app/src/main/java/az/kinera/edit/TimedRegions.java tests/AutonomousCreativeTest.java app/src/main/java/az/kinera/edit/KineraAI.java tests/AdvancedMotionIntelligenceTest.java app/src/main/java/az/kinera/edit/PreviewRecovery.java app/src/main/java/az/kinera/edit/CutConfidence.java tests/DeepCreativeIntelligenceTest.java app/src/main/java/az/kinera/edit/OutputFolder.java tests/NeuralCreativeFoundationTest.java tests/NeuralCreativeIntelligenceTest.java tests/NeuralProductionArchitectureTest.java tests/NeuralCreativeEvolutionTest.java app/src/main/java/az/kinera/edit/PlaybackWatchdog.java tests/NeuralProfessionalStudioTest.java tests/NeuralStudioPerformanceTest.java tests/NeuralAdaptiveStudioTest.java app/src/main/java/az/kinera/edit/PrecisionMath.java tests/NeuralPrecisionTest.java app/src/main/java/az/kinera/edit/MotionTrackMath.java tests/NeuralMasterTest.java app/src/main/java/az/kinera/edit/VisionMath.java tests/NeuralVisionTest.java tests/NeuralResilienceTest.java tests/NeuralFusionTest.java app/src/main/java/az/kinera/edit/EvolutionMath.java tests/NeuralEvolutionTest.java app/src/main/java/az/kinera/edit/DirectorMath.java tests/NeuralGenerationTest.java app/src/main/java/az/kinera/edit/AutonomousMath.java tests/AutonomousDirectorTest.java app/src/main/java/az/kinera/edit/TrackConfidence.java app/src/main/java/az/kinera/edit/RhythmMath.java tests/CinematicIntelligenceTest.java app/src/main/java/az/kinera/edit/AccentRisk.java tests/MultimodalDirectorTest.java app/src/main/java/az/kinera/edit/TemporalConfidence.java app/src/main/java/az/kinera/edit/TemporalPolicy.java tests/SemanticDirectorTest.java
java -cp "$tmp" az.kinera.edit.EditMathTest

java -cp "$tmp" az.kinera.edit.SceneMathTest

java -cp "$tmp" az.kinera.edit.ProfessionalTest

java -cp "$tmp" az.kinera.edit.UpgradeTest

java -cp "$tmp" az.kinera.edit.StudioMathTest

java -cp "$tmp" az.kinera.edit.ProjectMathTest

java -cp "$tmp" az.kinera.edit.TimelineMathTest

java -cp "$tmp" az.kinera.edit.ImportMathTest

java -cp "$tmp" az.kinera.edit.ReviewTest

java -ea -cp "$tmp" az.kinera.edit.CaptionBandTest

java -cp "$tmp" az.kinera.edit.MotionTest

java -cp "$tmp" az.kinera.edit.RegionTest

java -cp "$tmp" az.kinera.edit.ExportSafetyTest

java -cp "$tmp" az.kinera.edit.ProductionTest
java -cp "$tmp" az.kinera.edit.GalleryRenderTest

java -cp "$tmp" az.kinera.edit.FramingLocaleTest
java -cp "$tmp" az.kinera.edit.ExportValidationTest

java -cp "$tmp" az.kinera.edit.KAiEditTest

java -cp "$tmp" az.kinera.edit.StemMathTest
java -cp "$tmp" az.kinera.edit.AdaptiveMotionTest

java -cp "$tmp" az.kinera.edit.ToolAccessTest

java -cp "$tmp" az.kinera.edit.NeuralProcessingTest

java -cp "$tmp" az.kinera.edit.StabilityRecoveryTest
# Release must not link the experimental native audio engine.
if grep -R -nE "new NeuralAudioProcessor|ai\.onnxruntime" app/src/main/java app/build.gradle; then echo "Experimental engine leaked into release" >&2; exit 1; fi

java -cp "$tmp" az.kinera.edit.VisualMathTest

java -cp "$tmp" az.kinera.edit.IntelligentVisualTest

java -cp "$tmp" az.kinera.edit.NotificationPolicyTest

java -cp "$tmp" az.kinera.edit.BackgroundStudioTest

java -cp "$tmp" az.kinera.edit.ProfessionalIntelligenceTest

java -cp "$tmp" az.kinera.edit.NextGenerationTest
# Prevent regression of the actual v3.9 compiler failure.
if grep -n "exportRetries" app/src/main/java/az/kinera/edit/MainActivity.java; then exit 1; fi

java -cp "$tmp" az.kinera.edit.AdvancedProductionTest

java -cp "$tmp" az.kinera.edit.DynamicCreativeTest

java -cp "$tmp" az.kinera.edit.AutonomousCreativeTest

java -cp "$tmp" az.kinera.edit.AdvancedMotionIntelligenceTest

java -cp "$tmp" az.kinera.edit.DeepCreativeIntelligenceTest

java -cp "$tmp" az.kinera.edit.NeuralCreativeFoundationTest

java -cp "$tmp" az.kinera.edit.NeuralCreativeIntelligenceTest
# Regression for v4.6 Lint NewApi: callers must use the single guarded helper.
if grep -n 'getScaledFrameAtTime' app/src/main/java/az/kinera/edit/{AutoPlan,SceneScanner}.java; then exit 1; fi
grep -F 'minSdk 31' app/build.gradle >/dev/null
grep -F 'r.getScaledFrameAtTime' app/src/main/java/az/kinera/edit/AnalysisFrameReader.java >/dev/null

java -cp "$tmp" az.kinera.edit.NeuralProductionArchitectureTest

java -cp "$tmp" az.kinera.edit.NeuralCreativeEvolutionTest

java -cp "$tmp" az.kinera.edit.NeuralProfessionalStudioTest

java -cp "$tmp" az.kinera.edit.NeuralStudioPerformanceTest

java -cp "$tmp" az.kinera.edit.NeuralAdaptiveStudioTest

java -cp "$tmp" az.kinera.edit.NeuralPrecisionTest

java -cp "$tmp" az.kinera.edit.NeuralMasterTest

java -cp "$tmp" az.kinera.edit.NeuralVisionTest

# No visible manual template or batch export route may reappear.
! grep -F '()->openTemplates(' app/src/main/java/az/kinera/edit/MainActivity.java
! grep -F '()->showPage(QUEUE)' app/src/main/java/az/kinera/edit/MainActivity.java
grep -F 'app:surface_type="surface_view"' app/src/main/res/layout/kinera_preview_player.xml >/dev/null
grep -F 'if(valid&&any){recycleTimelineFrames();timelineFrames=frames;' app/src/main/java/az/kinera/edit/MainActivity.java >/dev/null
java -cp "$tmp" az.kinera.edit.NeuralResilienceTest
java -cp "$tmp" az.kinera.edit.NeuralFusionTest
! grep -F 'add(root,projectCard' app/src/main/java/az/kinera/edit/MainActivity.java
! grep -F 'setVideoEffects(java.util.Collections.emptyList())' app/src/main/java/az/kinera/edit/MainActivity.java
grep -F 'app:surface_type="texture_view"' app/src/main/res/layout/kinera_source_player.xml >/dev/null

# v5.8 UI contracts + parse Android source even without an installed SDK.
java -cp "$tmp" az.kinera.edit.NeuralEvolutionTest
java -cp "$tmp" az.kinera.edit.NeuralGenerationTest
java -cp "$tmp" az.kinera.edit.AutonomousDirectorTest
java -cp "$tmp" az.kinera.edit.CinematicIntelligenceTest
java -cp "$tmp" az.kinera.edit.MultimodalDirectorTest
java -cp "$tmp" az.kinera.edit.SemanticDirectorTest
python3 tests/ui_regression_v59.py
python3 tests/ui_regression_v61.py
python3 tests/ui_regression_v62.py
javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/CognitiveConfidence.java tests/CognitiveDirectorTest.java
java -cp "$tmp" az.kinera.edit.CognitiveDirectorTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/ExposureRisk.java tests/DeepVisionTest.java
java -cp "$tmp" az.kinera.edit.DeepVisionTest
javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/AnchorRisk.java tests/Professional47Test.java
java -cp "$tmp" az.kinera.edit.Professional47Test
javac -d "$tmp" tests/SyntaxAudit.java
java -cp "$tmp" SyntaxAudit
javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/{CreativePolicy,ChromaGuard,ChromaRisk}.java tests/Creative48Test.java
java -cp "$tmp" az.kinera.edit.Creative48Test
javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/{AppearanceGuard,AppearanceConfidence}.java tests/Advanced49Test.java
java -cp "$tmp" az.kinera.edit.Advanced49Test

javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/ReacquireConfidence.java tests/Autonomous50Test.java
java -cp "$tmp" az.kinera.edit.Autonomous50Test

javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/{SupremeConfidence,CinematicConfidence,SupremeTrackPolicy}.java tests/Supreme51Test.java
java -cp "$tmp" az.kinera.edit.Supreme51Test

javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/{ExpertTemplatePolicy,ExpertConfidence}.java tests/Expert52Test.java
java -cp "$tmp" az.kinera.edit.Expert52Test

javac -cp "$tmp" -d "$tmp" tests/Cinematic53Test.java
java -cp "$tmp" az.kinera.edit.Cinematic53Test

javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/{RestorePolicy,RestoreConfidence}.java tests/Hyper54Test.java
java -cp "$tmp" az.kinera.edit.Hyper54Test

javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/{TemporalRestorePolicy,TemporalRestoreConfidence}.java tests/Reconstruction55Test.java
java -cp "$tmp" az.kinera.edit.Reconstruction55Test

javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/{ReactiveMotionMath,MotionRestoreConfidence}.java tests/Generative56Test.java
java -cp "$tmp" az.kinera.edit.Generative56Test

 javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/DiagonalRestoreConfidence.java tests/Dynamic57Test.java
 java -cp "$tmp" az.kinera.edit.Dynamic57Test

javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/HistoryRestoreConfidence.java app/src/main/java/az/kinera/edit/UltraTemplatePolicy.java tests/Ultra58Test.java
java -cp "$tmp" az.kinera.edit.Ultra58Test

javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/{ThemePolicy,AdvancedTemplatePolicy,TextureRestoreConfidence}.java tests/Advanced59Test.java
java -cp "$tmp" az.kinera.edit.Advanced59Test

python3 tests/v79_source_audit.py

 javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/{CaptionLaneConfidence,FullCaptionPlan,UltimateTemplatePolicy}.java tests/Ultimate60Test.java
 java -cp "$tmp" az.kinera.edit.Ultimate60Test

python3 tests/v80_source_audit.py

javac -cp "$tmp" -d "$tmp" app/src/main/java/az/kinera/edit/{VisionLaneConfidence,DenseCaptionPlan}.java tests/Vision61Test.java
java -cp "$tmp" az.kinera.edit.Vision61Test
