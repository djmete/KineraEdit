#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
javac --release 17 -d "$tmp" @tests/host_sources.txt
java -cp "$tmp" az.kinera.edit.EditMathTest

java -cp "$tmp" az.kinera.edit.SceneMathTest

java -cp "$tmp" az.kinera.edit.ProfessionalTest

java -cp "$tmp" az.kinera.edit.UpgradeTest

java -cp "$tmp" az.kinera.edit.StudioMathTest

java -cp "$tmp" az.kinera.edit.ProjectMathTest

java -cp "$tmp" az.kinera.edit.TimelineMathTest

java -cp "$tmp" az.kinera.edit.ImportMathTest

java -cp "$tmp" az.kinera.edit.ReviewTest

java -ea -cp "$tmp" az.kinera.edit.CaptionBandTest

java -cp "$tmp" az.kinera.edit.MotionTest

java -cp "$tmp" az.kinera.edit.RegionTest

java -cp "$tmp" az.kinera.edit.ExportSafetyTest

java -cp "$tmp" az.kinera.edit.ProductionTest
java -cp "$tmp" az.kinera.edit.GalleryRenderTest

java -cp "$tmp" az.kinera.edit.FramingLocaleTest
java -cp "$tmp" az.kinera.edit.ExportValidationTest

java -cp "$tmp" az.kinera.edit.KAiEditTest

java -cp "$tmp" az.kinera.edit.StemMathTest
java -cp "$tmp" az.kinera.edit.AdaptiveMotionTest

java -cp "$tmp" az.kinera.edit.ToolAccessTest

java -cp "$tmp" az.kinera.edit.NeuralProcessingTest

java -cp "$tmp" az.kinera.edit.StabilityRecoveryTest
# Release must not link the experimental native audio engine.
if grep -R -nE "new NeuralAudioProcessor|ai\.onnxruntime" app/src/main/java app/build.gradle; then echo "Experimental engine leaked into release" >&2; exit 1; fi

java -cp "$tmp" az.kinera.edit.VisualMathTest

java -cp "$tmp" az.kinera.edit.IntelligentVisualTest

java -cp "$tmp" az.kinera.edit.NotificationPolicyTest

java -cp "$tmp" az.kinera.edit.BackgroundStudioTest

java -cp "$tmp" az.kinera.edit.ProfessionalIntelligenceTest

java -cp "$tmp" az.kinera.edit.NextGenerationTest
# Prevent regression of the actual v3.9 compiler failure.
if grep -n "exportRetries" app/src/main/java/az/kinera/edit/MainActivity.java; then exit 1; fi

java -cp "$tmp" az.kinera.edit.AdvancedProductionTest

java -cp "$tmp" az.kinera.edit.DynamicCreativeTest

java -cp "$tmp" az.kinera.edit.AutonomousCreativeTest

java -cp "$tmp" az.kinera.edit.AdvancedMotionIntelligenceTest

java -cp "$tmp" az.kinera.edit.DeepCreativeIntelligenceTest

java -cp "$tmp" az.kinera.edit.NeuralCreativeFoundationTest

java -cp "$tmp" az.kinera.edit.NeuralCreativeIntelligenceTest
# Regression for v4.6 Lint NewApi: callers must use the single guarded helper.
if grep -n 'getScaledFrameAtTime' app/src/main/java/az/kinera/edit/{AutoPlan,SceneScanner}.java; then exit 1; fi
grep -F 'minSdk 31' app/build.gradle >/dev/null
grep -F 'r.getScaledFrameAtTime' app/src/main/java/az/kinera/edit/AnalysisFrameReader.java >/dev/null

java -cp "$tmp" az.kinera.edit.NeuralProductionArchitectureTest

java -cp "$tmp" az.kinera.edit.NeuralCreativeEvolutionTest

java -cp "$tmp" az.kinera.edit.NeuralProfessionalStudioTest

java -cp "$tmp" az.kinera.edit.NeuralStudioPerformanceTest

java -cp "$tmp" az.kinera.edit.NeuralAdaptiveStudioTest

java -cp "$tmp" az.kinera.edit.NeuralPrecisionTest

java -cp "$tmp" az.kinera.edit.NeuralMasterTest

java -cp "$tmp" az.kinera.edit.NeuralVisionTest

# No visible manual template or batch export route may reappear.
! grep -F '()->openTemplates(' app/src/main/java/az/kinera/edit/MainActivity.java
! grep -F '()->showPage(QUEUE)' app/src/main/java/az/kinera/edit/MainActivity.java
grep -F 'app:surface_type="surface_view"' app/src/main/res/layout/kinera_preview_player.xml >/dev/null
grep -F 'if(valid&&any){recycleTimelineFrames();timelineFrames=frames;' app/src/main/java/az/kinera/edit/MainActivity.java >/dev/null
java -cp "$tmp" az.kinera.edit.NeuralResilienceTest
java -cp "$tmp" az.kinera.edit.NeuralFusionTest
! grep -F 'add(root,projectCard' app/src/main/java/az/kinera/edit/MainActivity.java
! grep -F 'setVideoEffects(java.util.Collections.emptyList())' app/src/main/java/az/kinera/edit/MainActivity.java
grep -F 'app:surface_type="texture_view"' app/src/main/res/layout/kinera_source_player.xml >/dev/null

# v5.8 UI contracts + parse Android source even without an installed SDK.
java -cp "$tmp" az.kinera.edit.NeuralEvolutionTest
java -cp "$tmp" az.kinera.edit.NeuralGenerationTest
java -cp "$tmp" az.kinera.edit.AutonomousDirectorTest
java -cp "$tmp" az.kinera.edit.CinematicIntelligenceTest
java -cp "$tmp" az.kinera.edit.MultimodalDirectorTest
java -cp "$tmp" az.kinera.edit.SemanticDirectorTest
python3 tests/ui_regression_v59.py
python3 tests/ui_regression_v61.py
python3 tests/ui_regression_v62.py
java -cp "$tmp" az.kinera.edit.CognitiveDirectorTest
java -cp "$tmp" az.kinera.edit.DeepVisionTest
java -cp "$tmp" az.kinera.edit.Professional47Test
java -cp "$tmp" SyntaxAudit
java -cp "$tmp" az.kinera.edit.Creative48Test
java -cp "$tmp" az.kinera.edit.Advanced49Test

java -cp "$tmp" az.kinera.edit.Autonomous50Test

java -cp "$tmp" az.kinera.edit.Supreme51Test

java -cp "$tmp" az.kinera.edit.Expert52Test

java -cp "$tmp" az.kinera.edit.Cinematic53Test

java -cp "$tmp" az.kinera.edit.Hyper54Test

java -cp "$tmp" az.kinera.edit.Reconstruction55Test

java -cp "$tmp" az.kinera.edit.Generative56Test

 java -cp "$tmp" az.kinera.edit.Dynamic57Test

java -cp "$tmp" az.kinera.edit.Ultra58Test

java -cp "$tmp" az.kinera.edit.Advanced59Test

python3 tests/v79_source_audit.py

 java -cp "$tmp" az.kinera.edit.Ultimate60Test

python3 tests/v80_source_audit.py

java -cp "$tmp" az.kinera.edit.Vision61Test

java -cp "$tmp" az.kinera.edit.Precision62Test

java -cp "$tmp" az.kinera.edit.Professional63Test

python3 tests/v83_source_audit.py

 java -cp "$tmp" az.kinera.edit.Deep64Test
 python3 tests/v84_source_audit.py

 java -cp "$tmp" az.kinera.edit.Intelligent65Test
 python3 tests/v85_source_audit.py

 java -cp "$tmp" az.kinera.edit.Creator66Test

 java -cp "$tmp" az.kinera.edit.Creative67Test

java -cp "$tmp" az.kinera.edit.Cognitive68Test

java -cp "$tmp" az.kinera.edit.Evolution69Test
python3 tests/v89_source_audit.py

java -cp "$tmp" az.kinera.edit.Master70Test
python3 tests/v90_source_audit.py

java -cp "$tmp" az.kinera.edit.Stable71Test

java -cp "$tmp" az.kinera.edit.Director72Test

python3 tests/v92_source_audit.py
java -cp "$tmp" az.kinera.edit.Cinematic73Test

java -cp "$tmp" az.kinera.edit.Autonomous74Test

java -cp "$tmp" az.kinera.edit.Vision75Test

java -cp "$tmp" az.kinera.edit.Adaptive76Test

java -cp "$tmp" az.kinera.edit.Semantic77Test

java -cp "$tmp" az.kinera.edit.Precision78Test

 java -cp "$tmp" az.kinera.edit.Expert79Test

java -cp "$tmp" az.kinera.edit.Vision80Test

java -cp "$tmp" az.kinera.edit.Scene81Test

java -cp "$tmp" az.kinera.edit.Reliability82Test

java -cp "$tmp" az.kinera.edit.Cinematic83Test

java -cp "$tmp" az.kinera.edit.Production84Test

python3 tests/maven_ci_test.py

java -cp "$tmp" az.kinera.edit.Professional85Test
python3 tests/android_compile_regression.py "$tmp"

java -cp "$tmp" az.kinera.edit.Advanced86Test

java -cp "$tmp" az.kinera.edit.Performance87Test

java -cp "$tmp" az.kinera.edit.Adaptive88Test

java -cp "$tmp" az.kinera.edit.Dynamic89Test

java -cp "$tmp" az.kinera.edit.Cognitive90Test

java -cp "$tmp" az.kinera.edit.Contextual91Test
python3 tests/editor_history_v102.py

java -cp "$tmp" az.kinera.edit.Precision92Test

java -cp "$tmp" az.kinera.edit.Vision93Test

python3 tests/vision93_ui_audit.py

java -cp "$tmp" az.kinera.edit.Studio94Test

python3 tests/studio94_ui_audit.py
