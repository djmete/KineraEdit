package az.kinera.edit;
import java.nio.file.*;import java.util.*;
final class Adaptive76Test {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args)throws Exception{
  check(ExpertTemplatePolicy.TOTAL==4184);for(int i=584;i<634;i++){check(RegionMath.active(Adaptive76TemplatePolicy.window(i)));check(BrandMotionMath.motionKind(i)>=60&&BrandMotionMath.motionKind(i)<78);EditSpec s=new EditSpec("Test",i,720,30,0,0,false,false,false,1000000,0,0,1,1,0,new long[0],false);check(s.template==i&&s.withEncoding(480,24,false).template==i);}
  for(int f=0;f<5;f++)for(int p=0;p<10;p++)check(Adaptive76TemplatePolicy.choose(180,new float[]{.56f,.8f,1f,1.77f,2.3f}[f],1,p,9)==584+10*f+p);
  for(int n=0;n<=120;n++){int[] ix=AdaptiveCutPolicy.indices(n);check(ix.length==Math.min(n,16));if(n>0){check(ix[0]==0&&ix[ix.length-1]==n-1);for(int i=1;i<ix.length;i++)check(ix[i]>ix[i-1]);}}
  int[] a=new int[2304],b=new int[2304],c=new int[2304];for(int i=0;i<a.length;i++){a[i]=40+i%100;b[i]=a[i]+65;c[i]=a[i];}double[] x=AdaptiveCutPolicy.features(a,b,c);check(Math.abs(x[0]-65./255)<1e-10&&Math.abs(x[1]-65./255)<1e-10&&x[2]<1e-10&&x[3]>0&&x[4]<0&&x[5]<1e-10&&x[6]<1e-10);check(AdaptiveCutPolicy.features(a,new int[1],c)==null);
  double max=0;int n=0;for(String l:Files.readAllLines(Path.of("tests/kai76_pulse_parity.csv"))){String[] v=l.split(",");double[] z=new double[7];for(int i=0;i<7;i++)z[i]=Double.parseDouble(v[i]);max=Math.max(max,Math.abs(AdaptivePulseConfidence.score(z)-Double.parseDouble(v[7])));n++;}check(n==32&&max<1e-10&&AdaptivePulseConfidence.ENABLED);
  float[] r={.2f,.7f,.8f,.8f};check(FullCaptionPlan.covered(Arrays.asList(new TimedRegions.Mask(r,5,15),new TimedRegions.Mask(r,0,10),new TimedRegions.Mask(r,20,25)))==20);check(FullCaptionPlan.covered(null)==0);
  check(DirectorMath.sourceAccent(.1f,.1f)==.1f&&DirectorMath.sourceAccent(.1f,.9f)<.02f&&DirectorMath.sourceAccent(.1f,Float.NaN)==0);
  check(KAiEdit.SCENE_BUDGET_MS<KAiEdit.SCENE_UI_TIMEOUT_MS&&KAiEdit.SCENE_UI_TIMEOUT_MS<KAiEdit.EXPORT_PREP_TIMEOUT_MS);check(!ReleaseHighlightPolicy.shouldShowForRelease(86,false,true,true,103,103,false));
  System.out.println("Adaptive76Test OK: 50 template IDs, 121 distributed schedules, triple features, interval union, transient attenuation, model parity="+max);
 }
}
