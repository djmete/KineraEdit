from pathlib import Path
import re
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();a=(p/'TemplateArt.java').read_text();d=(p/'AutoPlan.java').read_text();l=(p/'UiLanguage.java').read_text();
assert len(set(re.search(r'\bNAMES=\{([^\n]+)\};',a).group(1).split(',')))==1534
assert 'EvolutionTemplatePolicy.window(style)' in a and 'EvolutionTemplatePolicy.choose(' in (p/'KAiDirector.java').read_text()
assert 'EvolutionSceneConfidence.lightingPulse(' in d and 'Adaptive88.enoughCoverage(processed,count,n/64)' in d
assert 'syncEditorWorkspace();' in s and 'editorDock.addView(actions,new LinearLayout.LayoutParams(-1,-2))' in s and 'buildBlurAdjust(editorDock)' in s
assert 'new EvolutionWorkspaceArt' in s and 'Daha geniş redaktor və 50 yeni şablon' in l
print('v89 source integration audit OK: 1534 unique names, new layout wiring, trained lighting guard, separate editor actions, latest release localization')
