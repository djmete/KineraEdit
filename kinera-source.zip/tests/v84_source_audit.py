from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();n=(p/'StudioNotifications.java').read_text();b=(p/'BrandEffect.java').read_text();l=(p/'UiLanguage.java').read_text();d=(p/'KAiDirector.java').read_text()
assert 'dialog.setOnShowListener' in s and 'ReleaseHighlightPolicy.mark(' in s and 'onWindowFocusChanged' in s and 'ValueAnimator.areAnimatorsEnabled()' in s
assert 'if(releaseHighlight!=null)releaseHighlight.dismiss()' in s and 'toolBar=toolsStrip;' in s and 'buildBlurAdjust(editorDock)' in s
assert 'RESULTS_ENABLED' in n and 'RESULTS_ENABLED' in s and 'setDescription(' in n
assert 'CaptionBudget99.windows(duration,DeviceLoad87.pressure(c))' in d and 'Studio94CaptionPlan.build(duration,n,left,right,restore)' in d
assert 'DEEP_FRAG' in b and 'deepFallback' in b and 'deepSafe' in b and 'deepUnsupported' in b
for key in ['Yeni böyük yenilik','Mətnli sahə','Bərpa prinsipi','İxrac nəticəsi bildirişləri']:
 assert 'TABLE.put("'+key+'"' in l
print('v84 source integration audit OK: highlight lifecycle, localization, notification controls, dense OCR, new shader fallback, equal toolbar')
