package az.kinera.edit;
final class Vision93Test {
 static void ok(boolean x){if(!x)throw new AssertionError();}
 public static void main(String[] args){
  ok(ReleaseHighlightPolicy.shouldShow(104,false,true,true));ok(!ReleaseHighlightPolicy.shouldShow(105,false,true,true));ok(!ReleaseHighlightPolicy.shouldShow(103,false,true,false));ok(!ReleaseHighlightPolicy.shouldShow(103,true,true,true));
  int[] a=new int[2304],b=new int[2304];for(int y=0;y<48;y++)for(int x=0;x<48;x++){int v=(x/3+y/3)%2==0?70:180;a[y*48+x]=0xff000000|v*0x10101;b[y*48+x]=0xff000000|(v+2)*0x10101;}ok(Vision93.score(a,b,.34f)<.34f);ok(Vision93.score(a,b,.48f)==.48f);java.util.Arrays.fill(b,0xff777777);ok(Vision93.score(a,b,.34f)==.34f);
  for(int i=1434;i<1484;i++){ok(RegionMath.active(Vision93TemplatePolicy.window(i)));ok(BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);}
  System.out.println("Vision93: current release gate, conservative scene guard, 50 templates passed");
 }
}
