package az.kinera.edit;
import java.util.*;
final class Cognitive90Test {
 static void ok(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
 int[] a=new int[2304],b=new int[2304];for(int y=0;y<48;y++)for(int x=0;x<48;x++){int p=30+(x/2%2)*80+(y/2%2)*20;int q=p+40;int i=y*48+x;a[i]=0xff000000|(p<<16)|(p<<8)|p;b[i]=0xff000000|(q<<16)|(q<<8)|q;}
 ok(Cognitive90.sceneScore(a,b,.34f)<.34f);ok(Cognitive90.sceneScore(a,b,.50f)==.50f);Arrays.fill(b,0xff808080);ok(Cognitive90.sceneScore(a,b,.34f)==.34f);
 Random rnd=new Random(90);for(int i=0;i<50000;i++){long[] cuts=DirectorMath.clean(new long[]{rnd.nextInt(3000000),rnd.nextInt(3000000),rnd.nextInt(3000000)},4000000);long p=rnd.nextInt(3000000)-10000L,n=p+rnd.nextInt(300000)-20000;int fps=12+rnd.nextInt(50);ok(Cognitive90.recentSorted(p,n,cuts,fps)==TemporalRestorePolicy.recent(p,n,cuts,fps));}
 for(int round=0;round<120;round++){List<TimedRegions.Mask> masks=new ArrayList<>();for(int i=0;i<384;i++){long p=rnd.nextInt(100)*1000L;float x=(i%10)*.02f;masks.add(new TimedRegions.Mask(new float[]{x,.4f,x+.2f,.6f},p,p+1000L*(1+rnd.nextInt(15)),rnd.nextBoolean()));}MaskTimeline87 idx=new MaskTimeline87(masks);float[] a1=new float[12],b1=new float[3],a2=new float[12],b2=new float[3];for(int i=0;i<400;i++){long time=rnd.nextInt(120000)-5000;TimedRegions.fillBoth(masks,time,a1,b1);idx.fill(time,a2,b2);ok(Arrays.equals(a1,a2)&&Arrays.equals(b1,b2));}}
 for(int i=1284;i<1334;i++){ok(RegionMath.active(Cognitive90TemplatePolicy.window(i)));ok(BrandMotionMath.motionKind(i)>=120&&BrandMotionMath.motionKind(i)<126);}ok(Cognitive90TemplatePolicy.choose(2,.6f,1,0,6)>=1284);ok(Cognitive90.blurMenuWidth(320,1)==48);ok(Cognitive90.blurValueWidth(320,1.3f)==54);
 System.out.println("Cognitive90: exposure guard, 50000 temporal cut parity and 48000 overlapping mask parity cases, 50 styles, slider sizing passed");}
}
