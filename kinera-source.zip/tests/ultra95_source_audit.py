from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit')
s=(p/'MainActivity.java').read_text();e=(p/'ExportTask.java').read_text();b=(p/'BrandEffect.java').read_text();c=(p/'PrecisionCaptionPlan.java').read_text();o=(p/'CaptionReview.java').read_text()
assert 'Temporal97.height(size==null' in s and 'Reconstruction96.fps(sourceFps,' in s and 'Reconstruction96.fallbacks(s.height,s.fps)' in s
assert 'Reconstruction96.fps(ready.fps' in e and 'Reconstruction96.fallbacks(spec.height,spec.fps)' in e
assert 'restored<.5&&stepSize.x>0.' in b and 'Temporal97.safeUnion' in c and 'Ultra95.caption' in o
print('Ultra95 source integration: adaptive export + retries, zero-strength GPU skip, caption guard, UI policy passed')

a=(p/'AutoPlan.java').read_text();assert a.index('r.release();')<a.index('SequentialCutReader.refineBounded')
print('Ultra95 sequential refinement is bounded and starts after retriever release')
