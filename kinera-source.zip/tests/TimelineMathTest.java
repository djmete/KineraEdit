package az.kinera.edit;
final class TimelineMathTest {
 public static void main(String[] args){
  if(TimelineMath.position(500,1000,120000)!=60000)throw new AssertionError();
  if(TimelineMath.position(-1,1000,3000)!=0||TimelineMath.position(1001,1000,3000)!=3000)throw new AssertionError();
  if(TimelineMath.progress(120000,240000,1000)!=500||TimelineMath.progress(1,0,1000)!=0)throw new AssertionError();
  if(!TimelineMath.time(103000).equals("01:43")||!TimelineMath.time(3601000).equals("1:00:01"))throw new AssertionError();
  for(int i=0;i<=1000;i++){long t=TimelineMath.position(i,1000,103000);if(TimelineMath.progress(t,103000,1000)!=i)throw new AssertionError();}
  System.out.println("TimelineMath tests passed");
 }
}
