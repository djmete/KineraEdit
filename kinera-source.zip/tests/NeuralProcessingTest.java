package az.kinera.edit;
import java.nio.*;
import java.util.Arrays;
public final class NeuralProcessingTest {
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);}
 public static void main(String[] args){
  int n=2*StemMath.MODEL_FRAMES;
  FloatBuffer direct=ByteBuffer.allocateDirect(n*Float.BYTES).order(ByteOrder.nativeOrder()).asFloatBuffer();
  float[] pcm={.2f,-.3f,.4f,-.5f};
  StemMath.fillModel(pcm,2,44100,2,direct);
  check(direct.isDirect()&&direct.position()==0&&direct.remaining()==n,"direct input ready");
  check(direct.get(0)==.2f&&direct.get(StemMath.MODEL_FRAMES)==-.3f,"channel order");
  StemMath.fillModel(new float[]{.7f},1,44100,1,direct);
  check(direct.get(0)==.7f&&direct.get(StemMath.MODEL_FRAMES)==.7f&&direct.get(1)==0,"reuse clears old samples and mono expansion");
  float[] stems=new float[n*4];Arrays.fill(stems,0,n,.1f);Arrays.fill(stems,n,2*n,.2f);Arrays.fill(stems,2*n,3*n,.3f);Arrays.fill(stems,3*n,4*n,99f);
  float[] mix=new float[n];Arrays.fill(mix,42f);StemMath.sumMusic(FloatBuffer.wrap(stems),mix);check(Math.abs(mix[0]-.6f)<1e-6&&Math.abs(mix[n-1]-.6f)<1e-6,"sum excludes vocal stem and overwrites scratch");
  float[] out=new float[8];Arrays.fill(out,99f);StemMath.fillNative(mix,2,44100,2,out);check(Math.abs(out[3]-.6f)<1e-6&&out[4]==99f,"native output respects active frames");
  stems[0]=Float.NaN;boolean rejected=false;try{StemMath.sumMusic(FloatBuffer.wrap(stems),mix);}catch(IllegalStateException e){rejected=true;}check(rejected,"NaN rejected");
  check(StemMath.inferenceThreads(1)==1&&StemMath.inferenceThreads(4)==2&&StemMath.inferenceThreads(32)==3,"bounded CPU policy");
  check(TimelineMath.shouldSeek(-1,0,false)&&!TimelineMath.shouldSeek(100,120,false)&&TimelineMath.shouldSeek(100,180,false)&&TimelineMath.shouldSeek(100,101,true),"scrub throttling and final seek");
  float[] r=CaptionRegionMath.include(RegionMath.empty(),.2f,.60f,.8f,.65f);
  check(Arrays.equals(r,CaptionRegionMath.include(r,.2f,.8f,.8f,.85f)),"separate regions not merged");
  check(Arrays.equals(r,CaptionRegionMath.include(r,.81f,.61f,.99f,.66f)),"unrelated horizontal text not merged");
  check(CaptionRegionMath.include(r,.3f,.66f,.7f,.70f)[3]==.70f,"adjacent lines merged");
  check(KAiEdit.previewHeight(true,512)==480&&KAiEdit.previewHeight(false,192)==640&&KAiEdit.previewHeight(false,512)==854,"preview memory policy");
  System.out.println("NeuralProcessingTest: reusable PCM, stem aggregation, CPU bounds, scrub and region grouping passed");
 }
}
