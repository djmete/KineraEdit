package az.kinera.edit;
final class Professional115Test {
 static void ok(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] a){
  for(int i=2934;i<2984;i++){float[] r=Professional115TemplatePolicy.window(i);ok(RegionMath.active(r));ok(r[0]>=0&&r[1]>=0&&r[2]<=1&&r[3]<=1);ok(BrandMotionMath.motionKind(i)>=136&&BrandMotionMath.motionKind(i)<146);ok(BrandMotionMath.periodUs(i)>0);}
  int count=0;for(int h:new int[]{320,480,549,619,620,680,720,900})for(int mode=0;mode<=2;mode++)for(float f:new float[]{1,1.3f,1.8f})for(boolean focus:new boolean[]{false,true}){boolean seek=Professional115Workspace.seek(h,mode,focus,f),film=Professional115Workspace.filmstrip(h,mode,focus,f);ok(!focus||!seek&&!film);ok(mode==0||!film);ok(mode==0||h>=620||!seek);ok(!film||h>=720);count++;}
  for(int t=0;t<5;t++)for(int tone=0;tone<10;tone++){float ar=new float[]{.56f,.8f,1f,1.77f,2.35f}[t];int kind=t<3?CreativePolicy.PERSON:CreativePolicy.LANDSCAPE;ok(Professional115TemplatePolicy.choose(0,ar,kind,tone,0)==2934+t*10+tone);}
  ok(Professional115TemplatePolicy.choose(22,1,CreativePolicy.DOCUMENT,0,0)==22);ok(Professional115TemplatePolicy.choose(22,Float.NaN,CreativePolicy.PERSON,0,0)==22);
  ok(!Professional115Workspace.liveTick(0,199,true,true));ok(Professional115Workspace.liveTick(0,200,true,true));ok(Professional115Workspace.liveTick(-1,0,false,false));
  for(int a1=1;a1<=8;a1++)for(int b=1;b<=8;b++){long[] cuts={a1*1000000L};long duration=(a1+b)*1000000L;float c=Professional115Director.continuity(cuts,0,duration);ok(c>=0&&c<=1);for(long t=0;t<duration;t+=100000L){float z=DirectorMath.zoom(cuts,t,duration,.2f,true);ok(z==1f);}}
  ok(Professional115Director.continuity(new long[]{0},0,10)==0);ok(Professional115Director.continuity(new long[]{4000000},0,8000000)==1f);
  for(int i=0;i<50;i++){float x=.10f+i*.006f;float[] center={x,.75f,x+.24f,.82f},near={x+.01f,.75f,x+.25f,.82f},other={.1f,.2f,.34f,.27f};ok(RegionMath.active(Professional115Caption.review(center,java.util.List.of(near,other),3)));ok(!RegionMath.active(Professional115Caption.review(center,java.util.List.of(other,other),3)));ok(!RegionMath.active(Professional115Caption.review(RegionMath.empty(),java.util.List.of(near,near),3)));ok(java.util.Arrays.equals(center,Professional115Caption.review(center,java.util.List.of(),1)));}
  System.out.println("Professional115: 50 template IDs, "+count+" workspace combinations, 50 selection cases, pressure throttle and 64 timing cases and 200 anchored OCR decisions passed");
 }
}
