package az.kinera.edit;
public final class NeuralProfessionalStudioTest {
 static void check(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] a){PlaybackWatchdog w=new PlaybackWatchdog();check(!w.stalled(1000,0,true,false));check(!w.stalled(12999,0,true,false));check(w.stalled(13000,0,true,false));w.reset();check(!w.stalled(20000,0,true,true));for(int i=1;i<=20;i++)check(!w.stalled(20000+i*200,i*200,true,true));check(w.stable(24000));check(!w.stalled(50000,4000,false,false));check(!w.stalled(90000,4000,false,false));check(!w.stalled(95000,4000,true,false));check(w.stalled(107000,4000,true,false));check(PreviewRecovery.previewHeight(854,1)==480);for(int i=72;i<78;i++){check(BrandMotionMath.motionKind(i)==i-42);check(BrandMotionMath.motionPhase(BrandMotionMath.periodUs(i),i)==0);}check(KineraAI.layoutFor(28,1.78f)==72);System.out.println("NeuralProfessionalStudioTest: watchdog, pause, recovery and new motion modes passed");}
}
