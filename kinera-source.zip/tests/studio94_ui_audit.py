from pathlib import Path
p=Path('app/src/main/java/az/kinera/edit');s=(p/'MainActivity.java').read_text();d=(p/'KAiDirector.java').read_text();g=(p/'BrandEffect.java').read_text();c=(p/'PrecisionCaptionPlan.java').read_text()
row=s[s.index('root=page(EXPORT,true)'):s.index('root=page(RESULT,true)')]
assert row.index('size=spinner')<row.index('root=vertical();fps=spinner')<row.index('root=visibleExport;')<row.index('kAI • Avtomatik ixrac')
assert 'efficientExport' not in row and 'autoExportHeight(),autoExportFps()' in s and 'EditSpec requested=spec();' in s
assert 'blurAxis.setSelection(2)' in s and 'blurAdjust.setMax(100)' in s and 'Studio94.encode(value)' in s and 'Studio94.normalize(Integer.parseInt(fields[8]))' in s
assert 'startFullCaptionPlan(false)' in s and 'startFullCaptionPlan(true)' in s and 'Studio94CaptionPlan.build(duration,left,right,restore)' in d
assert 'restoration?RestorePolicy.usable(r):RegionMath.active(r)' in c and '1.8f*active.blurStrength*Math.max(1f,Math.min(iw,ih)/720f)' in g
print('Studio94 UI source audit: visible size and hidden legacy export widgets, automatic policy, persistent strength slider, legacy draft migration, separate timed blur / restoration modes, shader radius wiring passed')
