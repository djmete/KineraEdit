package az.kinera.edit;
final class AutonomousDirectorTest {public static void main(String[] args){
 int[] dark=new int[256];for(int i=0;i<256;i++){int v=i/3;dark[i]=v*0x010101;}int[] g=AutonomousMath.grade(dark);if(g[0]<=50||g[0]>63)throw new AssertionError("dark exposure");
 if(AutonomousMath.grade(new int[0])[0]!=50)throw new AssertionError("empty");
 if(DirectorMath.clean(null,10000000).length!=0)throw new AssertionError("null cuts");
 long[] cuts={6000000,12000000};if(DirectorMath.sound(cuts,6023000,18000000)==0)throw new AssertionError("medium accent");
 for(String lang:new String[]{"az","tr","en","ru"}){UiLanguage.set(lang,"en");if(UiLanguage.tr("Proqramdan çıxmaq istəyirsiniz?").isEmpty())throw new AssertionError("locale");}
 UiLanguage.set("tr","en");if(!UiLanguage.tr("Vaxt").equals("Süre"))throw new AssertionError("blur locale");
 System.out.println("AutonomousDirectorTest OK");}}
