#!/usr/bin/env python3
import json,os,pathlib,re,sys
root=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'diagnostics');root.mkdir(parents=True,exist_ok=True)
try: outcomes=json.loads(os.environ.get('KINERA_STEP_OUTCOMES','{}'))
except json.JSONDecodeError: outcomes={}
lines=['KINERA CI stage outcomes:']+[f'{k}: {v}' for k,v in outcomes.items()]
failed=[k for k,v in outcomes.items() if v in ('failure','cancelled')]
lines+=['Failed stage(s): '+(', '.join(failed) or 'No failing step reported; inspect workflow initialization or post-job cleanup.')]
pattern=re.compile(r'error:|error |exception|failed|failure|could not|missing|mismatch|not found|denied|timed out|HTTP [45]\d\d',re.I)
for p in sorted(root.glob('*.log')):
 data=p.read_text(errors='replace').splitlines();hits=[x for x in data if pattern.search(x)]
 lines += [f'\n[{p.name}] matching lines:',*hits[-35:], 'Last log lines:',*data[-35:]]
report='\n'.join(lines)+'\n';(root/'FIRST_ERROR.txt').write_text(report)
print(report[-18000:]);summary=os.environ.get('GITHUB_STEP_SUMMARY')
if summary:
 with open(summary,'a') as f:f.write('### Kinera CI diagnostics\n```text\n'+report[-18000:]+'\n```\n')
