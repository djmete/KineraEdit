#!/usr/bin/env bash
# Read-only diagnostics; run while the app is active on an authorized Android device.
set -euo pipefail
command -v adb >/dev/null
adb get-state | grep -qx device
pkg=meteapps.kineraedit
out=${1:-kinera-device138-$(date +%Y%m%d-%H%M%S)}
mkdir -p "$out"
for service in meminfo gfxinfo cpuinfo thermalservice; do
  case "$service" in
    meminfo) adb shell dumpsys meminfo "$pkg" > "$out/$service.txt" 2>&1 || true;;
    gfxinfo) adb shell dumpsys gfxinfo "$pkg" framestats > "$out/$service.txt" 2>&1 || true;;
    *) adb shell dumpsys "$service" > "$out/$service.txt" 2>&1 || true;;
  esac
done
adb shell dumpsys package "$pkg" | grep -E 'versionCode=|versionName=' > "$out/version.txt" || true
printf 'Diagnostics saved in %s. Review logs for private details before sharing.\n' "$out"
