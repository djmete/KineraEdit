# v1.0.2 release acceptance (physical Android required)
1. Install signed APK over v1.0.1; verify existing projects remain.
2. Import unchanged 85053.mp4 locally. Test OtoEdit, OtoBlur and OtoBlurPro on your own or authorized media; inspect result, audio sync, actual subtitle mask and reconstruction artifacts.
3. Apply a blur, enter Blur again, change strength/geometry, leave without Apply. Confirm old effect remains and persists after app restart. Repeat while playing, in focus mode, with another tool and on background/resume.
4. Test narrow displays, large system fonts, landscape, focus, slider, cancel, seek and export. Verify no controls overlap or become inaccessible.
5. Record duration of analysis and export, result file format, frame drops, peak memory and temperature before/after. `bash qa/device138/collect.sh` uses ADB to collect diagnostic snapshots; gfxinfo is UI frame timing, not GPU utilization. CPU/thermal dumps are device-wide. Review logs for private data.
6. Do not label release Stable until GitHub build/sign/lint and these physical tests pass. Candidate neural weights remain disabled without independent benchmark and Android parity.

7. Confirm compact one-line controls at ordinary font scales and two-line labels at large scales; review text clipping and measure effective touch targets (48dp minimum recommended). Test a 440–939dp-high editor with seek bar rather than filmstrip. Keep before/after outputs and actual APK build logs.
8. At width 320–359dp verify the four tools scroll horizontally; at 360+dp verify equal targets when text fits. Inspect Slider on ordinary and 2x system font, and during playback. Verify the new asymmetric visual/zoom envelope on two adjacent shots of very different lengths.
