# V118 device acceptance — Kinera v0.8.2

- Build signed universal APK on GitHub; verify certificate and upgrade without losing projects.
- In airplane mode run Settings > kAI • CNN self-test. Expect PASS, two 32x32 patches, max error <=2e-5. This is not a reconstruction/export test.
- Open a 159s owned video; test OtoBlur and OtoBlurPro, small subtitles and off-center text, cancel/restart, wait for thumbnail decoder, return to player, preserve masks on failure. Check source-rescue logs and CPU/RAM/thermal.
- Compare OCR precision/recall on independently manually annotated real clips. Check higher-res source reread adds at most four decode requests and only within time/resource guards.
- Check Blur strength at 0/50/100, live playing/paused, CANCEL from interrupted touch should restore last committed strength, outside drags must not move the region. Undo/redo; portrait, compact and accessibility font.
- Export at user-selected HD/1080p and supported 2K/4K; verify exact dimensions, AutoSəs range, visual quality, wall time, peak RAM and temperature. Compare with V117 on same video.
- All physical-device checks pending.
