# v0.5.4 device verification (not run here)

- Install signed universal APK over v0.5.3; verify signer, package, migration and old template selection.
- On Poco F5 Pro and a small-screen Android 12 device, test portrait/landscape, system font 100/130/200%, 3-button and gesture navigation, screen rotation, background/foreground. Check four buttons, long labels, preview size and full-screen exit.
- In Blur, drag slider width/height/strength/X/Y, release/cancel, change axes, tap elsewhere, undo/redo, preview seek, play and back. Check slider remains visible and mask follows source coordinates for portrait/landscape/rotated input. Check actual blur rendering and export mask timing.
- Test silent, mono, stereo, high-rate audio, unsupported PCM fallback; confirm audio cannot invent cuts. Use hard cuts, pans, flash, music onset, speech; compare original and refined markers and note missed detections.
- Export 720/1080/4K, 24/30/60 fps, AVC/HEVC where supported; compare output aspect, duration, sync, first/last frame, heat, memory, and cancellation; test previous-frame GPU fallback and black preview recovery.
- CI: inspect lint, actual APK size report, certificate, all ABI/model assets and direct release download. No APK is included in source archive.
