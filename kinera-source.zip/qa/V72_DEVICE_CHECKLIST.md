# v7.2 device acceptance (not executed)
- Build signed APK, verify version 63 and signer pin.
- Upgrade without uninstalling; test existing draft style IDs 0–137.
- New IDs 138–155: inspect all 18 in preview and export, across 9:16, 1:1 and 16:9 sources; ensure video window remains clear.
- Restore a draft while auto audio is pending; verify it resumes measurement.
- Test malformed/overlapping saved blur masks, three-frame motion, timeline, navigation and export.
- Verify ML Kit offline availability, memory and player recovery.
