# v0.5.3 Stable — Neural Precision Director: device acceptance

This is a source release candidate; the Stable version name is not proof of device validation.

- Install the CI-signed universal APK over v0.5.2 on Android 12+; check drafts, package identity and signing certificate. Do not uninstall first.
- Test editor on 320/360/411/600 dp widths, landscape, split screen and 1.0/1.3 font scaling. Check four tools, focus, filmstrip, exact seek, back, and source/composed aspect alignment.
- Test Blur width, height, position, strength and time, pinch, cancel, undo/redo, orientation, and pause/resume. Verify no lost gesture on layout changes.
- Test native playback for VFR, H.264, HEVC, rotated MP4, 4K, audio-only rejection, slow decoder and unavailable codecs. Do not assume device-specific codec support.
- Test new template IDs 684–733 in portrait, square and landscape with long names, new six shader families, original color and no masked-area displacement.
- Confirm OtoBlur remains Gaussian blur. OtoBlurPro uses prior spatial/temporal reconstruction and denser short-clip OCR; it is not full generative inpainting. Inspect all masks visually.
- Test GPU shader compilation and fallback on Qualcomm/Adreno and Mali; compare exported frames with preview, check AV sync and MP4 validity for H.264/HEVC where supported.
- Check 24 consecutive-window cut probes and false-cut suppression on camera flashes, real cuts, fast pans, fades, subtitles and low light. The 7.8 classifier was trained on synthetic labels from three previously available clips, not semantic understanding or every-frame whole-video analysis.
- For own content, keep source footage, project edits and export proof. Do not use template effects as a guarantee of platform eligibility; appeal incorrect decisions through platform controls.
- Host Java tests and source audits were run; Android SDK, Gradle, physical device and actual APK verification were unavailable. Optional host EGL smoke test crashed before reporting results.
