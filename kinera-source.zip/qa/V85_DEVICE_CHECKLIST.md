# v8.5 physical-device checks (not executed on host)

1. Upgrade v7.x directly: only v8.5 highlight, never intermediate highlights.
2. Close by Continue, X or back; restart, rotate, background, change theme/language: no repeat.
3. Fresh install: no upgrade highlight. Minor release MAJOR=false: no highlight.
4. Check 320dp screen, landscape, font scale 1.5/2, gesture and 3-button navigation, cutout; footer reachable and no text overlap.
5. Confirm each AZ/TR/EN/RU translation, reduced motion and AMOLED color.
6. Verify 248-sample scan success, cancel and timeout; original masks preserved on failure.
7. Inspect moving subtitles and fixed text; compare preview/export on all GPU branches, ensure no contaminated corner samples.
8. Test 3GP, MP4, MKV; pause/seek/retry, gallery and result player; preserve original audio and timing.
9. Check output notifications and export failure recovery.
10. Confirm GitHub single signed universal APK, no nested ZIP.
