"""Evaluate compact CNN on user-authorized local clean videos with artificial masks.
Usage: python benchmark_video.py --weights /path/to/architecture105_student.npz --video clip.mp4
This is known-ground-truth reconstruction, not OCR detection or burned-in text removal validation.
"""
import argparse, json, cv2, numpy as np, torch
from torch import nn
p=argparse.ArgumentParser();p.add_argument('--weights',required=True);p.add_argument('--video',required=True);p.add_argument('--limit',type=int,default=100);args=p.parse_args();torch.set_num_threads(2)
class Mix(nn.Module):
 def __init__(self):
  super().__init__();self.net=nn.Sequential(nn.Conv2d(12,16,3,padding=1),nn.ReLU(),nn.Conv2d(16,3,1))
 def forward(self,x):
  w=self.net(x).softmax(1);return x[:,:3]*(1-x[:,9:10])+(x[:,:3]*w[:,0:1]+x[:,3:6]*w[:,1:2]+x[:,6:9]*w[:,2:3])*x[:,9:10]
n=Mix();w=np.load(args.weights);n.load_state_dict({k:torch.from_numpy(w[k]) for k in w.files});n.eval();cap=cv2.VideoCapture(args.video);previous=None;results=[];step=0;old_mask=np.zeros((32,32),np.uint8)
while len(results)<max(1,args.limit):
 ok,frame=cap.read()
 if not ok:break
 step+=1;f=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB);h,w=f.shape[:2];e=max(1,min(h,w)//2);left=(w-e)//2;top=h-e;f=cv2.resize(f[top:top+e,left:left+e],(32,32));m=np.zeros((32,32),np.uint8);m[18:25,5+step%5:25+step%5]=1;masked=f.copy();masked[m>0]=0;s=cv2.inpaint(masked,m,3,cv2.INPAINT_TELEA)
 if previous is not None:
  b=np.where(((m>0)&(old_mask==0))[:,:,None],previous,s);clean=cv2.inpaint(previous,old_mask,3,cv2.INPAINT_TELEA);a=cv2.cvtColor(clean,cv2.COLOR_RGB2GRAY).astype(np.float32);c=cv2.cvtColor(s,cv2.COLOR_RGB2GRAY).astype(np.float32);(dx,dy),r=cv2.phaseCorrelate(a,c,cv2.createHanningWindow((32,32),cv2.CV_32F));
  if not np.isfinite(dx+dy+r) or r<.25 or max(abs(dx),abs(dy))>6:dx=dy=0
  mat=np.float32([[1,0,dx],[0,1,dy]]);v=cv2.warpAffine((1-old_mask).astype(np.float32),mat,(32,32),flags=cv2.INTER_LINEAR)>=.999;a=cv2.warpAffine(previous,mat,(32,32));a=np.where(v[:,:,None],a,s);x=np.concatenate([s.transpose(2,0,1)/255,b.transpose(2,0,1)/255,a.transpose(2,0,1)/255,m[None],old_mask[None],v[None]]).astype(np.float32)
  with torch.no_grad():pred=n(torch.from_numpy(x[None]))[0].numpy().transpose(1,2,0)
  truth=f.astype(np.float32)/255;mae=lambda q:float(np.abs(q-truth)[m>0].mean());results.append([mae(s/255),mae(b/255),mae(a/255),mae(pred),float(np.abs(pred-truth)[m==0].max())])
 previous=masked;old_mask=m
cap.release();assert results,'No usable frame pairs';r=np.array(results);print(json.dumps(dict(frame_pairs=len(r),spatial_mae=r[:,0].mean(),raw_mae=r[:,1].mean(),aligned_mae=r[:,2].mean(),student_mae=r[:,3].mean(),visible_max_error=r[:,4].max(),note='Synthetic subtitle-region masks on decoded video crops; source type supplied by operator.'),indent=2))
