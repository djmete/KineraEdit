# v127 device acceptance checklist (pending)

- Build signed APK with existing signing secret and check package/version/upgrade.
- Test 320dp narrow width, large fonts, portrait and landscape, crop, blur focus, persistent slider, touch cancel, scrub and playback resume. Verify no clipped controls.
- On actual Android, `adb logcat -s KineraMetrics` for wall/thread CPU time, heap and thermal status, sequential frame counts and completion. Collect total process PSS via `adb shell dumpsys meminfo meteapps.kineraedit`; use Perfetto or device GPU profiler for GPU/CPU load, dropped frames and thermal throttling.
- Test authorized independent clips: portrait/landscape, faces, pans, flashing lights, hard cuts, low-light, OCR multilingual and subtitles. Compare precision/recall, IoU, false positives, PSNR/SSIM and subjective quality against v126. No independent video tested in host environment; DNS unavailable.
- Verify 720p/30fps short full sequential scan and fallback for >12s, 1080p/4K, 60fps, decoder rejection, thermal or budget pressure.
- Run full export with CPU/GPU/RAM and battery measurements; no unverified guarantee.
