# v7.3 device acceptance (not executed)
- Signed APK versionCode 64, same package/cert; upgrade from existing app without uninstall.
- Inspect all new styles 156–161 and shader families 48–53 in preview and export; compare prior 0–155.
- Force decoder errors while timeline is decoding; check bounded retries and fallback.
- Export failure/cancel: confirm editor and draft return; verify raw preview is clearly labelled.
- Test slow export and timeout fallback, audio/video duration and mask alignment.
- Test last short tracking interval and check results before export.
