# v0.5.5 physical validation (not executed)
- Test 320/360/393/480dp widths, portrait and landscape, 1.0/1.3/1.5 font scales, gesture and 3-button navigation. Confirm tool text stays readable, preview never collapses, all four tools reachable.
- Play 9:16, 16:9, square, rotated and VFR sources; verify overlay alignment in source/composed views, seek after pause, resume and back navigation.
- Blur: all five axes, continuous drag, cancellation, undo/redo, timed masks, switch between source/composed, confirm saved project reopened.
- OtoBlurPro: moving and static masks, cuts, gaps and seeks; compare against clean reference pixels, check fallback and temporal ghosting.
- Export H.264/HEVC at supported resolutions, audio sync, progress, cancellation, thermal load, file integrity and permanent signer. Test a real device before shipping.
