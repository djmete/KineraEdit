# Android device verification pending
- Install signed APK on a device with previous stable version; verify project/history migration and same signing fingerprint.
- 320/360/411 dp phones, font scale 1.0/1.3/1.8; portrait and landscape: verify 4 tools, readable controls, focus, timeline, undo/redo and apply.
- Blur: drag, tap, keyboard adjustment, second finger, cancellation, outside touch, rotation, app pause/resume; verify live preview and export match.
- Player: crop/blur switches, surface detach, 10 seek loops, pause/resume, 20 rapid mode switches; 24/30/60 fps H.264/HEVC and audio sync.
- OtoBlur review: compare ground truth text masks on independently recorded authorized video; report precision, recall and IoU, not just synthetic decisions.
- Reconstruct independently recorded video using clean target and synthetic occlusions; report MAE, PSNR, SSIM, temporal stability and GPU parity; do not activate candidate with regression.
- CPU/GPU/RAM, peak temperature, dropped frames, battery and export time: measure actual devices separately by resolution and codec.
- All tests above are pending, not implied by host checks.
