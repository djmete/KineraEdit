# v8.7 device cases (not run on host)
- Compare side-only mask reconstruction in preview/export, seek and scene change boundaries.
- Check all 228 styles and 78 motion families, existing four tools and themes.
- Check silent/no-cut export and scene accents, source duration and audio synchronization.
- Confirm single universal APK, retained signing certificate, no stale release highlight.
