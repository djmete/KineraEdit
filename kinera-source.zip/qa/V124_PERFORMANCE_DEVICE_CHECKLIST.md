# V124 device acceptance — Kinera v0.8.8
- CI compile and install signed universal APK over v0.8.7; verify versionCode 124 and permanent signing certificate.
- Compare OtoBlurPro on identical owned clips (static caption, pan, cut, face, moving caption) and old-vs-new high-quality GPU; measure MAE against clean originals, temporal flicker, actual export duration, RAM and temperature. Check fallback and exact HD/FHD/2K/4K dimensions.
- Test narrow editor/large font, two-line clock, seek cancel via multitouch or OS interruption, background/foreground, page change during scrub, live Blur, 9:16 Crop, reset and undo/redo; verify ordinary masks with/without scene markers.
- No actual Android device test or APK build completed in this environment.
