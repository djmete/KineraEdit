# v0.6.3 / VersionCode 99 — device acceptance checklist

**Permanent release gate:** export responsiveness, RAM, GPU, thermal throttling and output quality must be checked for each subsequent update. Do not claim device performance improvements from host timings.

1. Build in Actions using the matching ZIP and TXT. Verify permanent certificate, universal ABI inventory and APK_SIZE_REPORT.json.
2. On Poco F5 Pro, start cool, unplugged and with the same source file and same export profile for 0.6.2 and 0.6.3. Run three exports per version; record duration, resolution, FPS, source duration, render and total time, thermal status, reported heap/PSS, retry count, responsiveness. Let phone cool between runs.
3. Test 1080p/30 ordinary editing, 1080p/30 timed restoration, a 60 FPS full-quality source, portrait and landscape inputs. Check output frame dimensions, duration, audio sync, visible edit, masks and seams. Do not use a resolution/FPS downgrade as evidence of speed at equal quality.
4. During export open notification shade, return to app, attempt cancel, and test background/foreground transition. Check unfinished output is not published as successful. If the OS reports critical thermal/low RAM, the task should stop and keep source/draft intact. Do not deliberately overheat the phone.
5. Check blur controls on 320/360/393/411 dp widths, large fonts, drag/cancel, mask boundaries, undo/redo, and rotation. Player remains FIT; validate actual preview.
6. Compare OtoBlurPro across a short and long clip, verify no unwanted mask or reconstruction ghost, preserve draft on interruption. Bounded OCR is not an every-frame semantic model; no perfect inpainting claim.
7. Record unsupported or failed paths instead of marking them as passed. APK size alone cannot establish feature parity.

8. Under naturally occurring moderate thermal or low RAM conditions, verify the constrained preview/analysis paths and compare spatial/temporal output visually; record the quality trade-off. Never deliberately induce overheating. Check the scene-analysis fallback note after a bounded timeout.
