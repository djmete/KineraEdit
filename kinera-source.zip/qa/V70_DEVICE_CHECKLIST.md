# v7.0 device release gate (not run locally)
Build with original signer; install over v4.7 without uninstalling; back up drafts. Verify semantic fallback, OCR on single/three frames, export PCM, transition edges, tracking midpoint retention, preview seek and recovery, all tools, language and exit dialog.
