# Kinera v0.7.9 — V115 device release gate

Host validation is not an Android build. New bundled selfie segmentation SDK is beta; verify the Gradle dependency resolves, release builds, APK signing certificate is unchanged, and install succeeds in airplane mode. Confirm the existing ML Kit models and all ABIs remain present. Compare APK asset/native sizes against v0.7.8. The experimental Fusion104 CNN is not deployed.

## Poco F5 Pro acceptance
- Import portrait, landscape, no-person and document clips. Check model fallback only on the middle sample when previous classifiers are uncertain and pressure is low. Capture logs of inference duration, failure, and peak memory; test timeout and re-import. No need for Internet at runtime for the bundled SDK, subject to actual test.
- OtoBlur/Pro: use authorized clips with bottom-center, left/right, multiline, very small and moving captions; measure bounding box IoU and missed/false masks against hand annotation. Compare V114 vs V115. Check existing lower captions are not replaced by higher OCR text. Test cancellation and retry on 30s, 159s and 5min clips. Verify masks don't change on outside touch. Pro still uses existing GPU reconstruction, not the research CNN.
- Player: fast drag, keyboard/accessibility seek, exact final seek, both directions, back/resume. Compare scrubbing latency, dropped frames and freeze frequency. Confirm full video area at 320/360/411dp and large fonts. Verify reset/apply and persistent Blur slider, upper undo/redo, separate new and saved project workflows.
- Export same 720p, 1080p, 2K, 4K samples at least three times; compare wall-clock, peak RSS, thermal state, bitrate/FPS and final dimensions. No silent output resolution downgrade. Validate AutoSəs 5–20%, manual choice, audio/video sync, output file. Test 30s and 159s with restoration and without. Confirm temperature/load protection and no loss of edits on failure.
- Test notification/What's New, airplane mode, Maven 429 cold/warm cache CI, permanent signature. Verify all four main editor tools and prior languages.

Record actual screenshots, logcat, time/RAM and device build identifiers. A release labeled Stable still needs these physical checks.
