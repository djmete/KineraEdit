# v1.0.0 release acceptance (physical Android required)
1. Install signed APK over v0.9.9; verify existing projects remain.
2. Import unchanged 85053.mp4 locally. Test OtoEdit, OtoBlur and OtoBlurPro on your own or authorized media; inspect result, audio sync, actual subtitle mask and reconstruction artifacts.
3. Apply a blur, enter Blur again, change strength/geometry, leave without Apply. Confirm old effect remains and persists after app restart. Repeat while playing, in focus mode, with another tool and on background/resume.
4. Test narrow displays, large system fonts, landscape, focus, slider, cancel, seek and export. Verify no controls overlap or become inaccessible.
5. Record duration of analysis and export, result file format, frame drops, peak memory and temperature before/after. `bash qa/device136/collect.sh` uses ADB to collect diagnostic snapshots; gfxinfo is UI frame timing, not GPU utilization. CPU/thermal dumps are device-wide. Review logs for private data.
6. Do not label release Stable until GitHub build/sign/lint and these physical tests pass. Candidate neural weights remain disabled without independent benchmark and Android parity.
