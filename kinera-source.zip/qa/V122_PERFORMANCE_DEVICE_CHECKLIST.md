# V122 device acceptance — Kinera v0.8.6
- CI compile and install signed universal APK over v0.8.5; verify versionCode 122 and certificate.
- OtoBlurPro: compare identical owned clips in v0.8.5 and v0.8.6; include stable, panning, cut, moving face, persistent text, multi-line captions. Compare mask coverage, temporal flicker and clean reference if available.
- Verify fallback when new shader does not link; high load should still use existing lower-cost path. Record elapsed export, peak RAM and temperature; compare HD/FHD/2K/4K exact dimensions.
- In 470–679 dp and large font, confirm filmstrip fallback to time slider; test larger screen filmstrip, player focus, crop and blur live gestures, cancel, undo/redo, accidental touches, reset/apply while dragging.
- Test all four tools in AZ/TR/EN, template IDs, preview restart, audio and export. No physical device tested.
