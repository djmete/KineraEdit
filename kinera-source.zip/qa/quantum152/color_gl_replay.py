#!/usr/bin/env python3
"""Optional Linux/Mesa GLES2 check of actual base fragment shader.
No Android decoder, YUV/HDR or hardware timing assumptions. Requires NumPy + EGL/Mesa.
"""
import ctypes as C, os, re, json, sys
from pathlib import Path
import numpy as np
os.environ.setdefault('EGL_PLATFORM','surfaceless');os.environ.setdefault('LIBGL_ALWAYS_SOFTWARE','1');os.environ.setdefault('GALLIUM_DRIVER','softpipe')
root=Path(__file__).resolve().parents[2]; src=root/'app/src/main/java/az/kinera/edit'
def shader(dir):
 b=(dir/'BrandEffect.java').read_text();r=(dir/'RestoreConfidence.java').read_text()
 vert=next(l for l in b.splitlines() if l.strip().startswith('static final String VERT='))
 frag=next(l for l in b.splitlines() if l.strip().startswith('static final String FRAG='))
 lit=r'"(?:\\.|[^"\\])*"';v=json.loads(re.findall(lit,vert)[0]);f=list(map(json.loads,re.findall(lit,frag)));g=json.loads(re.findall(lit,next(l for l in r.splitlines() if 'static final String GLSL=' in l))[0]);assert len(f)==5
 return v,f[0]+g+f[1]+f[2]+f[4] # RestoreConfidence.ENABLED true
P=C.c_void_p;I=C.c_int;U=C.c_uint;F=C.c_float;B=C.c_ubyte;S=C.c_char_p
E=C.CDLL('libEGL.so.1')
def egl(name,ret,*args):
 f=getattr(E,name);f.restype=ret;f.argtypes=list(args);return f
getd=egl('eglGetDisplay',P,P);init=egl('eglInitialize',U,P,C.POINTER(I),C.POINTER(I));choose=egl('eglChooseConfig',U,P,C.POINTER(I),C.POINTER(P),I,C.POINTER(I));bind=egl('eglBindAPI',U,U);surf=egl('eglCreatePbufferSurface',P,P,P,C.POINTER(I));ctx=egl('eglCreateContext',P,P,P,P,C.POINTER(I));make=egl('eglMakeCurrent',U,P,P,P,P);proc=egl('eglGetProcAddress',P,S)
d=getd(None);a=I();b=I();assert init(d,C.byref(a),C.byref(b));assert bind(0x30A0)
# EGL_PBUFFER_BIT + EGL_OPENGL_ES2_BIT + RGBA8
attrs=(I*13)(0x3033,1,0x3040,4,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3038);cfg=P();count=I();assert choose(d,attrs,C.byref(cfg),1,C.byref(count)) and count.value
N=64;sf=surf(d,cfg,(I*5)(0x3057,N,0x3056,N,0x3038));cc=ctx(d,cfg,None,(I*3)(0x3098,2,0x3038));assert sf and cc and make(d,sf,sf,cc)
def gl(name,ret,*args):
 addr=proc(name.encode());assert addr,name;return C.CFUNCTYPE(ret,*args)(addr)
getstr=gl('glGetString',S,U);create=gl('glCreateShader',U,U);source=gl('glShaderSource',None,U,I,C.POINTER(S),C.POINTER(I));compile=gl('glCompileShader',None,U);getiv=gl('glGetShaderiv',None,U,U,C.POINTER(I));getlog=gl('glGetShaderInfoLog',None,U,I,C.POINTER(I),P);cp=gl('glCreateProgram',U);attach=gl('glAttachShader',None,U,U);link=gl('glLinkProgram',None,U);piv=gl('glGetProgramiv',None,U,U,C.POINTER(I));plog=gl('glGetProgramInfoLog',None,U,I,C.POINTER(I),P);use=gl('glUseProgram',None,U);uloc=gl('glGetUniformLocation',I,U,S);aloc=gl('glGetAttribLocation',I,U,S);u1i=gl('glUniform1i',None,I,I);u1=gl('glUniform1f',None,I,F);u2=gl('glUniform2f',None,I,F,F);u3=gl('glUniform3f',None,I,F,F,F);u4=gl('glUniform4f',None,I,F,F,F,F);gtex=gl('glGenTextures',None,I,C.POINTER(U));act=gl('glActiveTexture',None,U);bindtex=gl('glBindTexture',None,U,U);param=gl('glTexParameteri',None,U,U,I);img=gl('glTexImage2D',None,U,I,I,I,I,I,U,U,P);viewport=gl('glViewport',None,I,I,I,I);ena=gl('glEnableVertexAttribArray',None,U);attrib=gl('glVertexAttribPointer',None,U,I,U,B,I,P);draw=gl('glDrawArrays',None,U,I,I);read=gl('glReadPixels',None,I,I,I,I,U,U,P);err=gl('glGetError',U)
def program(v,f):
 ss=[]
 for typ,t in [(0x8B31,v),(0x8B30,f)]:
  sh=create(typ);p=S(t.encode());source(sh,1,C.byref(p),None);compile(sh);ok=I();getiv(sh,0x8B81,C.byref(ok));log=C.create_string_buffer(8192);getlog(sh,len(log),None,log);assert ok.value,log.value.decode();ss.append(sh)
 pr=cp();[attach(pr,sh) for sh in ss];link(pr);ok=I();piv(pr,0x8B82,C.byref(ok));log=C.create_string_buffer(8192);plog(pr,len(log),None,log);assert ok.value,log.value.decode();return pr
tex=(U*2)();gtex(2,tex);vertices=(F*8)(-1,-1,1,-1,-1,1,1,1);viewport(0,0,N,N)
gbuf=gl("glGenBuffers",None,I,C.POINTER(U));bbuf=gl("glBindBuffer",None,U,U);bufdata=gl("glBufferData",None,U,C.c_ssize_t,P,U);vbo=U();gbuf(1,C.byref(vbo));bbuf(0x8892,vbo);bufdata(0x8892,C.sizeof(vertices),C.cast(vertices,P),0x88E4)
y,x=np.mgrid[0:N,0:N];rng=np.random.default_rng(158);pattern=rng.integers(20,236,(N,N,4),dtype=np.uint8);pattern[:,:,3]=255;art=np.zeros_like(pattern)
def render(pr,pixels,strength,grade,rect):
 use(pr)
 def loc(name):return uloc(pr,name.encode())
 for index,data in enumerate((pixels,art)):
  act(0x84C0+index);bindtex(0x0DE1,tex[index]);param(0x0DE1,0x2801,0x2601);param(0x0DE1,0x2800,0x2601);param(0x0DE1,0x2802,0x812F);param(0x0DE1,0x2803,0x812F);img(0x0DE1,0,0x1908,N,N,0,0x1908,0x1401,data.ctypes.data)
 u1i(loc('src'),0);u1i(loc('art'),1);u4(loc('fit'),0,0,1,1);u4(loc('cropRect'),0,0,1,1);u4(loc('blurRect'),*rect)
 for i in range(3):u4(loc(f'extraBlur[{i}]'),0,0,0,0);u1(loc(f'restoreMode[{i}]'),0)
 for k,v in {'mirror':0,'fade':1,'brightness':0,'contrast':1,'saturation':1,'cutZoom':1,'directorGrade':grade,'brandProgress':-1,'motionPhase':-1,'motionKind':0}.items():u1(loc(k),v)
 u2(loc('pixelStep'),1/N,1/N);u2(loc('stepSize'),strength/N,strength/N);u3(loc('accentColor'),.5,.7,.8)
 index=aloc(pr,b'position');assert index>=0
 ena(index)
 bbuf(0x8892,vbo)
 attrib(index,2,0x1406,0,0,None)
 draw(0x0005,0,4)
 out=np.zeros((N,N,4),dtype=np.uint8)
 read(0,0,N,N,0x1908,0x1401,out.ctypes.data)
 assert err()==0;return out
v,f=shader(src);pr=program(v,f);base=render(pr,pattern,0,0,(0,0,0,0));outside=~((x>=16)&(x<48)&(y>=16)&(y<48));inside=~outside;rows=[]
for strength in [.4,1.,2.5,4.]:
 for grade in [-.15,0,.15]:
  result=render(pr,pattern,strength,grade,(.25,.25,.75,.75));diff=np.abs(result.astype(int)-base.astype(int))[:,:,:3];assert diff[outside].max()==0;assert diff[inside].mean()>1;rows.append({'strength_pixels':strength,'director_grade_uniform':grade,'outside_max_rgb_delta':int(diff[outside].max()),'inside_mean_rgb_delta':float(diff[inside].mean())})
solid=np.tile(np.uint8([54,123,203,255]),(N,N,1));flat0=render(pr,solid,0,0,(0,0,0,0));flat1=render(pr,solid,4,.15,(.25,.25,.75,.75));assert np.abs(flat1.astype(int)-flat0.astype(int)).max()<=1
report={'renderer':getstr(0x1F01).decode(),'version':getstr(0x1F02).decode(),'test':'actual base GLES2 fragment, synthetic RGB texture, transparent overlay, SDR neutral grade, fixed geometry','cases':rows,'outside_pixels_per_case':int(outside.sum()),'solid_color_max_delta':int(np.abs(flat1.astype(int)-flat0.astype(int)).max()),'android_device_or_hdr_verified':False}
if len(sys.argv)>1:
 oldv,oldf=shader(Path(sys.argv[1]));old=program(oldv,oldf);oldres=render(old,pattern,1,.15,(.25,.25,.75,.75));diff=np.abs(oldres.astype(int)-base.astype(int))[:,:,:3];report['previous_shader_outside_mean_rgb_delta']=float(diff[outside].mean());assert diff[outside].mean()>1
print(json.dumps(report,indent=2))
