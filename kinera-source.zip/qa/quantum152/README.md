# Quantum152 color audit

Linux Mesa softpipe: actual base shader linked and rendered with a 64x64 synthetic RGB texture, transparent art, neutral grade, fixed crop/fit and no animation. Twelve strength/legacy grade combinations; 3072 outside-mask pixels each, zero RGB delta; constant-color image unchanged. Previous shader with grade +0.15 had mean outside-mask RGB change 13.70/255. This is not a device test, color-management or HDR equivalence check. Initial llvmpipe/driver draw crashed; softpipe completed. Reproduce: `python qa/quantum152/color_gl_replay.py` (requires NumPy and Mesa EGL). Optional first argument points to previous Java source directory for negative control.

Native splash: https://developer.android.com/develop/ui/views/launch/splash-screen ; HDR and preview/export distinctions: https://developer.android.com/media/media3/transformer/supported-formats .

Device acceptance: import SDR clip, pause away from scene cut, compare unmasked regions while moving and adjusting Blur, apply, export, inspect unmasked region in decoded output. Older project with saved grading: use Reset colors on export settings if desired; verify HDR separately, as output uses existing SDR tone mapping. No guarantees of identical encoder pixels.
