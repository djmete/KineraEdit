# 30 review workstreams — not independent agents
1. Source baseline: v7.7 tree copied.
2. Version: 7.8.0 / 69; regression assertions.
3. kAI version: 5.8.
4. Historical training entries: SHA256 audit.
5. Row counts: previous inventory plus new arrays.
6. Nominal weights: exact Python integer sums.
7. Source-disjoint synthetic benchmark.
8. Model training: weighted RGB regression.
9. Model quantization: int16, full weights retained.
10. Python/Java prediction parity.
11. OtoBlurPro: second raw history texture.
12. History cut/seek protection.
13. History memory budget.
14. Masked pixel rejection in old frame.
15. Shader fallback and five shader compile tests.
16. GPU synthetic pixel rendering.
17. OCR valid seed geometry.
18. Player watchdog stable-state reset.
19. Existing player recovery tests.
20. Existing export safety tests; no new encoder.
21. Six appended template IDs, prior IDs unchanged.
22. New template geometry and selection tests.
23. Existing 60 motion families reused.
24. UI: controls and time label; visual device test outstanding.
25. Single universal APK workflow.
26. Native compression without ABI exclusions.
27. Single APK archive inspection fixture.
28. Existing signer pin / package checks.
29. XML/YAML/shell syntax and embedded source integrity.
30. Android build, install, real media tests: outstanding (no SDK/device).
