# Version 130 physical-device acceptance
- Install signed version 130 over version 129 with the same certificate. Confirm drafts and settings remain intact.
- On 320dp / 360dp / 411dp phones, font scales 1.0 and 1.5, verify crop/blur tools, play/seek, back, apply/reset, focus mode and rotation; check no hidden actions, black preview, or text overlap.
- Drag Blur strength at 0, 50, 100; cancel and multi-touch; confirm committed value, effect and export agree. During a long drag verify pressure throttling.
- Try 12/30/60/90s 720p 30fps clips, 120s long clips, VFR/60fps/4K. Verify full-pass acceptance only with EOS, old markers retained on failure and no thermal overload. Record `adb logcat -s KineraMetrics`, elapsed time, heap, device thermal status, `adb shell dumpsys meminfo meteapps.kineraedit` and gfxinfo. Never infer device performance from host tests.
- Benchmark independently recorded licensed camera videos with artificial masks and ground truth, group-disjoint from training. Compare MAE/PSNR, temporal flicker, scene boundary behavior, visual quality and export latency; do not activate experimental weights before both quality and device checks.
- Run GitHub workflow with correct archive digest; confirm signed APK, lint and release delivery. Cold-cache offline failure recovered online must be reported as successful delivery. No key rotation.
