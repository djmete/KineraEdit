# Physical Android acceptance (not run here)
1. Install as upgrade from 6.1 without clearing data; verify signature, channel, language and draft preservation.
2. Poco F5 Pro: import 176x144, 1080x1440, 1080x1920 and landscape H.264/HEVC. Compare composed vs source mode, seek +/-5s, fullscreen, edit panel, pause/resume and rotation.
3. Apply Blur at center, drag edges, change tool, seek, reopen, compare preview and export. Confirm controls fit at 320dp and 1.3x font scale.
4. OtoBlur unified OCR and long-press OtoBlurPro; review all intervals and after tracking stops. Do not assume complete privacy masking.
5. Export a clip with source audio and detected cuts; verify accent timing, no clipping, unchanged duration and correct video dimensions. Test silence, loud transients, muted video, insufficient storage and unsupported codec without losing preview.
6. Check all four UI languages, back navigation, exit confirmation, gallery sort/filter, channel selection, settings and about. Confirm hidden home shortcuts remain hidden.
7. Record build and GPU/decoder logs, screenshots and frame rates; no real device success declared in advance.
