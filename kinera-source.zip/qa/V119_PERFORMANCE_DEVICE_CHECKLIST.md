# V119 device acceptance — Kinera v0.8.3
- Build universal APK; confirm same signer, exact versionCode 119, projects preserved.
- In editor manually analyze scene markers or use existing markers; test subtitles ending just before/after a scene change, short blank intervals, and both OtoBlur modes. Compare masks and annotate missed text; no-marker fallback should match V118.
- Test 470–539dp Blur panel, timeline seek, mask outside taps, cancel gesture, Undo/Redo, 0/50/100 strength, playing and paused. Verify player height and controls at larger accessibility fonts.
- Run the existing CNN self-test in airplane mode. The new mixture model is not deployed.
- Measure OCR latency, native decoder stalls, peak RAM, temperature, 720p/1080p/2K/4K export dimensions and wall time on actual phone.
- Physical Android device and full APK build are pending.
