# v8.3 on-device acceptance checklist (not executed here)
- Install signed v8.3 over v8.2; confirm existing drafts, channels, preferences and theme.
- Import MP4, HEVC and legacy 3GP; check play/pause, timeline and seek, rotation and background recovery.
- Run OtoBlur and OtoBlurPro full-video scan on authorized test content; compare OCR proposal at transitions and short captions. Cancel while OCR is pending, then seek/play after decoder exits.
- Use fixed-area restore for stable subtitles and manually review the whole result. The OCR scan is sampled, not per-frame; spatial reconstruction is approximate and cannot reconstruct unknowable content exactly.
- Test two overlapping restore/blur masks; verify clean boundary behavior, review when both spatial axes are blocked.
- Verify template IDs 162–209 on preview and export; test export fallback at lower resolution and verify no template remapping.
- Check gallery player, notification completion, dark theme, language layout and file integrity. Benchmark actual export speed on device.
- GitHub build must produce one signed universal APK with no nested artifact ZIP. Do not change the signing secret.
