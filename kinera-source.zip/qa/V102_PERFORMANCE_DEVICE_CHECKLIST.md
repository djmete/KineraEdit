# v0.6.6 / VersionCode 102 — device acceptance (pending)

1. Pick video A; apply manual Blur, resize, change strength; Undo until clean and Redo each step. Verify both visible preview and exported output, including paused playback. Confirm one new edit after Undo clears Redo. Repeat with OtoBlurPro temporal masks and reset. Test rapid taps and timeline seek; check no stale GPU frame.
2. Leave editor; pick A again via New Video. No prior masks, old cut markers or history should appear. Explicitly open Saved Projects to resume latest saved draft; new saves to same URI replace that draft. Original video never overwritten. Repeat A/B/A.
3. Check top history buttons, bottom reset/apply visibility, 320/360/400dp widths, large fonts and landscape. Check all four main tools and FIT player.
4. Compare identical input, resolution, FPS, quality and initial thermal state on v0.6.5 and v0.6.6. Record median of three runs: preparation/render time, FPS, peak thermal, Java heap and process RAM, UI responsiveness, output size. Separate ordinary export and Pro restoration; do not intentionally overheat phone. Test cancel and subsequent export; verify thermal protection and mask accuracy.
5. Run GitHub CI; check APK versionCode 102, permanent signer and universal ABI coverage, APK_SIZE_REPORT.json, lint, dependency/compile diagnostics. Physical device tests not performed in host environment.
