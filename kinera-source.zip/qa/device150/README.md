# v1.1.4 RC device acceptance
- Compare v1.1.3 and v1.1.4 with the four exact reference videos; use same resolution, FPS and device conditions. Record OtoEdit, OtoBlur, OtoBlurPro and export wall times, RAM and thermal conditions.
- Inspect alternating dark/soft accents on successive medium shots and quieter adjacent audio accents. No semantic match-cut or dialogue classifier is shipped.
- Check paused/live Blur (drag, strength, cancel, apply, scrubbing, first frame, near end and timed boundaries). Confirm resumed READY tick flushes the pending draft.
- Verify masks after seeking backwards and across a restoration gap; no history capture change expected. Manual crop must remain unchanged.
- Prior 5–20% OtoSes level policy remains; no speech/music separation. No APK or device results claimed.
