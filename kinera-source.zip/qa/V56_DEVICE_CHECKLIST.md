# v5.6 device acceptance (not executed on Android)
1. Import a 176x144 3GP H.263 clip, a 176x144 MP4 and a regular H.264 MP4. Confirm the first frame appears in composed mode or the labelled direct-source fallback. Press Play, +/-5s and scrub; ensure position is retained.
2. Switch Crop -> Blur -> normal several times, check complete centered frame, no stale frame from another video. Check masks remain in source coordinates. Raw fallback is not a rendered montage and must never be represented as one.
3. Trigger a GPU error: verify limited retry, direct SurfaceView mode with no effect pipeline, explicit failure notice and static source frame if possible. Retry by touching the notice.
4. Check gallery scroll, filename and dimensions, multi-channel profile switching, settings, export and about in all languages. Home must not show last project, template library or batch export.
5. Export H.264 on physical device; verify original masks and correct template. Test both Android 12 and 15/16; measure frame latency and dropped frames. Never infer successful export from preview success.
