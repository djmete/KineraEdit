# V123 device acceptance — Kinera v0.8.7
- CI compile and install signed universal APK over v0.8.6; verify versionCode 123 and permanent signing certificate.
- Compare OtoBlurPro on identical owned clips in v0.8.6 and v0.8.7 (static text, panning, scene cuts, moving face, long subtitles). Measure reconstruction MAE against clean originals if available and temporal flicker.
- Compare high-quality GPU export versus fallback; log actual export duration, RAM and temperature; verify HD/FHD/2K/4K exact dimensions.
- Verify narrow editor and long time labels, missing thumbnail slots, timeline multi-touch, memory pressure; test live Blur, 9:16 Crop, gesture cancel, undo/redo, all four tools and player reopening.
- No device tests completed in this environment.
