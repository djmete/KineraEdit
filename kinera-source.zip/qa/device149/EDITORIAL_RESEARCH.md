# Editorial research — v1.1.3
Public tutorial descriptions and summaries reviewed (not full video playback):
- https://www.youtube.com/watch?v=y5-fGEiAcUo — Daniel Livingstone action montage; pacing, match action, flare and sound effects.
- https://www.youtube.com/watch?v=YtULPT1aBWM — essential editing cuts; J/L, match, jump and smash cuts.
- https://helpx.adobe.com/ca/premiere/desktop/edit-projects/trim-clips/perform-j-cuts-and-l-cuts.html — J/L dialogue transitions.
Applied: shot-duration/neighbor-balance decisions for restrained clean/soft, dip, lift and push accents, shared visual and audio cadence. Not implemented: semantic match cuts, split audio J/L cuts or independent multi-track editor. No external video copied or trained on.
