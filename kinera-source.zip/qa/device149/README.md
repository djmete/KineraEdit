# v1.1.3 device acceptance
- Open Blur on a paused frame at 00:33, drag strength from 0 to 100 and back without Apply; verify image changes while dragging. Repeat during playback, resizing and moving the mask, and under memory/thermal pressure. A paused refresh can temporarily move by one frame; verify Apply/Cancel returns to original anchor. Test beginning/end, timed mask boundaries, decoder fallback and fast tool switching.
- Verify no disk/history changes before Apply and correct rollback on Cancel, back or multitouch cancellation.
- Compare short, medium, long balanced and long asymmetric scene transitions with v1.1.2; inspect visual quality and audio, ensure masks and manual crop prohibit zoom.
- Measure actual Android OtoEdit/OtoBlur/OtoBlurPro and export timing with four private references. Host timing and replay do not establish physical device quality or latency.
