# v7.9 device verification checklist (not executed on a phone)

The user requested 50 agents; this build used a single development workflow. The following are 50 review/device checks, not independent agent results. Host tests cover pure logic, Java parsing, and Mesa EGL shader smoke only.

1. Fresh install
2. Upgrade previous signed release
3. Retain channels
4. Retain drafts
5. Restore source URI
6. Keep legacy template IDs
7. Studio theme
8. AMOLED theme
9. Device night theme
10. Theme persists on restart
11. Theme changes do not alter rendered video
12. Dialog text contrast
13. Gallery background contrast
14. Navigation bar contrast
15. Small-screen header
16. Large-font tool labels
17. Turkish labels
18. Azerbaijani labels
19. English labels
20. Russian labels
21. Back navigation
22. Crop interaction
23. Blur slider and mask edits
24. OtoBlur OCR grouping
25. OCR cancellation
26. OtoBlurPro texture reconstruction
27. Mask safety and manual review
28. Two-frame memory bounds
29. Seek resets history
30. Scene cut resets history
31. Pause/resume
32. Playback scrub
33. H.264 preview
34. HEVC preview
35. 3GP H.263 preview where device supports it
36. Raw fallback
37. Result Media3 controls
38. Result player close
39. Background during result playback
40. Export H.264
41. Export HEVC where supported
42. Export cancellation
43. Audio preservation
44. Auto audio fallback
45. New template geometry
46. New GPU animations
47. Old template rendering
48. Gallery search and open
49. APK signature/size report
50. Offline model inference
