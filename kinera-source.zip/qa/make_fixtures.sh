#!/usr/bin/env bash
set -euo pipefail
mkdir -p "${1:-fixtures}"
for size in 1080x1440 720x1280 1280x720 720x720; do
 ffmpeg -hide_banner -loglevel error -y -f lavfi -i "testsrc2=size=$size:rate=30:duration=6" -f lavfi -i "sine=frequency=440:sample_rate=48000:duration=6" -c:v libx264 -preset ultrafast -crf 25 -pix_fmt yuv420p -c:a aac -shortest "${1:-fixtures}/fixture-$size.mp4"
done
