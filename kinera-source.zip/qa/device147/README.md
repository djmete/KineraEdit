# Android acceptance checks — v1.1.1 RC
Use original four private reference videos: 85053, 85196, 85197, 85198. Use the previous APK as the control, same device and export resolution/FPS.
- With stable player preference enabled, open Blur, verify composed preview unless decoder fallback is required. Add mask after seeking to 30 seconds, apply full video, seek to beginning, middle and end, then export and inspect the same timestamps. Verify intentional partial ranges and reverse seeks across mask boundaries.
- At tall display sizes verify the global audio control below filmstrip; verify it disappears in focus, crop/blur and large-font modes. Check automatic gain (5–20%, or 0 for no audio) and unchanged manual gain. Not an independent audio track.
- Record render duration, prep duration, thermal state and UI responsiveness using prior ADB diagnostics. New CPU-side short circuits and mask cursor are not measured Android export speedups.
- Verify Cut ratios and four existing tool buttons, home without saved-drafts section, old project data unchanged, preview and final 9:16 canvas.
