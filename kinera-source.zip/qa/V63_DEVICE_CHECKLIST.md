# 6.3 device verification (pending)
1. Build signed APK in GitHub, verify versionCode 54, package and original certificate.
2. Test import 176x144 legacy, 1080x1920 portrait, 1080x1440, landscape; first frame, pause/play, seek ±5s, rotate/fullscreen, raw fallback.
3. Enter Blur and leave repeatedly, resize handles, verify mask and template persist, compare preview to export.
4. OtoBlurPro on still, motion, occlusion and cuts. Verify midpoint masks and coverage manually; never assume anonymization.
5. Export a clip with loud source audio and cut accents; check PCM clipping, source volume, synchronization and frame count. Test no-audio clip.
6. Check all four languages, small-screen buttons, gallery, channel selection, settings, about, back navigation and exit dialog.
7. Record device model, OS, export duration, crashes and logs; no pass implied before testing.
