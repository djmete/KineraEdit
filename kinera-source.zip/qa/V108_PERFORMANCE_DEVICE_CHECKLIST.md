# V108 device verification (pending)
- Upgrade from v0.6.8 with permanent signing key. Home release highlight opens once, manual Yeniliklər works and notification test still works with allowed/denied/disabled channel states.
- 320/360/393/411 dp widths; 1.0/1.3/1.5 font scale; portrait and landscape. FIT player, top Undo/Redo, four tools, full screen and dock. No overlap or cut-off. Blur strength slider stays visible while dragging. Geometry moves by drag and pinch; timing/masks in More. Verify accessibility focus and keyboard input.
- New video starts fresh; saved project restores its original encoded strength (legacy 0/1/2 and new 100–200). Test 0, 60, 100 percent; Undo/Redo and re-open; verify preview and export correspond.
- OtoBlur full-duration sampled plan is blur-only; OtoBlurPro restore-only. Test variable subtitles, short captions, no text, scene changes, dense text, edge captions, cancelled scan, low memory, rotated videos. Confirm before applying, verify prior edits preserved after cancel. No guarantee of every-frame OCR or perfect reconstruction.
- Export has no manual FPS/bitrate/codec controls. User selects HD, FHD, QHD or UHD portrait canvas, up to 30 FPS (source-dependent), H.264 and automatic bitrate; retries preserve chosen dimensions. Check 15/24/25/30/60 FPS source, 4K source, pressure and Pro mask cases. Record actual output media metadata and check A/V sync. Test no-source, cancellation, unsupported codec and low storage.
- Same 60s 1080p clip with/without masks, compare v0.6.8 with v0.7.2. Record prep/render duration, actual FPS, PSS, heap, max thermal status, touch responsiveness and quality. Repeat long/thermal-pressure clip. Do not claim device speed before measurement.
- Verify Android compile, universal APK cert, size report, real-device GPU render. Host tests are not Android tests.

- Compare low-resolution source output, 1080p source under pressure, retry FPS without lowering resolution, 0% Blur and short centered caption alongside corner text.
- Record actual export wall time, heat and RAM.

- Select each resolution; verify output metadata exactly matches it or an explicit failure is shown. No silent downscaling. Check 429 with warm Gradle cache.

## New checks
- Only HD 720p, FHD, QHD and UHD available; legacy SD setting migrates to HD.
- Confirm output exact geometry and no silent downgrade.
- Verify mask overflow does not reuse contaminated prior frames.
- Check 540dp Blur seek, large fonts and landscape.

## Host EGL smoke
`python3 tests/gpu_reconstruction_smoke.py --softpipe --ultra-blur` passed on software Mesa, not Android.
