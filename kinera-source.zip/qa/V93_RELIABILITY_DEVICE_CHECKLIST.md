# v0.5.7 device acceptance (pending)
- Install signed APK over v0.5.6; verify draft, preferences, template ID preservation.
- Poco F5 Pro / Android 12+ : portrait and landscape, 320/360/411dp, font 1.0/1.3/1.5, split screen. Check toolbar scrolling, focus, back, all four tools and apply/undo.
- Blur: drag width/height/X/Y and strength, cancel touch, rotate, scrub, play; verify region maps to video content without stretching.
- Preview: source/effect transition, pause/resume/background, seek and recovery, audio/no-audio, HDR and rotated inputs.
- Export: 0.5/1/5/60-second clips, 24/30/60fps, codec fallback, low storage, cancellation, gallery; verify actual duration and frame integrity.
- GPU: new template animations and restoration against known clean frames; inspect temporal ghosting, no cut/seek contamination.
- Collect Actions logs if compilation or lint fails; no physical device results have been recorded.
