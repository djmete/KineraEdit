# Physical device validation (pending)
- Android 12, 13, 14, 15: install/upgrade with original signer; inspect output.
- POCO F5 Pro: portrait, landscape, font scales 1.0/1.3/1.5; check player bounds, slider CANCEL and drag, back, undo, redo.
- Verify 24/30/60fps timeline, source/preview switch, seeking, long clip, audio, export 720/1080p, memory/thermal.
- Test GPU motion IDs 96–101 and history across cuts; inspect visual artifacts.
- Compare original content and editing quality; no platform originality guarantee.
