# v8.2 device checks (not executed here)

- Verify v8.1 upgrade with original signature; restore old projects.
- Verify 62-mask project save, reopen, undo, redo and export; no more than three active extra masks.
- Test different subtitle locations in each half-window, missing second detection, and stationary subtitle fixed-region mode.
- Cancel OCR mid-frame, rotate/pause/resume, open another video, and test 170-second deadline.
- Inspect all six new templates and preview/export parity at 720p, 1080p, 4K.
- Test MP4/3GP/MKV, legacy codec fallback, scrubbing, repeated recovery and result gallery playback.
- Verify single universal APK and release assets, signer, size report and no nested archive.
- All older QA lists remain in the source; no claim of 50 independently executed agent tasks.
