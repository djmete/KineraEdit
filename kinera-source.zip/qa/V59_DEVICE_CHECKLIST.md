# v5.9 device acceptance (not executed here)
- Install release over v5.8 with the same certificate; confirm channel and saved edits retained.
- Test 1080x1920 (the reported regression), 1080x1440, 720x1280, 1280x720, 176x144 and rotated source clips. Test on the actual target phone.
- Open Blur, compare full composition before/after opening, resize all four edge handles, and verify that the output occupies the whole exact-ratio canvas, not a bottom-left quadrant. Test pause, playback, ±5s, scrub, tool exit, undo/redo, fullscreen and back navigation. Check handles align with the exported region when mirror is active.
- Inspect actual output for black bars, cropped labels or misplaced blur. Verify source fallback clearly states effects are not live; retry returns to composition.
- Tap OtoBlur once; no frame-count selector should appear. Confirm only a proposed region after analyzing; if OCR disagrees, no edit is applied. Long-press OtoBlur to track a selected region; confirm results before using them.
- Test 4K export, memory usage, HDR fallback, Android lifecycle, and gallery/permission behavior. Compare startup, stalls, and export time with v5.8.
