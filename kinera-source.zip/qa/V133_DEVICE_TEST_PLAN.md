# v0.9.7 device acceptance checklist
- Install signed APK over existing install; confirm package identity and user settings.
- Import private original 85053.mp4; do not redistribute it. Verify 159.2s and audio. Run AutoEdit and capture `adb logcat -s KineraMetrics` (scan wall/CPU, heap, thermal, decoded/sampled frames, EOS).
- Inspect the 18 host candidate positions, compare actual playback; review missed/false cuts manually, do not assume host timestamps are Android output.
- Test OtoBlur at the 11 timestamps in qa/reference85053/caption_anchors.csv, inspect suggested mask and manually approve only authorized caption edits. Verify neighboring objects and text are not covered. Export a short authorized test and compare to reference; no clean ground truth exists for embedded text.
- Blur: change mask, strength, timing, multiple regions; back without Apply; switch tools; focus Back; background; export; verify confirmed preview, persistence and exported result remain unchanged. Repeat with Apply and verify persistence after restart.
- Studio: portrait/landscape, 320–600 dp widths and large font; test slider, scrubbing, playback, navigation. Check CPU/GPU/RAM/thermal and frame drops on real hardware; no numerical performance promise.
