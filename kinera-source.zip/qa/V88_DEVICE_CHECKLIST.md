# v8.8 physical-device checks (not run on host)
- Compare cognitive side weighting vs old shader on textured masks, overlapping captions, scene cuts, seeking and export; inspect text leakage and flicker.
- Recheck the existing four editor tools, all 234 template IDs and 78 animation families, Studio/AMOLED/system themes.
- Check foreground notification final progress, channel/permission off/on, cancellation, repeated exports and completion alerts.
- Test stalled or oscillating player position, intentional seek, pause/resume, background, 3GP and 4K import; verify fallback and retry limits.
- Verify strong audio onset protection without modifying chronology, audio/video sync, source gain and silent clips.
- Verify universal APK signature, upgrade from v8.7, no nested delivery ZIP and no stale release highlight.
