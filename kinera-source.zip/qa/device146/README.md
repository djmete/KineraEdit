# Android acceptance checks — v1.1.0 RC
Reference: user-provided CapCut screenshot 85204.jpg (not redistributed).
- On 85053, 85196, 85197, 85198, open editor, seek to 30 seconds, create a new manual Blur region. Apply; seek to 0:00, 0:01, 0:10, 0:29, 0:30 and final seconds. Verify the same region in preview and exported video. Repeat while stable/raw preview is off.
- Set a deliberate 30–60 second range; confirm no blur outside it, then choose Bütün video; confirm from first frame. Test Cancel, Undo/Redo, reset, and previously saved extra masks.
- Verify home does not display saved projects; existing files not deleted. Verify four tools, fullscreen control below preview, touch and native seek at different font scales, portrait/landscape.
- Export at the same resolution/FPS as v1.0.9 on the same device; record prep/render/total durations and thermals using the existing diagnostics. Compare output visually. No speedup is asserted without these measurements.
- Verify automatic volume remains 5–20% for audio tracks; no-audio clips may return 0. Manual gain unchanged.
