# v6.6 device checklist (not yet executed)
- Import a dark, normal and clipped-highlight source; confirm automatic grade remains conservative and saved projects retain existing grade.
- Verify Blur/Flip coordinate alignment on portrait, landscape, rotated and legacy codecs; seek ±5 s and switch tools.
- Track a target moving back toward its origin; confirm short intervals after recent motion and no fabricated masks after loss.
- Export 720p/1080p/4K and compare preview geometry/audio; confirm no clipping or stereo balance regression.
- Verify all four tools, gallery, channels, settings, language switching and exit dialog on Android 12–15.
