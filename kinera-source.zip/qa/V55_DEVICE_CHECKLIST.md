# v5.5 device acceptance checklist (not yet executed on physical Android)
1. Open 1080x1440, 9:16, 16:9, rotated and square MP4. In normal preview, all four boundaries of the 9:16 template are visible; the exact canvas is centered, neutral surrounding editor area is not part of export.
2. Open Blur at 0:00; resize all four side handles; tap outside; scrub ±5 seconds; pause/play; Apply; reopen Blur. Position, mask and template remain unchanged unless deliberately edited.
3. Test crop raw/composed transitions, full-screen focus, device rotation, background/foreground, selecting the same URI and resuming a saved draft. Test recovery when shader or decoder fails; raw fallback must be labeled and not modify project.
4. Check timeline thumbnails arriving during scrubbing. Confirm no reset and no layout jump. Test rapid seek and seek while edits are dirty.
5. Compare paused preview and exported output at a blurred subtitle, mirrored source and timed region boundaries. Validate the softer shader on real Adreno/Mali GPUs; assess frame time and privacy coverage.
6. Verify home has no manual template library/batch export, four toolbar tools fit without horizontal scrolling, and imported videos receive content-based stable style. Ensure template is the same in export.
7. Track a chosen object for up to 16 seconds; verify all intervals, low-confidence stop, no changes on cancel, undo/redo and draft restore. Tracking is experimental; do not rely on it for guaranteed privacy.
8. Run GitHub signed APK build and install over v5.4. Confirm app data and signing certificate remain valid.
