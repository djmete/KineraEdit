# v0.6.7 / VersionCode 103 — device acceptance (pending)

- Repeat identical ordinary and OtoBlurPro exports at same resolution, FPS and quality, initial thermal status; record three runs, median preparation/render/total duration, Java heap, process RAM, peak thermal status, UI responsiveness and APK size. Compare v0.6.6. Do not deliberately overheat device.
- On small screen, confirm hidden timeline produces no frame decoding; on large screen, show timeline and verify frame preview. Hide during loading, switch video and export; confirm decoder released and no stale thumbnails.
- Test 320/360/400dp widths, large fonts, landscape, top Undo/Redo (48dp each), slider, player FIT, four tools. Apply Blur and Pro masks, undo/redo, pause/seek, leave and choose same video (fresh), explicitly reopen saved draft.
- Compare contrast-change and real cut clips; evaluate both false positives and missed cuts. Check recovery around cuts and seeks. Do not assume model generalization.
- GitHub CI: verify signed universal APK versionCode 103, certificate, APK_SIZE_REPORT.json and lint; Android and physical GPU tests pending.
