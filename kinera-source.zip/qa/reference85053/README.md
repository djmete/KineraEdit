# Permanent private reference 85053
Keep the original unchanged. Run `bash qa/reference85053/replay.sh /absolute/path/to/85053.mp4` in each release. This runs a desktop replay of production Java scene-selection policies on all decoded luma frames, and geometry-only checks using 11 approximately hand-reviewed subtitle rectangles. The existing old-policy vs new-policy marker lists are not scene ground truth. No Android MediaCodec, Media3, ML Kit OCR, OtoBlurPro export, or TikTok classifier is exercised by these checks.

For device testing, import the private original with the app's normal video picker. Check 0, 15, 30, 45, 60, 75, 90, 105, 120, 135, and 150 s. The lower text is embedded in the picture. Inspect the current-frame proposal before applying; do not use removal to obscure attribution or bypass originality rules. Check mask outline, nearby face/background detail, manual Apply/Cancel, exact seek, original audio and duration, and final exported frame. Record device, Android version, decode wall time, thermal status, memory, crashes, and signed APK build. Use only footage you have permission to edit and distribute. Do not put the raw source into a public GitHub repository or release APK.

## v0.9.8 / 134
Re-run `replay.sh` for baseline and new Java scene and geometry policies. The optional motion veto remains research-only; the 85053 replay preserved the same 18 candidates, but no scene labels prove improved detection. `model_benchmark_v134.json` is a new FFmpeg-decoded artificial-occlusion test; no clean subtitle-free target or Android export was available. Keep the reference outside training and the APK. No uploaded video is embedded in this source package.

## v0.9.9 / 135
Fresh full decode of SHA-pinned reference. 18 unchanged candidates; 275/275 synthetic anchor coverage and unchanged extra-area ratio. New stale-neighbor guard tested separately. Residual network and held-out-context motion matching remain research-only after reference MAE regressed. No actual subtitle-free ground truth or Android export.

## v1.0.0 RC / 136
Fresh full decode and geometry replay. 18 unchanged candidates. Anchor coverage 275/275 and extra area 5.4562%. Candidate residual model remains research-only; see ultimate130_metrics.json. Device checklist in qa/device136.

## v1.0.1 RC
`replay.sh` also runs Supreme131ReferenceReplay; 85053.mp4 is excluded from training, and repeatedly used as a regression fixture (not a fresh independent test). 275 synthetic perturbations on 11 manual anchors retain coverage; mean extra area unchanged at 5.4562%. The candidate residual model underperformed the active blend on artificial occlusions in this video, so production remains unchanged.

## v1.0.2 RC
Full replay: 3980 frames, 3979 adjacent pairs, 18 retained scene candidates; 275/275 anchor geometry coverage and mean extra area 5.4562% -> 5.1362%. Synthetic perturbations of 11 manual anchors, not OCR. 7632 artificial occlusion rows on the same repeated regression video; 865-parameter research candidate regressed versus the active model and stays disabled.

## v1.0.3 RC
Full replay: 3980 frames, 3979 pairs, 18 candidate scene markers; 275/275 synthetic anchor coverage, 5.1362% mean extra area unchanged. Residual model selected epoch 0 (baseline parity); no new weights activated. Separate research-only half-pixel alignment experiment: 120 synthetic pairs and 159 reference pairs, using disjoint visible-context fit/check; hidden-region MAE fell from 0.0418201 to 0.0413384 on reference. See subpixel_metrics_v139.json; executable script is in the training delta. Not Android or actual subtitle-free ground truth.

## v140
Re-run `replay.sh` for full decoded frame/caption geometry checks. Quarter-pixel and residual research scripts are in the separately distributed Training Delta. Reference clip stays excluded from training; repeated regression clip, not independent test footage.

## v1.0.5 RC
Replayed the full 85053.mp4 decode, 3980 frames / 3979 pairs, 18 candidates; previous caption geometry unchanged. Adaptive fractional alignment did not beat quarter-pixel alone; research only. See cognitive135_metrics.json and adaptive_motion_v141.json.

## v142
Replayed original reference; 3980 frames, 3979 pairs, 18 candidate cuts; current mask geometry unchanged. Local two-block fractional alignment on 159 held-out pairs is research only; no independent video or Android export validation. Metrics: local_motion_v142.json, deep136_metrics.json.
