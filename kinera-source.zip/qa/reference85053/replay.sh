#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
video="${1:?Usage: bash qa/reference85053/replay.sh /absolute/path/to/85053.mp4}"
expected=63103f26e13e765b431c7abc0c4e03b0394243795201e8a6746ed33899ca42b3
actual=$(sha256sum "$video" | cut -d' ' -f1)
[[ "$actual" == "$expected" ]] || { echo 'Reference file mismatch; use the unchanged original 85053.mp4.' >&2; exit 1; }
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
javac --release 17 -d "$tmp" @tests/host_sources.txt
ffmpeg -v error -threads 2 -i "$video" -map 0:v:0 -vf 'scale=48:48:flags=neighbor,format=gray' -f rawvideo "$tmp/luma48.bin"
java -cp "$tmp" az.kinera.edit.Adaptive122VideoReplay "$tmp/luma48.bin" 40000
java -cp "$tmp" az.kinera.edit.Adaptive122CaptionReplay qa/reference85053/caption_anchors.csv

java -cp "$tmp" az.kinera.edit.Reconstruction123VideoReplay "$tmp/luma48.bin" 40000
java -cp "$tmp" az.kinera.edit.Reconstruction123CaptionReplay qa/reference85053/caption_anchors.csv

java -cp "$tmp" az.kinera.edit.Director124ReferenceReplay qa/reference85053/caption_anchors.csv

java -cp "$tmp" az.kinera.edit.Ultimate130ReferenceReplay qa/reference85053/caption_anchors.csv

java -cp "$tmp" az.kinera.edit.Supreme131ReferenceReplay qa/reference85053/caption_anchors.csv

java -cp "$tmp" az.kinera.edit.Advanced132ReferenceReplay qa/reference85053/caption_anchors.csv

java -cp "$tmp" az.kinera.edit.Precision133ReferenceReplay qa/reference85053/caption_anchors.csv
