#!/usr/bin/env python3
"""Run reproducible full-frame luma replay on the four private, unchanged reference clips.
Requires FFmpeg, FFprobe, Java 17 and Python 3. No video is downloaded or copied into source.
"""
import argparse, hashlib, json, subprocess, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def run(args):return subprocess.check_output(args,text=True,cwd=ROOT)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('video_dir',type=Path);ap.add_argument('--decoded-dir',type=Path,help='Optional already decoded raw luma files; use only when generated from verified originals');ap.add_argument('--output',type=Path);a=ap.parse_args()
 manifest=json.loads((ROOT/'qa/reference_suite/REFERENCES.json').read_text());results=[]
 with tempfile.TemporaryDirectory() as d:
  subprocess.run(['javac','--release','17','-d',d,'@tests/host_sources.txt'],cwd=ROOT,check=True)
  for item in manifest['clips']:
   p=a.video_dir/item['file'];assert sha(p)==item['sha256'],f'File hash mismatch: {p}'
   raw=a.decoded_dir/(p.stem+'.luma') if a.decoded_dir else Path(d)/(p.stem+'.luma')
   if not a.decoded_dir:subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(p),'-map','0:v:0','-vf','scale=48:48:flags=neighbor,format=gray','-f','rawvideo',str(raw)],check=True)
   assert raw.stat().st_size==item['frames']*2304,f'Incomplete decode: {p}'
   r=json.loads(run(['java','-cp',d,'az.kinera.edit.Fusion138VideoReplay',str(raw),str(item['fps_num']),str(item['fps_den'])]));results.append({'file':item['file'],**r})
 result={'scope':'Full decoded CFR luma replay; no Android decoder, semantic ground truth or export quality claim.','clips':results}
 out=json.dumps(result,indent=2);print(out)
 if a.output:a.output.write_text(out+'\n')
if __name__=='__main__':main()
