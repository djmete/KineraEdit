# v6.7 device checklist — pending
Verify short/long video import, black-screen recovery, orientation, Crop and Blur alignment, Flip, reset and undo, OtoBlurPro coverage on fast movement, export visual/audio parity, all supported locales, gallery and exit dialog on phone.
