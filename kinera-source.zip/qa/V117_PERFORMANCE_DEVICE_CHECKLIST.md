# V117 device acceptance — Kinera v0.8.1

- Install the signed universal APK over V116; verify certificate, saved projects, and model assets.
- Open 159-second source; press OtoBlur while thumbnails are generating, select mode. Verify bounded wait, visible progress, cancellation, old masks retained on failure, player returns. Repeat with Pro.
- Test two-line subtitles with a short centered line and unrelated nearby text. Record recall/precision against manually annotated frames.
- On small and large screens and 1.3x font, check full-width slider, action row, player, timing, Undo/Redo, masks outside touch and accessibility navigation.
- Test live slider at 0, 50, 100%, playing and paused.
- Export 720p and 1080p; verify exact dimensions, audio 5–20% when automatic, time, peak RAM, temperature, and no app freeze. Test 2K/4K if codec supports them.
- Verify bundled segmentation on airplane mode. No new active CNN is enabled.
- Compare real owned clean footage with synthetic subtitles and masked ground truth; measure MAE, temporal flicker, OCR recall and runtime.
- Capture logcat and CI diagnostics for failures. All device checks pending.
