# V125 device acceptance — Kinera v0.8.9
- CI compile and install the signed universal APK over v0.8.8; confirm versionCode 125 and permanent signing certificate.
- Test native seek slider one finger, two fingers, interruption/cancel, normal release, accessibility/keyboard, page/focus switches; verify restored timestamp on cancel and no unwanted seek afterward.
- Open Crop/Blur while filmstrip loads; check late thumbnail results are discarded and resources released. Check return to normal editor, RAM/temperature and exact HD/FHD/2K/4K dimensions.
- Compare identical owned clips for OtoBlurPro quality, ordinary Blur live strength and 9:16 Crop; compare old/new export duration, memory and thermal state. Active reconstruction model unchanged.
- No actual Android device test or APK build completed in this environment.
