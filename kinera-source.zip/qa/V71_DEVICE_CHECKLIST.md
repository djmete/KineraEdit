# v7.1 device release gate (not run locally)
Build with original signer; install over v4.7 after backing up drafts; verify all four tools, OCR three-frame consensus, partial motion tracking, 0.5s caution scheduling, stereo PCM, player effect preview vs export, GPU performance, languages and exit dialog.
