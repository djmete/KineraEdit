# v0.6.1 device acceptance (not yet executed)

1. Compare same source video, same resolution/FPS and template on 0.6.0 and 0.6.1. Record import, analysis, export, actual render time and total time; phone temperature, memory, dropped frames and responsiveness. Repeat efficient and full quality profiles separately (same FPS when measuring engine alone).
2. Test 9:16, 16:9, 1:1, short and long clips, 30/60 FPS, HDR and SDR, H264 and HEVC, audio/no audio. Check output duration, aspect, audio sync and codec.
3. Check narrow/large font editor; Undo/Redo after crop, blur strength/timing, masks, volume/mute, template, color, scene markers; branch after undo and verify redo clears. Confirm save/reopen.
4. OtoBlurPro one choice; compare subtitle masks and restoration against clean ground truth, especially moving subtitles and text over faces. Verify no destructive source changes. Exact hidden pixel recovery is not guaranteed.
5. Validate all template previews and actual GPU pixel output, cancel export, retry, background and foreground return.
6. CI APK report: confirm all intended ABIs, signing certificate, assets, app version and APK byte size; compare old APK using tests/compare_apk.py.
