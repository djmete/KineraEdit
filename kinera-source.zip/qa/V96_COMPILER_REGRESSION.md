# v0.6.0 build and device acceptance
1. Run `bash tests/run.sh`. The targeted compiler check must pass both positive checks and negative controls. Android stubs exist only in a temporary host test directory.
2. GitHub must pass real `:app:compileReleaseJavaWithJavac` with Android SDK 35 and then `:app:assembleRelease`. Do not interpret host stubs or syntax audits as a successful Android build.
3. Verify signed artifact certificate, version code 96, package meteapps.kineraedit, universal APK and lint.
4. On a physical Android device: install over existing signed release; verify import, portrait/landscape, seeking, 4 tool buttons, 320/360/400 dp widths, enlarged fonts, persistent Blur drag and cancellation, OtoBlurPro restoration, save/reopen, audio, export and back navigation.
