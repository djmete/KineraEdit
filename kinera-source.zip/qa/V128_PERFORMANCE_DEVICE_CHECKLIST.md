# V128 device acceptance — pending

- Install signed version 128 over 127; verify project retention and certificate.
- Exercise 1.8, 12, 30 and >30 second clips, 720p/30 and higher resolution/FPS. Record sequential EOS, pair count, scan wall time and CPU time, fallback on cancellation and pressure. No partial plan should commit.
- On small screens and 1.3x font, verify video fit, filmstrip/seek availability, accessible Blur value, options sheet, touch cancellation and playback.
- Record export dimensions, audio sync, dropped frames, peak RAM, GPU frame time and thermal status for 720p and 1080p. Compare against version 127 on same device and clip.
- Use independently recorded, owned footage with ground truth and manually annotated captions; measure reconstruction MAE/PSNR, flicker, caption precision/recall and editorial quality. No candidate activation without device/export parity.
- Capture logcat and CI diagnostics. These tests have not been run on physical devices.
