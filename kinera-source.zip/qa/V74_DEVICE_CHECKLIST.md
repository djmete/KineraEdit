# v7.4 device acceptance (not executed)
- Build signed APK versionCode 65; check upgrade without uninstall.
- Test 3GP H.263/AMR and MPEG-4 Part 2, H.264/HEVC MP4, WebM, MKV, MOV, variable FPS, rotated sources. Unsupported device codecs must show recovery/error; no format guarantee.
- Test normal OtoBlur and separate OtoBlurPro on user-authorized video: narrow selected region, movement, crop/flip, raw fallback, undo/redo, reopen draft, export retries. Reconstruction is spatial, not temporal, complex backgrounds can smear.
- Check GPU shader on actual GLES devices, audio sync, old projects, same signer.
- Measure export times and actual output FPS for 15/30/60fps.
- Test editor at 320dp width, large font, landscape, back navigation, all four tools.
