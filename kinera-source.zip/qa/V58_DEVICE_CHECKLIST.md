# v5.8 device verification

1. Install signed upgrade over v5.7 without clearing app data.
2. Import an asymmetric clip with text: live composition and exported video must mirror source horizontally; template text must remain readable.
3. Change Automatic mirror in Settings; new clips follow choice. Reopen a saved draft and confirm its stored orientation.
4. Apply an off-center blur; check both edges correspond to same source pixels after flipping. Seek ±5 seconds, scrub, enter/exit crop and blur, then export.
5. Reset crop and confirm immediate preview refresh and persistence. Test stable source mode and GPU failure recovery; raw source intentionally has no effects.
6. Check back navigation, gallery, channel settings; no template library, batch or last-project card.
7. Compare preview/export on 176×144 and 1080×1440 source videos. Report Android model, codec, and last player error on failures.
