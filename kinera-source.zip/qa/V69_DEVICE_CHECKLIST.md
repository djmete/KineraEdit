# v6.9 device release gate (not executed in the authoring environment)

1. Run GitHub workflow with the existing KINERA_SIGNING_BUNDLE. Check assembleRelease, lintRelease, signed APK, exact certificate, versionCode 60 and package meteapps.kineraedit.
2. Back up old projects; install over an actual v4.7 APK signed by the same key, without uninstalling. Verify old channel settings, language, crop, blur, audio, mirror settings, draft restoration and permissions. One-time v5.8 mirror default migration remains intentional; per-draft mirror should remain as stored.
3. Test offline cold start and first import of a portrait, landscape and text video; face detector should only bias new unknown-label imports; saved drafts must not change their template. Confirm timeout fallback and repeated imports, memory, rotation and cancellation.
4. Test OtoBlurPro with stable motion, brightness changes, occlusion, scene cuts, wrong-object drift, and end-of-video; check all masks before exporting, especially untracked intervals. Not a privacy guarantee.
5. Verify player surface dimensions, play/pause, seek, stall recovery, Android back, four tools, narrow screens, Turkish/Azerbaijani/English/Russian, Blur strength persistence, audio, and 1080p export. Record logs and frame screenshots if failures occur.
6. Verify the signed release on Poco F5 Pro and other Android 12+ devices. No host tests can substitute for actual Android build/device coverage.
