# Kinera Edit v5.7.0 — Real-device acceptance checklist

**Build/test status:** Host-only Java tests and Java syntax parsing pass. Android SDK/Gradle compiler, signed APK and Poco F5 Pro tests were not available in the authoring environment. Do not claim the player is bug-free until this checklist passes on devices.

## Playback and editor
1. Install over existing v5.6 with same signing certificate; check draft, channel and saved edit data remain.
2. Open 1080×1920 MP4 with embedded text; default mirror must be OFF; labels/subtitles must be readable and remain readable in export.
3. On Android 12, Android 13, Android 14, Android 15: Play, pause, seek using both the timeline and +/-5s controls; playback time must not remain at 00:00 during continuous playing.
4. Test from portrait and landscape videos, Android hardware and software decoders if available; keep audio/video synchronized. If effects stall, the raw SurfaceView fallback must show the source video with a clear label.
5. Settings → Player quality → Stable player: confirm direct source video playback while effect settings stay in the edit draft and apply on export. Switch back to Automatic and verify effects return.
6. Enter Blur, drag the four corner and edge handles, resize/move the mask; unrelated taps must not move/reset it. Timeline must remain draggable in blur editing mode.
7. Use full-screen mode, then Android gesture and button Back; full-screen must close first, then active region mode, then editor → home. Export → editor must return without losing draft.
8. Verify unsaved draft, undo/redo, crop, blur ranges, export, and gallery both before and after repeated back navigation and app background/resume.

## AutoBlur
9. The AutoBlur menu must offer exactly three modes in one dialog: 3-frame, 1-frame, and Pro tracking. Verify default 3-frame and persistent selected mode. Pro must require selecting a blur region first.
10. For 3-frame auto suggestions, verify regions on more than one scene; no privacy guarantee. Confirm/cancel suggestions; ensure cancel leaves original masks intact. Test source video captions in lower frame region.
11. Add multiple timed blur regions and export; check no unwanted blur outside time intervals.

## Build and signing
12. Upload .github/workflows/kinera-build.yml from the standalone text workflow. Run GitHub Actions on main. Confirm tests, :app:assembleRelease, :app:lintRelease, apksigner certificate pin and the release download assets.
13. Verify package `meteapps.kineraedit`, Android 12+, `versionCode 48`, version `5.7.0`, signing cert continuity.

## Training archive
14. Keep prior research/training ZIP unchanged and separate from APK. Its bytes are not a packaged on-device neural network. Don't remove earlier datasets or promise new training results without a verifiable training run.
