# Precision116 research provenance

13 bundled scikit-image still-image groups, synthetic affine camera motion/exposure and controlled mask regions. Separate groups per train/validation/test in this dataset; photos overlap prior experiments. Not independently recorded video. Warm-start and cold-start models reuse the exact same rows; counts are not doubled. Test results exploratory because the first experiment used the same test split. Neither model is active in Android or GPU export. Production Multimodal113 model and shader unchanged. No rights to third-party video asserted.
