# v6.5 device checks (not executed here)
- Open portrait, landscape, rotated and legacy clips; seek, pause, resume, enter Blur and exit.
- Export stereo and mono PCM-backed videos. Compare channel balance, A/V sync and peak levels.
- OtoBlurPro: track moving target, occlusion, scene cut, and verify only accepted intervals are blurred. Manually inspect uncovered intervals.
- Check four tools, gallery, channel, settings, language changes, exit confirmation, and compact screen layout.
- Build with permanent signer; verify upgrade version 56 / 6.5.0.
