# 5.4 device acceptance
1. Existing signed APK update: old channel profiles, per-video draft and template retained.
2. Open portrait, square, landscape, rotated source. Compare FIT preview/export and crop overlay geometry.
3. Resize blur; seek ±5s; pause, play, scrub, rotate/reopen, background/resume. Verify masks and template persist.
4. Switch template page and channel; select old/new styles; export every new motion family on GLES device.
5. Long press OtoBlur > Motion Track. Select textured region, confirm four intervals or reject; verify no change if rejected and review frames. Do not rely on this for guaranteed privacy.
6. Export HD, FHD, 2K, 4K supported; compare audio gain/metadata/duration. Record dropped frames, temperature, elapsed time, battery and memory.
7. Test gallery permissions and provider failures, short clips, low-memory recovery, offline operation.
