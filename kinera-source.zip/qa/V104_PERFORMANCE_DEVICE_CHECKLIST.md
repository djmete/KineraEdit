# V104 device checklist — pending physical verification
- Install as upgrade from v0.6.7 using same signing key: Home should show release highlight once after setup. Reopen manually from Yeniliklər. On a fresh install auto highlight is intentionally suppressed; manual access remains.
- Settings → Bildirişi yoxla: test granted, denied, and disabled channel states. Check export progress/result and reminder channels.
- Test 320/360/393/411 dp widths, 1.0/1.3/1.5 font scale, Android gesture and three-button navigation. Top history actions, player and export must not overlap; test portrait and landscape. Check full-screen, no duplicated timeline scrubber on larger screens, and narrow screen fallback.
- Blur: drag slider, change parameter via menu, choose timing, strength and masks; apply/undo/redo; reopen same video as fresh vs Saved Projects. Verify OtoBlurPro preview and export match and no stale texture.
- Repeat the same 60s 1080p clip, with and without masks, in efficient and full quality modes; record preparation/render time, FPS, Java heap, PSS, maximum thermal status, responsiveness. Repeat long clip with heat pressure and cancellation. Compare v0.6.7 and v0.6.8 on the same phone. No actual device timing claimed.
- Verify universal APK certificate and size report, Android compile and lint, GPU pixel render. Host tests are not a substitute.
