# V129 device acceptance (not run)
- On POCO F5 Pro, test import portrait/landscape 720p/1080p/4K, seek while playing, rotate, background/resume, tap and drag Blur, undo/redo, OtoBlur selection, export audio/video sync.
- Record `adb shell dumpsys thermalservice`, `adb shell dumpsys meminfo meteapps.kineraedit`, `adb logcat -s KineraMetrics` before/after 60-second clips.
- Compare first/last frames, masks, duration, dropped frames and actual playback. New model remains research-only until held-out recorded-video and device parity tests pass.
