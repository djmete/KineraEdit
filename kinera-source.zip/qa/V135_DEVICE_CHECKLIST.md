# v135 / 1.0 release gate
- Install signed APK over v134; verify project and template IDs unchanged. Do not change signing identity.
- On 85053.mp4 run OtoEdit with the same settings as v134. Compare actual duration, frame drops, A/V sync, 18 candidate markers, export file, visual quality and artifact logs. Candidates are not ground truth.
- Apply, cancel, Back, tool switching, background, focus mode, multitouch cancel and export while a Blur or Crop draft is open; only explicit Apply may save a change.
- Test 240/320/360/411 dp widths, 1.0/1.3/2.0 font scales, portrait/landscape, gesture navigation, TalkBack, keyboard sliders; confirm nonoverlap and minimum 48 dp target.
- Record Android version, device, RAM, thermal status, elapsed export time, average and worst frame time, and failures. Compare identical clips/settings and power state.
- Do not activate research reconstruction until independent clean footage, held-out quality and Android GPU/export parity pass. No originality detector claim.
