# Android acceptance — v1.1.2 RC
Compare v1.1.1 to v1.1.2 on the same physical device and quality settings.
- Reproduce 85217.jpg: choose a tall window template, crop a 1080×1400 video to a square. Apply. Verify the complete selected frame remains visible and the two unused areas contain template artwork, not the artificial black rectangle; repeat in actual export, not only preview. Existing black pixels encoded in source are intentionally untouched.
- Repeat for narrow and landscape crop, flip, all six locked ratios, custom crop; verify matching Blur viewport, manual region from 0 s, undo/redo, Cancel and Reset.
- Test corner and edge touch at 320/360/411dp, move, pinch, zoom slider from 0 to 1000, tap and reverse drag; verify no jump on no-op, no unintended crop on cancellation.
- Four private references: 85053/85196/85197/85198; record OtoEdit, OtoBlur, OtoBlurPro, export wall time, thermal status, RAM, dropped preview frames. Preserve output dimensions, automatic gain 5–20% (0 when no audio), cancellation safety. Use existing ADB diagnostics. No physical APK or speed claim until measured.
