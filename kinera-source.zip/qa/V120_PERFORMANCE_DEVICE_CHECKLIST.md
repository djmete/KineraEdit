# V120 device acceptance — Kinera v0.8.4
- Install CI universal signed APK over v0.8.3; verify versionCode 120, same certificate, projects and settings.
- Crop portrait, square, landscape and rotation-metadata 90° videos. Verify 9:16 solid frame and actual inner template guide. Move inside; resize each corner; pinch; zoom 1.0–5.0×; outside tap/drag and cancel; reset; undo/redo; save/reopen; rotate device; focus mode; larger font and 320dp width. Confirm exported framing, including existing template window, motion and mirroring. Custom crop should keep chosen template.
- Test OtoBlur/Pro with known scene boundaries, brief single OCR miss, two consecutive misses and no markers. No bridging across cuts. Measure missed text and false masks on owned footage.
- Exercise ordinary Blur live strength 0/50/100, mask outside touch, paused and playing; old AutoSəs 5–20%, HD–4K exact output dimensions, RAM, thermal and export wall time.
- Existing CNN diagnostic can run offline; Adaptive109 is research-only. No physical Android tests or APK build performed in host environment.
