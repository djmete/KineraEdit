# v6.0 physical device verification (not yet run)
- Install signed update over previous build; check project and channel retention.
- Import portrait, landscape, rotated, H.263, HEVC and HDR sources. Check preview geometry before/after blur and +/- 5 s.
- Verify preview markers and export transitions on actual cut points; check no zoom when masks exist.
- Compare manual volume and mute with exported audio, verify no added sound on muted/no-audio input and no clipping or A/V drift.
- Test OtoBlur single/three-frame automatic selection and tracking under scene cuts, occlusion, camera movement, and timeouts. Confirm results before export.
- Test gallery, settings, back navigation, permissions, full-screen and 4K export. Check for dropped frames and thermals on physical device.
