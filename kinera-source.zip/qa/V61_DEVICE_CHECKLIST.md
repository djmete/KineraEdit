# Device acceptance checklist (not executed)
- Install signed v6.1 over v6.0 without data loss; confirm selected language on all pages.
- On home and first setup, back prompts exit; cancel stays; confirm exits. In editor, back closes current tool first, then returns home.
- On 320/360/411dp and large font: four tools stay separated; Blur controls scroll and Apply remains reachable; seek, play, full-screen remain usable.
- Import 176×144, 1080×1440, 1080×1920 and landscape clips. Verify fitted preview, first frame, seeking ±5s, full-screen, no stale frame; compare preview to export.
- On new source confirm auto grade and auto volume; reopen two drafts and compare independently saved grade and masks. Verify manual audio remains unchanged.
- Check short/medium/long scene cuts and audio accents on exported MP4; audio peak must remain bounded, no accent in muted export. Verify source chronology and duration.
- OtoBlurPro: static textured object, translation, scene cut, occlusion and timeout. Ensure only proposed confident intervals are applied after confirmation; visually review all masks.
- Test Turkish, Azerbaijani, English and Russian, including errors and exit dialog; device diagnostics may contain system locale strings.
