# v6.8 physical Android acceptance (not executed here)
1. Build the signed APK via the self-contained workflow, inspect lint diagnostics and verify package/version/signature. Confirm Gradle resolves the bundled image-labeling library.
2. In airplane mode, import a portrait clip, a landscape clip and a text-rich clip; compare selected templates. Verify fallback with an unsupported format and that previous drafts retain template, grade and flip. Measure import latency.
3. In editor, check all four tools at 320/360/412dp, with large font scale, Turkish/Azerbaijani/English/Russian. Test crop/blur reset, back, exit dialog, timeline scrub, orientation, raw fallback and re-entry.
4. Export bright saturated footage and check for clipped colors; verify manually selected grades are unchanged. Compare preview vs output; check audio, stereo and transition timing.
5. Test OtoBlurPro with target crossing a boundary, a short final interval, motion, occlusion and scene cuts; review each mask before export. Tracking stops at low confidence/time budget/31 mask cap; no guarantee of masking entire target.
6. Test 4K/60 fps, very short and legacy clips, interrupted imports/exports, background/foreground and gallery share/delete. Device GPU results not available in host JVM tests.
