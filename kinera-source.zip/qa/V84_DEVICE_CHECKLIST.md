# Kinera 8.4 physical-device acceptance checklist (not executed in host environment)

A single assistant prepared this release; these are 50 manual acceptance cases, not 50 agents or 50 passed tests. Run on an upgraded install and a fresh install. Record device, OS, codecs, source URI, actual output, and logs. Verify owned/authorized footage only.

1. Upgrade from v8.3 using same signing key.
2. Preserve existing channel profile.
3. Preserve existing draft crop.
4. Preserve existing draft masks.
5. Preserve existing draft gain.
6. Preserve selected language.
7. Preserve theme selection.
8. First idle home on upgrade shows one feature card.
9. Dismiss card with Continue.
10. Reopen app: card does not repeat.
11. Rotate/recreate Activity: card does not repeat.
12. Fresh install does not show upgrade card.
13. Upgrade while export is attached: defer card until idle home.
14. Android back dismisses spotlight without repeat.
15. System animations disabled: card remains readable.
16. Azerbaijani spotlight labels and body.
17. Turkish spotlight labels and body.
18. English spotlight labels and body.
19. Russian spotlight labels and body.
20. Small screen and enlarged font: spotlight can scroll.
21. Studio theme editor contrast.
22. AMOLED theme editor contrast.
23. Device night theme selection remains settings-only.
24. Four equal editor tool widths at 320 dp.
25. Long localized toolbar labels at 360 dp.
26. Blur adjustment scrolling on short display.
27. Region overlay drag and resize.
28. Android back closes region before editor.
29. Raw surface single tap play/pause.
30. Raw surface double tap seek.
31. Composed surface single/double tap.
32. H.264 MP4 import/preview.
33. HEVC MP4 import/preview.
34. H.263/MPEG-4 Part 2 3GP fallback (device-dependent).
35. OCR cancel while playback controls disabled.
36. Resume preview after OCR completion.
37. Dense scan on a 5-second clip.
38. Dense scan on a 60-second clip.
39. Dense scan on a long clip; verify timeout/cancel.
40. Fixed subtitle band covers all timestamps.
41. Multiple masks with clean horizontal/vertical boundaries.
42. Multiple masks block both axes; verify clean-edge fallback.
43. No clean edge; verify limitations are visible in preview.
44. Moving scene and persistent text; compare flicker and texture.
45. All six Deep templates preview/export IDs retained.
46. New GPU animations remain outside video window.
47. Export result notifications on/off independently.
48. Reminder disabled/enabled; notification channel disabled.
49. Export 720p/1080p and assess elapsed time and output validity.
50. GitHub single APK, signer, version, direct release asset and no nested release ZIP.
