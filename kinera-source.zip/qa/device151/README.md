# v1.1.5 RC acceptance
- Upload the source ZIP first, then commit the matching workflow (or commit both atomically). After this workflow is installed, source-only pushes do not trigger CI. The old workflow may still trigger one final mismatch during the migration. Manual dispatch remains available.
- Archive integrity is checked before SDK/Gradle setup; mismatches are rejected, not ignored.
- Compare v1.1.4 and v1.1.5 on the same physical device and four private references. Record OtoEdit, OtoBlur, OtoBlurPro and export wall times, RAM, thermal conditions, and output correctness.
- Inspect clustered scene accents and live Blur while paused/playing, scrubbing backwards, changing mask, cancel/apply, and export. OtoSes 5–20% policy retained. No actual Android timings claimed.
