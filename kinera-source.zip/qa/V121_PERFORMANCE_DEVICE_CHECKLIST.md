# V121 device acceptance — Kinera v0.8.5
- Install universal signed CI APK over 0.8.4; confirm versionCode 121 and previous signing certificate.
- Crop 9:16 in 470–559dp portrait editor; check time slider, corner/pinch, cancel, undo/redo and exact export framing. Test large fonts and landscape.
- Blur manual region plus OtoBlurPro mask overlapping it. Check manual strength 0/50/100, paused and playing; positive manual blur takes priority. Test non-overlap and old masks.
- OCR compatible adjacent observations in same shot, across shot boundary and missing sample. Measure missed text and false masks on owned footage.
- Test player recovery, HD–4K exact output dimensions, AutoSəs 5–20%, temperature, RAM and wall time. New model research-only; no physical device tested.
