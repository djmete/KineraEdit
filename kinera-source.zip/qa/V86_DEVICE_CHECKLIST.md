# v8.6 device cases (not run on host)
- Verify upgrade from v7/v8.5 shows no old highlight; language and theme survive.
- Test partially blocked mask corners, outer rings, moving captions, full-video and fixed-area modes. Compare preview and exported pixels.
- Verify all 222 templates, new animations and retained old motion IDs in preview/export.
- Test corrupted mask timestamp followed by valid entry, pause/seek/resume, legacy 3GP, background/foreground and output notifications.
- Check signed single universal release APK on GitHub.
