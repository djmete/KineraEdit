# Kinera Edit v0.5.5 Stable — Neural Vision Intelligence

- Android 12+, versionCode 91, kAI 8.0 / OtoBlurPro 8.0; same package and signing key, single universal APK.
- 50 appended template IDs (784–833), five composition families, 6 added decorative GPU motion patterns (96 total). Earlier names, palettes and IDs preserved; shared player/layout changes apply to all templates, not an individual redesign.
- 32 candidate refinement windows, 90-second total analysis budget. 8/16/1 MLP trained on 12,000 photo-derived simulated frame pairs, validated/tested on disjoint image sources (2,000 each). Guard requires strong measured alignment and low cut probability; veto only, never creates a cut. Synthetic validation is not general video understanding. Existing 12 encoded procedural clips decoded for regression (852 pairs, zero known-cut vetoes; also zero triggered guards). Prior AV MLP remains disabled. Existing local ML Kit object/face labeling retained, not newly trained.
- FIT playback, compact toolbar, increased filmstrip and metadata collapse thresholds, persistent wider Blur selector; 4 main tools retained. Temporal second-history reuse requires both adjacent time gaps and the full time span to be valid. No new generative inpainting model or new export backend.
- Host Java/static suite passed (consolidated compile). Host EGL compiled/linked shaders, pixel render segfaulted. No Android SDK/physical device validation or APK build performed. No claim of platform originality eligibility or detector bypass.
- Next: v0.5.6 Stable — Neural Scene Intelligence. Annotated real-world videos, semantic and audio evaluation, physical Android layout/preview/export measurements.

# Kinera Edit v0.5.4 Stable — Neural Expert Precision

- Android 12+, versionCode 90, kAI 7.9 and OtoBlurPro 7.9. Same app ID and permanent signing contract.
- 50 appended templates (734–783), five layout families, six new decorative GPU animation families (90 total). All earlier template names, palettes and IDs retained. The shared editing engine serves every template; no individual redesign of the 734 old templates.
- Local PCM envelope reads at most the first 30 seconds within a 5-second wall-clock budget. Corroborates strong visual candidates only; no new shot from audio alone. Missing audio is unknown. 28 distributed probe windows, still budget-limited, not every frame. Existing chronology and duration preserved.
- Experimental 4/12/1 audiovisual MLP trained on 24,000 augmented feature rows from 8 procedural encoded clips, validated/tested on distinct clips (2 each). Raw held-out precision 25%; disabled. Existing neural files retained; deterministic conservative audio rule used instead. No general real-world semantic model.
- Compact height toolbar, optional filmstrip and info collapse, wider fixed Blur slider, source player fit mode; prior 4 tools and navigation preserved. Not a complete visual redesign, no physical layout/device test.
- 150 ms nominal OCR interval for short clips; 192-window cap retained. FPS-aware conservative temporal history reuse, not a new generative inpainting model. Same Media3 export and signing pipeline; no guarantee of device or platform eligibility.
- Single universal APK CI. Host Java and static source suites passed in consolidated compilation; full Gradle build, physical device and shader execution not verified. See QA checklist.

## Next: v0.5.5 Stable
Real annotated speech/music/cut benchmarks, device layout and preview fixes based on screenshots/logs, temporal restoration comparisons, hardware export measurements. No detector evasion or originality guarantee.

# Kinera Edit v0.5.3 Stable — Neural Precision Director

- Android 12+, versionCode 89; kAI 7.8 / OtoBlurPro 7.8; same package and signing requirements.
- 50 additional template IDs (684–733; 734 total), five composition families and six new GPU decorative motion families. Existing IDs and arrays are preserved.
- Triple-frame neural flash false-cut guard integrated into the bounded consecutive-frame refinement. 24 candidate probes rather than 20; prior model files retained. The new 6/16/1 INT16 MLP was trained on 36,000 synthetic-labeled feature rows with 6,000 validation and 6,000 test rows, using disjoint previously available video clips. It is not a general video semantic model. No claim that every frame is decoded.
- Larger preview allocation on compact heights, widened Blur adjustment value and control, slightly tighter control padding, safe focus placement, preserved four primary tools. Existing Player/Media3 and export paths retained; analysis timeout budgets aligned.
- Denser short-clip OCR sampling (160 ms vs 180 ms); previous approximate spatial/temporal reconstruction retained. No new generative inpainting model.
- Single universal APK workflow. Source and model archive audit plus host tests included separately; Android build, physical device and GPU validation pending. See qa/V89_PRECISION_DEVICE_CHECKLIST.md.

## Next: v0.5.4 Stable

Device-verified responsive editor and export; real annotated shot, speech/music and inpainting evaluation; improve temporal reconstruction only after controlled quality benchmarks. No originality detector bypass or platform eligibility guarantee.

# Kinera Edit v0.5.2 Stable — Neural Semantic Director

- versionCode 88; kAI 7.7 / OtoBlurPro 7.7.
- 50 appended templates (634–683), 684 total; 78 existing motion families retained.
- Three-frame semantic voting at import; 20 distributed cut probes; conservative low-resolution motion alignment veto, never deletes a coarse marker. Proxy training labels, no superiority over rule-only test demonstrated.
- Fixed Blur slider and narrow action row autosizing, bounded preview notice, source preview double tap geometry, adaptive OCR rectangle padding, notification failure guards. Common decorative accent intensity reduced.
- No new shader, generative inpainting, or all-frame semantic analysis. Android build/device testing remains required.

# Kinera Edit v0.5.1 Stable — Neural Adaptive Director

- versionCode 87; kAI 7.6 / OtoBlurPro 7.6.
- 50 appended templates (584–633); 634 total, prior template identities and 78 GPU motion families retained.
- AdaptivePulseConfidence conservative three-frame refinement veto, up to 16 distributed probes; existing coarse cut never deleted by new model. Synthetic test, no superiority over rules demonstrated.
- Blur gesture viewport snapshot and lifecycle reset, wider fixed slider on narrow screens, watchdog suppression while dragging, source audio accent ducking, overlapping caption interval union.
- No new shader, generative inpainting, or full-frame semantic analysis. Android build/device testing remains required.

# Kinera Edit v0.5 Stable — Neural Vision Director

- versionCode 86; kAI 7.5 / OtoBlurPro 7.5; next public patch versions 0.5.1, 0.5.2.
- 50 appended templates (534–583), existing motion families and all prior models retained.
- VisionLightConfidence active only as a conservative veto on an existing cut refinement; up to 12 distributed probes, 14-second budget. No source chronology changes.
- Fixed non-scrolling blur slider strip, compact width/height/font-scale layout, stable resize origin; smooth scene accent envelope, short two-letter caption recognition, notification-manager guard.
- No new shader, generative inpainting, or full-frame semantic analysis. Android device and APK build testing remain required.

# Kinera Edit v0.4 Stable — Neural Autonomous Director

- versionCode 85; kAI 7.4 / OtoBlurPro 7.4; same package and signer, one universal APK.
- 50 appended templates, IDs 484–533; existing template entries and motion families retained.
- Distributed sequential cut refinement, up to eight candidates; lighting pulse confidence gate if benchmark passes. Original coarse marker fallback.
- Narrow caption padding, stable blur slider, theme-coherent region handles, zero-size player canvas guard, aligned time budgets.
- No full-video semantic analysis, new shader, or generative inpainting; Android device testing required.

# Kinera Edit v0.3 Stable — Neural Cinematic Director

- versionCode 84; kAI 7.3 / OtoBlurPro 7.3. Same package/signature, universal APK.
- 50 appended templates (IDs 434–483), prior 434 entries and 78 motion families preserved.
- Bounded sequential MediaCodec refinement of detected cut candidates, with coarse fallback and preserved duration; no full-video semantic analysis.
- Fixture-derived residual luma model trained and retained but disabled after validation/test regression.
- Blur gesture hit selection, touch-state safety, player row sizing, draft persistence. No new shader or generative inpainting. Physical Android verification required.

# Kinera Edit v0.2 Stable — Neural Professional Director

- versionCode 83, kAI 7.2, OtoBlurPro 7.2. Same package and signature. One universal APK.
- 50 new templates (IDs 384–433); previous 384 entries and 78 animation families preserved.
- Blur region drag, pinch, relative edge resize and compact two-row fixed slider, with five adjustment choices. Preview invalidation deferred until slider release. More room by hiding header in region mode; four main editor tools retained.
- 320 sampled editorial frames, 24 refined markers, 54 s budget; existing 384 OCR/mask capacity retained. 57,000 new train rows, 7,000 validation and 7,000 test, from six fixture MP4s (216 decoded frames). New experimental model trained on fixture-derived synthetic triplets, not activated after poor held-out test. No generative inpainting or all-frame semantics. Short centered lower-caption OCR fallback, aligned analysis/export time budgets, duplicate scene scoring eliminated.
- Physical Android verification required.

# Kinera Edit v0.1 Stable — Neural Master Intelligence (development line v9.1)

- Public version restarts at 0.1 Stable; versionCode 82 remains monotonic, same application ID/signing certificate. kAI 7.1 and OtoBlurPro 7.1 retain earlier models and features.
- 64,000 synthetic image-pair rows, 8,000 validation and 8,000 test; new motion confidence model remains experimental if quality gate fails. No external video dataset.
- 50 appended templates, IDs 334–383; 78 GPU animation families and 12 shader variants retained. 288 sampled editorial frames and 20 refined markers, up to 384 OCR samples/timed masks. No full per-frame semantic inference or generative inpainting.
- Compact viewport-aware editor controls, revised studio palette, short-clip player recovery. Latest-only full-screen highlight. Existing notification settings retained.
- One universal APK; no nested APK archive. Physical Android verification required.

# Kinera Edit v9.0 — Neural Master Studio

- kAI 7.0: 48,000 synthetic translated/shot-change photo-crop rows, 6,000 validation and 6,000 test. Experimental motion model retained but disabled after missing predeclared quality gate.
- OtoEdit: 216 sampled analysis frames, 280 ms target interval, coverage check, up to 16 refined scene markers. Conservative visual accent adjustment, not a full per-frame semantic model or crossfade.
- 50 new templates (five layouts × ten palettes), stable IDs 284–333. Existing 78 GPU animation families and 12 shaders retained.
- OtoBlurPro: up to 320 OCR samples and timed masks, prior reconstruction shaders preserved. No generative inpainting.
- Editor: region adjustment hides main tool strip as well as thumbnails; apply/reset/history remain accessible. Updated studio palette. Latest-only announcement, four languages. Notifications avoid duplicate initial progress.
- One universal APK; previous signer, package and source workflow retained.

# Kinera Edit v8.9 — Neural Evolution Studio

- kAI 6.9: 48,000 simulated three-frame lighting/scene training rows, 6,000 validation and 6,000 test. New conservative lighting-pulse model integrated into bounded scene analysis, not an originality classifier.
- Up to 144 approximate analysis samples, 26-second budget; incomplete scan retains previous edit. Effects applied at render timestamps; not every frame analyzed semantically.
- 50 new templates (five layouts × ten palettes), IDs 234–283, 78 existing motion families retained.
- Editor workspace collapses thumbnail strip and metadata during region adjustment, separates apply/undo row from scroll; refreshed slate/ice-blue UI.
- Full-screen latest-only v8.9 announcement in four languages. Notifications retain existing channels; result category/timestamp and accent updated.
- OtoBlurPro retains prior 12 shader variants and models; no new generative inpainting in this release. One universal APK, prior signer/package preserved.

# Kinera Edit v8.8 — Neural Cognitive Studio

- kAI 6.8: 96,000 simulated clean side-pixel examples, 12,000 validation, 12,000 test; 17 parameter INT16 model, conservative half-strength weighting. Full model slightly regressed on stills; reused test after inspection.
- OtoBlurPro 6.8: texture-aware side ring, old shader fallback, no full generative inpainting.
- Player high-water watchdog, delayed trailing progress notification, strong PCM transient attenuation. Six additional templates, existing 78 GPU animation families.
- Single universal APK, unchanged signing pin and offline dependencies. Minor release: no full-screen highlight.

# Kinera Edit v8.7 — Neural Creative Intelligence

- OtoBlurPro 6.7: last-resort quarter-side and midpoint pixel sampling at three bounded distances; previous ten shader variants retained. Padded other-mask and source boundary guards. Not generative inpainting.
- kAI 6.7: 88,000 simulated spatial examples, 11,000 validation and 11,000 test from 16 stills and 504 decoded frames of three previously used sample clips. New 8→12→1 INT16 candidate retained inactive because validation and video subset regress. No nominal increment.
- Six templates using the existing 78 decorative GPU motion families; old IDs and colors preserved. New animation branches reverted after host driver crashes. Shot-marker-driven decorative animation, not direct audio motion.
- Gap-aware scene-neighborhood analysis, skip optional rhythm work when there are no shot markers, invalid player positions clear stability.
- Single universal APK and full-screen release highlight policy retained (no major highlight for this incremental release). Android compilation and device validation pending.

# Kinera Edit v8.6 — Neural Advanced Creator

- OtoBlurPro 6.6: three additional bounded perimeter rings (2, 4, 8 pixel-step offsets) when all nearer edge and corner samples are blocked. Existing nine shader variants remain fallback options. Not full generative inpainting or pixel-level glyph segmentation.
- kAI 6.6: 80,000 newly sampled synthetic outer-corner training examples from 16 stills and 420 decoded frames of three previously used clips; 10,000 validation and 10,000 test. No new nominal weight.
- Six new templates and six GPU decorative motion families, preserving old IDs. New styles react to shot timing, not live audio or dense optical flow.
- Sweep-line timed mask validation, isolated malformed mask timestamp recovery, playback watchdog monotonic check.
- Full-screen major-update highlight retained but disabled for this incremental release; no stale highlights.
- Single signed universal APK workflow, no nested artifact ZIP. Android compilation and device validation pending.

# Kinera Edit v8.5 — Neural Intelligent Creator

- Latest-release-only full-screen localized highlight, system bar/cutout insets, reduced-motion support; minor releases can disable the highlight. Fresh installs skip it.
- OtoBlurPro 6.5: up to 248 OCR samples and 248 timed regions; new corner-only fallback when all straight boundaries are unavailable. Prior eight shaders and their fallback chain preserved. The new INT16 corner network is conditional on clean edge candidates. It is not generative video inpainting or full per-frame OCR.
- kAI 6.5: 72,000 new simulated corner samples, 9,000 validation and 9,000 test samples, drawn from stills and previously used decoded video examples. No new nominal weight.
- One-pass mask/mode collection, linear draft serialization, reused local OCR session, coarse shot marker retained when refinement lacks frames.
- Same signed single universal APK workflow; no nested release ZIP. Physical device and Android compilation still need verification.

# Kinera Edit v8.4 — Neural Deep Inpainting

- kAI 6.4 / OtoBlurPro 6.4: up to 93 windows (186 sampled frames and timed masks). Sampling is not frame-by-frame OCR. Fixed-region full-duration and selected 48s tracking modes stay available.
- DeepEdgeConfidence (2→8→1, 33 parameters, INT16) trains on 64,000 simulated blocked-axis samples. Uses 16 still images and 252 decoded frames from three previously used sample clips, separated by source within this run. 8,000 validation and 8,000 test. Active only when both opposite edge pairs are unusable, clean one-sided edges exist and gradient observations are available. If gradient context is unavailable, inverse-distance weighting; if no clean boundary exists, preserve prior source fallback. This is not a generative video inpainting model or a glyph segmentation model.
- New eighth shader with seven existing fallback variants. Six new templates (216 total) and six GPU decoration families (72 total); old template IDs and render bounds retained.
- Upgrade-only localized major feature spotlight, persisted after dialog actually shows; skip fresh install and defer until home is idle. Fade/slide animation honors disabled system animations. One major feature only; subsequent major releases must increment ReleaseHighlightPolicy.ID intentionally.
- Notifications: export outcome switch separate from foreground progress and reminders, channel descriptions, disabled-channel checks, expanded reminder text. Appearance settings remain settings-only.
- Editor: four equal-width tools, responsive adjustment scroll height, theme-consistent surfaces, guard touch/play/retry/watchdog during OCR ownership; add double-tap seek to raw source surface. No new proxy or independent codec.
- One universal signed APK, no nested ZIP; previous signer and dependency set retained. Host logic/syntax/GLES tests only; physical Android, complete Gradle build and actual export speed/quality unverified.

# Kinera Edit v8.3 — Neural Professional Vision

- kAI 6.3 / OtoBlurPro 6.3: 124 sampled OCR frames, up to 124 timed masks, previous 48s track and fixed full-duration mode retained.
- Fix template clamp at 161 (all 210 IDs now renderable), six new template designs.
- New INT16 experimental spatial blend model trained on 64k samples from stills and 3 decoded sample videos; not enabled due to validation/video regression.
- New advanced shader blocks current-mask boundary sampling when another mask overlaps; old shaders are fallback.
- Disable seek/play/export during OCR ownership, restore UI state on completion.
- Single universal APK, same signer, no nested release ZIP.
- Host tests do not substitute for Android build or device testing. No full generative inpainting.

# v8.2 — Neural Precision Studio

- One universal signed APK, no manually nested release ZIP. Actions APK artifact contains only APK; direct release also provides size report and checksums separately.
- kAI 6.2: MaskPrecisionConfidence trained on 64,000 synthetic coordinate pairs; conservative merge veto with previous models preserved.
- OtoBlurPro 6.2: retain both half-windows for incompatible text observations; up to 62 stored intervals, 3 concurrent masks unchanged, 31-window tracker unchanged. Guard merge drift with anchor and latest observation.
- Six Precision templates (204 total), existing 66 GPU animation families retained.
- Reuse one OCR recognizer throughout a dense scan; defer bitmap/client cleanup while pending recognition reads it. Reject oversized fixed restoration regions. Prevent seek during OCR analysis; old player and export engine retained. Host tests only; Android and real video quality not yet verified.

# v8.1 — Neural Vision Pro

- GitHub workflow now reads a separate root `kinera-source.zip` (500 KB workflow limit); same signer and one universal APK.
- kAI 6.1, two OCR observations per window (up to 62); conservative half-window masks if observations disagree; fixed full-duration mode remains.
- New VisionLaneConfidence trained on 40,000 synthetic pairs; old model retained.
- Reuse metadata retriever for dense scan; conservative handling of incomplete loud audio; lifecycle guard for gallery player.
- Host checks only; Android compile, device UI, real video quality, full generative inpainting, proxy and new codecs not verified.

# Kinera Edit v8.0 — Neural Ultimate Studio

- kAI 6.0, OtoBlurPro 6.0: full-duration OCR proposal mode, at most 31 evenly spaced windows, 180 s UI timeout, cooperative cancellation; no partial plans applied automatically. A fixed-region reconstruction option covers all timestamps without claiming every subtitle is detected. Existing 48 s tracking stays available. All proposals require confirmation; prior masks replaced only on confirmation.
- CaptionLaneConfidence (6→16→8→1, 257 parameters) trained on 60,000 synthetic coordinate pairs, validation/test 6,000 each. Geometry and neural gates prevent risky adjacent mask unions. Model only vetoes merges, not restoration quality. No new nominal statistical budget; prior nominal accounting unchanged. No real-video training added.
- Six new automatic templates, 198 total; existing 66 motion families reused. Old IDs retained. Mint/charcoal studio palette and AMOLED accents, theme selection available only from Settings. No change to output palette of existing templates.
- Gallery video uses existing in-app Media3 player with external playback option on content URI error. Reminder switch in Settings, app-level Android channel settings, bounded progress, expanded result text. Audio rhythm state resets on sample-rate changes.
- Single universal signed APK, all prior dependencies, model files and ABI support kept. Host checks only; Android compile/device tests, proxy, new codecs, actual full generative video inpainting and GPU performance remain unverified.

# Kinera Edit v7.9 — Neural Advanced Reconstruction

- kAI 5.9 texture-aware INT16 older-frame reconstruction; new shader with old history shader fallback. Preserves two-frame memory bound and avoids duplicate timestamp eviction.
- 48,000 new synthetic training rows, 6,000 validation, 6,000 test; exact nominal budget 798,617,728 quadrillion recorded as decimal strings; relative difficulty weights actually used. No claim of that many distinct samples.
- 12 new automatic templates (192 total), 6 GPU decoration families (66 total), stable old IDs.
- Settings: Studio dark, AMOLED Black, follow device night mode (Studio when device not in night mode). Theme does not alter video rendering.
- Media3 result player with decoder fallback and lifecycle cleanup; header sizing, OCR grouping, audio null guards, scene refinement safeguards.
- One universal signed APK, all existing ABIs and offline models retained. No proxy, new independent codec, dense flow or external generative model. Host tests only; Android assembly/device UI/performance remain unverified.

# Kinera Edit v7.8 — Neural Ultra Compact Studio

- Single universal signed APK, all ABIs and dependencies retained; compressed native libraries; size and SHA-256 inventory generated in CI.
- kAI 5.8: second prior frame fallback for <=720p sources, strict scene/time/mask guards, quantized int16 gate; original weights retained in training archive.
- 48,000 new synthetic rows with nonuniform weights, nominal budget 719,517 quadrillion (Python exact integer sums).
- Watchdog, OCR seed filter, editor control spacing and time label improvements.
- Six new Ultra templates (180 total), reuse existing 60 motion families. No new dense flow, proxy, or external generative model. Android build/device validation outstanding.

# Kinera Edit v7.7 — Neural Dynamic Intelligence

- kAI 5.7: diagonal motion reconstruction model, conservative fallback after cardinal search fails; 48,000 new synthetic rows, 898 quadrillion nominal weights normalized in selected-diagonal loss.
- Compact ARM64 signed APK plus universal; bundled AI and all existing features retained. APK size audit checks asset and ARM64 library hashes and reports actual bytes in CI. No R8 or resource pruning.
- Duplicate OCR boxes no longer inflate cluster score; null scene list disables temporal reuse.
- Full multi-frame history, proxy, dense optical flow, audio-reactive templates and Android runtime benchmarks remain future work.

# Kinera Edit v7.6 — Neural Generative Vision

- kAI 5.6 / OtoBlurPro 5.6: optional local five-position translation search, clean-ring and prior-mask validation, neural RGB blending; falls back to v7.5 temporal or spatial shader. Not dense optical flow or full generative inpainting.
- 48,000 new synthetic training rows, 6,000 validation and 6,000 test; 899 quadrillion nominal weights, normalized for selected-shift training, not distinct observations.
- Twelve new automatic layout/palette combinations (IDs 162–173); six new GPU decorative motion families react to shot boundaries. Existing template IDs and tools retained.
- Export preserves the semantic template (IDs 138+) selected at import rather than replacing it during the palette scan.
- OtoBlur: shared legacy-safe frame reader; strongest compact OCR line cluster rather than OCR enumeration order.
- Android compilation, physical player and GPU performance remain unverified; no proxy codec or external pretrained model added.

# Kinera Edit v7.5 — Neural Reconstruction Studio

- kAI 5.5 / OtoBlurPro 5.5: optional preceding-frame RGB reconstruction with neural blend; spatial fallback, mask and ring checks, reset on seek/cut; capped at 2.07M source pixels. Not optical flow or full temporal inpainting.
- 48,000 new weighted training rows, 6,000 validation and 6,000 test; nominal weight 898 quadrillion, normalized in actual training, not distinct data.
- Preview retries seek to sync frames; watchdog resets stable interval on backward jump. Existing tools, templates, weights and signing config retained.
- Android compile and real GPU/device tests remain pending.

# Kinera Edit v7.4 — Neural Hyper Intelligence

Offline Android editor. OtoBlur uses Gaussian blur; OtoBlurPro uses tracked, approximate spatial pixel reconstruction (not temporal generative inpainting). See `qa/V74_DEVICE_CHECKLIST.md`. Source codec availability depends on Android device.

# v7.3 Neural Cinematic Master
Current release: 7.3.0 / versionCode 64 / kAI 5.3. Six new landscape variants (162 total), six decorative GPU families (54 total), auxiliary neural tracking scheduling, bounded preview endpoint and export stall recovery. See qa/V73_DEVICE_CHECKLIST.md. Android compilation and device verification not executed.

# v7.2 Neural Expert Intelligence
Current release: 7.2.0 / versionCode 63 / kAI 5.2. 18 new template variants (156 total), automatic semantic/aspect selection, draft audio state and overlap guard, precise three-frame swept mask. Prior SupremeConfidence remains active for scheduling. New ExpertConfidence is experimental. See qa/V72_DEVICE_CHECKLIST.md.

# v7.1 Neural Supreme Intelligence
Current release: 7.1.0 / versionCode 62 / kAI 5.1. Existing bundled ML Kit image labeling and face detection remain. SupremeConfidence is consulted only for conservative tracking scheduling; it cannot accept or veto masks. See CHANGELOG and qa/V71_DEVICE_CHECKLIST.md.

# v7.0 Neural Autonomous Studio
Current release: 7.0.0 / versionCode 61 / kAI 5.0. Existing bundled ML Kit image labeling and face detection remain. See CHANGELOG and qa/V70_DEVICE_CHECKLIST.md.

# Kinera Edit v6.9.0 — Neural Advanced Director

kAI 4.9, versionCode 60, Android 12+. Bundled ML Kit face detection 16.1.7 adds a bounded face-presence fallback when the image labeler returns unknown. No identity recognition. The new center import frame uses closest-frame retrieval; saved draft template decisions remain unchanged. Bitmap and model client cleanup now follows asynchronous task completion. OtoBlurPro 4.7 checks the original appearance before accepting a tracked region or a partially verified midpoint. Playback watchdog resets stability after long gaps. Editor tool buttons have updated sizing, selected state, padding and palette; Blur strength saves per draft.

AppearanceConfidence 6/32/16/1 is a new experimental MLP, not active. It uses 24,000 synthetic patch feature rows derived from 12 still images and five existing MP4 fixtures, with 3,000 separate validation and test rows each. Nominal 99 trillion uniform sample weights are normalized to one during fitting; no new distinct data are implied. Earlier training files are preserved byte-for-byte, not replayed into the new model. The general object detector was not integrated because the standard ML Kit API requires an initial download. No Android SDK/device test or APK build was executed. See qa/V69_DEVICE_CHECKLIST.md for a direct v4.7 upgrade test.

Sources: https://developers.google.com/ml-kit/vision/face-detection/android and https://developers.google.com/ml-kit/vision/object-detection/android.

# v6.7 — Neural Professional Intelligence

- kAI 4.7; experimental AnchorRisk MLP (24,000 photo-derived training pairs, 3,000 validation, 3,000 test; disabled because held-out recall is poor). Nominal 90 trillion weights not used during training.
- OtoBlurPro 4.5: validate midpoint and each displacement before keeping verified partial masks.
- Neighbor-aware effect envelope; finite controls; defensive normalized geometry.
- Editor: smaller bounded scroll panel, timeline remains available during region editing, minimum width removed, blur reset persisted, shared palette.
- Existing sections retained. Android SDK/device unavailable; APK not built.

# Kinera Edit v6.6.0 — Neural Deep Vision Studio

Android 12+, versionCode 57, kAI 4.6. ExposureRisk 6/24/12/1 is a photo-derived exposure classifier, used only to veto positive brightness/contrast when observed RGB clipping is at least 12%. Prior cut models retained. OtoBlurPro 4.4 uses cached luma arrays and recent-motion sampling. Existing controls and signing preserved.

77 trillion nominal counts are historical accounting only; actual training is 16,000 new augmented still-image crops (unweighted), 2,000 validation, 2,000 test. Not real video data. No externally pretrained visual network integrated. All prior training archive bytes retained. Android APK/device/GPU tests not executed. Run `bash tests/run.sh`.

# Kinera Edit v6.5.0 — Neural Cognitive Studio

Android 12+, kAI 4.5, versionCode 56. Existing local Media3 pipeline and signing configuration preserved. The new cognitive model is experimental, not active. See QA and training metrics.

# Kinera Edit 6.4.0 — Neural Semantic Director
Android 12+, applicationId meteapps.kineraedit, versionCode 55. Existing four tools, signer, Flip default, automatic templates, preferences, localization and exit confirmation preserved.

kAI 4.4 adds defensive temporal timeline validation and a five-distance experimental MLP (5/32/16/1), not deployed because holdout F1 declined. OtoBlurPro 4.2 uses adaptive sampling intervals and rejects excessive translation jumps. Not semantic video understanding or guaranteed anonymization. No Android SDK/device test.

Training archive preserves all 172 v6.3 files, adds 18,000 synthetic ordered sequences with 70 trillion exact statistical weights and 6,000 separate validation/test sequences. Old data are preserved, not replayed into the temporal model since old features lack ordered differences.

Run bash tests/run.sh. GitHub build uses existing KINERA_SIGNING_BUNDLE; Android compilation and signing occur in CI.

### v6.8 update
The new bundled ML Kit labeling model is optional at inference time (unknown/failure/timeout falls back to color-based template selection); requires Gradle dependency resolution during build. No user video is uploaded by Kinera. The local clipping guard applies only to newly imported video auto grades. ChromaRisk is archived as experimental, not an active decision model. See `qa/V68_DEVICE_CHECKLIST.md` before production use.

Reference documentation: https://developers.google.com/ml-kit/vision/image-labeling/android (bundled labeling API); https://developer.android.com/media/media3/ui/playerview (player surfaces). The original 5 MP4 fixtures are in the earlier v5.4 and v6.0 test archives; the new NPZ contains derived feature rows, not raw real-video labels.

## v0.5.6 Stable — Neural Scene Intelligence
- Version code 92; kAI/OtoBlurPro 8.1; 50 append-only template IDs, six decorative GPU families.
- 36 bounded sequential marker probes; 96-second scene budget. No exhaustive semantic video analysis.
- Compact editor threshold, persistent blur slider cancel recovery, tighter history timestamp gate.
- Experimental 8/12/1 model trained on 568 decoded pairs from old procedural fixtures; not enabled. No additional independently filmed clips or Android device validation.
- CI separates compile/sign/audit from lint and publishes artifacts before lint; signed but unapproved builds remain diagnostics if lint fails. Permanent signer required.
