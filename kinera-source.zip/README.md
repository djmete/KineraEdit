# v8.1 — Neural Vision Pro

- GitHub workflow now reads a separate root `kinera-source.zip` (500 KB workflow limit); same signer and one universal APK.
- kAI 6.1, two OCR observations per window (up to 62); conservative half-window masks if observations disagree; fixed full-duration mode remains.
- New VisionLaneConfidence trained on 40,000 synthetic pairs; old model retained.
- Reuse metadata retriever for dense scan; conservative handling of incomplete loud audio; lifecycle guard for gallery player.
- Host checks only; Android compile, device UI, real video quality, full generative inpainting, proxy and new codecs not verified.

# Kinera Edit v8.0 — Neural Ultimate Studio

- kAI 6.0, OtoBlurPro 6.0: full-duration OCR proposal mode, at most 31 evenly spaced windows, 180 s UI timeout, cooperative cancellation; no partial plans applied automatically. A fixed-region reconstruction option covers all timestamps without claiming every subtitle is detected. Existing 48 s tracking stays available. All proposals require confirmation; prior masks replaced only on confirmation.
- CaptionLaneConfidence (6→16→8→1, 257 parameters) trained on 60,000 synthetic coordinate pairs, validation/test 6,000 each. Geometry and neural gates prevent risky adjacent mask unions. Model only vetoes merges, not restoration quality. No new nominal statistical budget; prior nominal accounting unchanged. No real-video training added.
- Six new automatic templates, 198 total; existing 66 motion families reused. Old IDs retained. Mint/charcoal studio palette and AMOLED accents, theme selection available only from Settings. No change to output palette of existing templates.
- Gallery video uses existing in-app Media3 player with external playback option on content URI error. Reminder switch in Settings, app-level Android channel settings, bounded progress, expanded result text. Audio rhythm state resets on sample-rate changes.
- Single universal signed APK, all prior dependencies, model files and ABI support kept. Host checks only; Android compile/device tests, proxy, new codecs, actual full generative video inpainting and GPU performance remain unverified.

# Kinera Edit v7.9 — Neural Advanced Reconstruction

- kAI 5.9 texture-aware INT16 older-frame reconstruction; new shader with old history shader fallback. Preserves two-frame memory bound and avoids duplicate timestamp eviction.
- 48,000 new synthetic training rows, 6,000 validation, 6,000 test; exact nominal budget 798,617,728 quadrillion recorded as decimal strings; relative difficulty weights actually used. No claim of that many distinct samples.
- 12 new automatic templates (192 total), 6 GPU decoration families (66 total), stable old IDs.
- Settings: Studio dark, AMOLED Black, follow device night mode (Studio when device not in night mode). Theme does not alter video rendering.
- Media3 result player with decoder fallback and lifecycle cleanup; header sizing, OCR grouping, audio null guards, scene refinement safeguards.
- One universal signed APK, all existing ABIs and offline models retained. No proxy, new independent codec, dense flow or external generative model. Host tests only; Android assembly/device UI/performance remain unverified.

# Kinera Edit v7.8 — Neural Ultra Compact Studio

- Single universal signed APK, all ABIs and dependencies retained; compressed native libraries; size and SHA-256 inventory generated in CI.
- kAI 5.8: second prior frame fallback for <=720p sources, strict scene/time/mask guards, quantized int16 gate; original weights retained in training archive.
- 48,000 new synthetic rows with nonuniform weights, nominal budget 719,517 quadrillion (Python exact integer sums).
- Watchdog, OCR seed filter, editor control spacing and time label improvements.
- Six new Ultra templates (180 total), reuse existing 60 motion families. No new dense flow, proxy, or external generative model. Android build/device validation outstanding.

# Kinera Edit v7.7 — Neural Dynamic Intelligence

- kAI 5.7: diagonal motion reconstruction model, conservative fallback after cardinal search fails; 48,000 new synthetic rows, 898 quadrillion nominal weights normalized in selected-diagonal loss.
- Compact ARM64 signed APK plus universal; bundled AI and all existing features retained. APK size audit checks asset and ARM64 library hashes and reports actual bytes in CI. No R8 or resource pruning.
- Duplicate OCR boxes no longer inflate cluster score; null scene list disables temporal reuse.
- Full multi-frame history, proxy, dense optical flow, audio-reactive templates and Android runtime benchmarks remain future work.

# Kinera Edit v7.6 — Neural Generative Vision

- kAI 5.6 / OtoBlurPro 5.6: optional local five-position translation search, clean-ring and prior-mask validation, neural RGB blending; falls back to v7.5 temporal or spatial shader. Not dense optical flow or full generative inpainting.
- 48,000 new synthetic training rows, 6,000 validation and 6,000 test; 899 quadrillion nominal weights, normalized for selected-shift training, not distinct observations.
- Twelve new automatic layout/palette combinations (IDs 162–173); six new GPU decorative motion families react to shot boundaries. Existing template IDs and tools retained.
- Export preserves the semantic template (IDs 138+) selected at import rather than replacing it during the palette scan.
- OtoBlur: shared legacy-safe frame reader; strongest compact OCR line cluster rather than OCR enumeration order.
- Android compilation, physical player and GPU performance remain unverified; no proxy codec or external pretrained model added.

# Kinera Edit v7.5 — Neural Reconstruction Studio

- kAI 5.5 / OtoBlurPro 5.5: optional preceding-frame RGB reconstruction with neural blend; spatial fallback, mask and ring checks, reset on seek/cut; capped at 2.07M source pixels. Not optical flow or full temporal inpainting.
- 48,000 new weighted training rows, 6,000 validation and 6,000 test; nominal weight 898 quadrillion, normalized in actual training, not distinct data.
- Preview retries seek to sync frames; watchdog resets stable interval on backward jump. Existing tools, templates, weights and signing config retained.
- Android compile and real GPU/device tests remain pending.

# Kinera Edit v7.4 — Neural Hyper Intelligence

Offline Android editor. OtoBlur uses Gaussian blur; OtoBlurPro uses tracked, approximate spatial pixel reconstruction (not temporal generative inpainting). See `qa/V74_DEVICE_CHECKLIST.md`. Source codec availability depends on Android device.

# v7.3 Neural Cinematic Master
Current release: 7.3.0 / versionCode 64 / kAI 5.3. Six new landscape variants (162 total), six decorative GPU families (54 total), auxiliary neural tracking scheduling, bounded preview endpoint and export stall recovery. See qa/V73_DEVICE_CHECKLIST.md. Android compilation and device verification not executed.

# v7.2 Neural Expert Intelligence
Current release: 7.2.0 / versionCode 63 / kAI 5.2. 18 new template variants (156 total), automatic semantic/aspect selection, draft audio state and overlap guard, precise three-frame swept mask. Prior SupremeConfidence remains active for scheduling. New ExpertConfidence is experimental. See qa/V72_DEVICE_CHECKLIST.md.

# v7.1 Neural Supreme Intelligence
Current release: 7.1.0 / versionCode 62 / kAI 5.1. Existing bundled ML Kit image labeling and face detection remain. SupremeConfidence is consulted only for conservative tracking scheduling; it cannot accept or veto masks. See CHANGELOG and qa/V71_DEVICE_CHECKLIST.md.

# v7.0 Neural Autonomous Studio
Current release: 7.0.0 / versionCode 61 / kAI 5.0. Existing bundled ML Kit image labeling and face detection remain. See CHANGELOG and qa/V70_DEVICE_CHECKLIST.md.

# Kinera Edit v6.9.0 — Neural Advanced Director

kAI 4.9, versionCode 60, Android 12+. Bundled ML Kit face detection 16.1.7 adds a bounded face-presence fallback when the image labeler returns unknown. No identity recognition. The new center import frame uses closest-frame retrieval; saved draft template decisions remain unchanged. Bitmap and model client cleanup now follows asynchronous task completion. OtoBlurPro 4.7 checks the original appearance before accepting a tracked region or a partially verified midpoint. Playback watchdog resets stability after long gaps. Editor tool buttons have updated sizing, selected state, padding and palette; Blur strength saves per draft.

AppearanceConfidence 6/32/16/1 is a new experimental MLP, not active. It uses 24,000 synthetic patch feature rows derived from 12 still images and five existing MP4 fixtures, with 3,000 separate validation and test rows each. Nominal 99 trillion uniform sample weights are normalized to one during fitting; no new distinct data are implied. Earlier training files are preserved byte-for-byte, not replayed into the new model. The general object detector was not integrated because the standard ML Kit API requires an initial download. No Android SDK/device test or APK build was executed. See qa/V69_DEVICE_CHECKLIST.md for a direct v4.7 upgrade test.

Sources: https://developers.google.com/ml-kit/vision/face-detection/android and https://developers.google.com/ml-kit/vision/object-detection/android.

# v6.7 — Neural Professional Intelligence

- kAI 4.7; experimental AnchorRisk MLP (24,000 photo-derived training pairs, 3,000 validation, 3,000 test; disabled because held-out recall is poor). Nominal 90 trillion weights not used during training.
- OtoBlurPro 4.5: validate midpoint and each displacement before keeping verified partial masks.
- Neighbor-aware effect envelope; finite controls; defensive normalized geometry.
- Editor: smaller bounded scroll panel, timeline remains available during region editing, minimum width removed, blur reset persisted, shared palette.
- Existing sections retained. Android SDK/device unavailable; APK not built.

# Kinera Edit v6.6.0 — Neural Deep Vision Studio

Android 12+, versionCode 57, kAI 4.6. ExposureRisk 6/24/12/1 is a photo-derived exposure classifier, used only to veto positive brightness/contrast when observed RGB clipping is at least 12%. Prior cut models retained. OtoBlurPro 4.4 uses cached luma arrays and recent-motion sampling. Existing controls and signing preserved.

77 trillion nominal counts are historical accounting only; actual training is 16,000 new augmented still-image crops (unweighted), 2,000 validation, 2,000 test. Not real video data. No externally pretrained visual network integrated. All prior training archive bytes retained. Android APK/device/GPU tests not executed. Run `bash tests/run.sh`.

# Kinera Edit v6.5.0 — Neural Cognitive Studio

Android 12+, kAI 4.5, versionCode 56. Existing local Media3 pipeline and signing configuration preserved. The new cognitive model is experimental, not active. See QA and training metrics.

# Kinera Edit 6.4.0 — Neural Semantic Director
Android 12+, applicationId meteapps.kineraedit, versionCode 55. Existing four tools, signer, Flip default, automatic templates, preferences, localization and exit confirmation preserved.

kAI 4.4 adds defensive temporal timeline validation and a five-distance experimental MLP (5/32/16/1), not deployed because holdout F1 declined. OtoBlurPro 4.2 uses adaptive sampling intervals and rejects excessive translation jumps. Not semantic video understanding or guaranteed anonymization. No Android SDK/device test.

Training archive preserves all 172 v6.3 files, adds 18,000 synthetic ordered sequences with 70 trillion exact statistical weights and 6,000 separate validation/test sequences. Old data are preserved, not replayed into the temporal model since old features lack ordered differences.

Run bash tests/run.sh. GitHub build uses existing KINERA_SIGNING_BUNDLE; Android compilation and signing occur in CI.

### v6.8 update
The new bundled ML Kit labeling model is optional at inference time (unknown/failure/timeout falls back to color-based template selection); requires Gradle dependency resolution during build. No user video is uploaded by Kinera. The local clipping guard applies only to newly imported video auto grades. ChromaRisk is archived as experimental, not an active decision model. See `qa/V68_DEVICE_CHECKLIST.md` before production use.

Reference documentation: https://developers.google.com/ml-kit/vision/image-labeling/android (bundled labeling API); https://developer.android.com/media/media3/ui/playerview (player surfaces). The original 5 MP4 fixtures are in the earlier v5.4 and v6.0 test archives; the new NPZ contains derived feature rows, not raw real-video labels.
