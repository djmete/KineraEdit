# v1.1.5 RC — Neural Creative Intelligence (151)

- kAI/OtoBlurPro 14.5; 4,234 template IDs, 50 new compositions.
- Bounded recent-shot cadence budget reduces excessive visual/audio accents. No semantic recognition claim.
- GPU mask uniforms compared only when interval changes; retained live Blur, Cut and 5–20% OtoSes.
- GitHub source-first upload workflow: source ZIP alone no longer triggers CI after installing new workflow; update YML second or dispatch manually. Exact SHA-256 and signing certificate still enforced.
- New research dataset: 14,080 train, 8,960 validation, 8,960 test rows; 50 source groups. Historical reported training total 4,405,398; research weights inactive. Four private reference clips replayed (16,631 frames; 81 candidates).
- 100,000 mask upload parity cases, 74,180 interval comparisons skipped; not a measured device speedup.
- Device export and APK compilation not yet verified.

# v1.1.4 RC — Neural Cinematic Intelligence (150)

- kAI/OtoBlurPro 14.4; 4,184 template IDs, 50 new compositions.
- Cadence-aware alternating dark and soft accents; reduced audio accents for closely spaced cuts.
- Shared GPU preview/export render plan skips inactive transition calculations, caches repeated time/mask queries; manual crop and privacy mask zoom protection preserved.
- Live Blur pending draft recovery on READY playback tick; cached restoration interval checks, 100,400 parity cases. Cut aperture and OtoSes 5–20% retained. Four private references remain separate.
- New research-only model trained on 13,440 rows; archive reported total 4,391,318; candidate regressed on all four private benchmarks, production weights unchanged.
- 100,000 render parity checks, 89,393 inactive skips in synthetic schedule, not a measured Android speedup. Full host suite passed. 
- Device export and APK compilation not yet verified.

# v1.1.3 RC — Neural Hyper Intelligence (149)

- kAI / OtoBlurPro 14.3, 4,134 template IDs.
- Draft-only live Blur geometry and strength updates; coalesced paused refresh with bounded distinct seek rather than same-position seek. The paused frame may move by one source frame until Apply/Cancel; no device test yet.
- Clean cut preference for very short shots, restrained accents for rapid sequences, shared across visual/zoom/audio paths.
- Five editorial profiles (clean, soft, dip, lift, push); precompute audio accent parameters, retain immutable timed masks during manual preview changes.
- Preserve prior crop aperture, OtoSes 5–20% policy, four references and prior training files. No new neural training; reported historical count 4,377,878. Host regressions and 25,142 new timing/rhythm cases passed; Android build/device/export pending.

# v1.1.2 RC — Neural Performance Studio (148)

- kAI / OtoBlurPro 14.2; 4,084 template IDs (50 new).
- Manual crop preserves all selected pixels: artwork aperture is fitted to the actual displayed crop, leaving template artwork (not black empty window) around it. Source-encoded black borders are not removed. Shared preview/export geometry retained.
- Finer 1,000-step crop slider, unchanged-progress no-op, wider crop edge/corner hit targets and visible handles.
- Reuse OCR client and retriever in full restore and consensus; reuse scene refinement buffers; skip manual crop zoom computation; eliminate duplicate mask interval binary search. No device speed claim.
- Four private reference clips retained; no device APK/export test. Existing training archive preserved. Research-only 15,360 training rows (44 source groups); reported cumulative training total 4,377,878. Four-video reconstruction candidate regressed and remains inactive.

# v1.1.1 RC — Neural Responsive Studio (147)

- kAI / OtoBlurPro 14.1; 4,034 template IDs (50 new).
- Blur editor requests composed preview even with stable/raw preference; explicit decoder fallback remains available. Full-duration manual mask policy retained.
- Tall-screen audio control lane below filmstrip, hidden in focus, region edit, or large-font modes. It edits global gain, not a separate audio track.
- Mask interval cursor reuses unchanged buffers and supports reverse seeking; skip zero-envelope director calculations. Android speed not measured.
- Automatic preview gain bounded to 5–20% (0 for no audio). No new neural training; historical total 4,362,518.
- Existing four reference videos and signing configuration retained. Device touch, GPU and APK build not verified.

# v1.1.0 RC — Neural Professional Studio (146)

- kAI / OtoBlurPro 14.0; 3,984 template IDs (50 new).
- Manual Blur: full-clip masks independent of effect timestamp; new region initializes full interval, intentional timed masks retained, full clip action visible in menu.
- Cleaner home (draft data retained; card removed), focus control below preview, redundant metadata/seek hidden when filmstrip visible, larger filmstrip.
- OtoSes: 5–20% absolute volume, nine sampled windows for clips over 90 s; sample origin adjustment.
- Export: avoid unnecessary preparation decoder lock, skip scene analysis when scene and animation effects disabled; avoid unchanged GL uniforms. Thermal safety unchanged; actual Android speed unmeasured.
- Four private reference clips preserved. No new neural training; reported historical training total 4,362,518. Android build, touch, and export require device validation.

# v1.0.9 RC — Neural Multi-Vision Director (145)

- kAI/OtoBlurPro release version 13.9; 50 new template compositions (3,934 total); prior IDs, names, palettes, and 146 GPU families preserved. Active neural weights unchanged. This crop-focused update adds no neural training rows; historical reported train total 4,362,518, 41 groups, retained from v1.0.8.
- Cut starts in source-space free mode without forcing a 9:16 selection. Four corners and four independent edges, move and pinch; six optional ratio presets; pixel dimensions in the fixed control strip. The selection is provisional until Apply. Reset returns full source and legacy auto framing.
- Non-full manual crops are contained in the existing 9:16 template canvas, with no second cover crop or automatic cut zoom; template padding may be visible. Previously saved non-full manual crops also use this policy. The composed Blur overlay uses the same fitted window and sampled region. Final export remains 9:16; no arbitrary export dimensions added.
- Four verified private reference identities replayed from cached decoded luma: 16,631 frames, 16,627 pairs, 81 candidate cuts; no new decoding or pixel-quality Android export claimed. Source archive excludes original MP4s.
- Full host suite passed; final targeted crop and gesture tests cover source geometry and transaction semantics. Android compile, GPU render and device verification pending. Device acceptance checklist: qa/device145/README.md.

# v1.0.8 RC — Neural Temporal Fusion (144)

- kAI/OtoBlurPro 13.8; 50 editorial compositions (3,884 total). Preserve existing IDs, palettes and 146 motion families.
- Four private reference fixtures: 85053, 85196, 85197, 85198; 16,631 decoded frames and 81 cut candidates in host luma replay. All reference files remain excluded from training and public source; manifest, hashes and replay tool in qa/reference_suite.
- Bounded consecutive-frame eligibility extended to 195s (up to 30fps, 6144 pairs, unchanged thermal/memory and time budgets). Decoder waits for EOS at capacity and rejects additional pairs; prior plan retained on incomplete scan. Player timeline redraw cache reset on source switch.
- 38,912 train, 22,528 validation, 22,528 test rows, 41 source groups (23 existing images plus 18 procedural texture groups). Historical reported train total 4,362,518. 1,409-parameter residual candidate, 10 epochs, selected epoch 9; real reference regression in standard MAE on all four, so production shader/weights unchanged. Motion research from previous version retained, not activated.
- Full host tests passed prior to final timeline reset; final source wiring audit passed separately. Android compilation, device, actual export and OCR validation remain pending. See qa/device144.

# v1.0.7 RC — Neural Spatial Intelligence (143)

- kAI/OtoBlurPro 13.7; 50 new compositions (3,834 total), existing IDs/palettes and 146 GPU families preserved. Short-shot accent attenuation preserves the cut center. Timeline cache includes actual width and invalidates when hidden then visible.
- 36,864 train, 20,480 validation, 20,480 test rows from 38 source groups (3 additional procedural textures). Historical reported train total 4,323,606. Residual candidate 1,409 parameters, 10 epochs, selected epoch 10. Reference video slightly regressed; production weights remain unchanged.
- 85053.mp4: 3,980 frames, 3,979 pairs, 18 cut candidates. 275/275 geometry anchors, 5.1362% extra area. Cross-axis alignment MAE 0.033413 vs two-block 0.033849 (159 pairs; 16 improved, 8 regressed); research only. This is not final Android export.
- v1.0.6 APK reported available by user. v1.0.7 Android build/device/export tests remain unverified; see qa/device143.

# v1.0.6 RC — Neural Deep Director (142)

- kAI/OtoBlurPro 13.6; 50 new compositions (3,784 total). Preserve all prior IDs, palettes and 146 GPU families. Optional accent tails are reduced on short asymmetric shots; timeline redraws are limited to changes in playhead pixel or duration. Existing draft and caption policies preserved.
- 34,816 train, 18,432 validation, 18,432 test rows from 35 source groups (3 new procedural textures). Historical reported train total 4,286,742; no new independent videos in training. Residual 1,409 params, selected epoch 7 of 10. Video MAE slightly regressed, weights inactive.
- 85053.mp4: 3,980 frames, 18 cut candidates; 275/275 geometry anchors, 5.1362% extra area. Local two-block fractional alignment hidden-region MAE 0.033849 vs global quarter 0.040922 on 159 pairs; research-only, not final inpainting.
- Full host regression passed; 321 Java sources parsed and 3784 template paths against stubs; Android build, physical device and actual export not tested. See qa/device142.

# v1.0.5 RC — Neural Cognitive Studio (141)

- kAI/OtoBlurPro 13.5; 50 additional compositions, 3734 total. Existing IDs and GPU families retained. Shared short-side accent control; readable slider percentage and redundant layout update suppression. Research model and fractional motion are not enabled by default. Android build and physical-device tests pending.

- 32,768 new training, 16,384 validation and 16,384 test rows from 32 groups (3 new procedural textures); historical reported train total 4,251,926. Residual 1,409 parameters, selected epoch 0 of 10; active weights unchanged. Adaptive fractional selection on 159 reference pairs MAE 0.040983 vs quarter-only 0.040922, research only. 3,980 frames, 18 candidate cuts; 275/275 geometry anchors preserved at 5.1362% extra area. Device acceptance checklist qa/device141.

# v1.0.4 RC — Neural Motion Intelligence (140)

- kAI/OtoBlurPro 13.4; 50 new editorial compositions (3,684 total), old IDs, palettes and 146 GPU families retained. Shared short-shot accent attenuation for visual, zoom and audio. Slider value width, responsive slider padding and high-font tool scrolling improved; existing draft cancellation and OCR anchor policy unchanged.
- 46,080 new training rows, 21,504 validation, 21,504 test from 29 source groups (3 new procedural texture groups); historical reported total 4,219,158. 1,409-parameter residual candidate selected epoch 0 after 8 epochs; no activation. No independent new video source for training.
- 85053.mp4: 3,980 frames, 18 cut candidates, 275/275 geometry anchor coverage; quarter-pixel research benchmark improves hidden-region alignment MAE from 0.041820 to 0.040922 on 159 pairs, not Android export quality. Existing production shader remains unchanged.
- Physical Android and GitHub build not executed here; RC pending device validation. Stub template probe now iterates over actual catalog length (previous loop ended at 3,584).

# v1.0.3 RC — Neural Precision Director (139)

- kAI/OtoBlurPro 13.3; 50 new compositions (3,634 total), existing IDs and 146 GPU families preserved. Conservative leading accent on asymmetric shots; current text-band size guard; reduced disabled header controls, wider compact slider and redundant live render suppression. 57,344 new training rows (historical reported total 4,173,078); candidate selected epoch 0, active model retained. Separate half-pixel alignment experiment reduces reference hidden-region MAE by 1.15%, research only. 85053.mp4 held out of training. Physical Android build and export remain unverified.

# v1.0.2 RC — Neural Advanced Vision (138)

- kAI/OtoBlurPro 13.2. Append 50 editorial compositions (3,584 total); preserve prior IDs, 146 GPU motion families, names and palettes. Shared visual/zoom accent uses an asymmetric envelope for abrupt adjacent-shot duration changes; audio remains unchanged.
- Current OCR anchor preserved, horizontally displaced neighboring rectangles rejected, expansion capped at 8%. Reference: 275/275 anchor coverage, mean additional area 5.4562% -> 5.1362%. Geometry only, not actual OCR or inpainting accuracy.
- Compact tool strip scrolls below 360dp, small-screen compact mode and slider padding tuned. Apply/Cancel and pressure cadence retained. Not a full redesign or measured device performance gain.
- Experimental 9→32→16→1 residual network (865 params), 10 epochs, selected epoch 10. 53,248 training, 20,480 validation, 20,480 test synthetic pixel samples from 23 image groups; 5 additional groups. Reported cumulative train rows 4,115,734. Repeated 85053.mp4 held out from training; 3,980 decoded frames, 3,979 pairs, 18 candidates, 7,632 artificial occlusion rows. Candidate regressed on video and stays disabled. Active shader unchanged.
- Physical Android, signed CI build and actual OtoEdit/OtoBlurPro export remain pending. Device acceptance checklist: qa/device138. No detector bypass or platform approval guarantee.

# v1.0.1 RC — Neural Supreme Intelligence (137)

50 appended templates (3534 total), source-safe rhythm bounds, current OCR anchor vertical drift guard, compact controls and preview cadence. Experimental residual weights are not used by production. Android build/device validation pending.

# v1.0.0 RC — Neural Ultimate Studio (versionCode 136)

- kAI/OtoBlurPro 13.0; 50 appended compositions, 3,484 total. Existing 146 GPU motion families and IDs retained. Shared transition intensity scales by adjacent shot-duration ratio.
- Caption expansion cap varies with overlap while retaining current anchor. Reference geometry: 275/275 coverage, mean extra area 7.4335% to 5.4562%. No actual OCR or subtitle-removal quality claim.
- Compact Studio earlier on narrow displays; filmstrip deferred until taller screen; persistent slider, Apply/Cancel and resource cadence retained. No complete redesign.
- 737-parameter residual confidence network, 12 epochs, selected epoch 9; 46,080 train / 23,040 validation / 23,040 test procedural rows from reused stills. Reported cumulative training rows 4,008,726. Candidate not activated: reference video MAE regressed. Active shader unchanged.
- Full reference decode 3,980 frames, 3,979 pairs, 18 unchanged scene candidates; 7,632 artificial occlusion rows. No actual Android export tested.
- Host suite exit 0. Real Android, CI build and device performance pending. Read-only ADB collection and release acceptance checklist in qa/device136. No detector bypass or platform approval guarantee.

# v0.9.9 — Neural Professional Director (source candidate, versionCode 135)

- kAI/OtoBlurPro 12.4; 50 appended compositions (3,434 total); 146 existing GPU motion families; prior IDs/palettes preserved. Shared rhythm policy shortens visual/zoom/audio envelopes when nearby scene markers cluster; no changes to source chronology.
- Compact Studio threshold, accessible persistent Blur strength row, pressure-aware live preview cadence; existing draft Apply/Cancel guard retained. No full UI redesign or device performance claim.
- Current OCR anchor rejects stale/disjoint neighboring candidate rectangles; reference geometry replay preserves 275/275 anchors, same mean excess area as v134. This is not OCR or inpainting accuracy.
- 737-parameter residual confidence network (5→32→16→1) trained 12 epochs from zero correction around the active baseline; bounded residual; research alignment cross-checks a separate visible-context sample. 49,152 new procedural train rows, 24,576 validation, 24,576 test, from 12 existing still-image groups. Reported cumulative train rows 3,962,646; no new unique training videos.
- 85053.mp4 held out; freshly decoded 3,980 frames, 3,979 adjacent pairs, 18 unchanged scene candidates. 7,632 artificial-occlusion benchmark rows; reference MAE regressed, candidate inactive and active shader unchanged. Raw video not distributed.
- Host suite and source audit passed. Android build, physical-device UX, actual OCR/inpainting/export quality pending; release gate documented. No detector bypass or platform approval guarantee.

# v0.9.8 — Neural Reconstruction Intelligence (candidate)

- 50 appended templates (3,384 total), kAI/OtoBlurPro 12.3, versionCode 134; existing template IDs unchanged; duplicate display labels at 2985 and 3005 renamed Lagoon II.
- Shared conservative editorial accent pacing, compact workspace and live preview cadence.
- Motion confidence gate and temporal model are research-only pending labeled cuts and Android validation.
- Original 85053.mp4 held out; no source video redistribution.
- Guard delayed/live blur callbacks by active draft; cap neighbor-expanded caption area to 112% of current OCR anchor.
- 36,864 procedural training rows, 18,432 validation and 18,432 test rows; candidate unchanged at best validation epoch 0. Neither candidate nor experimental motion gate activated.
- Reference: 3,980 decoded frames, 18 unchanged scene candidates, 275/275 anchor coverage. Device and CI build pending.

# v0.9.7 — Neural Adaptive Studio (source candidate, versionCode 133)

- kAI/OtoBlurPro 12.2; 50 appended compositions, 3334 total; existing template IDs and 146 GPU families retained.
- Optional complete consecutive luma pass for 180s, <=30 fps, up to 1920x1080 pixels (including portrait), 6144 frame-pair buffer; 65s overall budget for >90s supported clips, 40s decode cap, 25s coarse cap; pressure/cancellation/incomplete EOS leaves base plan intact. This is not semantic comprehension of every frame.
- Adaptive122 localized-change guard, restrained transition accent density, compact Studio thresholds, wider persistent Blur slider; explicit transactional Apply/Cancel preserved. No full UI redesign or new shader family claimed.
- Adaptive122Caption bounds neighbor expansion; 11 approximate manually reviewed anchors from supplied 85053.mp4, 275 synthetic neighbor perturbations, all anchors covered and mean excess region reduced. Not ML Kit OCR accuracy or actual reconstruction quality.
- Private recurring reference fixture in qa/reference85053: exact SHA-256, metadata, scene and model replay results, approximate caption geometry, optional local replay script. Original user video is intentionally not bundled into release APK or public source; no permission to redistribute established. All 3980 frames decoded on host, 3979 pairs replayed, 18 conservative marker candidates in both policies. No scene ground truth.
- Research-only 5→80→40→1 model (3761 params), 20 epochs, selected 13; 32256 train, 16128 validation, 16128 test new procedural rows, 12 previously used photo groups. 85053 was excluded from training; its 7632 artificial-mask holdout examples showed the active baseline remained better. New weights inactive, production shader unchanged; no native subtitle-free ground truth.
- Reported cumulative archive training rows 3,876,630 (not unique videos). Historical training archives remain separate; merge helper preserves paths. No automatic on-device retraining or originality-classifier bypass.
- Android device tests, signed GitHub build and full export/ML Kit OCR quality pending. Existing app ID, signing certificate, AGP/Gradle/JDK versions retained.

# v0.9.6 — Neural Visual Intelligence (source candidate)

- kAI/OtoBlurPro 12.1; versionCode 132; 3284 templates, 50 appended; existing GPU families.
- Draft-first Back in focus mode, wider slider and compact layout. Existing apply/cancel transaction preserved.
- Sequential luma structure guard and bounded probes for longer clips; no complete semantic frame understanding.
- Android build and physical-device performance pending.

# v0.9.5 — Neural Vision Studio (source candidate, versionCode 131)

- Explicit transactional Crop/Blur: immutable baseline, RAM-only strength/geometry/time/masks while previewing, blocked autosave/history writes; Apply commits, Cancel/back/tool change/page exit/export/background discards, releases draft effect player. Reset is provisional until Apply. Stale gestures and nested dialog callbacks are gated. Audio and automatic caption dialogs continue requiring confirmation. Host method replay added; device lifecycle still requires test.
- kAI/OtoBlurPro 12.0; 50 appended composition variants, 3234 total; original template IDs and 146 GPU motion families retained. New edge-safe transition policy and caption geometry guard; no detector bypass or all-template individual redesign.
- 90s full consecutive luma scan unchanged; optional refinement up to six markers on long clips with 12s spare budget; resource-pressure fallback retained. Not unrestricted semantic analysis of every frame.
- Compact tool threshold, wider Blur slider, visible Cancel/Reset/Apply in focus. No complete UI redesign or device performance claim.
- Research-only Vision120 5→64→32→1, 2497 parameters, 15 epochs, selected 9. 23040 train, 11520 validation, 11520 test new procedural rows from 12 existing still-photo groups. Test aligned MAE regressed against prior research candidate; production weights unchanged. Real video fetch failed DNS. No independent camera benchmark or mobile GPU measurements.
- CI configuration from v130 preserved, version and SHA pinned to new archive; existing package/signing identity unchanged. v129 successful CI reported by user; v131 build pending. No guarantee of platform originality or zero bugs.

# v0.9.4 — Neural Studio Intelligence (source candidate, versionCode 130)

- kAI/OtoBlurPro 11.9; 50 appended compositions, 3184 total; existing IDs and 146 GPU motion families retained. No claim of new GPU shaders or all prior compositions individually redesigned.
- Full consecutive luma analysis eligibility through 90s at <=720p/30fps, up to 3072 frame pairs, max 25s decode within 28s global budget; long clips can probe four existing markers if 8s remains. EOS-only commit; old plan retained on interruption, pressure, unsupported media or incomplete decode. Not unrestricted semantic recognition of every frame.
- Restrained accents at closely spaced cuts; anchor overlap guard for caption suggestions; compact tool mode and metadata visibility, persistent Blur slider and pressure refresh on live dragging. Not a complete Studio redesign or device-verified fix.
- New 5→48→24→1 research model: 1489 parameters, 25 training epochs attempted, selected epoch 0 (validation did not improve); candidate inactive. Training archive delta uses new procedural motion/rotation examples from 12 existing still-photo groups. No camera-footage benchmark or mobile GPU parity.
- CI distinguishes recovered offline failures from final delivery; original signing certificate, AGP 8.7.3, Gradle 8.9, JDK 17, SDK 35 and package identity retained. User-provided v129 log confirms successful build/sign/lint/publish; v130 Android build pending.
- No platform originality or bug-free guarantee; intended for creative editing of authorized footage.

# v0.9.3 — Neural Cinematic Reconstruction (source candidate)

VersionCode 129; kAI/OtoBlurPro 11.8; 3,134 templates; optional bounded consecutive luma scan up to 60 s at <=720p/30 fps, complete-only merge; persistent Blur slider; retained production shader. No physical Android or independent real-video quality validation.

## v0.9.2 — Neural Adaptive Reconstruction (source candidate, versionCode 128)

- kAI/OtoBlurPro 11.7; 50 appended compositions, 3084 total. Existing IDs preserved.
- Optional contiguous luma analysis through 30s, 720p/30fps; max 1024 pairs, 12s bounded decode, full EOS required.
- Conservative exposure veto, shot accent bounds, compact timeline, persistent Blur slider, anchored caption geometry.
- Production neural shader retained pending independent camera footage and device parity.
- Android build and physical-device performance not verified.

# v0.9.1 — Neural Precision Studio (127)

Release-labeled source candidate; Android APK, signing and physical device tests pending. kAI/OtoBlurPro 11.6. 50 appended composition variants (3,034 total), prior IDs retained; existing 146 GPU motion families. Conservative 48×48 block translation check for ambiguous cuts, short-shot visual accents and bounded sequential luma pass for eligible short clips (1.8–12 seconds, <=720p/30fps, up to 420 frame pairs and 6 seconds, no partial commit, pressure-aware). Not full semantic understanding of every frame or unrestricted-length scanning. Requested-frame OCR suggestions limit expansion; live Blur strength persists in preview focus and rolls back pending input on multi-touch/cancel; compact dock and pressure-limited preview. New theme surface colors. Logcat KineraMetrics records scan wall/thread CPU time, Java heap, thermal status and frame counts on devices. New 537-parameter cold-start candidate regressed, warm-start candidate improved synthetic metrics; both inactive until independent footage/device/render validation. No new GPU shader, no full app redesign, no platform originality guarantee. Training delta only.

# v0.9.0 — Neural Professional Intelligence (126)

Release-labeled source candidate; Android SDK build, signing and device tests pending. kAI/OtoBlurPro 11.5. 50 appended compositions (2,984 total), prior IDs unchanged. One persistent Blur row frees 48 dp, reduced compact timeline chrome, pressure-aware live preview cadence, multi-touch cancel and both preview surfaces detached on release. Requested-frame OCR consensus and restrained transition continuity. New 121-parameter research model tested on simulated motion; held inactive because test PSNR regressed slightly and independent video/GPU evidence is missing. Existing shader and earlier training files unchanged; current delivery is a training delta. No platform originality guarantee.

# v0.8.9 — Neural HyperVision (125)

Native timeline multi-touch cancellation, late thumbnail result rejection during editing/pressure, workspace stability during scrubbing, compact play control, 50 new template variants. Hyper114 trained candidate regressed on test; retained active Multimodal113. No Android build/device or new camera footage.

# v0.8.8 — Neural Multimodal Director (124)

Multimodal113 distilled 81-parameter temporal decision replaces stacked high-quality blend, retains Cinematic112 and older shader fallbacks; canceled timeline gestures restore start, lifecycle reset, narrow two-line clock, ruler endpoint fitting, full-width Blur, short-shot accent guard and 50 new template variants. V118 training archive still incomplete. No new camera footage or Android device results.

# v0.8.7 — Neural Cinematic Intelligence (123)

Cinematic112 learned temporal correction over Context111, compile fallback to Context111 and legacy cognitive; timeline partial-frame placeholders, responsive time labels and multi-touch guards; critical memory cache release; 50 new templates. V118 archive still incomplete. Android device and real footage pending.

# v0.8.6 — Neural Context Intelligence (122)

Context111 learned temporal fallback in high-quality shader with old shader fallback, conservative OCR union area, responsive timeline and 50 additional templates. V118 archive still incomplete; no device verification.

# v0.8.5 — Neural Precision Director (121)

Same-shot OCR mask union, explicit Blur priority, compact Crop timeline and 50 additional templates. Training recovery is separately audited.

# v0.8.4 — Neural Adaptive Vision (120)

Locked 9:16 crop frame, corner handles, pinch and dedicated zoom slider, no outside replacement. Template-specific cover guide remains separate. Short single-miss OCR bridging only within known scene boundaries. 50 new presets. No new full video neural export.

# v0.8.3 — Neural Reconstruction Fusion (119)

Scene-bounded OCR proposals when scene markers exist; compact Blur seek; 50 Fusion108 templates. Existing trained CNN diagnostic remains available; not used for full video export.

# Kinera Edit v0.8.2 Stable — Neural Vision Transformer

Version 118; kAI/OtoBlurPro 10.7; 2584 templates, 146 GPU motion families. This is a release title, not a claim of a deployed Transformer. Up to four extra higher-resolution source reads for OCR rescue; existing scan deadline and fallback retained. Blur cancel discards uncommitted strength, compact dock spacing, asymmetric scene zoom restraint. Previous Architecture105 weights and two parity fixtures bundled; settings exposes a background CNN self-test, not production reconstruction. New contextual CNN (1958 parameters) archived, not active: prior CNN narrowly wins on test. No new pretrained external weights or camera footage. No Android APK/device verification.

# Kinera Edit v0.8.1 Stable — Neural Unified Vision

Version 117; kAI/OtoBlurPro 10.6. 2534 templates, 146 GPU motion families. Full-width Blur slider; bounded deferred OtoBlur start while thumbnail decoding drains; conservative adjacent short subtitle extension; sparse reference CNN inference. The new fine-tuned CNN did not beat the prior CNN on the reused-source test, so it is not activated. No new pretrained external weights or camera footage. No Android APK/device verification.

# Kinera Edit v0.8.0 Stable — Neural Intelligence Architecture

Version 116; kAI/OtoBlurPro 10.5. 2484 templates. Throttled live Blur slider preview, compact studio palette and rhythm-aware transition restraint. Android APK/device not yet verified.

# Kinera Edit v0.7.9 Stable — Neural Fusion Intelligence

Version 115; kAI/OtoBlurPro 10.4. 2434 templates. Bundled ML Kit selfie segmentation dependency and bounded middle-frame fallback, centered subtitle candidate ranking, pressure-aware scrubbing. Android APK/device not yet verified.

# Kinera Edit v0.7.8 Stable — Neural Deep Vision

Version 114; kAI/OtoBlurPro 10.3. 2384 templates. Bounded upscaled OCR rescue for missing/off-center candidates, existing learned scene guard applied to local refinement, transition balance, and 50 new layouts. Experimental temporal CNN is not deployed. No physical Android verification.

# v0.7.7 Stable — Neural Motion Intelligence

- kAI/OtoBlurPro 10.2; 50 new layouts and 300 moving GPU template variants across 20 motion families, including 10 new GPU algorithms. 2334 total templates, 146 total motion families.
- Existing Blur selection is protected against outside taps/drags and outside pinch; Android touch slop prevents jitter. Actual overlay method replay tested with host Android stubs.
- Studio shared surfaces and dock revised: flat surfaces, compact margins, playback above filmstrip, equal four-tool row on ordinary widths, accessible scrolling retained. Full app rewrite not claimed.
- OCR crop rescue on misses, at most eight additional calls per full normal-resource scan, same source bitmap, coordinate remapping, deadline headroom; no new decoder. Thumbnail lock wait limited to 1.5 seconds. OCR is still lower-caption oriented and sampled.
- Trained 12/32/16/1 scene model is wired into ambiguous-cut scoring only; it cannot add cuts, is bypassed under resource pressure and reduces eligible scores by at most 4%. Separate 13,187-parameter five-layer spatial CNN research is not deployed: no useful held-out improvement and regression on real still images.
- Previous model/data archives preserved. No new real video clips; six licensed real still photographs plus old procedural encoded clips used. See qa/AI_QUALITY_REQUIREMENTS.md. APK build, Android hardware and real-world OCR/restore quality remain unverified.

# v0.7.6 Stable — Neural Creative Intelligence

- kAI/OtoBlurPro 10.1; 50 layout variants + 100 animated templates (1984 total); 10 new decorative GPU motion families (136 total).
- Adaptive OCR edge size can decrease during a scan; compact filmstrip and dock spacing.
- HD+ user selected export dimensions, auto audio, history, previous source and signing retained.
- Android build and device verification pending; new model experimental.

# v0.7.5 Stable — Neural Professional Studio

- kAI/OtoBlurPro 10.0; 50 new templates (1834 total).
- Cancellable bounded decoder admission, cached OCR rotation, 720px OCR under pressure.
- Filmstrip above transport, adaptive height/slot budget, visible placeholder and retryable player state.
- Preserve HD+ selected export size, AutoSəs 5–20%, all prior modules and signing.
- Android build and physical device validation pending.

# Kinera Edit v0.7.4 — Neural Multimodal Studio

- Visible cancellable OtoBlur/Pro progress panel before releasing playback, 72/36 OCR windows (144/72 samples), 90s cooperative deadline; no results published after cancellation. Single live ML Kit OCR session, 250ms cooperative waiting, retain pending bitmap until task completion. A sparse scan may miss short subtitles. Native decoder stalls cannot be forcibly interrupted by a Java timeout.
- Flat editor controls, updated studio palette and 50 template variants. Previous functions preserved.
- HD–4K exact output size and AutoSəs 5–20% retained. Android/device validation pending.

# Kinera Edit v0.7.3 — Neural Cinematic Intelligence

- Auto audio 5–20% on audio tracks, fallback 10%, no-track zero and manual gain unchanged. Legacy measured auto gain migrates on saved-project open.
- 50 new Cinematic98 template variants, HD–4K user-selected resolution preserved.
- Long-shot zoom intensity is moderated for shorter eligible shots; editor metadata hidden on more compact screens; existing workspace controls and Blur retained.
- Existing temporal reconstruction and Maven recovery preserved. Android build and device validation pending.

# Kinera Edit v0.7.2 — Neural Temporal Director

- HD/FHD/2K/4K user-selected output, legacy SD selection migrates to HD. FPS remains automatic.
- Temporal history is not used or captured when active timed masks exceed the shader slot count.
- Tighter mask union guard, restrained transition accents in rapidly alternating scenes.
- 50 new template variants, Blur seek available from 540 dp.
- Cache-first Maven recovery preserved; Android build and device validation pending.

# Kinera Edit v0.7.1 — Neural Reconstruction Studio

- User-selected output resolution; automatic FPS and bitrate, no silent resolution fallback.
- Cache-first CI; remove mandatory HTTP probes; bounded network retries.
- More conservative temporal mask unions, 50 template variants, compact Blur seek.
- Android build/device verification pending.

# Kinera Edit v0.7.0 Stable — Neural Ultra Studio

- Automatic source-sensitive output height and FPS; lower resource envelope, lower fallback options.
- Up to two sequential cut refinements (3.6 second total deadline), only without resource pressure, after releasing the previous decoder.
- Caption geometry selection and bounded restoration union.
- Zero-strength blur bypass and compact seek controls.
- 50 new templates; previous IDs and data retained.
- Android build/device verification pending.

# Kinera Edit v0.6.9 Stable — Neural Studio Intelligence

- VersionCode 105; kAI / OtoBlurPro 9.4. 50 template variants (IDs 1484–1533), all previous template metadata and 126 motion families retained.
- Automatic export envelope replaces manual export settings in visible UI: 720p/1080p portrait canvas, source-aware frame cap at 30 FPS, H.264, existing calculated bitrate and codec fallback. Pro masks and pressure favor 720p. Source quality may be reduced by this policy. Old hidden widgets retained only for preference compatibility. Audio and scene analysis deferred to export unless requested manually; prevents parallel preview work. Prior thermal guards retained.
- Blur uses one persistent 0–100 strength slider, geometry via drag/pinch and More for timing/masks. Old encoded 0/1/2 strengths are preserved; new strength 0–12, higher shader sampling radius with unchanged 49-tap kernel. Actual quality and speed need Android verification. Undo/Redo and project histories retained.
- OtoBlur and OtoBlurPro share bounded full-duration two-sample interval OCR. Ordinary blur-only masks permit frame-edge geometry; Pro uses restoration-safe geometry. A single missing sample can be bridged for <=150ms when adjacent observed boxes closely agree. Larger gaps are not filled. Slightly enlarged OCR padding. Result confirmation, previous draft preservation on failure, cancellation and thermal/decode gates retained. Not every-frame OCR, new semantic model or generative inpainting.
- Experimental 10/12/1 subtitle-interval compatibility network: 5120 train, 1280 validation, 1280 test from 24 existing encoded procedural clips with synthetic box jitter. Test 564 TP, 12 FN, 704 TN, 0 FP; inactive, archived. No real camera data or actual OCR labels; no platform originality guarantee.
- Release news updated; existing notification permission/channel and test features retained. No complete rewrite of all UI pages. Android APK build and phone performance unverified; no independent agents launched.

# Kinera Edit v0.6.8 Stable — Neural Vision Director

- VersionCode 104; kAI / OtoBlurPro 9.3. 50 new template IDs (1434–1483), five layouts and ten palettes, prior template metadata and 126 animation families retained.
- Reorganizes the editor into an edge-to-edge weighted preview and dedicated bottom dock (transport, filmstrip or scrubber, tools, Blur controls and actions). Wider preview, 56dp top header, 48dp history buttons, persistent Blur slider with a parameter menu, filmstrip threshold 650dp and no duplicate seekbar while it is visible. Shared dark palette and Home spacing revised. Existing pages and rendering engines retained; not a complete rewrite of all screens. Device layout verification pending.
- Release highlight previously disabled by MAJOR=false; enabled for release 104. Manual Home entry, onResume retry, once-per-upgrade gate. Fresh install intentionally skips automatic highlight. Notification test button checks runtime permission and channel; existing progress/result/reminder channels retained. New labels translated into TR/EN/RU.
- Vision93 weak cut guard integrated in coarse and refined scene analysis, no extra decoding; no new object model or all-frame semantic analysis. No new generative inpainting; prior temporal and OCR engines retained. Non-editor thumbnail cache released on memory pressure. Earlier export safety, thermal controls and history preserved.
- Experimental compression-robust 10/12/1 network trained from 24 prior procedural video clips at JPEG qualities 95,55,25; 7872 train, 1968 validation, 1968 test. Test 96 TP, 17 FP, 0 FN, 1855 TN. Inactive; weights archived. Not real camera footage. No TikTok originality guarantee.
- Host suite completed before final localization. Final rerun reached Vision93Test then execution timeout; remaining source audit run separately and passed. Android build, phone performance and GPU pixel render unverified. No independent agents used.

# Kinera Edit v0.6.7 Stable — Neural Precision Director

- VersionCode 103; kAI / OtoBlurPro 9.2. 50 new template IDs (1384–1433), five layout families, ten palettes. All prior template names, colors, IDs and 126 motion families retained; shared foreground contrast selection updated.
- Precision92 coherent contrast-change guard integrated with coarse and fine scene candidate analysis. Strong candidates unchanged. No additional decoder pass and no new semantic object detector.
- OtoBlurPro two-frame cadence check uses binary cut search; 50,000 randomized equivalence cases against old policy. This is an optimization, not a new inpainting model.
- Timeline thumbnails no longer decoded when hidden or under resource pressure; delayed work checks visibility again and shares interruptible DecodeGate87. The top Undo/Redo pair has a fixed 96dp width (48dp per button); export button capped at 112dp. Existing history, draft isolation, Blur interaction, FIT preview, export safety and thermal protection preserved. No full UI rewrite.
- Experimental contrast robustness 10/12/1 model, trained on 24 existing procedural clips: 7,872 train, 1,968 validation, 1,968 test. New contrast augmentations, not new real camera videos. Model inactive, weights archived. No platform originality guarantee.
- Full host script reached final check. Real Android APK build, GPU pixel render and physical phone export performance remain unverified. No agents launched.

# Kinera Edit v0.6.6 Stable — Neural Contextual Intelligence

- VersionCode 102; kAI / OtoBlurPro 9.1. Adds 50 template IDs (1334–1383), five layout families and ten palettes. Previous styles and all 126 motion families retained.
- Fresh video selection no longer automatically restores edits or scene markers for the same URI. Explicit Saved Projects opens the saved draft. Saving a new edit to the same URI replaces its latest saved draft; source file never modified.
- Undo and redo are placed in the top header, including adjustment mode. Lower reset/apply row only visible when adjusting. Pending changes committed before history navigation, empty blur leaves adjustment mode, preview rebuilt at current position with a coalesced refresh; previous shader history cleared on mask changes. Host history tests and source wiring checks pass; actual touch/render behavior pending Android test.
- Contextual91 chroma shift guard only adjusts weak scene candidates where structure and RGB shifts remain coherent. No extra frame decode or new semantic object model. Import skips expensive semantic inference under device pressure. All previous thermal protection, decoder gate and indexed masks retained.
- Experimental 10/12/1 chroma-robust scene classifier trained using 24 existing procedural clips (7872 train, 1968 validation, 1968 test). New RGB color augmentations; model inactive. No new camera footage, no generative video inpainting added. No platform originality guarantee.
- Host tests passed. Full Android build, device export and GPU pixel rendering not verified.

# Kinera Edit v0.6.5 Stable — Neural Cognitive Performance

- VersionCode 101; kAI / OtoBlurPro 9.0. Appends 50 template IDs (1284–1333), five layout families and ten palettes; all previous IDs and 126 GPU animation families retained.
- Cognitive90 adds a conservative exposure-shift guard to weak scene candidates and nearby refinement. No new decoder pass or semantic object model. Strong candidates remain unchanged.
- OCR, dense restore and motion tracking share the interruptible decoder gate with scene and audio analysis. Mask index construction uses an event sweep preserving original slot order; temporal history uses binary lookup of sorted cut boundaries. Existing thermal cancellation and adaptive GPU history retained. No measured device-speed claim.
- Blur value/menu widths adapt to screen/font, slider padding reduced. Existing Undo/Redo, four editing tools, FIT and unified OtoBlurPro retained. No full redesign or new generative inpainting model.
- Experimental exposure-robust cut classifier trained on 24 existing procedural clips (7872 train, 1968 validation, 1968 test), new exposure augmentations; weights and dataset separately stored, model inactive. No new camera footage.
- Full host suite passed; Android build, GPU rendering and physical device not verified. See QA checklist. No platform originality guarantee.

# Kinera Edit v0.6.4 Stable — Neural Dynamic Intelligence

- VersionCode 100; kAI / OtoBlurPro 8.9. Appends 50 template IDs (1234–1283) with five compositions and ten palettes; all previous IDs and 126 GPU animation families retained.
- Dynamic89 adds a bounded 6×6 local-motion score adjustment for weak cut candidates. It does not identify object classes or analyze every frame. Existing semantic and audio engines remain.
- Temporal GPU path checks resource pressure at 1.5-second intervals until constrained; it then frees history textures and disables second-frame history for that program. Full-resolution temporal history may be unavailable under pressure, with possible quality trade-offs. Existing critical heat cancellation remains. This is not a measured device-speed improvement.
- Blur value width adapts to screen width and font size; standard noncompact tool minimum height is slightly reduced. Existing Undo/Redo, four editing tools, FIT and unified OtoBlurPro retained. No full UI rewrite or new generative inpainting model.
- Experimental multi-gap scene model trained on 24 existing procedural video clips (3840 train, 960 validation, 960 test); weights and dataset stored separately, model inactive. No real-camera footage added.
- Complete host test suite passed; Android build, device and GPU rendering not verified. See qa/V100_PERFORMANCE_DEVICE_CHECKLIST.md. No platform originality guarantee.

# Kinera Edit v0.6.3 Stable — Neural Adaptive Performance

- VersionCode 99; kAI 8.8; OtoBlurPro 8.8. Adds 50 template IDs (1184–1233), keeps all 1184 existing names/colors and 126 GPU motion families.
- Adaptive88 uses Android thermal state and available RAM to reduce coarse scene probes and refinement, lower automatic preview resolution, and bound temporal history GPU memory. Normal profile retained; constrained reconstruction may use a simpler shader or spatial fallback. No measured device-wide speedup or perfect reconstruction claim.
- MaskTimeline87 uses merged time intervals for history-capture checks; the former linear reference implementation is retained in tests. 50,000 random parity queries verified.
- Editor: defer blur strength preference commits until slider release, reduce paused refresh frequency, avoid drawing a hidden filmstrip, apply a low-resolution automatic preview under pressure. Undo/redo and existing four tools retained. Incremental changes, not a complete redesign.
- Export results disclose skipped/incomplete scene analysis instead of silently suggesting successful analysis. Previous markers retained.
- Experimental Adaptive88 reconstruction-risk MLP trained on new masked samples from 24 existing procedural video clips; clip-level train/validation/test split. Model remains offline and inactive pending real-world evaluation. No real camera training footage added.
- Existing safety gates and universal signed APK workflow retained. Android/physical device/GPU pixel rendering not verified in this environment. See qa/V99_PERFORMANCE_DEVICE_CHECKLIST.md. Originality decisions remain the platform’s responsibility; no guarantee of acceptance.

# Kinera Edit v0.6.2 Stable — Neural Performance Intelligence

- VersionCode 98; Android 12+; kAI/OtoBlurPro 8.7. Same permanent signer, universal APK, Maven routing and build diagnostics.
- Performance-first release: serialize scene/audio decoder access using an interruptible gate; recycle timeline bitmaps before export; reduce UI/notification progress to at most every 1.2 s per stage, skip playback tick work outside editor, avoid redundant paused-frame UI redraws.
- Thermal/RAM protection: decline new export at severe system throttling or OS low-memory signal; stop on critical heat, sustained severe heat (15 s), or low memory. Full-duration OCR and scene analysis also stop at periodic checks on high load. Source/draft preserved; partial render removed. No forced temperature, no hardware speed promise.
- On successful export report prep time, render factor, highest sampled thermal status, sampled Java heap and process PSS after render. Not total peak native/GPU RAM. Resource-stop paths intentionally cancel rather than pretend to resume.
- GPU timed-mask lookup indexed per immutable mask snapshot; exact prior fillBoth geometry and slots retained. Release stale temporal GPU history after 0.5 s outside restore intervals. Prior shader models retained; actual GPU pixels/device behavior not verified.
- Coarse scene analysis budget preserved; efficient mode can refine up to 6 detected boundaries within remaining budget. Slightly wider and stronger cut grading/zoom within existing single-pass effects; no per-frame semantic model or actual human-level editing guarantee.
- Compact Blur menu labels/accessible names, avoid redundant player refresh, retain four tools, one OtoBlurPro option and previous undo/redo. Incremental editor changes, not full UI rewrite.
- 50 additional IDs 1134–1183 across five layouts, 126 prior motion families retained to avoid extra load. Old templates retained byte-for-byte as array entries. Experimental 8/12/1 model from 24 newly generated encoded procedural clips, 1328 train / 332 validation / 332 test rows. Not real-world footage. Model archived and disabled.
- No Android SDK or physical device in this environment. Host/regression test and audit evidence only. Refer to qa/V98_PERFORMANCE_DEVICE_CHECKLIST.md. No platform originality or monetization guarantee.

# Kinera Edit v0.6.1 Stable — Neural Advanced Intelligence

- versionCode 97; Android 12+, same signing contract, kAI/OtoBlurPro 8.6.
- Efficient profile defaults to at most 96 coarse samples, 28-second scene analysis budget, 30 FPS cap, and automatic preview up to 640 px high; full quality remains selectable. Import defers automatic scene/audio analysis in efficient mode. Ordinary renders use spatial shader without temporal reconstruction overhead. Device speed/thermal impact not measured.
- OtoBlurPro has one user-facing whole-duration scan/restoration option; OtoBlur remains separate. Bounded OCR samples, approximate restoration, not lossless removal or dense every-frame recognition.
- Visible undo/redo (40 snapshots) includes tracked regions, masks, audio, scene markers, template, color/effect settings. Global export settings not covered. Existing four editor tools preserved.
- 50 additional template IDs (1084–1133) in five layout families; existing 126 GPU motion families retained. No wholesale redesign or new generative model.
- Experimental cut MLP (6/12/1), 1704 train, 426 validation, 426 test rows from 12 prior procedural clips at three resolutions. Weights archived, not active. No new real-world footage.
- APK comparator included; v4.7 and 0.6.0 actual APK binaries unavailable. Prior native library compression and retired features are distinct causes. Source paths preserved, not evidence of feature equivalence.
- Host tests only; full Android compilation, pixel rendering and physical device checks pending. No platform eligibility guarantee.

# Kinera Edit v0.5.5 Stable — Neural Vision Intelligence

- Android 12+, versionCode 91, kAI 8.0 / OtoBlurPro 8.0; same package and signing key, single universal APK.
- 50 appended template IDs (784–833), five composition families, 6 added decorative GPU motion patterns (96 total). Earlier names, palettes and IDs preserved; shared player/layout changes apply to all templates, not an individual redesign.
- 32 candidate refinement windows, 90-second total analysis budget. 8/16/1 MLP trained on 12,000 photo-derived simulated frame pairs, validated/tested on disjoint image sources (2,000 each). Guard requires strong measured alignment and low cut probability; veto only, never creates a cut. Synthetic validation is not general video understanding. Existing 12 encoded procedural clips decoded for regression (852 pairs, zero known-cut vetoes; also zero triggered guards). Prior AV MLP remains disabled. Existing local ML Kit object/face labeling retained, not newly trained.
- FIT playback, compact toolbar, increased filmstrip and metadata collapse thresholds, persistent wider Blur selector; 4 main tools retained. Temporal second-history reuse requires both adjacent time gaps and the full time span to be valid. No new generative inpainting model or new export backend.
- Host Java/static suite passed (consolidated compile). Host EGL compiled/linked shaders, pixel render segfaulted. No Android SDK/physical device validation or APK build performed. No claim of platform originality eligibility or detector bypass.
- Next: v0.5.6 Stable — Neural Scene Intelligence. Annotated real-world videos, semantic and audio evaluation, physical Android layout/preview/export measurements.

# Kinera Edit v0.5.4 Stable — Neural Expert Precision

- Android 12+, versionCode 90, kAI 7.9 and OtoBlurPro 7.9. Same app ID and permanent signing contract.
- 50 appended templates (734–783), five layout families, six new decorative GPU animation families (90 total). All earlier template names, palettes and IDs retained. The shared editing engine serves every template; no individual redesign of the 734 old templates.
- Local PCM envelope reads at most the first 30 seconds within a 5-second wall-clock budget. Corroborates strong visual candidates only; no new shot from audio alone. Missing audio is unknown. 28 distributed probe windows, still budget-limited, not every frame. Existing chronology and duration preserved.
- Experimental 4/12/1 audiovisual MLP trained on 24,000 augmented feature rows from 8 procedural encoded clips, validated/tested on distinct clips (2 each). Raw held-out precision 25%; disabled. Existing neural files retained; deterministic conservative audio rule used instead. No general real-world semantic model.
- Compact height toolbar, optional filmstrip and info collapse, wider fixed Blur slider, source player fit mode; prior 4 tools and navigation preserved. Not a complete visual redesign, no physical layout/device test.
- 150 ms nominal OCR interval for short clips; 192-window cap retained. FPS-aware conservative temporal history reuse, not a new generative inpainting model. Same Media3 export and signing pipeline; no guarantee of device or platform eligibility.
- Single universal APK CI. Host Java and static source suites passed in consolidated compilation; full Gradle build, physical device and shader execution not verified. See QA checklist.

## Next: v0.5.5 Stable
Real annotated speech/music/cut benchmarks, device layout and preview fixes based on screenshots/logs, temporal restoration comparisons, hardware export measurements. No detector evasion or originality guarantee.

# Kinera Edit v0.5.3 Stable — Neural Precision Director

- Android 12+, versionCode 89; kAI 7.8 / OtoBlurPro 7.8; same package and signing requirements.
- 50 additional template IDs (684–733; 734 total), five composition families and six new GPU decorative motion families. Existing IDs and arrays are preserved.
- Triple-frame neural flash false-cut guard integrated into the bounded consecutive-frame refinement. 24 candidate probes rather than 20; prior model files retained. The new 6/16/1 INT16 MLP was trained on 36,000 synthetic-labeled feature rows with 6,000 validation and 6,000 test rows, using disjoint previously available video clips. It is not a general video semantic model. No claim that every frame is decoded.
- Larger preview allocation on compact heights, widened Blur adjustment value and control, slightly tighter control padding, safe focus placement, preserved four primary tools. Existing Player/Media3 and export paths retained; analysis timeout budgets aligned.
- Denser short-clip OCR sampling (160 ms vs 180 ms); previous approximate spatial/temporal reconstruction retained. No new generative inpainting model.
- Single universal APK workflow. Source and model archive audit plus host tests included separately; Android build, physical device and GPU validation pending. See qa/V89_PRECISION_DEVICE_CHECKLIST.md.

## Next: v0.5.4 Stable

Device-verified responsive editor and export; real annotated shot, speech/music and inpainting evaluation; improve temporal reconstruction only after controlled quality benchmarks. No originality detector bypass or platform eligibility guarantee.

# Kinera Edit v0.5.2 Stable — Neural Semantic Director

- versionCode 88; kAI 7.7 / OtoBlurPro 7.7.
- 50 appended templates (634–683), 684 total; 78 existing motion families retained.
- Three-frame semantic voting at import; 20 distributed cut probes; conservative low-resolution motion alignment veto, never deletes a coarse marker. Proxy training labels, no superiority over rule-only test demonstrated.
- Fixed Blur slider and narrow action row autosizing, bounded preview notice, source preview double tap geometry, adaptive OCR rectangle padding, notification failure guards. Common decorative accent intensity reduced.
- No new shader, generative inpainting, or all-frame semantic analysis. Android build/device testing remains required.

# Kinera Edit v0.5.1 Stable — Neural Adaptive Director

- versionCode 87; kAI 7.6 / OtoBlurPro 7.6.
- 50 appended templates (584–633); 634 total, prior template identities and 78 GPU motion families retained.
- AdaptivePulseConfidence conservative three-frame refinement veto, up to 16 distributed probes; existing coarse cut never deleted by new model. Synthetic test, no superiority over rules demonstrated.
- Blur gesture viewport snapshot and lifecycle reset, wider fixed slider on narrow screens, watchdog suppression while dragging, source audio accent ducking, overlapping caption interval union.
- No new shader, generative inpainting, or full-frame semantic analysis. Android build/device testing remains required.

# Kinera Edit v0.5 Stable — Neural Vision Director

- versionCode 86; kAI 7.5 / OtoBlurPro 7.5; next public patch versions 0.5.1, 0.5.2.
- 50 appended templates (534–583), existing motion families and all prior models retained.
- VisionLightConfidence active only as a conservative veto on an existing cut refinement; up to 12 distributed probes, 14-second budget. No source chronology changes.
- Fixed non-scrolling blur slider strip, compact width/height/font-scale layout, stable resize origin; smooth scene accent envelope, short two-letter caption recognition, notification-manager guard.
- No new shader, generative inpainting, or full-frame semantic analysis. Android device and APK build testing remain required.

# Kinera Edit v0.4 Stable — Neural Autonomous Director

- versionCode 85; kAI 7.4 / OtoBlurPro 7.4; same package and signer, one universal APK.
- 50 appended templates, IDs 484–533; existing template entries and motion families retained.
- Distributed sequential cut refinement, up to eight candidates; lighting pulse confidence gate if benchmark passes. Original coarse marker fallback.
- Narrow caption padding, stable blur slider, theme-coherent region handles, zero-size player canvas guard, aligned time budgets.
- No full-video semantic analysis, new shader, or generative inpainting; Android device testing required.

# Kinera Edit v0.3 Stable — Neural Cinematic Director

- versionCode 84; kAI 7.3 / OtoBlurPro 7.3. Same package/signature, universal APK.
- 50 appended templates (IDs 434–483), prior 434 entries and 78 motion families preserved.
- Bounded sequential MediaCodec refinement of detected cut candidates, with coarse fallback and preserved duration; no full-video semantic analysis.
- Fixture-derived residual luma model trained and retained but disabled after validation/test regression.
- Blur gesture hit selection, touch-state safety, player row sizing, draft persistence. No new shader or generative inpainting. Physical Android verification required.

# Kinera Edit v0.2 Stable — Neural Professional Director

- versionCode 83, kAI 7.2, OtoBlurPro 7.2. Same package and signature. One universal APK.
- 50 new templates (IDs 384–433); previous 384 entries and 78 animation families preserved.
- Blur region drag, pinch, relative edge resize and compact two-row fixed slider, with five adjustment choices. Preview invalidation deferred until slider release. More room by hiding header in region mode; four main editor tools retained.
- 320 sampled editorial frames, 24 refined markers, 54 s budget; existing 384 OCR/mask capacity retained. 57,000 new train rows, 7,000 validation and 7,000 test, from six fixture MP4s (216 decoded frames). New experimental model trained on fixture-derived synthetic triplets, not activated after poor held-out test. No generative inpainting or all-frame semantics. Short centered lower-caption OCR fallback, aligned analysis/export time budgets, duplicate scene scoring eliminated.
- Physical Android verification required.

# Kinera Edit v0.1 Stable — Neural Master Intelligence (development line v9.1)

- Public version restarts at 0.1 Stable; versionCode 82 remains monotonic, same application ID/signing certificate. kAI 7.1 and OtoBlurPro 7.1 retain earlier models and features.
- 64,000 synthetic image-pair rows, 8,000 validation and 8,000 test; new motion confidence model remains experimental if quality gate fails. No external video dataset.
- 50 appended templates, IDs 334–383; 78 GPU animation families and 12 shader variants retained. 288 sampled editorial frames and 20 refined markers, up to 384 OCR samples/timed masks. No full per-frame semantic inference or generative inpainting.
- Compact viewport-aware editor controls, revised studio palette, short-clip player recovery. Latest-only full-screen highlight. Existing notification settings retained.
- One universal APK; no nested APK archive. Physical Android verification required.

# Kinera Edit v9.0 — Neural Master Studio

- kAI 7.0: 48,000 synthetic translated/shot-change photo-crop rows, 6,000 validation and 6,000 test. Experimental motion model retained but disabled after missing predeclared quality gate.
- OtoEdit: 216 sampled analysis frames, 280 ms target interval, coverage check, up to 16 refined scene markers. Conservative visual accent adjustment, not a full per-frame semantic model or crossfade.
- 50 new templates (five layouts × ten palettes), stable IDs 284–333. Existing 78 GPU animation families and 12 shaders retained.
- OtoBlurPro: up to 320 OCR samples and timed masks, prior reconstruction shaders preserved. No generative inpainting.
- Editor: region adjustment hides main tool strip as well as thumbnails; apply/reset/history remain accessible. Updated studio palette. Latest-only announcement, four languages. Notifications avoid duplicate initial progress.
- One universal APK; previous signer, package and source workflow retained.

# Kinera Edit v8.9 — Neural Evolution Studio

- kAI 6.9: 48,000 simulated three-frame lighting/scene training rows, 6,000 validation and 6,000 test. New conservative lighting-pulse model integrated into bounded scene analysis, not an originality classifier.
- Up to 144 approximate analysis samples, 26-second budget; incomplete scan retains previous edit. Effects applied at render timestamps; not every frame analyzed semantically.
- 50 new templates (five layouts × ten palettes), IDs 234–283, 78 existing motion families retained.
- Editor workspace collapses thumbnail strip and metadata during region adjustment, separates apply/undo row from scroll; refreshed slate/ice-blue UI.
- Full-screen latest-only v8.9 announcement in four languages. Notifications retain existing channels; result category/timestamp and accent updated.
- OtoBlurPro retains prior 12 shader variants and models; no new generative inpainting in this release. One universal APK, prior signer/package preserved.

# Kinera Edit v8.8 — Neural Cognitive Studio

- kAI 6.8: 96,000 simulated clean side-pixel examples, 12,000 validation, 12,000 test; 17 parameter INT16 model, conservative half-strength weighting. Full model slightly regressed on stills; reused test after inspection.
- OtoBlurPro 6.8: texture-aware side ring, old shader fallback, no full generative inpainting.
- Player high-water watchdog, delayed trailing progress notification, strong PCM transient attenuation. Six additional templates, existing 78 GPU animation families.
- Single universal APK, unchanged signing pin and offline dependencies. Minor release: no full-screen highlight.

# Kinera Edit v8.7 — Neural Creative Intelligence

- OtoBlurPro 6.7: last-resort quarter-side and midpoint pixel sampling at three bounded distances; previous ten shader variants retained. Padded other-mask and source boundary guards. Not generative inpainting.
- kAI 6.7: 88,000 simulated spatial examples, 11,000 validation and 11,000 test from 16 stills and 504 decoded frames of three previously used sample clips. New 8→12→1 INT16 candidate retained inactive because validation and video subset regress. No nominal increment.
- Six templates using the existing 78 decorative GPU motion families; old IDs and colors preserved. New animation branches reverted after host driver crashes. Shot-marker-driven decorative animation, not direct audio motion.
- Gap-aware scene-neighborhood analysis, skip optional rhythm work when there are no shot markers, invalid player positions clear stability.
- Single universal APK and full-screen release highlight policy retained (no major highlight for this incremental release). Android compilation and device validation pending.

# Kinera Edit v8.6 — Neural Advanced Creator

- OtoBlurPro 6.6: three additional bounded perimeter rings (2, 4, 8 pixel-step offsets) when all nearer edge and corner samples are blocked. Existing nine shader variants remain fallback options. Not full generative inpainting or pixel-level glyph segmentation.
- kAI 6.6: 80,000 newly sampled synthetic outer-corner training examples from 16 stills and 420 decoded frames of three previously used clips; 10,000 validation and 10,000 test. No new nominal weight.
- Six new templates and six GPU decorative motion families, preserving old IDs. New styles react to shot timing, not live audio or dense optical flow.
- Sweep-line timed mask validation, isolated malformed mask timestamp recovery, playback watchdog monotonic check.
- Full-screen major-update highlight retained but disabled for this incremental release; no stale highlights.
- Single signed universal APK workflow, no nested artifact ZIP. Android compilation and device validation pending.

# Kinera Edit v8.5 — Neural Intelligent Creator

- Latest-release-only full-screen localized highlight, system bar/cutout insets, reduced-motion support; minor releases can disable the highlight. Fresh installs skip it.
- OtoBlurPro 6.5: up to 248 OCR samples and 248 timed regions; new corner-only fallback when all straight boundaries are unavailable. Prior eight shaders and their fallback chain preserved. The new INT16 corner network is conditional on clean edge candidates. It is not generative video inpainting or full per-frame OCR.
- kAI 6.5: 72,000 new simulated corner samples, 9,000 validation and 9,000 test samples, drawn from stills and previously used decoded video examples. No new nominal weight.
- One-pass mask/mode collection, linear draft serialization, reused local OCR session, coarse shot marker retained when refinement lacks frames.
- Same signed single universal APK workflow; no nested release ZIP. Physical device and Android compilation still need verification.

# Kinera Edit v8.4 — Neural Deep Inpainting

- kAI 6.4 / OtoBlurPro 6.4: up to 93 windows (186 sampled frames and timed masks). Sampling is not frame-by-frame OCR. Fixed-region full-duration and selected 48s tracking modes stay available.
- DeepEdgeConfidence (2→8→1, 33 parameters, INT16) trains on 64,000 simulated blocked-axis samples. Uses 16 still images and 252 decoded frames from three previously used sample clips, separated by source within this run. 8,000 validation and 8,000 test. Active only when both opposite edge pairs are unusable, clean one-sided edges exist and gradient observations are available. If gradient context is unavailable, inverse-distance weighting; if no clean boundary exists, preserve prior source fallback. This is not a generative video inpainting model or a glyph segmentation model.
- New eighth shader with seven existing fallback variants. Six new templates (216 total) and six GPU decoration families (72 total); old template IDs and render bounds retained.
- Upgrade-only localized major feature spotlight, persisted after dialog actually shows; skip fresh install and defer until home is idle. Fade/slide animation honors disabled system animations. One major feature only; subsequent major releases must increment ReleaseHighlightPolicy.ID intentionally.
- Notifications: export outcome switch separate from foreground progress and reminders, channel descriptions, disabled-channel checks, expanded reminder text. Appearance settings remain settings-only.
- Editor: four equal-width tools, responsive adjustment scroll height, theme-consistent surfaces, guard touch/play/retry/watchdog during OCR ownership; add double-tap seek to raw source surface. No new proxy or independent codec.
- One universal signed APK, no nested ZIP; previous signer and dependency set retained. Host logic/syntax/GLES tests only; physical Android, complete Gradle build and actual export speed/quality unverified.

# Kinera Edit v8.3 — Neural Professional Vision

- kAI 6.3 / OtoBlurPro 6.3: 124 sampled OCR frames, up to 124 timed masks, previous 48s track and fixed full-duration mode retained.
- Fix template clamp at 161 (all 210 IDs now renderable), six new template designs.
- New INT16 experimental spatial blend model trained on 64k samples from stills and 3 decoded sample videos; not enabled due to validation/video regression.
- New advanced shader blocks current-mask boundary sampling when another mask overlaps; old shaders are fallback.
- Disable seek/play/export during OCR ownership, restore UI state on completion.
- Single universal APK, same signer, no nested release ZIP.
- Host tests do not substitute for Android build or device testing. No full generative inpainting.

# v8.2 — Neural Precision Studio

- One universal signed APK, no manually nested release ZIP. Actions APK artifact contains only APK; direct release also provides size report and checksums separately.
- kAI 6.2: MaskPrecisionConfidence trained on 64,000 synthetic coordinate pairs; conservative merge veto with previous models preserved.
- OtoBlurPro 6.2: retain both half-windows for incompatible text observations; up to 62 stored intervals, 3 concurrent masks unchanged, 31-window tracker unchanged. Guard merge drift with anchor and latest observation.
- Six Precision templates (204 total), existing 66 GPU animation families retained.
- Reuse one OCR recognizer throughout a dense scan; defer bitmap/client cleanup while pending recognition reads it. Reject oversized fixed restoration regions. Prevent seek during OCR analysis; old player and export engine retained. Host tests only; Android and real video quality not yet verified.

# v8.1 — Neural Vision Pro

- GitHub workflow now reads a separate root `kinera-source.zip` (500 KB workflow limit); same signer and one universal APK.
- kAI 6.1, two OCR observations per window (up to 62); conservative half-window masks if observations disagree; fixed full-duration mode remains.
- New VisionLaneConfidence trained on 40,000 synthetic pairs; old model retained.
- Reuse metadata retriever for dense scan; conservative handling of incomplete loud audio; lifecycle guard for gallery player.
- Host checks only; Android compile, device UI, real video quality, full generative inpainting, proxy and new codecs not verified.

# Kinera Edit v8.0 — Neural Ultimate Studio

- kAI 6.0, OtoBlurPro 6.0: full-duration OCR proposal mode, at most 31 evenly spaced windows, 180 s UI timeout, cooperative cancellation; no partial plans applied automatically. A fixed-region reconstruction option covers all timestamps without claiming every subtitle is detected. Existing 48 s tracking stays available. All proposals require confirmation; prior masks replaced only on confirmation.
- CaptionLaneConfidence (6→16→8→1, 257 parameters) trained on 60,000 synthetic coordinate pairs, validation/test 6,000 each. Geometry and neural gates prevent risky adjacent mask unions. Model only vetoes merges, not restoration quality. No new nominal statistical budget; prior nominal accounting unchanged. No real-video training added.
- Six new automatic templates, 198 total; existing 66 motion families reused. Old IDs retained. Mint/charcoal studio palette and AMOLED accents, theme selection available only from Settings. No change to output palette of existing templates.
- Gallery video uses existing in-app Media3 player with external playback option on content URI error. Reminder switch in Settings, app-level Android channel settings, bounded progress, expanded result text. Audio rhythm state resets on sample-rate changes.
- Single universal signed APK, all prior dependencies, model files and ABI support kept. Host checks only; Android compile/device tests, proxy, new codecs, actual full generative video inpainting and GPU performance remain unverified.

# Kinera Edit v7.9 — Neural Advanced Reconstruction

- kAI 5.9 texture-aware INT16 older-frame reconstruction; new shader with old history shader fallback. Preserves two-frame memory bound and avoids duplicate timestamp eviction.
- 48,000 new synthetic training rows, 6,000 validation, 6,000 test; exact nominal budget 798,617,728 quadrillion recorded as decimal strings; relative difficulty weights actually used. No claim of that many distinct samples.
- 12 new automatic templates (192 total), 6 GPU decoration families (66 total), stable old IDs.
- Settings: Studio dark, AMOLED Black, follow device night mode (Studio when device not in night mode). Theme does not alter video rendering.
- Media3 result player with decoder fallback and lifecycle cleanup; header sizing, OCR grouping, audio null guards, scene refinement safeguards.
- One universal signed APK, all existing ABIs and offline models retained. No proxy, new independent codec, dense flow or external generative model. Host tests only; Android assembly/device UI/performance remain unverified.

# Kinera Edit v7.8 — Neural Ultra Compact Studio

- Single universal signed APK, all ABIs and dependencies retained; compressed native libraries; size and SHA-256 inventory generated in CI.
- kAI 5.8: second prior frame fallback for <=720p sources, strict scene/time/mask guards, quantized int16 gate; original weights retained in training archive.
- 48,000 new synthetic rows with nonuniform weights, nominal budget 719,517 quadrillion (Python exact integer sums).
- Watchdog, OCR seed filter, editor control spacing and time label improvements.
- Six new Ultra templates (180 total), reuse existing 60 motion families. No new dense flow, proxy, or external generative model. Android build/device validation outstanding.

# Kinera Edit v7.7 — Neural Dynamic Intelligence

- kAI 5.7: diagonal motion reconstruction model, conservative fallback after cardinal search fails; 48,000 new synthetic rows, 898 quadrillion nominal weights normalized in selected-diagonal loss.
- Compact ARM64 signed APK plus universal; bundled AI and all existing features retained. APK size audit checks asset and ARM64 library hashes and reports actual bytes in CI. No R8 or resource pruning.
- Duplicate OCR boxes no longer inflate cluster score; null scene list disables temporal reuse.
- Full multi-frame history, proxy, dense optical flow, audio-reactive templates and Android runtime benchmarks remain future work.

# Kinera Edit v7.6 — Neural Generative Vision

- kAI 5.6 / OtoBlurPro 5.6: optional local five-position translation search, clean-ring and prior-mask validation, neural RGB blending; falls back to v7.5 temporal or spatial shader. Not dense optical flow or full generative inpainting.
- 48,000 new synthetic training rows, 6,000 validation and 6,000 test; 899 quadrillion nominal weights, normalized for selected-shift training, not distinct observations.
- Twelve new automatic layout/palette combinations (IDs 162–173); six new GPU decorative motion families react to shot boundaries. Existing template IDs and tools retained.
- Export preserves the semantic template (IDs 138+) selected at import rather than replacing it during the palette scan.
- OtoBlur: shared legacy-safe frame reader; strongest compact OCR line cluster rather than OCR enumeration order.
- Android compilation, physical player and GPU performance remain unverified; no proxy codec or external pretrained model added.

# Kinera Edit v7.5 — Neural Reconstruction Studio

- kAI 5.5 / OtoBlurPro 5.5: optional preceding-frame RGB reconstruction with neural blend; spatial fallback, mask and ring checks, reset on seek/cut; capped at 2.07M source pixels. Not optical flow or full temporal inpainting.
- 48,000 new weighted training rows, 6,000 validation and 6,000 test; nominal weight 898 quadrillion, normalized in actual training, not distinct data.
- Preview retries seek to sync frames; watchdog resets stable interval on backward jump. Existing tools, templates, weights and signing config retained.
- Android compile and real GPU/device tests remain pending.

# Kinera Edit v7.4 — Neural Hyper Intelligence

Offline Android editor. OtoBlur uses Gaussian blur; OtoBlurPro uses tracked, approximate spatial pixel reconstruction (not temporal generative inpainting). See `qa/V74_DEVICE_CHECKLIST.md`. Source codec availability depends on Android device.

# v7.3 Neural Cinematic Master
Current release: 7.3.0 / versionCode 64 / kAI 5.3. Six new landscape variants (162 total), six decorative GPU families (54 total), auxiliary neural tracking scheduling, bounded preview endpoint and export stall recovery. See qa/V73_DEVICE_CHECKLIST.md. Android compilation and device verification not executed.

# v7.2 Neural Expert Intelligence
Current release: 7.2.0 / versionCode 63 / kAI 5.2. 18 new template variants (156 total), automatic semantic/aspect selection, draft audio state and overlap guard, precise three-frame swept mask. Prior SupremeConfidence remains active for scheduling. New ExpertConfidence is experimental. See qa/V72_DEVICE_CHECKLIST.md.

# v7.1 Neural Supreme Intelligence
Current release: 7.1.0 / versionCode 62 / kAI 5.1. Existing bundled ML Kit image labeling and face detection remain. SupremeConfidence is consulted only for conservative tracking scheduling; it cannot accept or veto masks. See CHANGELOG and qa/V71_DEVICE_CHECKLIST.md.

# v7.0 Neural Autonomous Studio
Current release: 7.0.0 / versionCode 61 / kAI 5.0. Existing bundled ML Kit image labeling and face detection remain. See CHANGELOG and qa/V70_DEVICE_CHECKLIST.md.

# Kinera Edit v6.9.0 — Neural Advanced Director

kAI 4.9, versionCode 60, Android 12+. Bundled ML Kit face detection 16.1.7 adds a bounded face-presence fallback when the image labeler returns unknown. No identity recognition. The new center import frame uses closest-frame retrieval; saved draft template decisions remain unchanged. Bitmap and model client cleanup now follows asynchronous task completion. OtoBlurPro 4.7 checks the original appearance before accepting a tracked region or a partially verified midpoint. Playback watchdog resets stability after long gaps. Editor tool buttons have updated sizing, selected state, padding and palette; Blur strength saves per draft.

AppearanceConfidence 6/32/16/1 is a new experimental MLP, not active. It uses 24,000 synthetic patch feature rows derived from 12 still images and five existing MP4 fixtures, with 3,000 separate validation and test rows each. Nominal 99 trillion uniform sample weights are normalized to one during fitting; no new distinct data are implied. Earlier training files are preserved byte-for-byte, not replayed into the new model. The general object detector was not integrated because the standard ML Kit API requires an initial download. No Android SDK/device test or APK build was executed. See qa/V69_DEVICE_CHECKLIST.md for a direct v4.7 upgrade test.

Sources: https://developers.google.com/ml-kit/vision/face-detection/android and https://developers.google.com/ml-kit/vision/object-detection/android.

# v6.7 — Neural Professional Intelligence

- kAI 4.7; experimental AnchorRisk MLP (24,000 photo-derived training pairs, 3,000 validation, 3,000 test; disabled because held-out recall is poor). Nominal 90 trillion weights not used during training.
- OtoBlurPro 4.5: validate midpoint and each displacement before keeping verified partial masks.
- Neighbor-aware effect envelope; finite controls; defensive normalized geometry.
- Editor: smaller bounded scroll panel, timeline remains available during region editing, minimum width removed, blur reset persisted, shared palette.
- Existing sections retained. Android SDK/device unavailable; APK not built.

# Kinera Edit v6.6.0 — Neural Deep Vision Studio

Android 12+, versionCode 57, kAI 4.6. ExposureRisk 6/24/12/1 is a photo-derived exposure classifier, used only to veto positive brightness/contrast when observed RGB clipping is at least 12%. Prior cut models retained. OtoBlurPro 4.4 uses cached luma arrays and recent-motion sampling. Existing controls and signing preserved.

77 trillion nominal counts are historical accounting only; actual training is 16,000 new augmented still-image crops (unweighted), 2,000 validation, 2,000 test. Not real video data. No externally pretrained visual network integrated. All prior training archive bytes retained. Android APK/device/GPU tests not executed. Run `bash tests/run.sh`.

# Kinera Edit v6.5.0 — Neural Cognitive Studio

Android 12+, kAI 4.5, versionCode 56. Existing local Media3 pipeline and signing configuration preserved. The new cognitive model is experimental, not active. See QA and training metrics.

# Kinera Edit 6.4.0 — Neural Semantic Director
Android 12+, applicationId meteapps.kineraedit, versionCode 55. Existing four tools, signer, Flip default, automatic templates, preferences, localization and exit confirmation preserved.

kAI 4.4 adds defensive temporal timeline validation and a five-distance experimental MLP (5/32/16/1), not deployed because holdout F1 declined. OtoBlurPro 4.2 uses adaptive sampling intervals and rejects excessive translation jumps. Not semantic video understanding or guaranteed anonymization. No Android SDK/device test.

Training archive preserves all 172 v6.3 files, adds 18,000 synthetic ordered sequences with 70 trillion exact statistical weights and 6,000 separate validation/test sequences. Old data are preserved, not replayed into the temporal model since old features lack ordered differences.

Run bash tests/run.sh. GitHub build uses existing KINERA_SIGNING_BUNDLE; Android compilation and signing occur in CI.

### v6.8 update
The new bundled ML Kit labeling model is optional at inference time (unknown/failure/timeout falls back to color-based template selection); requires Gradle dependency resolution during build. No user video is uploaded by Kinera. The local clipping guard applies only to newly imported video auto grades. ChromaRisk is archived as experimental, not an active decision model. See `qa/V68_DEVICE_CHECKLIST.md` before production use.

Reference documentation: https://developers.google.com/ml-kit/vision/image-labeling/android (bundled labeling API); https://developer.android.com/media/media3/ui/playerview (player surfaces). The original 5 MP4 fixtures are in the earlier v5.4 and v6.0 test archives; the new NPZ contains derived feature rows, not raw real-video labels.

## v0.5.6 Stable — Neural Scene Intelligence
- Version code 92; kAI/OtoBlurPro 8.1; 50 append-only template IDs, six decorative GPU families.
- 36 bounded sequential marker probes; 96-second scene budget. No exhaustive semantic video analysis.
- Compact editor threshold, persistent blur slider cancel recovery, tighter history timestamp gate.
- Experimental 8/12/1 model trained on 568 decoded pairs from old procedural fixtures; not enabled. No additional independently filmed clips or Android device validation.
- CI separates compile/sign/audit from lint and publishes artifacts before lint; signed but unapproved builds remain diagnostics if lint fails. Permanent signer required.

### v0.5.7 Stable — Neural Editing Reliability
Build with the matching `kinera-source.zip` and small workflow TXT; copy TXT contents into `.github/workflows/kinera-build.yml`. Keep the permanent signing secret and one universal APK. Host test suite: `bash tests/run.sh`. Optional shader compile/link only: `python3 tests/gpu_reconstruction_smoke.py --compile-only`. Android SDK/device verification is still required. The experimental restoration-risk training weights are archived separately and not enabled at runtime. No platform eligibility guarantees.

## v0.5.8 Stable — Neural Cinematic Intelligence
- kAI/OtoBlurPro 8.3; invalid timeline and score rejection, restrained visual accents for closely spaced cuts, irregular two-frame history rejection. 50 permanent template IDs and six motion modes; prior IDs retained. Compact toolbar starts scrolling below 380dp; source FIT and more slider width.
- 552 training / 138 validation / 138 test windows from 12 existing procedural fixtures. Experimental 8/12/1 MLP not enabled; no new real-world videos.
- CI separates dependency/resource/Java preflight, unsigned assemble, zipalign and permanent signing. Diagnostic summary/first error artifact; exact previous GitHub failure unknown. No SDK or device test in host.

## v0.5.9 Stable — Neural Production Intelligence
- Build resolution: Android repository filtered to Android-related groups; Maven Central uses its official Apache endpoint (official repo1 endpoint chosen only after failed POM probes). Direct Android application plugin module resolution replaces plugin-portal lookup. No insecure mirrors, no TLS bypass or dependency downgrades. Network preflight and limited Gradle retries; diagnostics include full nested errors. Existing release certificate and universal APK strategy unchanged.
- Production84: 50 permanent template variants (1034 total), six new motion branches (120 total); conservative transition intensity and temporal cadence checks. Responsive scrollable toolbar, compact Blur selector.
- Experimental 8/16/1 patch history model archived separately; not activated. 3360 train, 840 validation, 840 test rows derived from 12 existing procedural clips; no new real-world videos. 400-iteration optimizer limit reached; holdout balanced accuracy 0.867434. No claim of semantic video understanding.
- Host tests and mock Maven tests are not Android builds. Real network/Android device validation pending.

## v0.6.0 Stable — Neural Professional Intelligence (96)
Critical Java compilation repair: TemplateArt's corner length no longer shadows loop variable `k`; MainActivity's editorTools is a LinearLayout (not a View). The targeted javac regression test compiles the full TemplateArt and extracted workspace method against narrow Android API stubs, executes all 1084 template branches and deliberately reproduces both original errors. It is not a substitute for Android SDK compilation. Added 50 permanent templates and six decorative shader motion IDs. Existing templates and neural sources remain unchanged. Experimental reconstruction model and new samples are in the separate training archive, not enabled. Build with the supplied small workflow TXT and exact source ZIP; first complete Gradle compiler diagnostic, signing certificate and universal APK audit remain mandatory.
