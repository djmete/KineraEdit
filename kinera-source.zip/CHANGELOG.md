# v8.1 — Neural Vision Pro

- GitHub workflow now reads a separate root `kinera-source.zip` (500 KB workflow limit); same signer and one universal APK.
- kAI 6.1, two OCR observations per window (up to 62); conservative half-window masks if observations disagree; fixed full-duration mode remains.
- New VisionLaneConfidence trained on 40,000 synthetic pairs; old model retained.
- Reuse metadata retriever for dense scan; conservative handling of incomplete loud audio; lifecycle guard for gallery player.
- Host checks only; Android compile, device UI, real video quality, full generative inpainting, proxy and new codecs not verified.

# Kinera Edit v8.0 — Neural Ultimate Studio

- kAI 6.0, OtoBlurPro 6.0: full-duration OCR proposal mode, at most 31 evenly spaced windows, 180 s UI timeout, cooperative cancellation; no partial plans applied automatically. A fixed-region reconstruction option covers all timestamps without claiming every subtitle is detected. Existing 48 s tracking stays available. All proposals require confirmation; prior masks replaced only on confirmation.
- CaptionLaneConfidence (6→16→8→1, 257 parameters) trained on 60,000 synthetic coordinate pairs, validation/test 6,000 each. Geometry and neural gates prevent risky adjacent mask unions. Model only vetoes merges, not restoration quality. No new nominal statistical budget; prior nominal accounting unchanged. No real-video training added.
- Six new automatic templates, 198 total; existing 66 motion families reused. Old IDs retained. Mint/charcoal studio palette and AMOLED accents, theme selection available only from Settings. No change to output palette of existing templates.
- Gallery video uses existing in-app Media3 player with external playback option on content URI error. Reminder switch in Settings, app-level Android channel settings, bounded progress, expanded result text. Audio rhythm state resets on sample-rate changes.
- Single universal signed APK, all prior dependencies, model files and ABI support kept. Host checks only; Android compile/device tests, proxy, new codecs, actual full generative video inpainting and GPU performance remain unverified.

# Kinera Edit v7.9 — Neural Advanced Reconstruction

- kAI 5.9 texture-aware INT16 older-frame reconstruction; new shader with old history shader fallback. Preserves two-frame memory bound and avoids duplicate timestamp eviction.
- 48,000 new synthetic training rows, 6,000 validation, 6,000 test; exact nominal budget 798,617,728 quadrillion recorded as decimal strings; relative difficulty weights actually used. No claim of that many distinct samples.
- 12 new automatic templates (192 total), 6 GPU decoration families (66 total), stable old IDs.
- Settings: Studio dark, AMOLED Black, follow device night mode (Studio when device not in night mode). Theme does not alter video rendering.
- Media3 result player with decoder fallback and lifecycle cleanup; header sizing, OCR grouping, audio null guards, scene refinement safeguards.
- One universal signed APK, all existing ABIs and offline models retained. No proxy, new independent codec, dense flow or external generative model. Host tests only; Android assembly/device UI/performance remain unverified.

# Kinera Edit v7.8 — Neural Ultra Compact Studio

- Single universal signed APK, all ABIs and dependencies retained; compressed native libraries; size and SHA-256 inventory generated in CI.
- kAI 5.8: second prior frame fallback for <=720p sources, strict scene/time/mask guards, quantized int16 gate; original weights retained in training archive.
- 48,000 new synthetic rows with nonuniform weights, nominal budget 719,517 quadrillion (Python exact integer sums).
- Watchdog, OCR seed filter, editor control spacing and time label improvements.
- Six new Ultra templates (180 total), reuse existing 60 motion families. No new dense flow, proxy, or external generative model. Android build/device validation outstanding.

# Kinera Edit v7.7 — Neural Dynamic Intelligence

- kAI 5.7: diagonal motion reconstruction model, conservative fallback after cardinal search fails; 48,000 new synthetic rows, 898 quadrillion nominal weights normalized in selected-diagonal loss.
- Compact ARM64 signed APK plus universal; bundled AI and all existing features retained. APK size audit checks asset and ARM64 library hashes and reports actual bytes in CI. No R8 or resource pruning.
- Duplicate OCR boxes no longer inflate cluster score; null scene list disables temporal reuse.
- Full multi-frame history, proxy, dense optical flow, audio-reactive templates and Android runtime benchmarks remain future work.

# Kinera Edit v7.6 — Neural Generative Vision

- kAI 5.6 / OtoBlurPro 5.6: optional local five-position translation search, clean-ring and prior-mask validation, neural RGB blending; falls back to v7.5 temporal or spatial shader. Not dense optical flow or full generative inpainting.
- 48,000 new synthetic training rows, 6,000 validation and 6,000 test; 899 quadrillion nominal weights, normalized for selected-shift training, not distinct observations.
- Twelve new automatic layout/palette combinations (IDs 162–173); six new GPU decorative motion families react to shot boundaries. Existing template IDs and tools retained.
- Export retains the semantic template chosen on import (IDs 138+).
- OtoBlur: shared legacy-safe frame reader and bounded compact OCR cluster selection.
- Android compilation, physical player and GPU performance remain unverified; no proxy codec or external pretrained model added.

# Kinera Edit v7.5 — Neural Reconstruction Studio

- kAI 5.5 / OtoBlurPro 5.5: optional preceding-frame RGB reconstruction with neural blend; spatial fallback, mask and ring checks, reset on seek/cut; capped at 2.07M source pixels. Not optical flow or full temporal inpainting.
- 48,000 new weighted training rows, 6,000 validation and 6,000 test; nominal weight 898 quadrillion, normalized in actual training, not distinct data.
- Preview retries seek to sync frames; watchdog resets stable interval on backward jump. Existing tools, templates, weights and signing config retained.
- Android compile and real GPU/device tests remain pending.

# v7.4 — Neural Hyper Intelligence
- Separate OtoBlurPro GPU spatial restoration mode for tracked masks; ordinary blur retained. 4→12→1 weighted RGB restoration model integrated into shader. No temporal propagation or deep video inpainting yet.
- Source MIME probe; lightweight 480-height preview for legacy/low-resolution/low-FPS media; decoder fallback retained. Small frame retrieval fallback.
- Precomputed Gaussian weights; preserve frame-rate limiter for variable-FPS inputs. Not benchmarked on device.
- Restoration modes survive undo/redo and draft reload; new localized Pro menu, two-line tool sizing.
- Old models, templates and sections retained; APK/device tests pending.

# v7.3.0 — Neural Cinematic Master
- CinematicConfidence 6/64/48/16/1; 36,000 new synthetic rows, 28,000 replay. Nominal 996 trillion weights are metadata only. Auxiliary scheduler only; existing mask validation retained.
- New stable styles 156–161 and GPU motion modes 48–53; prior IDs unchanged.
- Recovery of blocked preview retries, safe retry seek, guarded detachment, return to editor after failed export, export progress watchdog with 3–15 minute threshold.
- Short final tracking intervals and restrained effects on new landscape styles.

# v7.2.0 — Neural Expert Intelligence
- 18 additional templates in 3 layout families, stable IDs 138–155. Preserve all previous IDs and automatic-only template policy.
- ExpertConfidence 6/64/32/16/1, 28,000 synthetic new training rows + 32,000 replay. 98 trillion nominal metadata weights only. New model not deployed due to weaker holdout accuracy/recall.
- OtoBlurPro 5.2: exact three-rectangle union, single safety padding. Draft audio analysis status persisted; overlapping timed regions rejected on restore. Negative timeline times rejected.
- Existing player, Media3, ML Kit models, pages and signing identity retained. Android build/device testing pending.

# v7.1.0 — Neural Supreme Intelligence
- kAI 5.1: 6/64/32/1 patch network, confidence-driven additional tracking samples, verified partial short interval, OCR consensus expansion only on bilateral overlap, bounded float PCM, compact editor and palette refresh.
- 32,000 new synthetic training rows, 24,000 replay; 85 trillion nominal metadata weights only. No new external real-video dataset.
- Existing offline ML Kit models, signing, pages and four tools retained.

# v7.0.0 — Neural Autonomous Studio
- kAI 5.0: second semantic-frame fallback, OCR multi-frame consensus, completed PCM-window policy, bounded transition checks, conservative OtoBlurPro 5.0 interval retention and confidence-based interval shortening.
- New experimental ReacquireConfidence MLP (48/24 hidden units); 24,000 new synthetic patch training rows plus 24,000 replay rows. Nominal 78 trillion weights are metadata only. No real-video dataset added.
- Preserve all prior tools, model archives and signing identity. No Android build or device verification performed.

# Kinera Edit v6.9.0 — Neural Advanced Director

kAI 4.9, versionCode 60, Android 12+. Bundled ML Kit face detection 16.1.7 adds a bounded face-presence fallback when the image labeler returns unknown. No identity recognition. The new center import frame uses closest-frame retrieval; saved draft template decisions remain unchanged. Bitmap and model client cleanup now follows asynchronous task completion. OtoBlurPro 4.7 checks the original appearance before accepting a tracked region or a partially verified midpoint. Playback watchdog resets stability after long gaps. Editor tool buttons have updated sizing, selected state, padding and palette; Blur strength saves per draft.

AppearanceConfidence 6/32/16/1 is a new experimental MLP, not active. It uses 24,000 synthetic patch feature rows derived from 12 still images and five existing MP4 fixtures, with 3,000 separate validation and test rows each. Nominal 99 trillion uniform sample weights are normalized to one during fitting; no new distinct data are implied. Earlier training files are preserved byte-for-byte, not replayed into the new model. The general object detector was not integrated because the standard ML Kit API requires an initial download. No Android SDK/device test or APK build was executed. See qa/V69_DEVICE_CHECKLIST.md for a direct v4.7 upgrade test.

Sources: https://developers.google.com/ml-kit/vision/face-detection/android and https://developers.google.com/ml-kit/vision/object-detection/android.

# v6.7 — Neural Professional Intelligence

- kAI 4.7; experimental AnchorRisk MLP (24,000 photo-derived training pairs, 3,000 validation, 3,000 test; disabled because held-out recall is poor). Nominal 90 trillion weights not used during training.
- OtoBlurPro 4.5: validate midpoint and each displacement before keeping verified partial masks.
- Neighbor-aware effect envelope; finite controls; defensive normalized geometry.
- Editor: smaller bounded scroll panel, timeline remains available during region editing, minimum width removed, blur reset persisted, shared palette.
- Existing sections retained. Android SDK/device unavailable; APK not built.

# v6.6.0 — Neural Deep Vision Studio
- ExposureRisk MLP conservative AutoColor guard integrated in KAiDirector; existing scene and audio models unchanged.
- OtoBlurPro 4.4: cache per-pair luma, recent-motion adaptive interval, protect against dimension multiplication overflow.
- Updated shared palette and version checks; preserved sections and four tools.
- Added model parity and motion tests; Android runtime unverified.

# v6.5.0 — Neural Cognitive Studio

- kAI 4.5: validates refinement inputs and rejects nonfinite scene scores.
- Experimental CognitiveConfidence 5→48→24→1; training on 24,000 artificial sequences from decoded fixtures and still images, replay 18,000 prior rows. Not enabled in release.
- 890 trillion nominal multiplicities; not unique data, no natural-video corpus downloaded.
- Linked-channel audio compression preserves channel balance.
- OtoBlurPro 4.3: retain a verified first half if a longer interval fails, never fabricate the rest.
- Updated editor spacing, tool scrolling, shared palette and stale about text.
- Existing sections and four tools preserved.
- JVM tests only; Android build, GPU, and device tests pending.

# 6.4.0
- kAI 4.4: reject invalid/nonmonotonic scene timestamps, ignore neighbors across irregular gaps.
- Experimental temporal MLP with parity test, disabled on holdout regression.
- OtoBlurPro 4.2 adaptive intervals and jump rejection.
- Version 55 and regression tests.
- Existing editor and other UI retained, no full redesign.

# Kinera Edit 5.8.0 — Neural Fusion Studio
- Restore default horizontal mirror; preserve explicitly stored per-video orientation.
- Refresh and save crop reset, guard stale playback callbacks and invalid region input, clamp initial seek.
- kAI 3.8 controller input guard; 2B weighted synthetic scene examples and replay, candidate archived (not deployed).
- VersionCode 49; permanent signing identity retained. Host tests pass; Android device tests pending.

# Kinera Edit 5.7.0 — Playback & Navigation Studio
- Fix default mirror orientation (subtitle/text no longer reversed for new clips); preserve old drafts and user-defined flip settings.
- Unified AutoBlur mode selector: 3-frame consensus, 1-frame quick analysis, OtoBlurPro motion tracking. One mode setting instead of independent dialogs/hidden long-press modes.
- Register Android 13+ predictive back callback; back closes fullscreen then region editing, then navigates pages; export back returns to editor.
- Keep timeline seeking enabled during crop/blur edits. Blur handles and central rectangle drag work without consuming unrelated taps.
- Rebuild blur controls as a clearer card (time, strength, additional masks, sizing), soften and standardize button/page/section styling across the app.
- User-selectable Stable Player: raw source SurfaceView decoding when the live-effects TextureView path fails. It is expressly not a preview of effects; export is unchanged. Automatic fallback from v5.6 remains.
- Keep four editor tools, previous drafts/training assets, app ID and signing certificate policy. Upgrade to versionCode 48.
- All host Java regressions plus Java syntax parse and v5.7 wiring checks pass. Android compile, APK and device playback tests are still pending.

# Kinera Edit 5.6.0 — Neural Resilience Studio
- Separate TextureView composited and SurfaceView raw playback routes. New player instance on graph change, no video-effect initialization for raw mode. Bounded recovery; static source frame with explicit failure label if playback cannot open. Small-source failure skips the redundant GPU retry.
- Centered canvas layout explicitly uses measured dimensions; live blur edits reuse compatible effect state, with paused-frame seek refresh. Original edit and draft data are retained.
- Home last-project card removed; manual template library and batch export remain absent. Gallery now shows filename, resolution and size, with revised palette and shared card/button styling.
- OtoBlur defaults to multi-frame consensus; OtoBlurPro reuses matching scores; AutoSes measures the trailing short transient. Tracking remains bounded and requires review.
- kAI 3.6 controller; 900M weighted scene examples, 450M/class, candidate trained but not deployed because independent holdout precision/F1 regressed. Production scene weights unchanged. Archive retains all previous files. No real-video neural training claimed.
- APK/device tests pending; source checks and host Java tests only.

## 5.9.0 — Neural Evolution Studio
- Fixed-size composed render surface, exact single-pass preview layout, explicit GL viewport, alternative source texture.
- Automatic OtoBlur frame sampling and one suggested region; conflicting OCR proposals rejected; motion tracking on long press.
- 12 additional automatic template variants, shared palette refinements, preserved flip and four-tool workflow.
- kAI 3.9 candidate trained on weighted synthetic dataset plus prior replay. 107 previous archive entries preserved; no new real video corpus.
- Host logic and syntax checks pass; Android compilation and device test pending.

## 6.0.0 — Neural Generation Studio
- Adds conservative cut-timed visual grading, light/dark pulses and mask-safe zoom, plus low-level synthesized audio accents and PCM peak compression in export. Original clip order and length are unchanged; not a full nonlinear editor or music generator.
- Fixes export dropping the transition strength; respects existing transition toggle, gain and mute. Audio effects are export-only; preview plays the original mix with gain.
- OtoBlurPro 3.0: adaptive half/one-second sampling, forward/backward confidence and scene discontinuity rejection; up to approximately 28 seconds under the existing region and time caps. Translation only; user review required.
- kAI 4.0 cut MLP: 50B weighted categorical draws (25B per class), 50,000 new procedural examples, old replay. Not 50B unique real clips. New candidate passed synthetic release gate. Encoded procedural smoke test, no real-world validation.
- Shared palette and gallery refinements; no new visible tools, no manual templates, batch or last-project home card. Package and signing preserved.
- Android compilation and physical tests remain outstanding.

## v6.1.0 — Autonomous Director Studio
- Adaptive source grade and automatic audio measurement on new imports; per-draft grade saved.
- Bounded editor control scroll, responsive Blur action row, app-exit confirmation, localization improvements and shared palette.
- Two synthesized transition accent styles, null/short-scene guard and longer bounded OtoBlurPro tracking.
- 88B weighted synthetic count candidate with larger MLP; prior deployed weights retained after precision regression. Training archive append-only.
- No APK/device testing performed in this environment.

## v6.2.0 — Neural Cinematic Intelligence (versionCode 53)
- Central KAiDirector coordinates scene scanning/refinement, palette, grade, templates, source audio, OCR and tracking. OtoEdit policy is now routed through this layer; no extra visible editor tool.
- Source-energy rhythm detection and transient-aware generated transition accents on export PCM. Source duration and chronology unchanged; no claimed beat-synchronized scene rearrangement or semantic understanding.
- OtoBlurPro 4.0: up to 48 seconds subject to a 29-second decode budget, 31-interval cap and stricter peak-margin/round-trip checks at wider intervals. Experimental learned gate archived but disabled after holdout evaluation.
- Responsive editor labels and controls, narrower margins, smaller playback and seek rows, consistent shared palette and flexible gallery filter/channel controls. Existing screens and exit prompt preserved. No complete screen-by-screen device visual validation.
- Avoid releasing playback before export storage/codec validation succeeds. Cache unchanged transition GL uniforms. Fix release badging version check (6.1 workflow incorrectly expected 6.0.0).
- 2 trillion statistical weights (1T per class), 30,000 fresh procedural shot rows, 43,300 weighted labeled bins; 64/32 MLP candidate trained and archived, previous deployed scene network retained. Two tracking candidates trained using real-photo-derived synthetic motion; neither promoted after independent validation. Real video training remains unavailable.

## 6.3.0 — Neural Multimodal Director
- kAI 4.3: 7T exact weighted synthetic draws and replay, new scene candidate retained for research; production scene network unchanged pending real-video validation.
- Active AccentRisk neural PCM gate (4/24/12/1), with 20 ms rolling features, no per-sample inference allocation, attenuation only; old rhythm and peak guards preserved.
- Two experimental visual/audio-visual models trained on derived features from three demo clips with artificial join labels; not deployed.
- OtoBlurPro 4.1: midpoint and whole-interval agreement checks, larger swept mask where intermediate positions require coverage, bounded cancellation checks.
- Responsive playback controls, autosizing shared buttons, refined palette; four tools and existing navigation preserved.
- VersionCode 54; prior signing configuration and CI verification maintained.
- Host checks and cross-runtime model parity only; Android compilation/device/export tests pending.

## v6.8 — Neural Creative Intelligence (kAI 4.8)
- Bundled ML Kit image labeling 17.0.9: a single sampled frame of newly imported clips, limited background wait, high-confidence recognized labels only influence orientation-compatible automatic template choices. Saved projects retain their settings. Model binaries resolved at Android build time, not hosted here.
- Static shader simulation measures additional clipping from saturation; reduces only automatic saturation until clipping is below threshold. Existing ExposureRisk retained. ChromaRisk MLP is an experimental candidate (0 recall at 0.70 threshold), not used by production.
- OtoBlurPro 4.6 clamps the next verified timestamp to the clip/horizon endpoint, with existing bounded interval, confidence and mask-count checks. This does not guarantee full tracking or coverage.
- Small editor/shared card color and spacing polish; all existing tools, gallery, localization, exit confirmation and flip behavior retained.
- Training archive append only: 24,000 synthetic grading examples, 3,000 validation, 3,000 test. Source-separated photo/fixture datasets, 66 sampled decoded frames. 78 trillion nominal weights (39 trillion/class), unused for model training; not distinct data.
- Version code 59. JVM and source syntax tests passed; Android compile, bundled ML Kit inference, export and hardware tests pending.
